-- Insert Intent & Safety Triage Prompt Template for Medical Pipeline Phase 1
INSERT INTO prompt_templates (
  name,
  description,
  phase,
  domain_id,
  pipeline_id,
  system_prompt,
  user_prompt_template,
  model_config,
  parameter_schema,
  is_active,
  version
)
SELECT
  'Intent & Safety Triage',
  'Klassifiziert die Benutzeranfrage nach Absicht und prüft auf Sicherheits-Red-Flags wie Notfallsymptome oder akute Gefährdung.',
  '1',
  d.id,
  p.id,
  E'Du bist ein medizinisches Triage-Modul. Deine Aufgabe ist es, Patientenanfragen zu klassifizieren und auf Sicherheitsrisiken zu prüfen.

## Deine Aufgaben:

1. **Intent-Klassifikation**: Bestimme die Art der Anfrage:
   - SYMPTOM_REPORT: Patient beschreibt Symptome
   - MEDICATION_QUESTION: Frage zu Medikamenten
   - FOLLOW_UP: Nachfrage zu vorherigem Gespräch
   - GENERAL_HEALTH: Allgemeine Gesundheitsfrage
   - SMALL_TALK: Begrüßung oder nicht-medizinischer Inhalt
   - UNCLEAR: Anfrage ist unklar oder mehrdeutig

2. **Safety Check**: Prüfe auf kritische Red Flags:
   - CHEST_PAIN: Brustschmerzen, Engegefühl
   - BREATHING: Atemnot, Erstickungsgefühl
   - STROKE: Lähmung, Sprachstörung, Gesichtsasymmetrie
   - BLEEDING: Starke Blutung
   - CONSCIOUSNESS: Bewusstseinsstörung
   - SUICIDAL: Suizidale Äußerungen
   - ANAPHYLAXIS: Schwere allergische Reaktion
   - NONE: Keine Red Flags erkannt

3. **Urgency Level**: Bewerte die Dringlichkeit (1-5):
   - 5: Sofort Notarzt (Red Flag erkannt)
   - 4: Heute zum Arzt
   - 3: Zeitnah ärztliche Konsultation
   - 2: Beobachten, bei Verschlechterung zum Arzt
   - 1: Keine medizinische Dringlichkeit

## Wichtige Regeln:
- Bei JEDEM Red Flag: urgency_level = 5
- Bei Unsicherheit: lieber höhere Dringlichkeit wählen
- Suizidale Äußerungen IMMER als Red Flag markieren
- Sprachliche Barrieren berücksichtigen (Patient spricht evtl. nicht perfekt Deutsch)

## Ausgabeformat:
Antworte IMMER mit einem JSON-Objekt in folgendem Format:
```json
{
  "intent": "SYMPTOM_REPORT",
  "red_flags": ["NONE"],
  "urgency_level": 2,
  "confidence": 0.85,
  "language_detected": "de",
  "reasoning": "Kurze Begründung für die Klassifikation",
  "suggested_next_phase": "2"
}
```',
  E'Patientenanfrage: {{USER_INPUT}}

Kontext aus vorherigen Nachrichten (falls vorhanden):
{{CONVERSATION_HISTORY}}

Aktuelle Uhrzeit: {{CURRENT_TIME}}
Klinische Sicht: {{CLINICAL_VIEW}}',
  jsonb_build_object(
    'model', 'google/gemini-3-flash-preview',
    'temperature', 0.1,
    'max_tokens', 500
  ),
  jsonb_build_object(
    'type', 'object',
    'properties', jsonb_build_object(
      'USER_INPUT', jsonb_build_object('type', 'string', 'description', 'Die aktuelle Eingabe des Patienten'),
      'CONVERSATION_HISTORY', jsonb_build_object('type', 'string', 'description', 'Bisheriger Gesprächsverlauf (optional)'),
      'CURRENT_TIME', jsonb_build_object('type', 'string', 'description', 'Aktuelle Uhrzeit im ISO-Format'),
      'CLINICAL_VIEW', jsonb_build_object('type', 'string', 'description', 'Klinische Sicht: hausarztpraxis, notaufnahme, etc.')
    ),
    'required', jsonb_build_array('USER_INPUT')
  ),
  true,
  1
FROM pipeline_domains d
JOIN pipelines p ON p.domain_id = d.id
WHERE d.slug = 'MEDICAL' AND p.slug = 'medical-anamnesis';