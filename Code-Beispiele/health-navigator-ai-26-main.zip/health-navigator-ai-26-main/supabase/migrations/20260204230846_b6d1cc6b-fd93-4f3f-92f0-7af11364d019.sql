-- Add admin policies for managing HPO translations
CREATE POLICY "Admins can insert translations"
ON public.hpo_translations
FOR INSERT
TO authenticated
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update translations"
ON public.hpo_translations
FOR UPDATE
TO authenticated
USING (public.is_admin(auth.uid()))
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete translations"
ON public.hpo_translations
FOR DELETE
TO authenticated
USING (public.is_admin(auth.uid()));