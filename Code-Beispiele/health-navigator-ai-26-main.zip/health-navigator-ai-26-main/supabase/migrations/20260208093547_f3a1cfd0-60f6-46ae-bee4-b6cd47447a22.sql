-- Add version columns to sync_status for tracking ontology versions
ALTER TABLE public.sync_status 
ADD COLUMN IF NOT EXISTS remote_version text,
ADD COLUMN IF NOT EXISTS local_version text;