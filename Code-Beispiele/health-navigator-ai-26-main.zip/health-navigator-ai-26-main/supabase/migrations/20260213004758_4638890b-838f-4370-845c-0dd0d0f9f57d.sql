
-- ============================================
-- FHIR R4 Patient Data Management Tables
-- ============================================

-- 1. FHIR Patients
CREATE TABLE public.fhir_patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  active BOOLEAN DEFAULT true,
  given_name TEXT NOT NULL,
  family_name TEXT NOT NULL,
  birth_date DATE,
  gender TEXT CHECK (gender IN ('male','female','other','unknown')),
  identifier_mrn TEXT,
  telecom JSONB DEFAULT '[]'::jsonb,
  address JSONB DEFAULT '[]'::jsonb,
  fhir_resource JSONB NOT NULL,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_patients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own patients" ON public.fhir_patients FOR SELECT USING (auth.uid() = created_by);
CREATE POLICY "Users can create patients" ON public.fhir_patients FOR INSERT WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Users can update own patients" ON public.fhir_patients FOR UPDATE USING (auth.uid() = created_by);
CREATE POLICY "Users can delete own patients" ON public.fhir_patients FOR DELETE USING (auth.uid() = created_by);
CREATE POLICY "Admins can manage all patients" ON public.fhir_patients FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_fhir_patients_created_by ON public.fhir_patients(created_by);
CREATE INDEX idx_fhir_patients_name ON public.fhir_patients(family_name, given_name);

-- 2. FHIR Encounters (Aufenthalte)
CREATE TABLE public.fhir_encounters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  class TEXT,
  type_code TEXT,
  type_display TEXT,
  period_start TIMESTAMPTZ,
  period_end TIMESTAMPTZ,
  reason_codes JSONB DEFAULT '[]'::jsonb,
  diagnosis_codes JSONB DEFAULT '[]'::jsonb,
  service_provider TEXT,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_encounters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view encounters of own patients" ON public.fhir_encounters FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_encounters.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can create encounters for own patients" ON public.fhir_encounters FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_encounters.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can update encounters of own patients" ON public.fhir_encounters FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_encounters.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can delete encounters of own patients" ON public.fhir_encounters FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_encounters.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Admins can manage all encounters" ON public.fhir_encounters FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_fhir_encounters_patient ON public.fhir_encounters(patient_id);

-- 3. FHIR Conditions (Diagnosen)
CREATE TABLE public.fhir_conditions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.fhir_encounters(id) ON DELETE SET NULL,
  clinical_status TEXT,
  verification_status TEXT,
  category TEXT,
  code_system TEXT,
  code TEXT,
  code_display TEXT,
  severity TEXT,
  onset_datetime TIMESTAMPTZ,
  abatement_datetime TIMESTAMPTZ,
  hpo_codes TEXT[] DEFAULT '{}',
  snomed_codes TEXT[] DEFAULT '{}',
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_conditions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view conditions of own patients" ON public.fhir_conditions FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_conditions.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can create conditions for own patients" ON public.fhir_conditions FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_conditions.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can update conditions of own patients" ON public.fhir_conditions FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_conditions.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can delete conditions of own patients" ON public.fhir_conditions FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_conditions.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Admins can manage all conditions" ON public.fhir_conditions FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_fhir_conditions_patient ON public.fhir_conditions(patient_id);

-- 4. FHIR Observations (Laborwerte & Vitalzeichen)
CREATE TABLE public.fhir_observations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.fhir_encounters(id) ON DELETE SET NULL,
  status TEXT NOT NULL,
  category TEXT,
  loinc_code TEXT,
  code_display TEXT,
  value_quantity NUMERIC,
  value_unit TEXT,
  value_string TEXT,
  reference_range_low NUMERIC,
  reference_range_high NUMERIC,
  interpretation TEXT,
  effective_datetime TIMESTAMPTZ,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_observations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view observations of own patients" ON public.fhir_observations FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_observations.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can create observations for own patients" ON public.fhir_observations FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_observations.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can update observations of own patients" ON public.fhir_observations FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_observations.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can delete observations of own patients" ON public.fhir_observations FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_observations.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Admins can manage all observations" ON public.fhir_observations FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_fhir_observations_patient ON public.fhir_observations(patient_id);
CREATE INDEX idx_fhir_observations_loinc ON public.fhir_observations(loinc_code);

-- 5. FHIR Medication Requests
CREATE TABLE public.fhir_medication_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.fhir_encounters(id) ON DELETE SET NULL,
  status TEXT NOT NULL,
  intent TEXT DEFAULT 'order',
  medication_code TEXT,
  medication_display TEXT,
  dosage_text TEXT,
  dosage_route TEXT,
  authored_on TIMESTAMPTZ,
  requester_display TEXT,
  reason_codes JSONB DEFAULT '[]'::jsonb,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_medication_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view meds of own patients" ON public.fhir_medication_requests FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_medication_requests.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can create meds for own patients" ON public.fhir_medication_requests FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_medication_requests.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can update meds of own patients" ON public.fhir_medication_requests FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_medication_requests.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can delete meds of own patients" ON public.fhir_medication_requests FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_medication_requests.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Admins can manage all meds" ON public.fhir_medication_requests FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_fhir_meds_patient ON public.fhir_medication_requests(patient_id);

-- 6. FHIR Document References
CREATE TABLE public.fhir_document_references (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.fhir_encounters(id) ON DELETE SET NULL,
  status TEXT NOT NULL,
  type_code TEXT,
  type_display TEXT,
  description TEXT,
  content_type TEXT,
  storage_path TEXT,
  date TIMESTAMPTZ,
  author_display TEXT,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_document_references ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view docs of own patients" ON public.fhir_document_references FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_document_references.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can create docs for own patients" ON public.fhir_document_references FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_document_references.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can update docs of own patients" ON public.fhir_document_references FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_document_references.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can delete docs of own patients" ON public.fhir_document_references FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_document_references.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Admins can manage all docs" ON public.fhir_document_references FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_fhir_docs_patient ON public.fhir_document_references(patient_id);

-- 7. FHIR Allergies
CREATE TABLE public.fhir_allergies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  clinical_status TEXT,
  verification_status TEXT,
  type TEXT,
  category TEXT,
  criticality TEXT,
  code TEXT,
  code_display TEXT,
  onset_datetime TIMESTAMPTZ,
  reactions JSONB DEFAULT '[]'::jsonb,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_allergies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view allergies of own patients" ON public.fhir_allergies FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_allergies.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can create allergies for own patients" ON public.fhir_allergies FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_allergies.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can update allergies of own patients" ON public.fhir_allergies FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_allergies.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can delete allergies of own patients" ON public.fhir_allergies FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.fhir_patients p WHERE p.id = fhir_allergies.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Admins can manage all allergies" ON public.fhir_allergies FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_fhir_allergies_patient ON public.fhir_allergies(patient_id);

-- 8. Patient chat messages
CREATE TABLE public.patient_chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
  content TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.patient_chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own chat messages" ON public.patient_chat_messages FOR SELECT
  USING (auth.uid() = user_id);
CREATE POLICY "Users can create chat messages" ON public.patient_chat_messages FOR INSERT
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own chat messages" ON public.patient_chat_messages FOR DELETE
  USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage all chat messages" ON public.patient_chat_messages FOR ALL USING (public.is_admin(auth.uid()));

CREATE INDEX idx_patient_chat_patient ON public.patient_chat_messages(patient_id);
CREATE INDEX idx_patient_chat_user ON public.patient_chat_messages(user_id);

-- Update triggers
CREATE TRIGGER update_fhir_patients_updated_at BEFORE UPDATE ON public.fhir_patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fhir_encounters_updated_at BEFORE UPDATE ON public.fhir_encounters FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fhir_conditions_updated_at BEFORE UPDATE ON public.fhir_conditions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fhir_observations_updated_at BEFORE UPDATE ON public.fhir_observations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fhir_medication_requests_updated_at BEFORE UPDATE ON public.fhir_medication_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fhir_document_references_updated_at BEFORE UPDATE ON public.fhir_document_references FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fhir_allergies_updated_at BEFORE UPDATE ON public.fhir_allergies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for patient documents
INSERT INTO storage.buckets (id, name, public) VALUES ('patient-documents', 'patient-documents', false);

CREATE POLICY "Users can view own patient docs" ON storage.objects FOR SELECT
  USING (bucket_id = 'patient-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can upload own patient docs" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'patient-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can delete own patient docs" ON storage.objects FOR DELETE
  USING (bucket_id = 'patient-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
