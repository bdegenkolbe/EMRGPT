-- Add unique constraint for pipelines.slug if missing
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'pipelines_slug_key'
  ) THEN
    ALTER TABLE public.pipelines ADD CONSTRAINT pipelines_slug_key UNIQUE (slug);
  END IF;
END $$;

-- Insert KNOWLEDGE domain for knowledge search classification
INSERT INTO public.pipeline_domains (name, slug, description, classification_keywords, is_active)
VALUES (
  'Wissenssuche',
  'KNOWLEDGE',
  'Klassifizierung von Wissenssuchanfragen: Literatursuche, Wissensbasis, Inventar, Erklärung oder kombinierte Suche',
  ARRAY['wissen', 'suche', 'dokument', 'leitlinie', 'artikel', 'pubmed', 'literatur', 'erkläre'],
  true
);