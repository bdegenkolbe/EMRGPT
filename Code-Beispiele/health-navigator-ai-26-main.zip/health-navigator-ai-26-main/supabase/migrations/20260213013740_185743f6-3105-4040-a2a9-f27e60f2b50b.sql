
ALTER TABLE public.profiles
ADD COLUMN sidebar_tab_order text[] DEFAULT ARRAY['guidelines', 'literature', 'trials', 'documents'];
