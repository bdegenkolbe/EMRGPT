-- Erweitere ontology_mappings um Validierungsstatus und Konflikt-Tracking
ALTER TABLE public.ontology_mappings 
ADD COLUMN IF NOT EXISTS validation_status text NOT NULL DEFAULT 'pending' 
  CHECK (validation_status IN ('pending', 'valid', 'conflict', 'exception'));

ALTER TABLE public.ontology_mappings 
ADD COLUMN IF NOT EXISTS conflict_details jsonb DEFAULT NULL;

ALTER TABLE public.ontology_mappings 
ADD COLUMN IF NOT EXISTS resolved_by uuid REFERENCES auth.users(id) DEFAULT NULL;

ALTER TABLE public.ontology_mappings 
ADD COLUMN IF NOT EXISTS resolved_at timestamptz DEFAULT NULL;

ALTER TABLE public.ontology_mappings 
ADD COLUMN IF NOT EXISTS extraction_source text DEFAULT NULL;

-- Index für schnelle Konflikt-Abfragen
CREATE INDEX IF NOT EXISTS idx_ontology_mappings_validation_status 
ON public.ontology_mappings(validation_status) WHERE validation_status != 'valid';

-- Index für Source-Code Lookups (für Graph-Traversierung)
CREATE INDEX IF NOT EXISTS idx_ontology_mappings_source 
ON public.ontology_mappings(source_code, source_system);

CREATE INDEX IF NOT EXISTS idx_ontology_mappings_target 
ON public.ontology_mappings(target_code, target_system);

-- Composite Index für bidirektionale Abfragen
CREATE INDEX IF NOT EXISTS idx_ontology_mappings_bidirectional 
ON public.ontology_mappings(source_system, target_system, validation_status);