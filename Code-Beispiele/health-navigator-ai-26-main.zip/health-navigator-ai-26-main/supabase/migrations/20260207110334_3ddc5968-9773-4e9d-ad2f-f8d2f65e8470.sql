-- Add sidebar_collapsed column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN sidebar_collapsed boolean NOT NULL DEFAULT false;