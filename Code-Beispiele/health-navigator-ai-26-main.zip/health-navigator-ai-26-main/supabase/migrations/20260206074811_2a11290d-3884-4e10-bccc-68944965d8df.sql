-- Create table for validated ontology mappings
CREATE TABLE public.ontology_mappings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  source_code text NOT NULL,
  source_label text NOT NULL,
  source_system text NOT NULL CHECK (source_system IN ('HPO', 'SNOMED', 'ICD10GM')),
  target_code text NOT NULL,
  target_label text NOT NULL,
  target_system text NOT NULL CHECK (target_system IN ('HPO', 'SNOMED', 'ICD10GM')),
  confidence numeric NOT NULL DEFAULT 0.9,
  mapping_type text NOT NULL CHECK (mapping_type IN ('exact', 'broad', 'narrow', 'related', 'validated')),
  validated_by uuid REFERENCES auth.users(id),
  validated_at timestamp with time zone DEFAULT now(),
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(source_code, source_system, target_code, target_system)
);

-- Enable RLS
ALTER TABLE public.ontology_mappings ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Ontology mappings are viewable by authenticated users"
ON public.ontology_mappings FOR SELECT
USING (true);

CREATE POLICY "Admins can manage ontology mappings"
ON public.ontology_mappings FOR ALL
USING (is_admin(auth.uid()));

CREATE POLICY "Authenticated users can create mappings"
ON public.ontology_mappings FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

-- Index for lookups
CREATE INDEX idx_ontology_mappings_source ON public.ontology_mappings(source_code, source_system);
CREATE INDEX idx_ontology_mappings_target ON public.ontology_mappings(target_code, target_system);

-- Updated_at trigger
CREATE TRIGGER update_ontology_mappings_updated_at
BEFORE UPDATE ON public.ontology_mappings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();