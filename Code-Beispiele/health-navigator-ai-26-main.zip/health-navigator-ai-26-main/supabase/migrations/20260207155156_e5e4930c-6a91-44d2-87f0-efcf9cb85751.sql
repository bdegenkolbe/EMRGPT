-- Add ontology_codes JSONB column to conversation_messages
-- This stores HPO, SNOMED, ICD-10 and other terminology mappings per message

ALTER TABLE public.conversation_messages 
ADD COLUMN IF NOT EXISTS ontology_codes jsonb DEFAULT '{}'::jsonb;

-- Add index for efficient querying of messages with specific codes
CREATE INDEX IF NOT EXISTS idx_conversation_messages_ontology_codes 
ON public.conversation_messages USING GIN (ontology_codes);

-- Add comment explaining the structure
COMMENT ON COLUMN public.conversation_messages.ontology_codes IS 
'JSONB storing recognized ontology codes per message. Structure: {
  "hpo": [{"code": "HP:0002027", "label": "Bauchschmerzen", "confidence": 0.9}],
  "snomed": [{"code": "21522001", "label": "Abdominal pain", "confidence": 0.85}],
  "icd10": [{"code": "R10.4", "label": "Sonstige Bauchschmerzen", "confidence": 0.8}],
  "rxnorm": [{"code": "...", "label": "...", "confidence": ...}],
  "mesh": [{"code": "...", "label": "...", "confidence": ...}]
}';