-- Add English definition, English explanation, and synonyms to hpo_translations
ALTER TABLE public.hpo_translations 
ADD COLUMN IF NOT EXISTS definition_en text,
ADD COLUMN IF NOT EXISTS explanation_en text,
ADD COLUMN IF NOT EXISTS synonyms text[] DEFAULT '{}';

-- Add comment for documentation
COMMENT ON COLUMN public.hpo_translations.definition_en IS 'English definition from HPO ontology';
COMMENT ON COLUMN public.hpo_translations.explanation_en IS 'AI-generated English explanation';
COMMENT ON COLUMN public.hpo_translations.synonyms IS 'Array of synonyms from HPO ontology';