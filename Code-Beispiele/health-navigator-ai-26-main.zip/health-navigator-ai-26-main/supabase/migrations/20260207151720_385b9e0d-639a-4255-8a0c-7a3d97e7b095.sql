-- ICD-11 Codes table (following icd10gm_codes pattern)
CREATE TABLE public.icd11_codes (
  code TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  title_short TEXT,
  definition TEXT,
  chapter TEXT,
  block TEXT,
  category TEXT,
  parent_code TEXT,
  is_terminal BOOLEAN DEFAULT false,
  labels JSONB DEFAULT '{}',
  foundation_uri TEXT,
  linearization_uri TEXT,
  class_kind TEXT,
  inclusions TEXT[],
  exclusions TEXT[],
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- ICD-11 Analyses table (following icd10gm_analyses pattern)
CREATE TABLE public.icd11_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  icd_code TEXT NOT NULL UNIQUE REFERENCES public.icd11_codes(code) ON DELETE CASCADE,
  content JSONB DEFAULT '{}',
  hpo_mappings JSONB,
  snomed_mappings JSONB,
  symptom_mappings JSONB,
  generated_at TIMESTAMP WITH TIME ZONE,
  generated_by TEXT,
  source_language TEXT DEFAULT 'de',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- ICD-11 Translations table (following icd10gm_translations pattern)
CREATE TABLE public.icd11_translations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  icd_code TEXT NOT NULL UNIQUE REFERENCES public.icd11_codes(code) ON DELETE CASCADE,
  title TEXT NOT NULL,
  title_short TEXT,
  labels JSONB DEFAULT '{}',
  synonyms TEXT[],
  explanation_de TEXT,
  explanation_en TEXT,
  explanations JSONB DEFAULT '{}',
  source TEXT DEFAULT 'official',
  confidence NUMERIC(3,2) DEFAULT 1.0,
  verified_at TIMESTAMP WITH TIME ZONE,
  verified_by UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_icd11_codes_parent ON public.icd11_codes(parent_code);
CREATE INDEX idx_icd11_codes_chapter ON public.icd11_codes(chapter);
CREATE INDEX idx_icd11_codes_block ON public.icd11_codes(block);
CREATE INDEX idx_icd11_codes_labels ON public.icd11_codes USING GIN(labels);
CREATE INDEX idx_icd11_codes_title_search ON public.icd11_codes USING GIN(to_tsvector('german', title));

-- Enable RLS
ALTER TABLE public.icd11_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.icd11_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.icd11_translations ENABLE ROW LEVEL SECURITY;

-- Public read access (reference data)
CREATE POLICY "ICD-11 codes are publicly readable"
  ON public.icd11_codes FOR SELECT USING (true);

CREATE POLICY "ICD-11 analyses are publicly readable"
  ON public.icd11_analyses FOR SELECT USING (true);

CREATE POLICY "ICD-11 translations are publicly readable"
  ON public.icd11_translations FOR SELECT USING (true);

-- Service role full access for Edge Functions
CREATE POLICY "Service role can manage ICD-11 codes"
  ON public.icd11_codes FOR ALL
  USING ((auth.jwt() ->> 'role') = 'service_role')
  WITH CHECK ((auth.jwt() ->> 'role') = 'service_role');

CREATE POLICY "Service role can manage ICD-11 analyses"
  ON public.icd11_analyses FOR ALL
  USING ((auth.jwt() ->> 'role') = 'service_role')
  WITH CHECK ((auth.jwt() ->> 'role') = 'service_role');

CREATE POLICY "Service role can manage ICD-11 translations"
  ON public.icd11_translations FOR ALL
  USING ((auth.jwt() ->> 'role') = 'service_role')
  WITH CHECK ((auth.jwt() ->> 'role') = 'service_role');

-- Trigger for updated_at
CREATE TRIGGER update_icd11_analyses_updated_at
  BEFORE UPDATE ON public.icd11_analyses
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_icd11_translations_updated_at
  BEFORE UPDATE ON public.icd11_translations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();