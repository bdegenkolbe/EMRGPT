-- Constraint erweitern um icd10_who
ALTER TABLE public.scheduled_sync_jobs 
DROP CONSTRAINT valid_source_name;

ALTER TABLE public.scheduled_sync_jobs 
ADD CONSTRAINT valid_source_name 
CHECK (source_name = ANY (ARRAY['hpo'::text, 'snomed'::text, 'icd11'::text, 'orphanet'::text, 'icd10_who'::text]));

-- Jetzt icd10_who einfügen
INSERT INTO public.scheduled_sync_jobs (source_name, cron_expression, is_enabled)
VALUES ('icd10_who', '0 5 * * 0', false)
ON CONFLICT (source_name) DO NOTHING;