-- Anamnese-Sessions
CREATE TABLE public.anamnesis_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  patient_identifier TEXT,
  clinical_view public.clinical_view NOT NULL,
  language TEXT NOT NULL DEFAULT 'de',
  status TEXT NOT NULL DEFAULT 'in_progress',
  started_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Beobachtungen/Symptome (HPO-normalisiert)
CREATE TABLE public.observations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.anamnesis_sessions(id) ON DELETE CASCADE NOT NULL,
  raw_input TEXT NOT NULL,
  normalized_value TEXT,
  language TEXT NOT NULL,
  hpo_codes TEXT[],
  rxnorm_codes TEXT[],
  mesh_terms TEXT[],
  negated BOOLEAN DEFAULT false,
  onset TEXT,
  duration TEXT,
  severity TEXT,
  confidence NUMERIC(3,2),
  provenance TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Evidenz-Anfragen (Audit-Log)
CREATE TABLE public.evidence_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.anamnesis_sessions(id) ON DELETE CASCADE NOT NULL,
  query_context JSONB NOT NULL,
  query_strings JSONB NOT NULL,
  sources TEXT[] NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Evidenz-Ergebnisse
CREATE TABLE public.evidence_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID REFERENCES public.evidence_requests(id) ON DELETE CASCADE NOT NULL,
  source TEXT NOT NULL,
  external_id TEXT NOT NULL,
  title TEXT NOT NULL,
  year INTEGER,
  venue TEXT,
  url TEXT,
  snippet TEXT,
  study_type TEXT,
  relevance_score NUMERIC(3,2),
  provenance JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS for all tables
ALTER TABLE public.anamnesis_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.evidence_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.evidence_items ENABLE ROW LEVEL SECURITY;

-- anamnesis_sessions: Users can manage their own sessions
CREATE POLICY "Users can view own sessions"
  ON public.anamnesis_sessions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own sessions"
  ON public.anamnesis_sessions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sessions"
  ON public.anamnesis_sessions FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all sessions"
  ON public.anamnesis_sessions FOR SELECT
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage all sessions"
  ON public.anamnesis_sessions FOR ALL
  USING (public.is_admin(auth.uid()));

-- observations: Access through session ownership
CREATE POLICY "Users can view observations of own sessions"
  ON public.observations FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.anamnesis_sessions s
      WHERE s.id = session_id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create observations for own sessions"
  ON public.observations FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.anamnesis_sessions s
      WHERE s.id = session_id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all observations"
  ON public.observations FOR ALL
  USING (public.is_admin(auth.uid()));

-- evidence_requests: Access through session ownership
CREATE POLICY "Users can view evidence requests of own sessions"
  ON public.evidence_requests FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.anamnesis_sessions s
      WHERE s.id = session_id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create evidence requests for own sessions"
  ON public.evidence_requests FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.anamnesis_sessions s
      WHERE s.id = session_id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all evidence requests"
  ON public.evidence_requests FOR ALL
  USING (public.is_admin(auth.uid()));

-- evidence_items: Access through request->session ownership
CREATE POLICY "Users can view evidence items of own sessions"
  ON public.evidence_items FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.evidence_requests r
      JOIN public.anamnesis_sessions s ON s.id = r.session_id
      WHERE r.id = request_id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create evidence items for own sessions"
  ON public.evidence_items FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.evidence_requests r
      JOIN public.anamnesis_sessions s ON s.id = r.session_id
      WHERE r.id = request_id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all evidence items"
  ON public.evidence_items FOR ALL
  USING (public.is_admin(auth.uid()));