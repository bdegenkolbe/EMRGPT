-- Create sync_status table for tracking paginated sync progress
CREATE TABLE IF NOT EXISTS public.sync_status (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_name TEXT NOT NULL UNIQUE,
  last_cursor TEXT,
  total_synced INTEGER DEFAULT 0,
  total_available INTEGER,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'error', 'paused')),
  error_message TEXT,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.sync_status ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read sync status
CREATE POLICY "Authenticated users can view sync status"
ON public.sync_status
FOR SELECT
TO authenticated
USING (true);

-- Allow authenticated users to manage sync status (admin function will handle actual updates)
CREATE POLICY "Authenticated users can manage sync status"
ON public.sync_status
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- Create index for faster lookups
CREATE INDEX idx_sync_status_source ON public.sync_status(source_name);

-- Add trigger for updated_at
CREATE TRIGGER update_sync_status_updated_at
BEFORE UPDATE ON public.sync_status
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();