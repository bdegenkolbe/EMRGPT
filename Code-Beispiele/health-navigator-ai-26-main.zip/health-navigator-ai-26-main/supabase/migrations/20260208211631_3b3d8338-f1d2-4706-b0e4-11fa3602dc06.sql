-- Add translated_title column to knowledge_sources
ALTER TABLE public.knowledge_sources 
ADD COLUMN IF NOT EXISTS translated_title TEXT;