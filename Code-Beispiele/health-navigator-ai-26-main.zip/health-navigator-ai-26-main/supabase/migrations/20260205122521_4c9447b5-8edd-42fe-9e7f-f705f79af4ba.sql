-- ================================================================
-- Domain-aware Prompt Orchestration Pipeline - Schema
-- ================================================================

-- 1. Pipeline Domains (MEDICAL, HR_LAW, etc.)
CREATE TABLE public.pipeline_domains (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  classification_keywords TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. Pipelines (domain-specific processing chains)
CREATE TABLE public.pipelines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id UUID NOT NULL REFERENCES public.pipeline_domains(id) ON DELETE CASCADE,
  slug TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  phase_order TEXT[] NOT NULL DEFAULT '{}',
  fallback_pipeline_id UUID REFERENCES public.pipelines(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(domain_id, slug)
);

-- 3. Prompt Templates (versioned, per phase)
CREATE TABLE public.prompt_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id UUID REFERENCES public.pipelines(id) ON DELETE CASCADE,
  domain_id UUID REFERENCES public.pipeline_domains(id) ON DELETE CASCADE,
  phase TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  system_prompt TEXT NOT NULL,
  user_prompt_template TEXT,
  parameter_schema JSONB DEFAULT '{}',
  model_config JSONB DEFAULT '{"model": "gpt-4o-mini", "temperature": 0.3, "max_tokens": 2000}',
  version INTEGER NOT NULL DEFAULT 1,
  is_active BOOLEAN NOT NULL DEFAULT true,
  parent_template_id UUID REFERENCES public.prompt_templates(id) ON DELETE SET NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Pipeline Executions (audit trail for complete runs)
CREATE TABLE public.pipeline_executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES public.anamnesis_sessions(id) ON DELETE SET NULL,
  pipeline_id UUID REFERENCES public.pipelines(id) ON DELETE SET NULL,
  domain TEXT NOT NULL DEFAULT 'MEDICAL',
  domain_classification JSONB,
  status TEXT NOT NULL DEFAULT 'running',
  input_data JSONB NOT NULL,
  output_data JSONB,
  total_tokens INTEGER DEFAULT 0,
  total_latency_ms INTEGER DEFAULT 0,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);

-- 5. Pipeline Phase Logs (detailed per-phase audit)
CREATE TABLE public.pipeline_phase_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  execution_id UUID NOT NULL REFERENCES public.pipeline_executions(id) ON DELETE CASCADE,
  phase TEXT NOT NULL,
  template_id UUID REFERENCES public.prompt_templates(id) ON DELETE SET NULL,
  input_data JSONB NOT NULL,
  output_data JSONB,
  prompt_tokens INTEGER DEFAULT 0,
  completion_tokens INTEGER DEFAULT 0,
  latency_ms INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);

-- Indexes for performance
CREATE INDEX idx_pipelines_domain_id ON public.pipelines(domain_id);
CREATE INDEX idx_prompt_templates_pipeline_id ON public.prompt_templates(pipeline_id);
CREATE INDEX idx_prompt_templates_phase ON public.prompt_templates(phase);
CREATE INDEX idx_pipeline_executions_session_id ON public.pipeline_executions(session_id);
CREATE INDEX idx_pipeline_executions_pipeline_id ON public.pipeline_executions(pipeline_id);
CREATE INDEX idx_pipeline_phase_logs_execution_id ON public.pipeline_phase_logs(execution_id);

-- Updated_at triggers
CREATE TRIGGER update_pipeline_domains_updated_at
  BEFORE UPDATE ON public.pipeline_domains
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_pipelines_updated_at
  BEFORE UPDATE ON public.pipelines
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_prompt_templates_updated_at
  BEFORE UPDATE ON public.prompt_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- RLS Policies
ALTER TABLE public.pipeline_domains ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pipelines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prompt_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pipeline_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pipeline_phase_logs ENABLE ROW LEVEL SECURITY;

-- pipeline_domains: Admins can manage, authenticated can read
CREATE POLICY "Admins can manage pipeline domains"
  ON public.pipeline_domains FOR ALL
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Authenticated can read active domains"
  ON public.pipeline_domains FOR SELECT
  USING (is_active = true);

-- pipelines: Admins can manage, authenticated can read
CREATE POLICY "Admins can manage pipelines"
  ON public.pipelines FOR ALL
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Authenticated can read active pipelines"
  ON public.pipelines FOR SELECT
  USING (is_active = true);

-- prompt_templates: Admins can manage, authenticated can read active
CREATE POLICY "Admins can manage prompt templates"
  ON public.prompt_templates FOR ALL
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Authenticated can read active templates"
  ON public.prompt_templates FOR SELECT
  USING (is_active = true);

-- pipeline_executions: Admins can manage all, users can view own
CREATE POLICY "Admins can manage all executions"
  ON public.pipeline_executions FOR ALL
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view own session executions"
  ON public.pipeline_executions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.anamnesis_sessions s
      WHERE s.id = pipeline_executions.session_id
      AND s.user_id = auth.uid()
    )
  );

-- pipeline_phase_logs: Admins can manage all, users can view own
CREATE POLICY "Admins can manage all phase logs"
  ON public.pipeline_phase_logs FOR ALL
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view own session phase logs"
  ON public.pipeline_phase_logs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.pipeline_executions pe
      JOIN public.anamnesis_sessions s ON s.id = pe.session_id
      WHERE pe.id = pipeline_phase_logs.execution_id
      AND s.user_id = auth.uid()
    )
  );

-- ================================================================
-- Seed Data: Domains and Medical Pipeline
-- ================================================================

-- Insert Domains (with explicit TEXT[] cast for empty arrays)
INSERT INTO public.pipeline_domains (slug, name, description, classification_keywords) VALUES
('MEDICAL', 'Medizin', 'Medizinische Anfragen, Symptome, Gesundheit', ARRAY['symptom', 'schmerz', 'krankheit', 'arzt', 'medikament', 'diagnose', 'behandlung', 'therapie']::TEXT[]),
('HR_LAW', 'HR & Recht', 'Arbeitsrecht, Tarifverträge, Personal', ARRAY['arbeitsvertrag', 'kündigung', 'tarif', 'urlaub', 'gehalt', 'arbeitszeit']::TEXT[]),
('ORGANIZATIONAL', 'Organisation', 'Prozesse, Verwaltung, Abläufe', ARRAY['prozess', 'ablauf', 'organisation', 'abteilung', 'zuständigkeit']::TEXT[]),
('TECHNICAL', 'Technik', 'IT, Software, technische Fragen', ARRAY['software', 'system', 'fehler', 'computer', 'login', 'passwort']::TEXT[]),
('GENERAL_INFO', 'Allgemein', 'Allgemeine Informationsanfragen', ARRAY[]::TEXT[]),
('UNCLEAR', 'Unklar', 'Nicht eindeutig zuordenbar', ARRAY[]::TEXT[])
ON CONFLICT (slug) DO NOTHING;

-- Insert Medical Pipeline
INSERT INTO public.pipelines (domain_id, slug, name, description, phase_order)
SELECT 
  pd.id,
  'medical-clinical',
  'Klinische Anamnese-Pipeline',
  '8-Phasen-Pipeline für medizinische Anfragen mit Triage, Kontexterhebung, Normalisierung, Kategorisierung, RAG, Reranking, Validierung und Synthese',
  ARRAY['-1', '1', '2', '3', '4', '5', '6', '7', '8']::TEXT[]
FROM public.pipeline_domains pd
WHERE pd.slug = 'MEDICAL'
ON CONFLICT (domain_id, slug) DO NOTHING;

-- Insert HR_LAW Pipeline (placeholder)
INSERT INTO public.pipelines (domain_id, slug, name, description, phase_order)
SELECT 
  pd.id,
  'hr-knowledge',
  'HR-Wissenspipeline',
  '2-Phasen-Pipeline für arbeitsrechtliche Anfragen',
  ARRAY['H1', 'H2']::TEXT[]
FROM public.pipeline_domains pd
WHERE pd.slug = 'HR_LAW'
ON CONFLICT (domain_id, slug) DO NOTHING;

-- Insert GENERAL_INFO Pipeline (lightweight)
INSERT INTO public.pipelines (domain_id, slug, name, description, phase_order)
SELECT 
  pd.id,
  'general-qa',
  'Allgemeine QA-Pipeline',
  'Einfache Pipeline für allgemeine Anfragen',
  ARRAY['G1']::TEXT[]
FROM public.pipeline_domains pd
WHERE pd.slug = 'GENERAL_INFO'
ON CONFLICT (domain_id, slug) DO NOTHING;