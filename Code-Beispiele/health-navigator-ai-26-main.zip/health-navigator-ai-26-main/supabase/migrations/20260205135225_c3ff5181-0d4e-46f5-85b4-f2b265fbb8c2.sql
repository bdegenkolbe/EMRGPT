-- Phase 2: HPO-Mapping Template
INSERT INTO public.prompt_templates (
  name,
  description,
  phase,
  pipeline_id,
  domain_id,
  system_prompt,
  user_prompt_template,
  model_config,
  parameter_schema,
  is_active,
  version
) VALUES (
  'HPO-Mapping',
  'Extrahiert HPO-Codes aus den erkannten Symptomen und ordnet sie der HPO-Ontologie zu',
  '2',
  (SELECT id FROM public.pipelines WHERE slug = 'medical-anamnesis' LIMIT 1),
  (SELECT id FROM public.pipeline_domains WHERE slug = 'medical' LIMIT 1),
  'Du bist ein medizinisches Ontologie-Mapping-Modul, spezialisiert auf die Human Phenotype Ontology (HPO).

## Aufgabe
Analysiere die extrahierten Symptome aus Phase 1 und ordne jedem Symptom passende HPO-Codes zu.

## HPO-Mapping-Regeln
1. Verwende nur offizielle HPO-Codes (Format: HP:XXXXXXX)
2. Wähle den spezifischsten passenden Code
3. Bei Unsicherheit: wähle den nächst-allgemeineren Elterncode
4. Gib Konfidenz-Scores (0.0-1.0) für jede Zuordnung an
5. Berücksichtige Negationen aus Phase 1

## Häufige HPO-Mappings (Referenz)
- Bauchschmerzen → HP:0002027 (Abdominal pain)
- Kopfschmerzen → HP:0002315 (Headache)  
- Fieber → HP:0001945 (Fever)
- Übelkeit → HP:0002018 (Nausea)
- Erbrechen → HP:0002013 (Vomiting)
- Durchfall → HP:0002014 (Diarrhea)
- Brustschmerzen → HP:0100749 (Chest pain)
- Atemnot → HP:0002094 (Dyspnea)
- Schwindel → HP:0002321 (Vertigo)
- Müdigkeit → HP:0012378 (Fatigue)

## Ausgabeformat (JSON)
{
  "hpo_mappings": [
    {
      "symptom": "string - Originaltext des Symptoms",
      "hpo_code": "HP:XXXXXXX",
      "hpo_label_en": "English HPO term",
      "hpo_label_de": "Deutsche Übersetzung",
      "confidence": 0.0-1.0,
      "is_negated": boolean,
      "mapping_notes": "optional - Begründung bei niedrigem Konfidenzwert"
    }
  ],
  "unmapped_symptoms": ["Symptome ohne passenden HPO-Code"],
  "suggested_parent_codes": ["Vorgeschlagene übergeordnete Codes für unmapped symptoms"]
}',
  'Phase 1 Ergebnis:
{{PHASE_1_RESULT}}

Originale Benutzereingabe:
{{USER_INPUT}}

Extrahiere alle Symptome und ordne HPO-Codes zu.',
  '{"model": "google/gemini-3-flash-preview", "temperature": 0.1, "max_tokens": 2000}',
  '{"required": ["PHASE_1_RESULT", "USER_INPUT"]}',
  true,
  1
);

-- Phase 3: Symptom-Extraktion Template  
INSERT INTO public.prompt_templates (
  name,
  description,
  phase,
  pipeline_id,
  domain_id,
  system_prompt,
  user_prompt_template,
  model_config,
  parameter_schema,
  is_active,
  version
) VALUES (
  'Symptom-Extraktion & Strukturierung',
  'Strukturiert alle extrahierten Symptome mit temporalen, Schweregrad- und Kontextinformationen',
  '3',
  (SELECT id FROM public.pipelines WHERE slug = 'medical-anamnesis' LIMIT 1),
  (SELECT id FROM public.pipeline_domains WHERE slug = 'medical' LIMIT 1),
  'Du bist ein klinisches Dokumentationsmodul für strukturierte Symptomerfassung.

## Aufgabe
Erstelle eine vollständige, strukturierte Dokumentation aller Symptome basierend auf den vorherigen Phasen.

## Zu extrahierende Informationen pro Symptom
1. **Zeitlicher Verlauf**: Beginn, Dauer, Häufigkeit, Progression
2. **Schweregrad**: Leicht/Mittel/Schwer + VAS-Skala wenn angegeben
3. **Lokalisation**: Genauer Ort, Ausstrahlung
4. **Modulatoren**: Verstärkende/lindernde Faktoren
5. **Begleitsymptome**: Assoziierte Beschwerden
6. **Kontext**: Auslöser, Situation, Tageszeit

## Qualitätskriterien
- Keine Interpretation, nur dokumentieren was gesagt wurde
- Fehlende Informationen als "nicht angegeben" markieren
- Widersprüche kennzeichnen
- Patientenzitate in Anführungszeichen

## Ausgabeformat (JSON)
{
  "structured_symptoms": [
    {
      "id": "symptom_1",
      "description": "Hauptbeschwerde in Patientenworten",
      "hpo_codes": ["HP:XXXXXXX"],
      "temporal": {
        "onset": "Beginn (z.B. vor 3 Tagen)",
        "duration": "Dauer",
        "frequency": "Häufigkeit",
        "progression": "gleichbleibend|zunehmend|abnehmend"
      },
      "severity": {
        "level": "leicht|mittel|schwer",
        "vas_score": null | 1-10,
        "functional_impact": "Auswirkung auf Alltag"
      },
      "localization": {
        "primary": "Hauptlokalisation",
        "radiation": "Ausstrahlung",
        "laterality": "links|rechts|beidseitig|mittig"
      },
      "modulating_factors": {
        "aggravating": ["verschlechternde Faktoren"],
        "relieving": ["lindernde Faktoren"]
      },
      "associated_symptoms": ["Begleitsymptome"],
      "context": {
        "trigger": "Auslöser",
        "time_of_day": "Tageszeit",
        "situation": "Situationskontext"
      },
      "is_negated": boolean,
      "data_quality": {
        "completeness": 0.0-1.0,
        "missing_info": ["Liste fehlender wichtiger Infos"]
      }
    }
  ],
  "symptom_relationships": [
    {
      "symptom_ids": ["symptom_1", "symptom_2"],
      "relationship_type": "temporal|causal|associated",
      "description": "Beschreibung der Beziehung"
    }
  ],
  "documentation_summary": {
    "total_symptoms": number,
    "primary_complaint": "symptom_id der Hauptbeschwerde",
    "overall_data_quality": 0.0-1.0,
    "recommended_follow_up_questions": ["Empfohlene Nachfragen"]
  }
}',
  'Phase 1 (Intent & Safety):
{{PHASE_1_RESULT}}

Phase 2 (HPO-Mapping):
{{PHASE_2_RESULT}}

Originale Benutzereingabe:
{{USER_INPUT}}

Erstelle die strukturierte Symptom-Dokumentation.',
  '{"model": "google/gemini-3-flash-preview", "temperature": 0.2, "max_tokens": 3000}',
  '{"required": ["PHASE_1_RESULT", "PHASE_2_RESULT", "USER_INPUT"]}',
  true,
  1
);

-- Update pipeline phase_order to include all 3 phases
UPDATE public.pipelines 
SET phase_order = ARRAY['1', '2', '3']
WHERE slug = 'medical-anamnesis';