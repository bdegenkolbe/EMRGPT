-- Enable pgvector extension for vector storage
CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA extensions;

-- Create guidelines table for metadata
CREATE TABLE public.guidelines (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  source TEXT, -- e.g., "AWMF", "DGK", etc.
  version TEXT,
  valid_from DATE,
  valid_until DATE,
  file_path TEXT, -- Storage path
  file_name TEXT,
  file_size INTEGER,
  mime_type TEXT,
  total_chunks INTEGER DEFAULT 0,
  embedding_status TEXT DEFAULT 'pending' CHECK (embedding_status IN ('pending', 'processing', 'completed', 'failed')),
  embedding_error TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create guideline chunks table with vector embeddings (1536 dimensions for text-embedding-3-small/ada)
CREATE TABLE public.guideline_chunks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  guideline_id UUID NOT NULL REFERENCES public.guidelines(id) ON DELETE CASCADE,
  chunk_index INTEGER NOT NULL,
  content TEXT NOT NULL,
  token_count INTEGER,
  section_title TEXT,
  page_number INTEGER,
  embedding extensions.vector(1536), -- text-embedding-3-small dimension (compatible with ivfflat)
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for fast vector similarity search (ivfflat supports max 2000 dimensions)
CREATE INDEX guideline_chunks_embedding_idx ON public.guideline_chunks 
USING ivfflat (embedding extensions.vector_cosine_ops)
WITH (lists = 100);

-- Create index for guideline lookup
CREATE INDEX guideline_chunks_guideline_id_idx ON public.guideline_chunks(guideline_id);

-- Enable RLS
ALTER TABLE public.guidelines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guideline_chunks ENABLE ROW LEVEL SECURITY;

-- RLS policies for guidelines (all authenticated users can read, admins can write)
CREATE POLICY "Authenticated users can view guidelines"
ON public.guidelines FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admins can insert guidelines"
ON public.guidelines FOR INSERT
TO authenticated
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update guidelines"
ON public.guidelines FOR UPDATE
TO authenticated
USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete guidelines"
ON public.guidelines FOR DELETE
TO authenticated
USING (public.is_admin(auth.uid()));

-- RLS policies for chunks (follow parent guidelines permissions)
CREATE POLICY "Authenticated users can view guideline chunks"
ON public.guideline_chunks FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Service role can manage chunks"
ON public.guideline_chunks FOR ALL
USING (true);

-- Create storage bucket for guideline PDFs
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'guidelines',
  'guidelines',
  false,
  52428800, -- 50MB limit
  ARRAY['application/pdf']
);

-- Storage policies
CREATE POLICY "Authenticated users can view guideline files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'guidelines');

CREATE POLICY "Admins can upload guideline files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'guidelines' AND public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete guideline files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'guidelines' AND public.is_admin(auth.uid()));

-- Function for semantic search
CREATE OR REPLACE FUNCTION public.search_guidelines(
  query_embedding extensions.vector(1536),
  match_threshold FLOAT DEFAULT 0.5,
  match_count INT DEFAULT 10,
  filter_guideline_ids UUID[] DEFAULT NULL
)
RETURNS TABLE (
  chunk_id UUID,
  guideline_id UUID,
  guideline_title TEXT,
  section_title TEXT,
  content TEXT,
  page_number INTEGER,
  similarity FLOAT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  RETURN QUERY
  SELECT
    gc.id AS chunk_id,
    gc.guideline_id,
    g.title AS guideline_title,
    gc.section_title,
    gc.content,
    gc.page_number,
    1 - (gc.embedding <=> query_embedding) AS similarity
  FROM public.guideline_chunks gc
  JOIN public.guidelines g ON g.id = gc.guideline_id
  WHERE 
    g.embedding_status = 'completed'
    AND (filter_guideline_ids IS NULL OR gc.guideline_id = ANY(filter_guideline_ids))
    AND 1 - (gc.embedding <=> query_embedding) > match_threshold
  ORDER BY gc.embedding <=> query_embedding
  LIMIT match_count;
END;
$$;

-- Trigger for updated_at
CREATE TRIGGER update_guidelines_updated_at
BEFORE UPDATE ON public.guidelines
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();