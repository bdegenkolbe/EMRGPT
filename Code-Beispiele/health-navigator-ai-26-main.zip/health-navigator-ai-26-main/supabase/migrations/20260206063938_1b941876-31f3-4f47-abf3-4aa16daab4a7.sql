-- Add columns to store detected medical codes in guidelines
ALTER TABLE public.guidelines 
ADD COLUMN IF NOT EXISTS detected_icd10_codes text[] DEFAULT '{}'::text[],
ADD COLUMN IF NOT EXISTS detected_hpo_codes text[] DEFAULT '{}'::text[],
ADD COLUMN IF NOT EXISTS detected_snomed_codes text[] DEFAULT '{}'::text[];

-- Add GIN indexes for efficient array searches
CREATE INDEX IF NOT EXISTS idx_guidelines_icd10_codes ON public.guidelines USING GIN (detected_icd10_codes);
CREATE INDEX IF NOT EXISTS idx_guidelines_hpo_codes ON public.guidelines USING GIN (detected_hpo_codes);
CREATE INDEX IF NOT EXISTS idx_guidelines_snomed_codes ON public.guidelines USING GIN (detected_snomed_codes);

-- Add a comment for documentation
COMMENT ON COLUMN public.guidelines.detected_icd10_codes IS 'ICD-10 codes detected during PDF parsing';
COMMENT ON COLUMN public.guidelines.detected_hpo_codes IS 'HPO codes detected during PDF parsing';
COMMENT ON COLUMN public.guidelines.detected_snomed_codes IS 'SNOMED CT codes detected during PDF parsing';