-- Add service role access using DO block to check existence first
DO $$
BEGIN
  -- SNOMED codes service role policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'snomed_codes' 
    AND policyname = 'Service role full access for SNOMED codes'
  ) THEN
    CREATE POLICY "Service role full access for SNOMED codes" ON public.snomed_codes
      FOR ALL USING ((auth.jwt() ->> 'role') = 'service_role')
      WITH CHECK ((auth.jwt() ->> 'role') = 'service_role');
  END IF;

  -- orphanet_analyses service role policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'orphanet_analyses' 
    AND policyname = 'Service role full access for orphanet_analyses'
  ) THEN
    CREATE POLICY "Service role full access for orphanet_analyses" ON public.orphanet_analyses
      FOR ALL USING ((auth.jwt() ->> 'role') = 'service_role')
      WITH CHECK ((auth.jwt() ->> 'role') = 'service_role');
  END IF;
END $$;