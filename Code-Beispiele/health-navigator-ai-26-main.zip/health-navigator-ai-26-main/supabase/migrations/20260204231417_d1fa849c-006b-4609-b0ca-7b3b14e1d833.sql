-- Add DELETE policy for users on their own sessions
CREATE POLICY "Users can delete own sessions"
ON public.anamnesis_sessions
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- Add DELETE policy for observations (users can delete observations of their sessions)
CREATE POLICY "Users can delete observations of own sessions"
ON public.observations
FOR DELETE
TO authenticated
USING (EXISTS (
    SELECT 1 FROM anamnesis_sessions s
    WHERE s.id = observations.session_id
    AND s.user_id = auth.uid()
));

-- Add DELETE policy for conversation_messages (users can delete messages of their sessions)
CREATE POLICY "Users can delete messages of own sessions"
ON public.conversation_messages
FOR DELETE
TO authenticated
USING (EXISTS (
    SELECT 1 FROM anamnesis_sessions s
    WHERE s.id = conversation_messages.session_id
    AND s.user_id = auth.uid()
));

-- Add DELETE policy for evidence_requests
CREATE POLICY "Users can delete evidence requests of own sessions"
ON public.evidence_requests
FOR DELETE
TO authenticated
USING (EXISTS (
    SELECT 1 FROM anamnesis_sessions s
    WHERE s.id = evidence_requests.session_id
    AND s.user_id = auth.uid()
));

-- Add DELETE policy for evidence_items
CREATE POLICY "Users can delete evidence items of own sessions"
ON public.evidence_items
FOR DELETE
TO authenticated
USING (EXISTS (
    SELECT 1 FROM evidence_requests r
    JOIN anamnesis_sessions s ON s.id = r.session_id
    WHERE r.id = evidence_items.request_id
    AND s.user_id = auth.uid()
));