-- ============================================================================
-- Orphanet (ORPHAcodes) - Seltene Erkrankungen Datenbank
-- Basierend auf api.orphacode.org für mehrsprachige Terminologie
-- ============================================================================

-- 1. Haupttabelle für Orphanet-Codes
CREATE TABLE IF NOT EXISTS public.orphanet_codes (
  orpha_code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  name_short TEXT,
  definition TEXT,
  -- JSONB für mehrsprachige Labels (analog zu HPO/SNOMED/ICD-10)
  labels JSONB DEFAULT '{}'::jsonb,
  definitions JSONB DEFAULT '{}'::jsonb,
  explanations JSONB DEFAULT '{}'::jsonb,
  -- Hierarchie
  parent_code TEXT,
  level INTEGER DEFAULT 0,
  classification TEXT, -- z.B. "Disorder", "Group", "Subtype"
  -- Mappings zu anderen Ontologien
  icd10_codes TEXT[],
  omim_codes TEXT[],
  hpo_codes TEXT[],
  snomed_codes TEXT[],
  -- Metadaten
  prevalence TEXT,
  inheritance TEXT[],
  age_of_onset TEXT[],
  orpha_url TEXT,
  is_terminal BOOLEAN DEFAULT true,
  -- Audit
  source TEXT DEFAULT 'orphacode_api',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 2. Übersetzungstabelle für Orphanet (analog zu hpo_translations)
CREATE TABLE IF NOT EXISTS public.orphanet_translations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  orpha_code TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL,
  name_de TEXT,
  definition_en TEXT,
  definition_de TEXT,
  explanation_de TEXT,
  explanation_en TEXT,
  -- JSONB für Mehrsprachigkeit
  labels JSONB DEFAULT '{}'::jsonb,
  definitions JSONB DEFAULT '{}'::jsonb,
  explanations JSONB DEFAULT '{}'::jsonb,
  synonyms TEXT[],
  source TEXT DEFAULT 'ai_translated',
  confidence NUMERIC DEFAULT 0.9,
  verified_at TIMESTAMP WITH TIME ZONE,
  verified_by UUID,
  explanation_generated_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 3. Indizes für performante Suche
CREATE INDEX IF NOT EXISTS idx_orphanet_codes_name_gin 
ON public.orphanet_codes USING gin (to_tsvector('german', name || ' ' || COALESCE(name_short, '')));

CREATE INDEX IF NOT EXISTS idx_orphanet_codes_labels_gin 
ON public.orphanet_codes USING gin (labels);

CREATE INDEX IF NOT EXISTS idx_orphanet_codes_parent 
ON public.orphanet_codes (parent_code);

CREATE INDEX IF NOT EXISTS idx_orphanet_codes_classification 
ON public.orphanet_codes (classification);

CREATE INDEX IF NOT EXISTS idx_orphanet_translations_orpha_code 
ON public.orphanet_translations (orpha_code);

CREATE INDEX IF NOT EXISTS idx_orphanet_translations_labels_gin 
ON public.orphanet_translations USING gin (labels);

-- 4. RLS-Policies
ALTER TABLE public.orphanet_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orphanet_translations ENABLE ROW LEVEL SECURITY;

-- Leserechte für alle authentifizierten Benutzer
CREATE POLICY "Orphanet codes are publicly readable" 
ON public.orphanet_codes FOR SELECT USING (true);

CREATE POLICY "Only admins can modify Orphanet codes" 
ON public.orphanet_codes FOR ALL USING (is_admin(auth.uid()));

CREATE POLICY "Orphanet translations are publicly readable" 
ON public.orphanet_translations FOR SELECT USING (true);

CREATE POLICY "Only admins can insert Orphanet translations" 
ON public.orphanet_translations FOR INSERT WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "Only admins can update Orphanet translations" 
ON public.orphanet_translations FOR UPDATE USING (is_admin(auth.uid()));

-- Service role für Edge Functions
CREATE POLICY "Service role full access for Orphanet translations" 
ON public.orphanet_translations FOR ALL 
USING ((auth.jwt() ->> 'role'::text) = 'service_role'::text)
WITH CHECK ((auth.jwt() ->> 'role'::text) = 'service_role'::text);

-- 5. Trigger für updated_at
CREATE TRIGGER update_orphanet_codes_updated_at
BEFORE UPDATE ON public.orphanet_codes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_orphanet_translations_updated_at
BEFORE UPDATE ON public.orphanet_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- 6. Kommentare
COMMENT ON TABLE public.orphanet_codes IS 'Orphanet-Nomenklatur für seltene Erkrankungen (ORPHAcodes)';
COMMENT ON TABLE public.orphanet_translations IS 'KI-generierte Übersetzungen für Orphanet-Begriffe';
COMMENT ON COLUMN public.orphanet_codes.labels IS 'Multi-language labels: {"de": "...", "en": "...", etc.}';
COMMENT ON COLUMN public.orphanet_codes.orpha_code IS 'ORPHA-Nummer ohne Präfix (z.B. "166024" für ORPHA:166024)';