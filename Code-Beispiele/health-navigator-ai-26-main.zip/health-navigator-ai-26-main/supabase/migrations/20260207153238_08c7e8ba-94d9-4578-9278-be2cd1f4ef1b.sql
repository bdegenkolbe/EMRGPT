-- Migration: Konsolidierung der Übersetzungen in JSONB-Spalten
-- Schritt 1: Sicherstellen, dass alle Haupttabellen die nötigen JSONB-Spalten haben

-- HPO: labels, definitions, explanations hinzufügen falls nicht vorhanden
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'hpo_codes' AND column_name = 'definitions') THEN
    ALTER TABLE public.hpo_codes ADD COLUMN definitions jsonb DEFAULT '{}'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'hpo_codes' AND column_name = 'explanations') THEN
    ALTER TABLE public.hpo_codes ADD COLUMN explanations jsonb DEFAULT '{}'::jsonb;
  END IF;
END $$;

-- SNOMED: definitions, explanations hinzufügen
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'snomed_codes' AND column_name = 'definitions') THEN
    ALTER TABLE public.snomed_codes ADD COLUMN definitions jsonb DEFAULT '{}'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'snomed_codes' AND column_name = 'explanations') THEN
    ALTER TABLE public.snomed_codes ADD COLUMN explanations jsonb DEFAULT '{}'::jsonb;
  END IF;
END $$;

-- ICD-10-GM: definitions, explanations hinzufügen
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'icd10gm_codes' AND column_name = 'definitions') THEN
    ALTER TABLE public.icd10gm_codes ADD COLUMN definitions jsonb DEFAULT '{}'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'icd10gm_codes' AND column_name = 'explanations') THEN
    ALTER TABLE public.icd10gm_codes ADD COLUMN explanations jsonb DEFAULT '{}'::jsonb;
  END IF;
END $$;

-- ICD-11: definitions, explanations hinzufügen
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'icd11_codes' AND column_name = 'definitions') THEN
    ALTER TABLE public.icd11_codes ADD COLUMN definitions jsonb DEFAULT '{}'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'icd11_codes' AND column_name = 'explanations') THEN
    ALTER TABLE public.icd11_codes ADD COLUMN explanations jsonb DEFAULT '{}'::jsonb;
  END IF;
END $$;

-- Schritt 2: Daten aus Translation-Tabellen in Haupttabellen migrieren

-- HPO Translations -> hpo_codes
UPDATE public.hpo_codes h
SET 
  labels = COALESCE(h.labels, '{}'::jsonb) || 
    jsonb_build_object('de', t.label_de, 'en', t.label_en),
  definitions = COALESCE(h.definitions, '{}'::jsonb) ||
    CASE WHEN t.definition_de IS NOT NULL OR t.definition_en IS NOT NULL 
    THEN jsonb_strip_nulls(jsonb_build_object('de', t.definition_de, 'en', t.definition_en))
    ELSE '{}'::jsonb END,
  explanations = COALESCE(h.explanations, '{}'::jsonb) ||
    CASE WHEN t.explanation_de IS NOT NULL OR t.explanation_en IS NOT NULL
    THEN jsonb_strip_nulls(jsonb_build_object('de', t.explanation_de, 'en', t.explanation_en))
    ELSE '{}'::jsonb END
FROM public.hpo_translations t
WHERE h.hpo_code = t.hpo_code;

-- SNOMED Translations -> snomed_codes
UPDATE public.snomed_codes s
SET 
  labels = COALESCE(s.labels, '{}'::jsonb) || 
    jsonb_build_object('de', t.pt_de, 'en', t.pt_en),
  definitions = COALESCE(s.definitions, '{}'::jsonb) ||
    CASE WHEN t.definition_de IS NOT NULL 
    THEN jsonb_build_object('de', t.definition_de)
    ELSE '{}'::jsonb END,
  explanations = COALESCE(s.explanations, '{}'::jsonb) ||
    CASE WHEN t.explanation_de IS NOT NULL OR t.explanation_en IS NOT NULL
    THEN jsonb_strip_nulls(jsonb_build_object('de', t.explanation_de, 'en', t.explanation_en))
    ELSE '{}'::jsonb END
FROM public.snomed_translations t
WHERE s.sctid = t.sctid;

-- ICD-10-GM Translations -> icd10gm_codes
UPDATE public.icd10gm_codes i
SET 
  labels = COALESCE(i.labels, '{}'::jsonb) || 
    COALESCE(t.labels, '{}'::jsonb),
  definitions = COALESCE(i.definitions, '{}'::jsonb),
  explanations = COALESCE(i.explanations, '{}'::jsonb) ||
    CASE WHEN t.explanation_de IS NOT NULL OR t.explanation_en IS NOT NULL
    THEN jsonb_strip_nulls(jsonb_build_object('de', t.explanation_de, 'en', t.explanation_en))
    ELSE '{}'::jsonb END
FROM public.icd10gm_translations t
WHERE i.code = t.icd_code;

-- ICD-11 Translations -> icd11_codes
UPDATE public.icd11_codes i
SET 
  labels = COALESCE(i.labels, '{}'::jsonb) || 
    COALESCE(t.labels, '{}'::jsonb),
  definitions = COALESCE(i.definitions, '{}'::jsonb),
  explanations = COALESCE(i.explanations, '{}'::jsonb) ||
    CASE WHEN t.explanation_de IS NOT NULL OR t.explanation_en IS NOT NULL
    THEN jsonb_strip_nulls(jsonb_build_object('de', t.explanation_de, 'en', t.explanation_en))
    ELSE '{}'::jsonb END
FROM public.icd11_translations t
WHERE i.code = t.icd_code;

-- Orphanet Translations -> orphanet_codes (hat bereits labels, definitions, explanations)
UPDATE public.orphanet_codes o
SET 
  labels = COALESCE(o.labels, '{}'::jsonb) || 
    jsonb_strip_nulls(jsonb_build_object('de', t.name_de, 'en', t.name_en)),
  definitions = COALESCE(o.definitions, '{}'::jsonb) ||
    CASE WHEN t.definition_de IS NOT NULL OR t.definition_en IS NOT NULL
    THEN jsonb_strip_nulls(jsonb_build_object('de', t.definition_de, 'en', t.definition_en))
    ELSE '{}'::jsonb END,
  explanations = COALESCE(o.explanations, '{}'::jsonb) ||
    CASE WHEN t.explanation_de IS NOT NULL OR t.explanation_en IS NOT NULL
    THEN jsonb_strip_nulls(jsonb_build_object('de', t.explanation_de, 'en', t.explanation_en))
    ELSE '{}'::jsonb END
FROM public.orphanet_translations t
WHERE o.orpha_code = t.orpha_code;

-- Schritt 3: Translation-Tabellen entfernen
DROP TABLE IF EXISTS public.hpo_translations CASCADE;
DROP TABLE IF EXISTS public.snomed_translations CASCADE;
DROP TABLE IF EXISTS public.icd10gm_translations CASCADE;
DROP TABLE IF EXISTS public.icd11_translations CASCADE;
DROP TABLE IF EXISTS public.orphanet_translations CASCADE;

-- Schritt 4: Indizes für JSONB-Suche erstellen
CREATE INDEX IF NOT EXISTS idx_hpo_codes_labels ON public.hpo_codes USING gin(labels);
CREATE INDEX IF NOT EXISTS idx_snomed_codes_labels ON public.snomed_codes USING gin(labels);
CREATE INDEX IF NOT EXISTS idx_icd10gm_codes_labels ON public.icd10gm_codes USING gin(labels);
CREATE INDEX IF NOT EXISTS idx_icd11_codes_labels ON public.icd11_codes USING gin(labels);
CREATE INDEX IF NOT EXISTS idx_orphanet_codes_labels ON public.orphanet_codes USING gin(labels);