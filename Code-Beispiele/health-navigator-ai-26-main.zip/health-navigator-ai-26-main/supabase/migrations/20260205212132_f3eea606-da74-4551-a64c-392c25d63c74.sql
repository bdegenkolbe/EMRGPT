-- Insert Phase 2b SNOMED-Mapping prompt template for MEDICAL pipeline
-- First, get the MEDICAL pipeline ID and domain ID
INSERT INTO public.prompt_templates (
  name,
  phase,
  description,
  system_prompt,
  user_prompt_template,
  model_config,
  is_active,
  pipeline_id,
  domain_id
)
SELECT 
  'SNOMED-CT Mapping',
  '2b',
  'Parallel zu HPO-Mapping: Extrahiert und kodiert klinische Befunde mit SNOMED CT Konzepten für umfassendere Terminologie-Abdeckung (Diagnosen, Prozeduren, anatomische Strukturen).',
  E'Du bist ein medizinischer Terminologie-Experte für SNOMED CT (Systematized Nomenclature of Medicine - Clinical Terms).

Deine Aufgabe: Analysiere die Patientenaussage und extrahiere relevante klinische Konzepte mit ihren SNOMED CT Codes.

SNOMED CT Hierarchien die du berücksichtigen sollst:
- Clinical finding (404684003): Symptome, Befunde, Diagnosen
- Body structure (123037004): Anatomische Strukturen
- Procedure (71388002): Medizinische Prozeduren
- Substance (105590001): Medikamente, Substanzen
- Qualifier value (362981000): Schweregrad, Lateralität

Wichtige Regeln:
1. Verwende nur verifizierte SNOMED CT Codes (8-18 stellige numerische IDs)
2. Bevorzuge spezifische Codes über allgemeine
3. Gib immer den Preferred Term (PT) auf Deutsch an falls verfügbar
4. Markiere negierte Befunde explizit

Antworte NUR mit validem JSON.',
  E'Patientenaussage: {{USER_INPUT}}

Bisheriger Kontext: {{CONVERSATION_HISTORY}}

Extrahiere SNOMED CT Konzepte im folgenden Format:
{
  "snomed_concepts": [
    {
      "sctid": "string (SNOMED CT Concept ID)",
      "term_de": "string (deutscher Preferred Term)",
      "term_en": "string (englischer Preferred Term)", 
      "semantic_tag": "string (finding|body structure|procedure|substance|qualifier)",
      "is_negated": boolean,
      "confidence": number (0.0-1.0),
      "source_text": "string (Originaltext aus Patientenaussage)"
    }
  ],
  "icd10_mappings": [
    {
      "sctid": "string",
      "icd10_code": "string",
      "map_group": number
    }
  ],
  "body_sites": [
    {
      "sctid": "string",
      "term": "string",
      "laterality": "left|right|bilateral|unspecified"
    }
  ]
}',
  '{"model": "google/gemini-3-flash-preview", "temperature": 0.1, "max_tokens": 2000}'::jsonb,
  true,
  p.id,
  p.domain_id
FROM public.pipelines p
JOIN public.pipeline_domains d ON p.domain_id = d.id
WHERE d.slug = 'MEDICAL' AND p.is_active = true
LIMIT 1;