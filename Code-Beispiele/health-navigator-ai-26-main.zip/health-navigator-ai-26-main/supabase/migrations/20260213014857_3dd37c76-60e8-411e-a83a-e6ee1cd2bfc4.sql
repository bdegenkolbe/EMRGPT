
-- 1. Procedures table for surgical/diagnostic procedures
CREATE TABLE public.fhir_procedures (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  fhir_id text NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.fhir_patients(id) ON DELETE CASCADE,
  encounter_id uuid REFERENCES public.fhir_encounters(id),
  status text NOT NULL DEFAULT 'completed',
  code text,
  code_display text,
  code_system text,
  category text,
  performed_datetime timestamptz,
  performer_display text,
  reason_codes jsonb DEFAULT '[]'::jsonb,
  body_site text,
  note text,
  fhir_resource jsonb NOT NULL,
  source_document_id uuid REFERENCES public.fhir_document_references(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.fhir_procedures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage all procedures" ON public.fhir_procedures FOR ALL USING (is_admin(auth.uid()));
CREATE POLICY "Users can view procedures of own patients" ON public.fhir_procedures FOR SELECT USING (EXISTS (SELECT 1 FROM fhir_patients p WHERE p.id = fhir_procedures.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can create procedures for own patients" ON public.fhir_procedures FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM fhir_patients p WHERE p.id = fhir_procedures.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can update procedures of own patients" ON public.fhir_procedures FOR UPDATE USING (EXISTS (SELECT 1 FROM fhir_patients p WHERE p.id = fhir_procedures.patient_id AND p.created_by = auth.uid()));
CREATE POLICY "Users can delete procedures of own patients" ON public.fhir_procedures FOR DELETE USING (EXISTS (SELECT 1 FROM fhir_patients p WHERE p.id = fhir_procedures.patient_id AND p.created_by = auth.uid()));

CREATE TRIGGER update_fhir_procedures_updated_at BEFORE UPDATE ON public.fhir_procedures FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2. Analysis columns on document references
ALTER TABLE public.fhir_document_references
  ADD COLUMN analysis_status text DEFAULT 'pending',
  ADD COLUMN analysis_result jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN transferred_resources jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN extracted_text text;

-- 3. Index for faster lookups
CREATE INDEX idx_fhir_procedures_patient_id ON public.fhir_procedures(patient_id);
CREATE INDEX idx_fhir_document_references_analysis_status ON public.fhir_document_references(analysis_status);
