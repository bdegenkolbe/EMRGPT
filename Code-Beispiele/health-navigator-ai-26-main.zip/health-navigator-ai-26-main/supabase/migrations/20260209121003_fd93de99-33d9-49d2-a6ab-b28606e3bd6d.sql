
-- Add content_type field to knowledge_sources to distinguish abstract vs fulltext
ALTER TABLE public.knowledge_sources 
ADD COLUMN content_type text NOT NULL DEFAULT 'abstract';

-- Add pdf_path field to store generated PDF location in storage
ALTER TABLE public.knowledge_sources 
ADD COLUMN pdf_path text;

-- Add comment for documentation
COMMENT ON COLUMN public.knowledge_sources.content_type IS 'Type of content stored: abstract or fulltext';
COMMENT ON COLUMN public.knowledge_sources.pdf_path IS 'Path to generated PDF in storage bucket';
