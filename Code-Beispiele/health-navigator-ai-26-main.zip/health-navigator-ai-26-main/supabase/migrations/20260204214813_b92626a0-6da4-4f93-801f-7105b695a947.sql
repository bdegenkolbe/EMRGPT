-- Insert admin role for bjoern.degenkolbe@4k-analytics.de
INSERT INTO public.user_roles (user_id, role)
VALUES ('076e2a57-e894-47a7-8117-5fb2f1c79968', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;