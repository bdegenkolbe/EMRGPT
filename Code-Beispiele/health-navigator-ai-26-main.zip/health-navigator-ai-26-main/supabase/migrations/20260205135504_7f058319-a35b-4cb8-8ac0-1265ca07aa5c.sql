-- Fix Phase 2 und 3 Templates: Link to the correct pipeline (medical-clinical)
UPDATE public.prompt_templates 
SET pipeline_id = '68006dd7-75bc-445e-b58b-43533a38c80d'
WHERE phase IN ('2', '3') AND pipeline_id IS NULL;

-- Update pipeline phase_order to only include phases 1,2,3 for now
UPDATE public.pipelines 
SET phase_order = ARRAY['1', '2', '3']
WHERE id = '68006dd7-75bc-445e-b58b-43533a38c80d';