-- Backfill HPO mappings from icd10gm_analyses
INSERT INTO public.ontology_mappings (source_code, source_label, source_system, target_code, target_label, target_system, confidence, mapping_type, notes)
SELECT 
  a.icd_code as source_code,
  COALESCE((SELECT title FROM public.icd10gm_codes WHERE code = a.icd_code LIMIT 1), a.icd_code) as source_label,
  'ICD10GM' as source_system,
  (hpo->>'code') as target_code,
  COALESCE(hpo->>'label_de', hpo->>'label_en') as target_label,
  'HPO' as target_system,
  0.85 as confidence,
  CASE 
    WHEN hpo->>'relation' = 'exact' THEN 'exact'
    WHEN hpo->>'relation' = 'broad' THEN 'broad'
    WHEN hpo->>'relation' = 'narrow' THEN 'narrow'
    ELSE 'related'
  END as mapping_type,
  'KI-generiert (Backfill aus ICD-10-Analyse)' as notes
FROM public.icd10gm_analyses a,
     jsonb_array_elements(COALESCE(a.hpo_mappings::jsonb, '[]'::jsonb)) as hpo
WHERE hpo->>'code' IS NOT NULL
ON CONFLICT (source_code, source_system, target_code, target_system) DO NOTHING;

-- Backfill SNOMED mappings from icd10gm_analyses
INSERT INTO public.ontology_mappings (source_code, source_label, source_system, target_code, target_label, target_system, confidence, mapping_type, notes)
SELECT 
  a.icd_code as source_code,
  COALESCE((SELECT title FROM public.icd10gm_codes WHERE code = a.icd_code LIMIT 1), a.icd_code) as source_label,
  'ICD10GM' as source_system,
  (snomed->>'sctid') as target_code,
  COALESCE(snomed->>'pt_de', snomed->>'pt_en') as target_label,
  'SNOMED' as target_system,
  0.85 as confidence,
  CASE 
    WHEN snomed->>'relation' = 'exact' THEN 'exact'
    WHEN snomed->>'relation' = 'broad' THEN 'broad'
    WHEN snomed->>'relation' = 'narrow' THEN 'narrow'
    ELSE 'related'
  END as mapping_type,
  'KI-generiert (Backfill aus ICD-10-Analyse)' as notes
FROM public.icd10gm_analyses a,
     jsonb_array_elements(COALESCE(a.snomed_mappings::jsonb, '[]'::jsonb)) as snomed
WHERE snomed->>'sctid' IS NOT NULL
ON CONFLICT (source_code, source_system, target_code, target_system) DO NOTHING;