-- Create enum for validation status
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'mapping_validation_status') THEN
        CREATE TYPE public.mapping_validation_status AS ENUM (
            'pending',
            'valid', 
            'conflict',
            'exception',
            'orphan'
        );
    END IF;
END$$;

-- Add new columns for enhanced graph validation
ALTER TABLE public.ontology_mappings
ADD COLUMN IF NOT EXISTS conflict_type text,
ADD COLUMN IF NOT EXISTS conflict_severity text,
ADD COLUMN IF NOT EXISTS related_mapping_ids uuid[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS is_bidirectional boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS reverse_mapping_id uuid,
ADD COLUMN IF NOT EXISTS graph_depth integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_validated_at timestamp with time zone;

-- Add index for efficient graph traversal
CREATE INDEX IF NOT EXISTS idx_ontology_mappings_source 
ON public.ontology_mappings (source_system, source_code);

CREATE INDEX IF NOT EXISTS idx_ontology_mappings_target 
ON public.ontology_mappings (target_system, target_code);

CREATE INDEX IF NOT EXISTS idx_ontology_mappings_validation_status 
ON public.ontology_mappings (validation_status);

CREATE INDEX IF NOT EXISTS idx_ontology_mappings_conflict_type 
ON public.ontology_mappings (conflict_type) WHERE conflict_type IS NOT NULL;

-- Add composite index for bidirectional lookups
CREATE INDEX IF NOT EXISTS idx_ontology_mappings_bidirectional 
ON public.ontology_mappings (source_system, source_code, target_system, target_code);

-- Add GIN index for related_mapping_ids array queries
CREATE INDEX IF NOT EXISTS idx_ontology_mappings_related 
ON public.ontology_mappings USING GIN (related_mapping_ids);

-- Create function to find circular references using recursive CTE
CREATE OR REPLACE FUNCTION public.find_circular_mappings(
    start_code text,
    start_system text,
    max_depth integer DEFAULT 5
)
RETURNS TABLE (
    path text[],
    cycle_detected boolean,
    path_length integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
    RETURN QUERY
    WITH RECURSIVE mapping_path AS (
        -- Base case: start from the given code
        SELECT 
            ARRAY[start_system || ':' || start_code] AS path,
            target_system,
            target_code,
            1 AS depth,
            false AS is_cycle
        FROM ontology_mappings
        WHERE source_system = start_system AND source_code = start_code
        
        UNION ALL
        
        -- Recursive case: follow the graph
        SELECT 
            mp.path || (om.target_system || ':' || om.target_code),
            om.target_system,
            om.target_code,
            mp.depth + 1,
            (om.target_system || ':' || om.target_code) = ANY(mp.path)
        FROM mapping_path mp
        JOIN ontology_mappings om 
            ON om.source_system = mp.target_system 
            AND om.source_code = mp.target_code
        WHERE mp.depth < max_depth
            AND NOT mp.is_cycle
            AND NOT ((om.target_system || ':' || om.target_code) = ANY(mp.path))
    )
    SELECT 
        mp.path,
        mp.is_cycle AS cycle_detected,
        mp.depth AS path_length
    FROM mapping_path mp
    WHERE mp.is_cycle = true
    ORDER BY mp.depth;
END;
$$;

-- Create function to validate transitive consistency
CREATE OR REPLACE FUNCTION public.validate_transitive_mappings(
    p_source_system text DEFAULT NULL,
    p_limit integer DEFAULT 100
)
RETURNS TABLE (
    mapping_id uuid,
    conflict_type text,
    description text,
    related_ids uuid[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
    RETURN QUERY
    -- Find cases where A->B (exact) and A->C (exact) exist for same target system
    SELECT 
        m1.id AS mapping_id,
        'multiple_exact_targets'::text AS conflict_type,
        format('%s:%s has multiple exact mappings to %s', 
            m1.source_system, m1.source_code, m1.target_system) AS description,
        array_agg(DISTINCT m2.id) AS related_ids
    FROM ontology_mappings m1
    JOIN ontology_mappings m2 
        ON m1.source_system = m2.source_system 
        AND m1.source_code = m2.source_code
        AND m1.target_system = m2.target_system
        AND m1.id < m2.id  -- Avoid duplicates
    WHERE m1.mapping_type = 'exact' 
        AND m2.mapping_type = 'exact'
        AND m1.target_code != m2.target_code
        AND (p_source_system IS NULL OR m1.source_system = p_source_system)
    GROUP BY m1.id, m1.source_system, m1.source_code, m1.target_system
    LIMIT p_limit;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION public.find_circular_mappings TO authenticated;
GRANT EXECUTE ON FUNCTION public.validate_transitive_mappings TO authenticated;