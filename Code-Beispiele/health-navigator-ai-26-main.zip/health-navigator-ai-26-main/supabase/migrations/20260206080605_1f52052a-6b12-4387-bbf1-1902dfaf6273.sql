-- Create LOINC codes table for local storage (no API auth required)
CREATE TABLE public.loinc_codes (
  loinc_num TEXT PRIMARY KEY,
  component TEXT NOT NULL,
  property TEXT,
  time_aspect TEXT,
  system TEXT,
  scale_type TEXT,
  method_type TEXT,
  class TEXT,
  class_type INTEGER,
  long_common_name TEXT,
  short_name TEXT,
  display_name TEXT,
  status TEXT DEFAULT 'ACTIVE',
  example_ucum_units TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create indexes for efficient searching
CREATE INDEX idx_loinc_component ON public.loinc_codes USING gin(to_tsvector('german', component));
CREATE INDEX idx_loinc_long_name ON public.loinc_codes USING gin(to_tsvector('german', long_common_name));
CREATE INDEX idx_loinc_class ON public.loinc_codes(class);
CREATE INDEX idx_loinc_status ON public.loinc_codes(status);

-- Enable RLS
ALTER TABLE public.loinc_codes ENABLE ROW LEVEL SECURITY;

-- Public read access
CREATE POLICY "LOINC codes are publicly readable"
  ON public.loinc_codes FOR SELECT
  USING (true);

-- Admin write access
CREATE POLICY "Only admins can modify LOINC codes"
  ON public.loinc_codes FOR ALL
  USING (public.is_admin(auth.uid()));

-- Insert common laboratory LOINC codes (German healthcare essentials)
INSERT INTO public.loinc_codes (loinc_num, component, property, time_aspect, system, scale_type, long_common_name, short_name, class, example_ucum_units) VALUES
-- Blood counts
('718-7', 'Hemoglobin', 'MCnc', 'Pt', 'Bld', 'Qn', 'Hemoglobin [Mass/volume] in Blood', 'Hgb Bld-mCnc', 'HEM/BC', 'g/dL'),
('789-8', 'Erythrocytes', 'NCnc', 'Pt', 'Bld', 'Qn', 'Erythrocytes [#/volume] in Blood', 'RBC # Bld', 'HEM/BC', '10*12/L'),
('6690-2', 'Leukocytes', 'NCnc', 'Pt', 'Bld', 'Qn', 'Leukocytes [#/volume] in Blood', 'WBC # Bld', 'HEM/BC', '10*9/L'),
('777-3', 'Platelets', 'NCnc', 'Pt', 'Bld', 'Qn', 'Platelets [#/volume] in Blood', 'Platelet # Bld', 'HEM/BC', '10*9/L'),
('4544-3', 'Hematocrit', 'VFr', 'Pt', 'Bld', 'Qn', 'Hematocrit [Volume Fraction] of Blood', 'Hct VFr Bld', 'HEM/BC', '%'),
('785-6', 'MCH', 'EntMass', 'Pt', 'RBC', 'Qn', 'MCH [Entitic mass]', 'MCH RBC', 'HEM/BC', 'pg'),
('786-4', 'MCHC', 'MCnc', 'Pt', 'RBC', 'Qn', 'MCHC [Mass/volume]', 'MCHC RBC', 'HEM/BC', 'g/dL'),
('787-2', 'MCV', 'EntVol', 'Pt', 'RBC', 'Qn', 'MCV [Entitic volume]', 'MCV RBC', 'HEM/BC', 'fL'),

-- Coagulation
('5902-2', 'Prothrombin time', 'Time', 'Pt', 'PPP', 'Qn', 'Prothrombin time (PT)', 'PT PPP', 'COAG', 's'),
('6301-6', 'INR', 'RelTime', 'Pt', 'Bld', 'Qn', 'INR in Platelet poor plasma', 'INR', 'COAG', '1'),
('3173-2', 'aPTT', 'Time', 'Pt', 'PPP', 'Qn', 'Activated partial thromboplastin time (aPTT)', 'aPTT PPP', 'COAG', 's'),

-- Clinical Chemistry - Electrolytes
('2951-2', 'Sodium', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Sodium [Moles/volume] in Serum or Plasma', 'Sodium SerPl-sCnc', 'CHEM', 'mmol/L'),
('2823-3', 'Potassium', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Potassium [Moles/volume] in Serum or Plasma', 'Potassium SerPl-sCnc', 'CHEM', 'mmol/L'),
('2075-0', 'Chloride', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Chloride [Moles/volume] in Serum or Plasma', 'Chloride SerPl-sCnc', 'CHEM', 'mmol/L'),
('17861-6', 'Calcium', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Calcium [Moles/volume] in Serum or Plasma', 'Calcium SerPl-sCnc', 'CHEM', 'mmol/L'),
('2601-3', 'Magnesium', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Magnesium [Moles/volume] in Serum or Plasma', 'Magnesium SerPl-sCnc', 'CHEM', 'mmol/L'),
('2777-1', 'Phosphate', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Phosphate [Moles/volume] in Serum or Plasma', 'Phosphate SerPl-sCnc', 'CHEM', 'mmol/L'),

-- Kidney function
('2160-0', 'Creatinine', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Creatinine [Mass/volume] in Serum or Plasma', 'Creat SerPl-mCnc', 'CHEM', 'mg/dL'),
('3094-0', 'Urea nitrogen', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Urea nitrogen [Mass/volume] in Serum or Plasma', 'BUN SerPl-mCnc', 'CHEM', 'mg/dL'),
('33914-3', 'eGFR', 'ArVRat', 'Pt', 'Ser/Plas', 'Qn', 'Glomerular filtration rate/1.73 sq M.predicted', 'GFR/1.73 sq M SerPl', 'CHEM', 'mL/min/{1.73_m2}'),
('3084-1', 'Uric acid', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Urate [Mass/volume] in Serum or Plasma', 'Urate SerPl-mCnc', 'CHEM', 'mg/dL'),

-- Liver function
('1920-8', 'AST', 'CCnc', 'Pt', 'Ser/Plas', 'Qn', 'Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma', 'AST SerPl-cCnc', 'CHEM', 'U/L'),
('1742-6', 'ALT', 'CCnc', 'Pt', 'Ser/Plas', 'Qn', 'Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma', 'ALT SerPl-cCnc', 'CHEM', 'U/L'),
('6768-6', 'ALP', 'CCnc', 'Pt', 'Ser/Plas', 'Qn', 'Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma', 'ALP SerPl-cCnc', 'CHEM', 'U/L'),
('2324-2', 'GGT', 'CCnc', 'Pt', 'Ser/Plas', 'Qn', 'Gamma glutamyl transferase [Enzymatic activity/volume] in Serum or Plasma', 'GGT SerPl-cCnc', 'CHEM', 'U/L'),
('1975-2', 'Bilirubin total', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Bilirubin.total [Mass/volume] in Serum or Plasma', 'Bilirub SerPl-mCnc', 'CHEM', 'mg/dL'),
('1968-7', 'Bilirubin direct', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Bilirubin.direct [Mass/volume] in Serum or Plasma', 'Bilirub Direct SerPl', 'CHEM', 'mg/dL'),

-- Lipid panel
('2093-3', 'Cholesterol total', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Cholesterol [Mass/volume] in Serum or Plasma', 'Cholest SerPl-mCnc', 'CHEM', 'mg/dL'),
('2085-9', 'HDL Cholesterol', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Cholesterol in HDL [Mass/volume] in Serum or Plasma', 'HDLc SerPl-mCnc', 'CHEM', 'mg/dL'),
('2089-1', 'LDL Cholesterol', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Cholesterol in LDL [Mass/volume] in Serum or Plasma', 'LDLc SerPl-mCnc', 'CHEM', 'mg/dL'),
('2571-8', 'Triglycerides', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Triglyceride [Mass/volume] in Serum or Plasma', 'Trigl SerPl-mCnc', 'CHEM', 'mg/dL'),

-- Glucose / Diabetes
('2345-7', 'Glucose', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Glucose [Mass/volume] in Serum or Plasma', 'Glucose SerPl-mCnc', 'CHEM', 'mg/dL'),
('4548-4', 'HbA1c', 'MFr', 'Pt', 'Bld', 'Qn', 'Hemoglobin A1c/Hemoglobin.total in Blood', 'HbA1c MFr Bld', 'CHEM', '%'),

-- Thyroid
('3016-3', 'TSH', 'ACnc', 'Pt', 'Ser/Plas', 'Qn', 'Thyrotropin [Units/volume] in Serum or Plasma', 'TSH SerPl-aCnc', 'CHEM', 'mU/L'),
('3053-6', 'T3 free', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Triiodothyronine (T3) Free [Mass/volume] in Serum or Plasma', 'T3 Free SerPl-mCnc', 'CHEM', 'pg/mL'),
('3024-7', 'T4 free', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Thyroxine (T4) free [Mass/volume] in Serum or Plasma', 'T4 Free SerPl-mCnc', 'CHEM', 'ng/dL'),

-- Cardiac markers
('2157-6', 'CK', 'CCnc', 'Pt', 'Ser/Plas', 'Qn', 'Creatine kinase [Enzymatic activity/volume] in Serum or Plasma', 'CK SerPl-cCnc', 'CHEM', 'U/L'),
('49563-0', 'Troponin I', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Troponin I.cardiac [Mass/volume] in Serum or Plasma', 'Troponin I SerPl', 'CHEM', 'ng/mL'),
('6598-7', 'Troponin T', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Troponin T.cardiac [Mass/volume] in Serum or Plasma', 'Troponin T SerPl', 'CHEM', 'ng/mL'),
('30934-4', 'BNP', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Natriuretic peptide B [Mass/volume] in Serum or Plasma', 'BNP SerPl-mCnc', 'CHEM', 'pg/mL'),
('33762-6', 'NT-proBNP', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Natriuretic peptide.B prohormone N-Terminal [Mass/volume]', 'NT-proBNP SerPl', 'CHEM', 'pg/mL'),

-- Inflammation
('1988-5', 'CRP', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'C reactive protein [Mass/volume] in Serum or Plasma', 'CRP SerPl-mCnc', 'CHEM', 'mg/L'),
('30522-7', 'hs-CRP', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'C reactive protein [Mass/volume] in Serum or Plasma by High sensitivity method', 'hsCRP SerPl', 'CHEM', 'mg/L'),
('4537-7', 'ESR', 'Vel', 'Pt', 'Bld', 'Qn', 'Erythrocyte sedimentation rate', 'ESR Bld Qn', 'HEM/BC', 'mm/h'),
('26515-7', 'Platelets', 'NCnc', 'Pt', 'Bld', 'Qn', 'Platelets [#/volume] in Blood', 'Platelet Bld', 'HEM/BC', '10*9/L'),

-- Iron studies
('2498-4', 'Iron', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Iron [Mass/volume] in Serum or Plasma', 'Iron SerPl-mCnc', 'CHEM', 'ug/dL'),
('2502-3', 'Transferrin', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Transferrin [Mass/volume] in Serum or Plasma', 'Transferrin SerPl', 'CHEM', 'mg/dL'),
('2500-7', 'TIBC', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Iron binding capacity [Mass/volume] in Serum or Plasma', 'TIBC SerPl-mCnc', 'CHEM', 'ug/dL'),
('2276-4', 'Ferritin', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Ferritin [Mass/volume] in Serum or Plasma', 'Ferritin SerPl-mCnc', 'CHEM', 'ng/mL'),

-- Proteins
('2885-2', 'Protein total', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Protein [Mass/volume] in Serum or Plasma', 'Prot SerPl-mCnc', 'CHEM', 'g/dL'),
('1751-7', 'Albumin', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Albumin [Mass/volume] in Serum or Plasma', 'Albumin SerPl-mCnc', 'CHEM', 'g/dL'),

-- Pancreas
('1798-8', 'Amylase', 'CCnc', 'Pt', 'Ser/Plas', 'Qn', 'Amylase [Enzymatic activity/volume] in Serum or Plasma', 'Amylase SerPl-cCnc', 'CHEM', 'U/L'),
('2532-0', 'Lipase', 'CCnc', 'Pt', 'Ser/Plas', 'Qn', 'Lipase [Enzymatic activity/volume] in Serum or Plasma', 'Lipase SerPl-cCnc', 'CHEM', 'U/L'),

-- Urinalysis
('5811-5', 'Specific gravity', 'RelDen', 'Pt', 'Urine', 'Qn', 'Specific gravity of Urine by Test strip', 'Spec Grav Ur Strip', 'UA', '1'),
('5803-2', 'pH', 'SCnc', 'Pt', 'Urine', 'Qn', 'pH of Urine by Test strip', 'pH Ur Strip', 'UA', '[pH]'),
('5804-0', 'Protein urine', 'ACnc', 'Pt', 'Urine', 'Ord', 'Protein [Presence] in Urine by Test strip', 'Prot Ur Strip-Ord', 'UA', NULL),
('5792-7', 'Glucose urine', 'ACnc', 'Pt', 'Urine', 'Ord', 'Glucose [Presence] in Urine by Test strip', 'Glucose Ur Strip-Ord', 'UA', NULL),
('20505-4', 'Leukocyte esterase', 'ACnc', 'Pt', 'Urine', 'Ord', 'Leukocyte esterase [Presence] in Urine by Test strip', 'Leuk Esterase Ur', 'UA', NULL),
('5802-4', 'Nitrite urine', 'ACnc', 'Pt', 'Urine', 'Ord', 'Nitrite [Presence] in Urine by Test strip', 'Nitrite Ur Strip', 'UA', NULL),

-- Blood gases
('2744-1', 'pH blood', 'SCnc', 'Pt', 'BldA', 'Qn', 'pH of Arterial blood', 'pH BldA', 'ABGAS', '[pH]'),
('2019-8', 'pCO2', 'Pres', 'Pt', 'BldA', 'Qn', 'Carbon dioxide [Partial pressure] in Arterial blood', 'pCO2 BldA', 'ABGAS', 'mm[Hg]'),
('2703-7', 'pO2', 'Pres', 'Pt', 'BldA', 'Qn', 'Oxygen [Partial pressure] in Arterial blood', 'pO2 BldA', 'ABGAS', 'mm[Hg]'),
('1960-4', 'Bicarbonate', 'SCnc', 'Pt', 'BldA', 'Qn', 'Bicarbonate [Moles/volume] in Arterial blood', 'HCO3 BldA-sCnc', 'ABGAS', 'mmol/L'),
('1925-7', 'Base excess', 'SCnc', 'Pt', 'BldA', 'Qn', 'Base excess in Arterial blood', 'Base Excess BldA', 'ABGAS', 'mmol/L'),

-- Vitamins
('2132-9', 'Vitamin B12', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Cobalamin (Vitamin B12) [Mass/volume] in Serum or Plasma', 'Vit B12 SerPl-mCnc', 'CHEM', 'pg/mL'),
('2284-8', 'Folate', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', 'Folate [Mass/volume] in Serum or Plasma', 'Folate SerPl-mCnc', 'CHEM', 'ng/mL'),
('1989-3', 'Vitamin D 25-OH', 'SCnc', 'Pt', 'Ser/Plas', 'Qn', '25-Hydroxyvitamin D3 [Mass/volume] in Serum or Plasma', 'Vit D 25-OH SerPl', 'CHEM', 'ng/mL'),

-- Tumor markers
('2857-1', 'PSA', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Prostate specific Ag [Mass/volume] in Serum or Plasma', 'PSA SerPl-mCnc', 'CHEM', 'ng/mL'),
('72518-4', 'CA 125', 'ACnc', 'Pt', 'Ser/Plas', 'Qn', 'Cancer Ag 125 [Units/volume] in Serum or Plasma', 'CA 125 SerPl', 'CHEM', 'U/mL'),
('2039-6', 'CEA', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Carcinoembryonic Ag [Mass/volume] in Serum or Plasma', 'CEA SerPl-mCnc', 'CHEM', 'ng/mL'),
('1834-1', 'AFP', 'MCnc', 'Pt', 'Ser/Plas', 'Qn', 'Alpha-1-Fetoprotein [Mass/volume] in Serum or Plasma', 'AFP SerPl-mCnc', 'CHEM', 'ng/mL');

COMMENT ON TABLE public.loinc_codes IS 'Local LOINC code storage - common laboratory tests without external API dependency';