-- Create table for storing conversation messages
CREATE TABLE public.conversation_messages (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id uuid NOT NULL REFERENCES public.anamnesis_sessions(id) ON DELETE CASCADE,
    role text NOT NULL CHECK (role IN ('user', 'assistant')),
    content text NOT NULL,
    is_red_flag boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);

-- Create index for efficient session lookups
CREATE INDEX idx_conversation_messages_session_id ON public.conversation_messages(session_id);

-- Enable RLS
ALTER TABLE public.conversation_messages ENABLE ROW LEVEL SECURITY;

-- Users can view messages of their own sessions
CREATE POLICY "Users can view messages of own sessions"
ON public.conversation_messages
FOR SELECT
TO authenticated
USING (EXISTS (
    SELECT 1 FROM anamnesis_sessions s
    WHERE s.id = conversation_messages.session_id
    AND s.user_id = auth.uid()
));

-- Users can insert messages for their own sessions
CREATE POLICY "Users can insert messages for own sessions"
ON public.conversation_messages
FOR INSERT
TO authenticated
WITH CHECK (EXISTS (
    SELECT 1 FROM anamnesis_sessions s
    WHERE s.id = conversation_messages.session_id
    AND s.user_id = auth.uid()
));

-- Admins can manage all messages
CREATE POLICY "Admins can manage all messages"
ON public.conversation_messages
FOR ALL
TO authenticated
USING (public.is_admin(auth.uid()));