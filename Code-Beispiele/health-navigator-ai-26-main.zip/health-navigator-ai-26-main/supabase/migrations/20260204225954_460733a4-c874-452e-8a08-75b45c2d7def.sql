-- Tabelle für HPO-Übersetzungen (offiziell + KI-generiert)
CREATE TABLE public.hpo_translations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  hpo_code TEXT NOT NULL UNIQUE,
  label_en TEXT NOT NULL,
  label_de TEXT NOT NULL,
  definition_de TEXT,
  source TEXT NOT NULL DEFAULT 'ai_translated',
  confidence NUMERIC(3,2) DEFAULT 0.90,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Index für schnelle Lookups nach HPO-Code
CREATE INDEX idx_hpo_translations_code ON public.hpo_translations(hpo_code);

-- Index für Quellenfilterung
CREATE INDEX idx_hpo_translations_source ON public.hpo_translations(source);

-- RLS aktivieren
ALTER TABLE public.hpo_translations ENABLE ROW LEVEL SECURITY;

-- Alle authentifizierten Benutzer können Übersetzungen lesen
CREATE POLICY "Authenticated users can read translations"
  ON public.hpo_translations
  FOR SELECT
  TO authenticated
  USING (true);

-- Edge Functions können Übersetzungen einfügen (via service_role)
-- Keine INSERT-Policy für authenticated, da nur Backend schreiben soll

-- Trigger für updated_at
CREATE TRIGGER update_hpo_translations_updated_at
  BEFORE UPDATE ON public.hpo_translations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();