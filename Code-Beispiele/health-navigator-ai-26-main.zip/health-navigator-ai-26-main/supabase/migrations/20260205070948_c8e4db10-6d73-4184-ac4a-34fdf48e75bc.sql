-- Create table for anamnesis pathways
CREATE TABLE public.anamnesis_paths (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id UUID REFERENCES public.anamnesis_sessions(id) ON DELETE CASCADE,
  
  -- HPO codes that this path covers
  hpo_codes TEXT[] NOT NULL DEFAULT '{}',
  
  -- The symptom hierarchy tree structure
  symptom_hierarchy JSONB NOT NULL DEFAULT '{}',
  
  -- Temporal sequence of symptoms with timestamps
  temporal_sequence JSONB NOT NULL DEFAULT '[]',
  
  -- Differential diagnoses with probabilities
  differential_diagnoses JSONB NOT NULL DEFAULT '[]',
  
  -- Question decision tree for next steps
  question_tree JSONB NOT NULL DEFAULT '{}',
  
  -- Mermaid diagram code
  mermaid_diagram TEXT,
  
  -- AI reasoning explanation
  ai_reasoning TEXT,
  
  -- Version tracking for path evolution
  version INTEGER NOT NULL DEFAULT 1,
  
  -- Whether this is a combined path (multiple HPOs)
  is_combined BOOLEAN NOT NULL DEFAULT false,
  
  -- Source observation IDs that contributed to this path
  source_observation_ids UUID[] DEFAULT '{}',
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.anamnesis_paths ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view paths of own sessions"
  ON public.anamnesis_paths
  FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM anamnesis_sessions s 
    WHERE s.id = anamnesis_paths.session_id AND s.user_id = auth.uid()
  ));

CREATE POLICY "Users can create paths for own sessions"
  ON public.anamnesis_paths
  FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM anamnesis_sessions s 
    WHERE s.id = anamnesis_paths.session_id AND s.user_id = auth.uid()
  ));

CREATE POLICY "Users can update paths of own sessions"
  ON public.anamnesis_paths
  FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM anamnesis_sessions s 
    WHERE s.id = anamnesis_paths.session_id AND s.user_id = auth.uid()
  ));

CREATE POLICY "Users can delete paths of own sessions"
  ON public.anamnesis_paths
  FOR DELETE
  USING (EXISTS (
    SELECT 1 FROM anamnesis_sessions s 
    WHERE s.id = anamnesis_paths.session_id AND s.user_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all paths"
  ON public.anamnesis_paths
  FOR ALL
  USING (is_admin(auth.uid()));

-- Create index for faster lookups
CREATE INDEX idx_anamnesis_paths_session ON public.anamnesis_paths(session_id);
CREATE INDEX idx_anamnesis_paths_hpo_codes ON public.anamnesis_paths USING GIN(hpo_codes);

-- Trigger for updated_at
CREATE TRIGGER update_anamnesis_paths_updated_at
  BEFORE UPDATE ON public.anamnesis_paths
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();