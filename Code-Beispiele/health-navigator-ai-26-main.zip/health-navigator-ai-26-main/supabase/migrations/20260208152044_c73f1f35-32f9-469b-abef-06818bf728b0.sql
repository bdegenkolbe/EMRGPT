-- Create knowledge searches table
CREATE TABLE public.knowledge_searches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  query TEXT NOT NULL,
  query_analysis JSONB DEFAULT '{}'::jsonb,
  language TEXT NOT NULL DEFAULT 'de',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create knowledge sources table
CREATE TABLE public.knowledge_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  search_id UUID REFERENCES public.knowledge_searches(id) ON DELETE CASCADE NOT NULL,
  source_type TEXT NOT NULL,  -- 'guideline', 'europepmc'
  external_id TEXT,
  title TEXT NOT NULL,
  authors TEXT,
  year INTEGER,
  
  -- Content loading
  content_status TEXT NOT NULL DEFAULT 'pending',  -- pending, loading, loaded, error
  original_content TEXT,
  original_language TEXT,
  
  -- Translation
  translated_content TEXT,
  target_language TEXT,
  translation_status TEXT NOT NULL DEFAULT 'pending',  -- pending, loading, completed, skipped
  
  -- Metadata
  relevance_score NUMERIC,
  url TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_knowledge_searches_user_id ON public.knowledge_searches(user_id);
CREATE INDEX idx_knowledge_searches_created_at ON public.knowledge_searches(created_at DESC);
CREATE INDEX idx_knowledge_sources_search_id ON public.knowledge_sources(search_id);
CREATE INDEX idx_knowledge_sources_content_status ON public.knowledge_sources(content_status);
CREATE INDEX idx_knowledge_sources_translation_status ON public.knowledge_sources(translation_status);

-- Enable RLS
ALTER TABLE public.knowledge_searches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.knowledge_sources ENABLE ROW LEVEL SECURITY;

-- RLS Policies for knowledge_searches
CREATE POLICY "Users can view own searches"
  ON public.knowledge_searches FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own searches"
  ON public.knowledge_searches FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own searches"
  ON public.knowledge_searches FOR DELETE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all searches"
  ON public.knowledge_searches FOR ALL
  USING (is_admin(auth.uid()));

-- RLS Policies for knowledge_sources
CREATE POLICY "Users can view sources of own searches"
  ON public.knowledge_sources FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.knowledge_searches ks
    WHERE ks.id = knowledge_sources.search_id AND ks.user_id = auth.uid()
  ));

CREATE POLICY "Service role can manage sources"
  ON public.knowledge_sources FOR ALL
  USING ((auth.jwt() ->> 'role'::text) = 'service_role');

CREATE POLICY "Admins can manage all sources"
  ON public.knowledge_sources FOR ALL
  USING (is_admin(auth.uid()));

-- Trigger for updated_at
CREATE TRIGGER update_knowledge_sources_updated_at
  BEFORE UPDATE ON public.knowledge_sources
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();