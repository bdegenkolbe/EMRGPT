-- Create table for SNOMED CT translations (analog to hpo_translations)
CREATE TABLE public.snomed_translations (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    sctid TEXT NOT NULL UNIQUE,
    fsn_en TEXT NOT NULL,
    pt_en TEXT NOT NULL,
    pt_de TEXT NOT NULL,
    definition_de TEXT,
    explanation_de TEXT,
    explanation_en TEXT,
    synonyms TEXT[],
    source TEXT NOT NULL DEFAULT 'ai_translated',
    confidence NUMERIC DEFAULT 0.9,
    verified_at TIMESTAMP WITH TIME ZONE,
    verified_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.snomed_translations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "SNOMED translations are viewable by everyone" 
ON public.snomed_translations 
FOR SELECT 
USING (true);

CREATE POLICY "Only admins can insert SNOMED translations" 
ON public.snomed_translations 
FOR INSERT 
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Only admins can update SNOMED translations" 
ON public.snomed_translations 
FOR UPDATE 
USING (public.is_admin(auth.uid()));

-- Service role needs full access for edge functions
CREATE POLICY "Service role full access for SNOMED translations"
ON public.snomed_translations
FOR ALL
USING (auth.jwt()->>'role' = 'service_role')
WITH CHECK (auth.jwt()->>'role' = 'service_role');

-- Create index for fast lookups
CREATE INDEX idx_snomed_translations_sctid ON public.snomed_translations(sctid);

-- Add trigger for updated_at
CREATE TRIGGER update_snomed_translations_updated_at
BEFORE UPDATE ON public.snomed_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add comment
COMMENT ON TABLE public.snomed_translations IS 'Cache für KI-generierte deutsche SNOMED CT Übersetzungen';