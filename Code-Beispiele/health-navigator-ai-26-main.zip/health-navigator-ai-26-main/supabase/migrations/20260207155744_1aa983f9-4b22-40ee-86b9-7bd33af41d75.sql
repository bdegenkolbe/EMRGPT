-- Create ai_usage_logs table to track ALL AI requests across the application
CREATE TABLE public.ai_usage_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  session_id UUID REFERENCES public.anamnesis_sessions(id),
  
  -- Source identification
  source_type TEXT NOT NULL CHECK (source_type IN ('pipeline', 'chat', 'analysis', 'translation', 'lookup', 'other')),
  source_detail TEXT, -- e.g., 'hpo-analyze', 'snomed-translate', phase name
  
  -- Model information
  provider TEXT NOT NULL, -- 'gemini', 'openai', 'lovable-gateway'
  model TEXT NOT NULL, -- 'gemini-2.0-flash', 'gpt-4o-mini', etc.
  
  -- Token metrics
  prompt_tokens INTEGER NOT NULL DEFAULT 0,
  completion_tokens INTEGER NOT NULL DEFAULT 0,
  total_tokens INTEGER GENERATED ALWAYS AS (prompt_tokens + completion_tokens) STORED,
  
  -- Performance metrics
  latency_ms INTEGER,
  
  -- Request context
  request_metadata JSONB DEFAULT '{}', -- Additional context (e.g., ontology code, input length)
  
  -- Status
  status TEXT NOT NULL DEFAULT 'success' CHECK (status IN ('success', 'error', 'timeout')),
  error_message TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create indexes for efficient querying
CREATE INDEX idx_ai_usage_logs_created_at ON public.ai_usage_logs(created_at DESC);
CREATE INDEX idx_ai_usage_logs_source_type ON public.ai_usage_logs(source_type);
CREATE INDEX idx_ai_usage_logs_user_id ON public.ai_usage_logs(user_id);
CREATE INDEX idx_ai_usage_logs_session_id ON public.ai_usage_logs(session_id);
CREATE INDEX idx_ai_usage_logs_provider ON public.ai_usage_logs(provider);

-- Enable RLS
ALTER TABLE public.ai_usage_logs ENABLE ROW LEVEL SECURITY;

-- Admin can view all logs
CREATE POLICY "Admins can view all AI usage logs"
ON public.ai_usage_logs
FOR SELECT
USING (public.is_admin(auth.uid()));

-- Users can view their own logs
CREATE POLICY "Users can view their own AI usage logs"
ON public.ai_usage_logs
FOR SELECT
USING (auth.uid() = user_id);

-- Service role can insert logs (from edge functions)
CREATE POLICY "Service role can insert AI usage logs"
ON public.ai_usage_logs
FOR INSERT
WITH CHECK (true);

-- Create a view for aggregated statistics
CREATE OR REPLACE VIEW public.ai_usage_statistics AS
SELECT
  date_trunc('day', created_at) as day,
  source_type,
  provider,
  model,
  COUNT(*) as request_count,
  SUM(prompt_tokens) as total_prompt_tokens,
  SUM(completion_tokens) as total_completion_tokens,
  SUM(prompt_tokens + completion_tokens) as total_tokens,
  AVG(latency_ms)::integer as avg_latency_ms,
  COUNT(*) FILTER (WHERE status = 'error') as error_count
FROM public.ai_usage_logs
GROUP BY date_trunc('day', created_at), source_type, provider, model
ORDER BY day DESC, total_tokens DESC;