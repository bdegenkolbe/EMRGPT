-- Clean HTML tags from existing guideline titles and descriptions
UPDATE guidelines 
SET title = regexp_replace(title, '<[^>]+>', '', 'g')
WHERE title ~ '<[^>]+>';

UPDATE guidelines 
SET description = regexp_replace(description, '<[^>]+>', '', 'g')
WHERE description ~ '<[^>]+>';