-- =========================================
-- 1. SNOMED_CODES Tabelle (fehlt komplett)
-- =========================================
CREATE TABLE IF NOT EXISTS public.snomed_codes (
  sctid TEXT PRIMARY KEY,
  fsn TEXT NOT NULL,
  pt TEXT NOT NULL,
  semantic_tag TEXT,
  is_active BOOLEAN DEFAULT true,
  effective_time DATE,
  module_id TEXT,
  definition_status TEXT,
  parent_codes TEXT[] DEFAULT '{}',
  is_terminal BOOLEAN DEFAULT true,
  level INTEGER DEFAULT 0,
  labels JSONB DEFAULT '{}',
  source TEXT DEFAULT 'snowstorm_api',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Index für Suche
CREATE INDEX IF NOT EXISTS idx_snomed_codes_pt ON public.snomed_codes USING gin(to_tsvector('german', pt));
CREATE INDEX IF NOT EXISTS idx_snomed_codes_fsn ON public.snomed_codes USING gin(to_tsvector('english', fsn));
CREATE INDEX IF NOT EXISTS idx_snomed_codes_labels ON public.snomed_codes USING gin(labels);

-- RLS
ALTER TABLE public.snomed_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "SNOMED codes are publicly readable" ON public.snomed_codes
  FOR SELECT USING (true);

CREATE POLICY "Only admins can modify SNOMED codes" ON public.snomed_codes
  FOR ALL USING (is_admin(auth.uid()));

-- =========================================
-- 2. ICD10GM_TRANSLATIONS Tabelle (fehlt)
-- =========================================
CREATE TABLE IF NOT EXISTS public.icd10gm_translations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  icd_code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  title_short TEXT,
  explanation_de TEXT,
  explanation_en TEXT,
  explanations JSONB DEFAULT '{}',
  labels JSONB DEFAULT '{}',
  synonyms TEXT[] DEFAULT '{}',
  source TEXT DEFAULT 'official',
  confidence NUMERIC DEFAULT 1.0,
  verified_at TIMESTAMPTZ,
  verified_by UUID,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_icd10gm_translations_labels ON public.icd10gm_translations USING gin(labels);

ALTER TABLE public.icd10gm_translations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ICD-10 translations are publicly readable" ON public.icd10gm_translations
  FOR SELECT USING (true);

CREATE POLICY "Only admins can modify ICD-10 translations" ON public.icd10gm_translations
  FOR ALL USING (is_admin(auth.uid()));

CREATE POLICY "Service role full access for ICD-10 translations" ON public.icd10gm_translations
  FOR ALL USING ((auth.jwt() ->> 'role') = 'service_role')
  WITH CHECK ((auth.jwt() ->> 'role') = 'service_role');

-- =========================================
-- 3. ORPHANET_ANALYSES Tabelle (fehlt)
-- =========================================
CREATE TABLE IF NOT EXISTS public.orphanet_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  orpha_code TEXT NOT NULL UNIQUE,
  content JSONB NOT NULL DEFAULT '{}',
  hpo_mappings JSONB DEFAULT '[]',
  snomed_mappings JSONB DEFAULT '[]',
  icd10_mappings JSONB DEFAULT '[]',
  omim_mappings JSONB DEFAULT '[]',
  source_language TEXT NOT NULL DEFAULT 'de',
  generated_at TIMESTAMPTZ,
  generated_by UUID,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orphanet_analyses_orpha_code ON public.orphanet_analyses(orpha_code);

ALTER TABLE public.orphanet_analyses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Orphanet analyses are publicly readable" ON public.orphanet_analyses
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create Orphanet analyses" ON public.orphanet_analyses
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update Orphanet analyses" ON public.orphanet_analyses
  FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Only admins can delete Orphanet analyses" ON public.orphanet_analyses
  FOR DELETE USING (is_admin(auth.uid()));

-- =========================================
-- 4. HPO_CODES Tabelle (fehlt - nur translations existiert)
-- =========================================
CREATE TABLE IF NOT EXISTS public.hpo_codes (
  hpo_code TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  definition TEXT,
  synonyms TEXT[] DEFAULT '{}',
  parent_codes TEXT[] DEFAULT '{}',
  is_terminal BOOLEAN DEFAULT true,
  level INTEGER DEFAULT 0,
  labels JSONB DEFAULT '{}',
  source TEXT DEFAULT 'ols4_api',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_hpo_codes_label ON public.hpo_codes USING gin(to_tsvector('english', label));
CREATE INDEX IF NOT EXISTS idx_hpo_codes_labels ON public.hpo_codes USING gin(labels);

ALTER TABLE public.hpo_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "HPO codes are publicly readable" ON public.hpo_codes
  FOR SELECT USING (true);

CREATE POLICY "Only admins can modify HPO codes" ON public.hpo_codes
  FOR ALL USING (is_admin(auth.uid()));

CREATE POLICY "Service role full access for HPO codes" ON public.hpo_codes
  FOR ALL USING ((auth.jwt() ->> 'role') = 'service_role')
  WITH CHECK ((auth.jwt() ->> 'role') = 'service_role');