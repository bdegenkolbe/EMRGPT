
-- Delete duplicate conditions (keep first per patient+code_display)
DELETE FROM fhir_conditions WHERE id IN (
  SELECT id FROM (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY patient_id, code_display ORDER BY fhir_id) as rn
    FROM fhir_conditions
  ) sub WHERE rn > 1
);

-- Delete duplicate observations (keep first per patient+code_display)
DELETE FROM fhir_observations WHERE id IN (
  SELECT id FROM (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY patient_id, code_display ORDER BY fhir_id) as rn
    FROM fhir_observations
  ) sub WHERE rn > 1
);

-- Delete duplicate medication_requests (keep first per patient+medication_display)
DELETE FROM fhir_medication_requests WHERE id IN (
  SELECT id FROM (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY patient_id, medication_display ORDER BY fhir_id) as rn
    FROM fhir_medication_requests
  ) sub WHERE rn > 1
);

-- Delete duplicate encounters (keep first per patient+type_display)
DELETE FROM fhir_encounters WHERE id IN (
  SELECT id FROM (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY patient_id, type_display ORDER BY fhir_id) as rn
    FROM fhir_encounters
  ) sub WHERE rn > 1
);

-- Delete duplicate allergies (keep first per patient+code_display)
DELETE FROM fhir_allergies WHERE id IN (
  SELECT id FROM (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY patient_id, code_display ORDER BY fhir_id) as rn
    FROM fhir_allergies
  ) sub WHERE rn > 1
);

-- Update patient names to realistic German names
UPDATE fhir_patients SET given_name = 'Anna', family_name = 'Schneider', birth_date = '1985-06-12', gender = 'female' WHERE fhir_id = 'patient-01';
UPDATE fhir_patients SET given_name = 'Thomas', family_name = 'Weber', birth_date = '1958-11-03', gender = 'male' WHERE fhir_id = 'patient-02';
UPDATE fhir_patients SET given_name = 'Maria', family_name = 'Fischer', birth_date = '1972-02-28', gender = 'female' WHERE fhir_id = 'patient-03';
UPDATE fhir_patients SET given_name = 'Stefan', family_name = 'Braun', birth_date = '1990-08-15', gender = 'male' WHERE fhir_id = 'patient-04';
UPDATE fhir_patients SET given_name = 'Claudia', family_name = 'Hoffmann', birth_date = '1965-04-22', gender = 'female' WHERE fhir_id = 'patient-05';
UPDATE fhir_patients SET given_name = 'Michael', family_name = 'Wagner', birth_date = '1948-12-07', gender = 'male' WHERE fhir_id = 'patient-06';
UPDATE fhir_patients SET given_name = 'Sabine', family_name = 'Becker', birth_date = '1983-09-19', gender = 'female' WHERE fhir_id = 'patient-07';
UPDATE fhir_patients SET given_name = 'Markus', family_name = 'Schäfer', birth_date = '1975-01-30', gender = 'male' WHERE fhir_id = 'patient-08';
UPDATE fhir_patients SET given_name = 'Elisabeth', family_name = 'Koch', birth_date = '1995-07-14', gender = 'female' WHERE fhir_id = 'patient-09';
UPDATE fhir_patients SET given_name = 'Andreas', family_name = 'Richter', birth_date = '1962-03-25', gender = 'male' WHERE fhir_id = 'patient-10';
