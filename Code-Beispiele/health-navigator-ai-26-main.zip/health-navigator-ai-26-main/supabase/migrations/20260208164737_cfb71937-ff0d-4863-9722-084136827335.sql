-- Add column to store AI response in knowledge_searches
ALTER TABLE public.knowledge_searches
ADD COLUMN ai_response text DEFAULT NULL;

-- Add column to track if answer was generated
ALTER TABLE public.knowledge_searches
ADD COLUMN answer_generated_at timestamp with time zone DEFAULT NULL;

COMMENT ON COLUMN public.knowledge_searches.ai_response IS 'The AI-generated answer for this search query';
COMMENT ON COLUMN public.knowledge_searches.answer_generated_at IS 'Timestamp when the AI answer was generated';