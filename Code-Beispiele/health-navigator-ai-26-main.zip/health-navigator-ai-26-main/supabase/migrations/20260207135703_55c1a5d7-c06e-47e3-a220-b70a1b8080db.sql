-- ============================================================================
-- Migration: Mehrsprachige Labels via JSONB für HPO, SNOMED, ICD-10
-- Konsolidiert bestehende Spalten in JSONB-Format für flexibles Multi-Language
-- ============================================================================

-- 1. HPO_TRANSLATIONS: labels JSONB Spalte hinzufügen
ALTER TABLE public.hpo_translations 
ADD COLUMN IF NOT EXISTS labels jsonb DEFAULT '{}'::jsonb;

-- Bestehende Daten migrieren
UPDATE public.hpo_translations 
SET labels = jsonb_build_object(
  'de', COALESCE(label_de, ''),
  'en', COALESCE(label_en, '')
)
WHERE labels = '{}'::jsonb OR labels IS NULL;

-- 2. HPO_TRANSLATIONS: definitions JSONB Spalte hinzufügen
ALTER TABLE public.hpo_translations 
ADD COLUMN IF NOT EXISTS definitions jsonb DEFAULT '{}'::jsonb;

UPDATE public.hpo_translations 
SET definitions = jsonb_build_object(
  'de', COALESCE(definition_de, ''),
  'en', COALESCE(definition_en, '')
)
WHERE definitions = '{}'::jsonb OR definitions IS NULL;

-- 3. HPO_TRANSLATIONS: explanations JSONB Spalte hinzufügen
ALTER TABLE public.hpo_translations 
ADD COLUMN IF NOT EXISTS explanations jsonb DEFAULT '{}'::jsonb;

UPDATE public.hpo_translations 
SET explanations = jsonb_build_object(
  'de', COALESCE(explanation_de, ''),
  'en', COALESCE(explanation_en, '')
)
WHERE explanations = '{}'::jsonb OR explanations IS NULL;

-- 4. SNOMED_TRANSLATIONS: labels JSONB Spalte hinzufügen
ALTER TABLE public.snomed_translations 
ADD COLUMN IF NOT EXISTS labels jsonb DEFAULT '{}'::jsonb;

UPDATE public.snomed_translations 
SET labels = jsonb_build_object(
  'de', COALESCE(pt_de, ''),
  'en', COALESCE(pt_en, '')
)
WHERE labels = '{}'::jsonb OR labels IS NULL;

-- 5. SNOMED_TRANSLATIONS: explanations JSONB Spalte hinzufügen
ALTER TABLE public.snomed_translations 
ADD COLUMN IF NOT EXISTS explanations jsonb DEFAULT '{}'::jsonb;

UPDATE public.snomed_translations 
SET explanations = jsonb_build_object(
  'de', COALESCE(explanation_de, ''),
  'en', COALESCE(explanation_en, '')
)
WHERE explanations = '{}'::jsonb OR explanations IS NULL;

-- 6. ICD10GM_CODES: labels JSONB Spalte hinzufügen (für zusätzliche Sprachen)
ALTER TABLE public.icd10gm_codes 
ADD COLUMN IF NOT EXISTS labels jsonb DEFAULT '{}'::jsonb;

-- ICD-10-GM ist bereits Deutsch, initialisiere mit bestehendem title
UPDATE public.icd10gm_codes 
SET labels = jsonb_build_object(
  'de', COALESCE(title, '')
)
WHERE labels = '{}'::jsonb OR labels IS NULL;

-- 7. Index für performante JSONB-Abfragen
CREATE INDEX IF NOT EXISTS idx_hpo_translations_labels_gin 
ON public.hpo_translations USING gin (labels);

CREATE INDEX IF NOT EXISTS idx_snomed_translations_labels_gin 
ON public.snomed_translations USING gin (labels);

CREATE INDEX IF NOT EXISTS idx_icd10gm_codes_labels_gin 
ON public.icd10gm_codes USING gin (labels);

-- 8. Kommentar zur Dokumentation
COMMENT ON COLUMN public.hpo_translations.labels IS 'Multi-language labels: {"de": "...", "en": "...", "fr": "...", etc.}';
COMMENT ON COLUMN public.hpo_translations.definitions IS 'Multi-language definitions';
COMMENT ON COLUMN public.hpo_translations.explanations IS 'Multi-language AI-generated explanations';
COMMENT ON COLUMN public.snomed_translations.labels IS 'Multi-language preferred terms';
COMMENT ON COLUMN public.snomed_translations.explanations IS 'Multi-language AI-generated explanations';
COMMENT ON COLUMN public.icd10gm_codes.labels IS 'Multi-language labels (original is German)';