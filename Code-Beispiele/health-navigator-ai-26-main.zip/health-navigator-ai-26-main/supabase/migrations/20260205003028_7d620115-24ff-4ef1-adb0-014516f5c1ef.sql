-- Add explanation columns to hpo_translations table
ALTER TABLE public.hpo_translations
ADD COLUMN IF NOT EXISTS explanation_de TEXT,
ADD COLUMN IF NOT EXISTS explanation_generated_at TIMESTAMP WITH TIME ZONE;

-- Add index for faster lookup
CREATE INDEX IF NOT EXISTS idx_hpo_translations_hpo_code ON public.hpo_translations(hpo_code);

-- Comment for documentation
COMMENT ON COLUMN public.hpo_translations.explanation_de IS 'KI-generierte deutsche Erklärung des HPO-Begriffs';
COMMENT ON COLUMN public.hpo_translations.explanation_generated_at IS 'Zeitpunkt der KI-Erklärungsgenerierung';