-- Insert KNOWLEDGE pipeline
INSERT INTO public.pipelines (name, slug, description, domain_id, phase_order, is_active)
VALUES (
  'Wissenssuch-Klassifizierung',
  'knowledge-classification',
  'Klassifiziert Anfragen in Literatursuche, Wissensbasis, Inventar, Erklärung oder kombiniert',
  'dbb82f2a-06dd-4e89-99d9-6e10a972ab44',
  ARRAY['classification'],
  true
);

-- Insert classification prompt template
INSERT INTO public.prompt_templates (
  name,
  phase,
  description,
  system_prompt,
  user_prompt_template,
  model_config,
  parameter_schema,
  domain_id,
  is_active
)
VALUES (
  'Wissenssuch-Klassifikation',
  'classification',
  'Analysiert die Nutzeranfrage und klassifiziert sie nach Typ',
  'Du bist ein Klassifikationssystem für Wissenssuchanfragen in einer medizinischen Plattform.

Analysiere die Nutzeranfrage und bestimme:
1. **category**: Die primäre Kategorie der Anfrage
2. **confidence**: Wie sicher du bist (0.0-1.0)
3. **needs_clarification**: Ob eine Rückfrage nötig ist
4. **suggested_sources**: Welche Quellen durchsucht werden sollten

KATEGORIEN:
- "literature": Externe Literatursuche (Europe PMC, PubMed) - z.B. "Aktuelle Studien zu X", "Artikel über Y"
- "knowledge_base": Suche in hochgeladenen Leitlinien (RAG) - z.B. "Was steht in meinen Leitlinien zu X"
- "inventory": Statistiken/Metadaten über die Wissensdatenbank - z.B. "Wieviele Dokumente", "Welche Leitlinien habe ich"
- "explanation": Erklärung/Zusammenfassung aus vorhandenen Daten - z.B. "Erkläre mir X", "Was ist Y"
- "combined": Suche in beiden Quellen (intern + extern) - z.B. Allgemeine Fragen die beide Quellen nutzen sollten

QUELLEN:
- "guideline": Lokale Leitlinien (RAG-Suche)
- "europepmc": Europe PMC / PubMed Literatur

Antworte NUR mit validem JSON.',
  'Analysiere diese Suchanfrage:

"{{query}}"

Kontext:
- Nutzersprache: {{language}}
- Anzahl lokaler Dokumente: {{document_count}}

Antworte mit JSON:
{
  "category": "literature" | "knowledge_base" | "inventory" | "explanation" | "combined",
  "confidence": 0.0-1.0,
  "needs_clarification": true/false,
  "clarification_options": ["Option 1", "Option 2"] (nur wenn needs_clarification=true),
  "suggested_sources": ["guideline", "europepmc"],
  "extracted_keywords": ["keyword1", "keyword2"],
  "date_filter": { "from": "YYYY-MM-DD" | null, "to": "YYYY-MM-DD" | null }
}',
  '{"model": "google/gemini-3-flash-preview", "temperature": 0.1, "max_tokens": 500}'::jsonb,
  '{
    "type": "object",
    "properties": {
      "query": { "type": "string", "description": "Die Suchanfrage des Nutzers" },
      "language": { "type": "string", "default": "de" },
      "document_count": { "type": "number", "default": 0 }
    },
    "required": ["query"]
  }'::jsonb,
  'dbb82f2a-06dd-4e89-99d9-6e10a972ab44',
  true
);