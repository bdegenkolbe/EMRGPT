-- Create function to increment term usage count
CREATE OR REPLACE FUNCTION public.increment_term_usage(term_id UUID)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.term_translations 
  SET usage_count = usage_count + 1 
  WHERE id = term_id;
$$;