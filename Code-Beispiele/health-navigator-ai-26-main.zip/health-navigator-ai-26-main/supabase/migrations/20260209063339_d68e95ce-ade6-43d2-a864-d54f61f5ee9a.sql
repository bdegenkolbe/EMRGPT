-- Fix security definer views by recreating with SECURITY INVOKER

-- 1. Fix background_job_summary (just created)
DROP VIEW IF EXISTS public.background_job_summary;
CREATE VIEW public.background_job_summary
WITH (security_invoker = true) AS
SELECT 
  search_id,
  batch_id,
  job_type,
  COUNT(*) FILTER (WHERE status = 'pending') AS pending_count,
  COUNT(*) FILTER (WHERE status = 'running') AS running_count,
  COUNT(*) FILTER (WHERE status = 'completed') AS completed_count,
  COUNT(*) FILTER (WHERE status = 'failed') AS failed_count,
  COUNT(*) AS total_count
FROM public.background_jobs
GROUP BY search_id, batch_id, job_type;

-- 2. Fix ai_usage_statistics (pre-existing view)
DROP VIEW IF EXISTS public.ai_usage_statistics;
CREATE VIEW public.ai_usage_statistics
WITH (security_invoker = true) AS
SELECT 
  date_trunc('day', created_at) AS day,
  provider,
  model,
  source_type,
  COUNT(*) AS request_count,
  SUM(prompt_tokens) AS total_prompt_tokens,
  SUM(completion_tokens) AS total_completion_tokens,
  SUM(total_tokens) AS total_tokens,
  AVG(latency_ms)::integer AS avg_latency_ms,
  COUNT(*) FILTER (WHERE status = 'error') AS error_count
FROM public.ai_usage_logs
GROUP BY date_trunc('day', created_at), provider, model, source_type;