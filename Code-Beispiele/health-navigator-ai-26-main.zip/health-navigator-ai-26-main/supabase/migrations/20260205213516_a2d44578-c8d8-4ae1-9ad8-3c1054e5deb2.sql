-- Add embedding progress field to track vectorization progress
ALTER TABLE public.guidelines 
ADD COLUMN IF NOT EXISTS embedding_progress integer DEFAULT 0;

-- Add comment for documentation
COMMENT ON COLUMN public.guidelines.embedding_progress IS 'Fortschritt der Vektorisierung in Prozent (0-100)';