-- Fix security issues from the previous migration

-- 1. Drop and recreate the view WITHOUT SECURITY DEFINER
DROP VIEW IF EXISTS public.ai_usage_statistics;

CREATE VIEW public.ai_usage_statistics AS
SELECT
  date_trunc('day', created_at) as day,
  source_type,
  provider,
  model,
  COUNT(*) as request_count,
  SUM(prompt_tokens) as total_prompt_tokens,
  SUM(completion_tokens) as total_completion_tokens,
  SUM(prompt_tokens + completion_tokens) as total_tokens,
  AVG(latency_ms)::integer as avg_latency_ms,
  COUNT(*) FILTER (WHERE status = 'error') as error_count
FROM public.ai_usage_logs
GROUP BY date_trunc('day', created_at), source_type, provider, model
ORDER BY day DESC, total_tokens DESC;

-- Grant access to authenticated users (respects underlying table RLS)
GRANT SELECT ON public.ai_usage_statistics TO authenticated;

-- 2. Fix the permissive INSERT policy - replace with a proper check
-- First drop the old permissive policy
DROP POLICY IF EXISTS "Service role can insert AI usage logs" ON public.ai_usage_logs;

-- Create a policy that allows edge functions (service role) to insert
-- Edge functions use service_role, so we check for that in the JWT
CREATE POLICY "Edge functions can insert AI usage logs"
ON public.ai_usage_logs
FOR INSERT
WITH CHECK (
  -- Allow service_role (edge functions)
  (auth.jwt() ->> 'role' = 'service_role')
  OR
  -- Allow authenticated users to insert their own logs
  (auth.uid() IS NOT NULL AND (user_id IS NULL OR user_id = auth.uid()))
);