-- Create scheduled sync jobs configuration table
CREATE TABLE public.scheduled_sync_jobs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  source_name TEXT NOT NULL UNIQUE,
  is_enabled BOOLEAN NOT NULL DEFAULT false,
  cron_expression TEXT NOT NULL DEFAULT '0 3 * * 0', -- Default: Sunday 3am
  last_run_at TIMESTAMPTZ,
  next_run_at TIMESTAMPTZ,
  last_run_status TEXT,
  last_run_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT valid_source_name CHECK (source_name IN ('hpo', 'snomed', 'icd11', 'orphanet'))
);

-- Enable RLS
ALTER TABLE public.scheduled_sync_jobs ENABLE ROW LEVEL SECURITY;

-- Only allow authenticated users to view/edit
CREATE POLICY "Authenticated users can view scheduled jobs" 
  ON public.scheduled_sync_jobs 
  FOR SELECT 
  TO authenticated 
  USING (true);

CREATE POLICY "Authenticated users can update scheduled jobs" 
  ON public.scheduled_sync_jobs 
  FOR UPDATE 
  TO authenticated 
  USING (true);

-- Insert default configurations for all sources
INSERT INTO public.scheduled_sync_jobs (source_name, cron_expression, is_enabled) VALUES
  ('hpo', '0 3 * * 0', false),      -- Sunday 3am
  ('snomed', '0 4 * * 0', false),   -- Sunday 4am
  ('icd11', '0 5 * * 0', false);    -- Sunday 5am

-- Create index for quick lookups
CREATE INDEX idx_scheduled_sync_jobs_source ON public.scheduled_sync_jobs(source_name);
CREATE INDEX idx_scheduled_sync_jobs_enabled ON public.scheduled_sync_jobs(is_enabled) WHERE is_enabled = true;