-- Create table for ICD-10-GM AI analyses with multilingual content
CREATE TABLE public.icd10gm_analyses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  icd_code TEXT NOT NULL UNIQUE,
  
  -- Multilingual content stored as JSON: { "de": { explanation, symptoms, therapy, notes }, "en": {...} }
  content JSONB NOT NULL DEFAULT '{}'::jsonb,
  
  -- Source language of original AI generation
  source_language TEXT NOT NULL DEFAULT 'de',
  
  -- Mappings to other ontologies
  hpo_mappings JSONB DEFAULT '[]'::jsonb, -- [{ code, label_de, label_en, relation }]
  snomed_mappings JSONB DEFAULT '[]'::jsonb, -- [{ sctid, pt_de, pt_en, relation }]
  symptom_mappings JSONB DEFAULT '[]'::jsonb, -- [{ symptom, hpo_code, snomed_code }]
  
  -- Metadata
  generated_at TIMESTAMP WITH TIME ZONE,
  generated_by UUID REFERENCES auth.users(id),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.icd10gm_analyses ENABLE ROW LEVEL SECURITY;

-- Everyone can read analyses
CREATE POLICY "ICD-10 analyses are publicly readable"
  ON public.icd10gm_analyses
  FOR SELECT
  USING (true);

-- Authenticated users can create analyses
CREATE POLICY "Authenticated users can create analyses"
  ON public.icd10gm_analyses
  FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- Authenticated users can update analyses
CREATE POLICY "Authenticated users can update analyses"
  ON public.icd10gm_analyses
  FOR UPDATE
  USING (auth.uid() IS NOT NULL);

-- Only admins can delete analyses
CREATE POLICY "Only admins can delete analyses"
  ON public.icd10gm_analyses
  FOR DELETE
  USING (is_admin(auth.uid()));

-- Create index for fast lookup by code
CREATE INDEX idx_icd10gm_analyses_code ON public.icd10gm_analyses(icd_code);

-- Auto-update timestamp trigger
CREATE TRIGGER update_icd10gm_analyses_updated_at
  BEFORE UPDATE ON public.icd10gm_analyses
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();