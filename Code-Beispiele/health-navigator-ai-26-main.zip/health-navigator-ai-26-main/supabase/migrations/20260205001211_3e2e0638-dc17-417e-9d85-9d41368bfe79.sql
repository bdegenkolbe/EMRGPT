-- Create table for storing German-to-English term translations
CREATE TABLE public.term_translations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  german_term TEXT NOT NULL,
  english_term TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'user', -- 'user', 'ai_learned', 'system'
  usage_count INTEGER NOT NULL DEFAULT 0,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(german_term)
);

-- Enable RLS
ALTER TABLE public.term_translations ENABLE ROW LEVEL SECURITY;

-- Everyone can read translations (they're shared knowledge)
CREATE POLICY "Anyone authenticated can read translations"
ON public.term_translations
FOR SELECT
TO authenticated
USING (true);

-- Admins can manage all translations
CREATE POLICY "Admins can manage translations"
ON public.term_translations
FOR ALL
TO authenticated
USING (is_admin(auth.uid()));

-- Users can create translations
CREATE POLICY "Authenticated users can create translations"
ON public.term_translations
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = created_by OR created_by IS NULL);

-- Create index for fast lookups
CREATE INDEX idx_term_translations_german ON public.term_translations(german_term);
CREATE INDEX idx_term_translations_german_lower ON public.term_translations(LOWER(german_term));

-- Trigger for updated_at
CREATE TRIGGER update_term_translations_updated_at
BEFORE UPDATE ON public.term_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert initial system translations (the hardcoded ones)
INSERT INTO public.term_translations (german_term, english_term, source) VALUES
('kopfschmerzen', 'headache', 'system'),
('kopfschmerz', 'headache', 'system'),
('migräne', 'migraine', 'system'),
('schwindel', 'vertigo dizziness', 'system'),
('übelkeit', 'nausea', 'system'),
('erbrechen', 'vomiting', 'system'),
('fieber', 'fever', 'system'),
('husten', 'cough', 'system'),
('atemnot', 'dyspnea shortness of breath', 'system'),
('brustschmerzen', 'chest pain', 'system'),
('bauchschmerzen', 'abdominal pain', 'system'),
('durchfall', 'diarrhea', 'system'),
('verstopfung', 'constipation', 'system'),
('müdigkeit', 'fatigue tiredness', 'system'),
('schlafstörung', 'insomnia sleep disturbance', 'system'),
('angst', 'anxiety', 'system'),
('depression', 'depression', 'system'),
('hautausschlag', 'rash skin eruption', 'system'),
('juckreiz', 'pruritus itching', 'system'),
('schwellung', 'swelling edema', 'system'),
('schmerz', 'pain', 'system'),
('gelenkschmerzen', 'joint pain arthralgia', 'system'),
('rückenschmerzen', 'back pain', 'system'),
('herzrasen', 'tachycardia palpitations', 'system'),
('bluthochdruck', 'hypertension', 'system'),
('diabetes', 'diabetes mellitus', 'system'),
('allergie', 'allergy hypersensitivity', 'system'),
('asthma', 'asthma', 'system'),
('epilepsie', 'epilepsy seizure', 'system'),
('krampfanfall', 'seizure convulsion', 'system'),
('bewusstlosigkeit', 'unconsciousness syncope', 'system'),
('sehstörung', 'visual impairment', 'system'),
('hörverlust', 'hearing loss', 'system'),
('taubheit', 'numbness paresthesia', 'system'),
('lähmung', 'paralysis', 'system'),
('tremor', 'tremor', 'system'),
('gewichtsverlust', 'weight loss', 'system'),
('appetitlosigkeit', 'anorexia loss of appetite', 'system')
ON CONFLICT (german_term) DO NOTHING;