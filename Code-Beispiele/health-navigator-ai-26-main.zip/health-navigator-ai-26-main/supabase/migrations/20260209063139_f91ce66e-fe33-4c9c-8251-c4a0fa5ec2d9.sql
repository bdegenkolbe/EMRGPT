-- Table to track background processing jobs (PDF downloads, content loading, translations)
CREATE TABLE public.background_jobs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  
  -- Job classification
  job_type TEXT NOT NULL, -- 'pdf_download', 'content_load', 'translate'
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'running', 'completed', 'failed'
  
  -- Context reference
  search_id UUID REFERENCES public.knowledge_searches(id) ON DELETE CASCADE,
  source_id UUID REFERENCES public.knowledge_sources(id) ON DELETE CASCADE,
  
  -- Job payload (e.g. pmcid, title, metadata)
  payload JSONB NOT NULL DEFAULT '{}',
  
  -- Result/error tracking
  result JSONB,
  error_message TEXT,
  
  -- Progress for batch jobs
  progress_current INTEGER DEFAULT 0,
  progress_total INTEGER DEFAULT 0,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  
  -- For self-invocation loop: which batch this job belongs to
  batch_id UUID
);

-- Indexes for efficient querying
CREATE INDEX idx_background_jobs_status ON public.background_jobs(status);
CREATE INDEX idx_background_jobs_search_id ON public.background_jobs(search_id);
CREATE INDEX idx_background_jobs_batch_id ON public.background_jobs(batch_id);
CREATE INDEX idx_background_jobs_pending ON public.background_jobs(status, created_at) WHERE status = 'pending';

-- Enable RLS
ALTER TABLE public.background_jobs ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view jobs for own searches"
  ON public.background_jobs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM knowledge_searches ks
      WHERE ks.id = background_jobs.search_id
        AND ks.user_id = auth.uid()
    )
  );

CREATE POLICY "Service role can manage all jobs"
  ON public.background_jobs FOR ALL
  USING (((auth.jwt() ->> 'role'::text) = 'service_role'::text))
  WITH CHECK (((auth.jwt() ->> 'role'::text) = 'service_role'::text));

CREATE POLICY "Admins can manage all jobs"
  ON public.background_jobs FOR ALL
  USING (is_admin(auth.uid()));

-- Summary view for polling
CREATE OR REPLACE VIEW public.background_job_summary AS
SELECT 
  search_id,
  batch_id,
  job_type,
  COUNT(*) FILTER (WHERE status = 'pending') AS pending_count,
  COUNT(*) FILTER (WHERE status = 'running') AS running_count,
  COUNT(*) FILTER (WHERE status = 'completed') AS completed_count,
  COUNT(*) FILTER (WHERE status = 'failed') AS failed_count,
  COUNT(*) AS total_count
FROM public.background_jobs
GROUP BY search_id, batch_id, job_type;