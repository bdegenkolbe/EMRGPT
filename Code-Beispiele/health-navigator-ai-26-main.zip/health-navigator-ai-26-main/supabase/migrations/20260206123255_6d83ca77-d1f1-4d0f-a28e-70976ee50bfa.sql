-- Create storage bucket for ICD-10-GM imports
INSERT INTO storage.buckets (id, name, public)
VALUES ('icd10gm-imports', 'icd10gm-imports', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: only admins can access
CREATE POLICY "Admins can upload ICD-10-GM files"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'icd10gm-imports' 
  AND public.is_admin(auth.uid())
);

CREATE POLICY "Admins can read ICD-10-GM files"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'icd10gm-imports' 
  AND public.is_admin(auth.uid())
);

CREATE POLICY "Admins can delete ICD-10-GM files"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'icd10gm-imports' 
  AND public.is_admin(auth.uid())
);