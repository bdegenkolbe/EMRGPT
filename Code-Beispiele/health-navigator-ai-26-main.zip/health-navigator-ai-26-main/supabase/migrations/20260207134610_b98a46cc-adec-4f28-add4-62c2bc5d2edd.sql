-- Create HPO analyses table (like icd10gm_analyses)
CREATE TABLE public.hpo_analyses (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  hpo_code text NOT NULL UNIQUE,
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  source_language text NOT NULL DEFAULT 'de',
  icd10_mappings jsonb DEFAULT '[]'::jsonb,
  snomed_mappings jsonb DEFAULT '[]'::jsonb,
  generated_at timestamp with time zone,
  generated_by uuid REFERENCES auth.users(id),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create SNOMED analyses table (like icd10gm_analyses)
CREATE TABLE public.snomed_analyses (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sctid text NOT NULL UNIQUE,
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  source_language text NOT NULL DEFAULT 'de',
  hpo_mappings jsonb DEFAULT '[]'::jsonb,
  icd10_mappings jsonb DEFAULT '[]'::jsonb,
  generated_at timestamp with time zone,
  generated_by uuid REFERENCES auth.users(id),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.hpo_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.snomed_analyses ENABLE ROW LEVEL SECURITY;

-- RLS policies for hpo_analyses
CREATE POLICY "HPO analyses are publicly readable"
  ON public.hpo_analyses FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create HPO analyses"
  ON public.hpo_analyses FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update HPO analyses"
  ON public.hpo_analyses FOR UPDATE
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Only admins can delete HPO analyses"
  ON public.hpo_analyses FOR DELETE
  USING (is_admin(auth.uid()));

-- RLS policies for snomed_analyses
CREATE POLICY "SNOMED analyses are publicly readable"
  ON public.snomed_analyses FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create SNOMED analyses"
  ON public.snomed_analyses FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update SNOMED analyses"
  ON public.snomed_analyses FOR UPDATE
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Only admins can delete SNOMED analyses"
  ON public.snomed_analyses FOR DELETE
  USING (is_admin(auth.uid()));

-- Add triggers for updated_at
CREATE TRIGGER update_hpo_analyses_updated_at
  BEFORE UPDATE ON public.hpo_analyses
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_snomed_analyses_updated_at
  BEFORE UPDATE ON public.snomed_analyses
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();