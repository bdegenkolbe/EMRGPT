-- Add preference column for expanded English explanation sections
ALTER TABLE public.profiles
ADD COLUMN show_english_details boolean NOT NULL DEFAULT false;