-- Fix Phase 2 und 3 Templates: Link to correct pipeline
UPDATE public.prompt_templates 
SET pipeline_id = (SELECT id FROM public.pipelines WHERE slug = 'medical-anamnesis' LIMIT 1)
WHERE phase IN ('2', '3') AND pipeline_id IS NULL;

-- Verify the pipeline phase_order is correct (should be 1,2,3 not the old 8-phase order)
UPDATE public.pipelines 
SET phase_order = ARRAY['1', '2', '3']
WHERE slug = 'medical-anamnesis';