import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

type OntologySystem = 'HPO' | 'SNOMED' | 'ICD10GM' | 'ICD10WHO' | 'ICD11';

interface MappingRequest {
  sourceCode: string;
  sourceLabel: string;
  sourceSystem: OntologySystem;
  targetSystem: OntologySystem;
}

interface MappingResult {
  sourceCode: string;
  sourceLabel: string;
  sourceSystem: OntologySystem;
  targetCode: string;
  targetLabel: string;
  targetSystem: OntologySystem;
  confidence: number;
  mappingType: 'exact' | 'broad' | 'narrow' | 'related' | 'ai_suggested';
  source: 'umls' | 'ai' | 'manual' | 'snomed_map' | 'fhir_translate' | 'who_crosswalk' | 'local_db';
}

// FHIR system URIs
const SYSTEM_URIS: Record<OntologySystem, string> = {
  HPO: 'http://purl.obolibrary.org/obo/hp.owl',
  SNOMED: 'http://snomed.info/sct',
  ICD10GM: 'http://fhir.de/CodeSystem/bfarm/icd-10-gm',
  ICD10WHO: 'http://hl7.org/fhir/sid/icd-10',
  ICD11: 'http://id.who.int/icd/entity',
};

function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(supabaseUrl, supabaseServiceKey);
}

/**
 * 1. Check local database for existing mappings
 */
async function findLocalMappings(
  supabase: any,
  sourceCode: string,
  sourceSystem: OntologySystem,
  targetSystem: OntologySystem
): Promise<MappingResult[]> {
  const { data, error } = await supabase
    .from("ontology_mappings")
    .select("*")
    .eq("source_code", sourceCode)
    .eq("source_system", sourceSystem)
    .eq("target_system", targetSystem)
    .order("confidence", { ascending: false })
    .limit(5);

  if (error || !data) return [];

  return data.map((m: any) => ({
    sourceCode: m.source_code,
    sourceLabel: m.source_label,
    sourceSystem: m.source_system as OntologySystem,
    targetCode: m.target_code,
    targetLabel: m.target_label,
    targetSystem: m.target_system as OntologySystem,
    confidence: m.confidence,
    mappingType: m.mapping_type,
    source: 'local_db' as const,
  }));
}

/**
 * 2. FHIR $translate via fhir-translate function
 */
async function findFhirMappings(
  sourceCode: string,
  sourceLabel: string,
  sourceSystem: OntologySystem,
  targetSystem: OntologySystem
): Promise<MappingResult[]> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/fhir-translate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${supabaseServiceKey}`,
      },
      body: JSON.stringify({
        sourceSystem: SYSTEM_URIS[sourceSystem],
        sourceCode,
        targetSystem: SYSTEM_URIS[targetSystem],
      }),
    });

    if (!response.ok) return [];

    const data = await response.json();
    const mappings: MappingResult[] = [];

    for (const m of data.mappings || []) {
      mappings.push({
        sourceCode,
        sourceLabel,
        sourceSystem,
        targetCode: m.code,
        targetLabel: m.display || m.code,
        targetSystem,
        confidence: m.equivalence === 'equivalent' || m.equivalence === 'equal' ? 0.95 : 
                   m.equivalence === 'wider' ? 0.85 : 
                   m.equivalence === 'narrower' ? 0.80 : 0.75,
        mappingType: m.equivalence === 'equivalent' || m.equivalence === 'equal' ? 'exact' :
                    m.equivalence === 'wider' ? 'broad' :
                    m.equivalence === 'narrower' ? 'narrow' : 'related',
        source: 'fhir_translate',
      });
    }

    return mappings;
  } catch (err) {
    console.error("FHIR translate error:", err);
    return [];
  }
}

/**
 * 3. WHO Crosswalk for ICD-10 <-> ICD-11
 */
async function findWhoCrosswalk(
  supabase: any,
  code: string,
  sourceLabel: string,
  direction: 'icd10-to-icd11' | 'icd11-to-icd10'
): Promise<MappingResult[]> {
  const isIcd10ToIcd11 = direction === 'icd10-to-icd11';
  const sourceField = isIcd10ToIcd11 ? 'icd10_code' : 'icd11_code';
  const targetField = isIcd10ToIcd11 ? 'icd11_code' : 'icd10_code';

  const { data, error } = await supabase
    .from("icd10_icd11_mappings")
    .select("*")
    .eq(sourceField, code)
    .order("priority", { ascending: true })
    .limit(5);

  if (error || !data) return [];

  const mappings: MappingResult[] = [];

  for (const m of data) {
    const targetCode = m[targetField];
    
    // Get target label from appropriate table
    let targetLabel = targetCode;
    if (isIcd10ToIcd11) {
      const { data: icd11 } = await supabase
        .from("icd11_codes")
        .select("title")
        .eq("code", targetCode)
        .maybeSingle();
      targetLabel = icd11?.title || targetCode;
    } else {
      const { data: icd10 } = await supabase
        .from("icd10_who_codes")
        .select("title")
        .eq("code", targetCode)
        .maybeSingle();
      if (!icd10) {
        // Try ICD-10-GM
        const { data: icd10gm } = await supabase
          .from("icd10gm_codes")
          .select("title")
          .eq("code", targetCode)
          .maybeSingle();
        targetLabel = icd10gm?.title || targetCode;
      } else {
        targetLabel = icd10.title;
      }
    }

    mappings.push({
      sourceCode: code,
      sourceLabel,
      sourceSystem: isIcd10ToIcd11 ? 'ICD10WHO' : 'ICD11',
      targetCode,
      targetLabel,
      targetSystem: isIcd10ToIcd11 ? 'ICD11' : 'ICD10WHO',
      confidence: m.mapping_type === 'exact' ? 0.98 :
                 m.mapping_type === 'broad' ? 0.90 :
                 m.mapping_type === 'narrow' ? 0.85 : 0.80,
      mappingType: m.mapping_type as any || 'related',
      source: 'who_crosswalk',
    });
  }

  return mappings;
}

/**
 * 4. SNOMED RefSet for SNOMED -> ICD-10
 */
async function findSnomedToIcd10Map(
  snomedCode: string,
  snomedLabel: string
): Promise<MappingResult[]> {
  try {
    const response = await fetch(
      `https://browser.ihtsdotools.org/snowstorm/snomed-ct/browser/MAIN/members?referenceSet=447562003&referencedComponentId=${snomedCode}&active=true&limit=10`,
      { headers: { Accept: "application/json" } }
    );

    if (!response.ok) return [];

    const data = await response.json();
    const results: MappingResult[] = [];

    for (const item of data.items || []) {
      if (item.additionalFields?.mapTarget) {
        const icdCode = item.additionalFields.mapTarget;
        results.push({
          sourceCode: snomedCode,
          sourceLabel: snomedLabel,
          sourceSystem: 'SNOMED',
          targetCode: icdCode,
          targetLabel: `ICD-10: ${icdCode}`,
          targetSystem: 'ICD10GM',
          confidence: 0.92,
          mappingType: item.additionalFields.mapGroup === 1 ? 'exact' : 'related',
          source: 'snomed_map',
        });
      }
    }

    // Enrich labels
    if (results.length > 0) {
      const supabase = getSupabaseAdmin();
      const codes = results.map(r => r.targetCode);
      const { data: icdData } = await supabase
        .from("icd10gm_codes")
        .select("code, title")
        .in("code", codes);

      if (icdData) {
        const titleMap = new Map(icdData.map((d: any) => [d.code, d.title]));
        for (const result of results) {
          const title = titleMap.get(result.targetCode);
          if (title) result.targetLabel = title;
        }
      }
    }

    return results.slice(0, 5);
  } catch (e) {
    console.error("SNOMED->ICD-10 map error:", e);
    return [];
  }
}

/**
 * 5. Snowstorm text search for HPO -> SNOMED
 */
async function findDirectSnomedMappings(
  hpoCode: string,
  hpoLabel: string
): Promise<MappingResult[]> {
  try {
    const response = await fetch(
      `https://browser.ihtsdotools.org/snowstorm/snomed-ct/browser/MAIN/descriptions?term=${encodeURIComponent(hpoLabel)}&limit=5&active=true`,
      { headers: { Accept: "application/json" } }
    );

    if (!response.ok) return [];

    const data = await response.json();
    const results: MappingResult[] = [];

    for (const item of data.items || []) {
      if (item.concept?.active) {
        results.push({
          sourceCode: hpoCode,
          sourceLabel: hpoLabel,
          sourceSystem: 'HPO',
          targetCode: item.concept.conceptId,
          targetLabel: item.term,
          targetSystem: 'SNOMED',
          confidence: 0.70,
          mappingType: 'related',
          source: 'umls',
        });
      }
    }

    return results.slice(0, 3);
  } catch (e) {
    console.error("SNOMED search error:", e);
    return [];
  }
}

/**
 * 6. OLS4 for SNOMED -> HPO
 */
async function findDirectHpoMappings(
  snomedCode: string,
  snomedLabel: string
): Promise<MappingResult[]> {
  try {
    const response = await fetch(
      `https://www.ebi.ac.uk/ols4/api/search?q=${encodeURIComponent(snomedLabel)}&ontology=hp&rows=5`,
      { headers: { Accept: "application/json" } }
    );

    if (!response.ok) return [];

    const data = await response.json();
    const results: MappingResult[] = [];

    for (const doc of data.response?.docs || []) {
      if (doc.obo_id?.startsWith('HP:')) {
        results.push({
          sourceCode: snomedCode,
          sourceLabel: snomedLabel,
          sourceSystem: 'SNOMED',
          targetCode: doc.obo_id,
          targetLabel: doc.label,
          targetSystem: 'HPO',
          confidence: 0.70,
          mappingType: 'related',
          source: 'umls',
        });
      }
    }

    return results.slice(0, 3);
  } catch (e) {
    console.error("HPO search error:", e);
    return [];
  }
}

/**
 * 7. ICD-10-GM local DB search
 */
async function findIcd10GmMappings(
  sourceCode: string,
  sourceLabel: string,
  sourceSystem: OntologySystem
): Promise<MappingResult[]> {
  const supabase = getSupabaseAdmin();

  try {
    const { data, error } = await supabase
      .from("icd10gm_codes")
      .select("code, title, title_short, is_terminal")
      .or(`title.ilike.%${sourceLabel}%,title_short.ilike.%${sourceLabel}%`)
      .order("code")
      .limit(5);

    if (error) return [];

    return (data || []).map((item: any) => ({
      sourceCode,
      sourceLabel,
      sourceSystem,
      targetCode: item.code,
      targetLabel: item.title,
      targetSystem: 'ICD10GM' as OntologySystem,
      confidence: item.is_terminal ? 0.75 : 0.60,
      mappingType: 'related' as const,
      source: 'umls' as const,
    }));
  } catch (e) {
    console.error("ICD-10-GM search error:", e);
    return [];
  }
}

/**
 * 8. AI fallback
 */
async function findMappingsWithAI(
  request: MappingRequest
): Promise<MappingResult[]> {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");

  const systemPrompt = `Du bist ein Experte für medizinische Ontologien und Terminologien.
Deine Aufgabe ist es, semantische Zuordnungen zwischen HPO, SNOMED CT, ICD-10-GM, ICD-10 WHO und ICD-11 zu finden.

Für jeden gefundenen Match gib an:
- targetCode: Der Code im Zielsystem
- targetLabel: Die Bezeichnung im Zielsystem  
- confidence: Konfidenzwert zwischen 0.0 und 1.0
- mappingType: Art der Zuordnung (exact, broad, narrow, related)

Beachte:
- HPO-Codes: HP:0000001 bis HP:9999999
- SNOMED-Codes: Rein numerisch (z.B. 386661006)
- ICD-10: [A-Z][0-9]{2}(.[0-9]+)? (z.B. E11.9)
- ICD-11: Alphanumerisch (z.B. 5A11, BA00.Z)
- Maximal 5 beste Zuordnungen`;

  const userPrompt = `Finde Zuordnungen für:
Quellsystem: ${request.sourceSystem}
Quellcode: ${request.sourceCode}
Quellbezeichnung: "${request.sourceLabel}"
Zielsystem: ${request.targetSystem}

Antworte NUR mit einem JSON-Array:
[{"targetCode": "...", "targetLabel": "...", "confidence": 0.95, "mappingType": "exact"}, ...]`;

  let response: Response;

  if (openaiKey) {
    response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 1500,
      }),
    });
  } else if (lovableKey) {
    response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 1500,
      }),
    });
  } else {
    throw new Error("No AI API key configured");
  }

  if (!response.ok) return [];

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";

  const jsonMatch = content.match(/\[[\s\S]*\]/);
  if (!jsonMatch) return [];

  try {
    const rawMappings = JSON.parse(jsonMatch[0]);

    return rawMappings.map((m: any) => ({
      sourceCode: request.sourceCode,
      sourceLabel: request.sourceLabel,
      sourceSystem: request.sourceSystem,
      targetCode: m.targetCode,
      targetLabel: m.targetLabel,
      targetSystem: request.targetSystem,
      confidence: Math.min(m.confidence || 0.65, 0.75), // Cap AI confidence
      mappingType: ['exact', 'broad', 'narrow', 'related'].includes(m.mappingType) ? m.mappingType : 'related',
      source: 'ai' as const,
    }));
  } catch (e) {
    console.error("Failed to parse AI response:", e);
    return [];
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const request: MappingRequest = await req.json();

    if (!request.sourceCode || !request.sourceLabel || !request.sourceSystem || !request.targetSystem) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Finding mappings: ${request.sourceSystem}:${request.sourceCode} -> ${request.targetSystem}`);

    const supabase = getSupabaseAdmin();
    const allMappings: MappingResult[] = [];
    const seenCodes = new Set<string>();

    const addMappings = (mappings: MappingResult[]) => {
      for (const m of mappings) {
        if (!seenCodes.has(m.targetCode)) {
          seenCodes.add(m.targetCode);
          allMappings.push(m);
        }
      }
    };

    // Priority 1: Local DB
    const localMappings = await findLocalMappings(supabase, request.sourceCode, request.sourceSystem, request.targetSystem);
    addMappings(localMappings);

    // Priority 2: FHIR $translate (for SNOMED <-> ICD mappings)
    if (['SNOMED', 'ICD10GM', 'ICD10WHO', 'ICD11'].includes(request.sourceSystem) &&
        ['SNOMED', 'ICD10GM', 'ICD10WHO', 'ICD11'].includes(request.targetSystem)) {
      const fhirMappings = await findFhirMappings(request.sourceCode, request.sourceLabel, request.sourceSystem, request.targetSystem);
      addMappings(fhirMappings);
    }

    // Priority 3: WHO Crosswalk (ICD-10 <-> ICD-11)
    if ((request.sourceSystem === 'ICD10WHO' || request.sourceSystem === 'ICD10GM') && request.targetSystem === 'ICD11') {
      const crosswalk = await findWhoCrosswalk(supabase, request.sourceCode, request.sourceLabel, 'icd10-to-icd11');
      addMappings(crosswalk);
    } else if (request.sourceSystem === 'ICD11' && (request.targetSystem === 'ICD10WHO' || request.targetSystem === 'ICD10GM')) {
      const crosswalk = await findWhoCrosswalk(supabase, request.sourceCode, request.sourceLabel, 'icd11-to-icd10');
      addMappings(crosswalk);
    }

    // Priority 4: SNOMED RefSet
    if (request.sourceSystem === 'SNOMED' && (request.targetSystem === 'ICD10GM' || request.targetSystem === 'ICD10WHO')) {
      const snomedMappings = await findSnomedToIcd10Map(request.sourceCode, request.sourceLabel);
      addMappings(snomedMappings);
    }

    // Priority 5: API text search
    if (request.sourceSystem === 'HPO' && request.targetSystem === 'SNOMED') {
      const directMappings = await findDirectSnomedMappings(request.sourceCode, request.sourceLabel);
      addMappings(directMappings);
    } else if (request.sourceSystem === 'SNOMED' && request.targetSystem === 'HPO') {
      const directMappings = await findDirectHpoMappings(request.sourceCode, request.sourceLabel);
      addMappings(directMappings);
    } else if (request.targetSystem === 'ICD10GM') {
      const icdMappings = await findIcd10GmMappings(request.sourceCode, request.sourceLabel, request.sourceSystem);
      addMappings(icdMappings);
    }

    // Priority 6: AI fallback (only if we have < 3 mappings)
    if (allMappings.length < 3) {
      try {
        const aiMappings = await findMappingsWithAI(request);
        addMappings(aiMappings);
      } catch (aiError) {
        console.error("AI mapping error:", aiError);
      }
    }

    // Sort by confidence
    allMappings.sort((a, b) => b.confidence - a.confidence);
    const mappingsToReturn = allMappings.slice(0, 10);

    // Persist AI-generated mappings
    try {
      const aiMappingsToPersist = mappingsToReturn.filter((m) => m.source === "ai");

      if (aiMappingsToPersist.length > 0) {
        const rows = aiMappingsToPersist.map((m) => ({
          source_code: m.sourceCode,
          source_label: m.sourceLabel,
          source_system: m.sourceSystem,
          target_code: m.targetCode,
          target_label: m.targetLabel,
          target_system: m.targetSystem,
          confidence: m.confidence,
          mapping_type: m.mappingType,
          notes: "KI-generiert",
          extraction_source: "ai_mapping",
        }));

        await supabase
          .from("ontology_mappings")
          .upsert(rows, {
            onConflict: "source_code,source_system,target_code,target_system",
            ignoreDuplicates: true,
          });
      }
    } catch (persistError) {
      console.error("Persist mappings error:", persistError);
    }

    console.log(`Found ${mappingsToReturn.length} mappings`);

    return new Response(
      JSON.stringify({ mappings: mappingsToReturn }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("ontology-mapping error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Mapping failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
