import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface JobPayload {
  pmcid?: string;
  title?: string;
  metadata?: Record<string, unknown>;
  sourceId?: string;
  searchId?: string;
  targetLanguage?: string;
}

interface BackgroundJob {
  id: string;
  job_type: string;
  status: string;
  search_id: string | null;
  source_id: string | null;
  payload: JobPayload;
  batch_id: string | null;
}

/**
 * Self-invoking background job runner for PDF downloads and content loading.
 * Processes jobs in batches and re-invokes itself until queue is empty.
 */
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");

  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const body = await req.json().catch(() => ({}));
    const mode = body.mode as string | undefined;
    const batchId = body.batchId as string | undefined;
    const searchId = body.searchId as string | undefined;
    const jobTypes = body.jobTypes as string[] || ['pdf_download', 'content_load', 'translate', 'generate_pdf'];
    const batchSize = Math.min(body.batchSize || 5, 10);
    const targetLanguage = body.targetLanguage as string || 'de';

    // Re-queue mode: detect orphaned knowledge_sources and create new jobs
    if (mode === "requeue") {
      return await handleRequeue(supabase, supabaseUrl, supabaseServiceKey, searchId, targetLanguage);
    }

    console.log(`[background-job-runner] Starting batch processing. batchId=${batchId}, types=${jobTypes.join(',')}`);

    // Fetch pending jobs (optionally filtered by batch)
    let query = supabase
      .from("background_jobs")
      .select("*")
      .eq("status", "pending")
      .in("job_type", jobTypes)
      .order("created_at", { ascending: true })
      .limit(batchSize);

    if (batchId) {
      query = query.eq("batch_id", batchId);
    }

    const { data: jobs, error: fetchError } = await query;

    if (fetchError) {
      console.error("[background-job-runner] Fetch error:", fetchError);
      return new Response(JSON.stringify({ error: fetchError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!jobs || jobs.length === 0) {
      console.log("[background-job-runner] No pending jobs found. Queue empty.");
      return new Response(JSON.stringify({ processed: 0, remaining: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[background-job-runner] Processing ${jobs.length} jobs`);

    let processedCount = 0;
    let failedCount = 0;

    for (const job of jobs as BackgroundJob[]) {
      try {
        // Mark as running
        await supabase
          .from("background_jobs")
          .update({ status: "running", started_at: new Date().toISOString() })
          .eq("id", job.id);

        let result: Record<string, unknown> | null = null;
        let errorMessage: string | null = null;

        // Process based on job type
        if (job.job_type === "pdf_download") {
          const response = await processPdfDownload(supabase, job);
          result = response.result;
          errorMessage = response.error;
        } else if (job.job_type === "content_load") {
          const response = await processContentLoad(supabase, job, lovableApiKey);
          result = response.result;
          errorMessage = response.error;
        } else if (job.job_type === "translate") {
          const response = await processTranslation(supabase, job, lovableApiKey);
          result = response.result;
          errorMessage = response.error;
        } else if (job.job_type === "generate_pdf") {
          const response = await processGeneratePdf(supabase, supabaseUrl, supabaseServiceKey, job);
          result = response.result;
          errorMessage = response.error;
        } else {
          errorMessage = `Unknown job type: ${job.job_type}`;
        }

        // Update job status
        const finalStatus = errorMessage ? "failed" : "completed";
        await supabase
          .from("background_jobs")
          .update({
            status: finalStatus,
            result: result || {},
            error_message: errorMessage,
            completed_at: new Date().toISOString(),
          })
          .eq("id", job.id);

        if (errorMessage) {
          failedCount++;
          console.warn(`[background-job-runner] Job ${job.id} failed: ${errorMessage}`);
        } else {
          processedCount++;
          console.log(`[background-job-runner] Job ${job.id} completed`);
        }
      } catch (jobError) {
        failedCount++;
        console.error(`[background-job-runner] Job ${job.id} error:`, jobError);
        
        await supabase
          .from("background_jobs")
          .update({
            status: "failed",
            error_message: jobError.message || "Unknown error",
            completed_at: new Date().toISOString(),
          })
          .eq("id", job.id);
      }
    }

    // Check if more jobs remain
    let remainingQuery = supabase
      .from("background_jobs")
      .select("id", { count: "exact", head: true })
      .eq("status", "pending")
      .in("job_type", jobTypes);

    if (batchId) {
      remainingQuery = remainingQuery.eq("batch_id", batchId);
    }

    const { count: remainingCount } = await remainingQuery;

    console.log(`[background-job-runner] Processed ${processedCount}, failed ${failedCount}, remaining ${remainingCount || 0}`);

    // Self-invoke if more jobs remain
    if (remainingCount && remainingCount > 0) {
      console.log("[background-job-runner] Re-invoking for next batch...");
      
      // Fire-and-forget self-invocation
      const selfUrl = `${supabaseUrl}/functions/v1/background-job-runner`;
      fetch(selfUrl, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${supabaseServiceKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ batchId, jobTypes, batchSize }),
      }).catch(err => console.warn("[background-job-runner] Self-invoke failed:", err));
    }

    return new Response(
      JSON.stringify({
        processed: processedCount,
        failed: failedCount,
        remaining: remainingCount || 0,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("[background-job-runner] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

/**
 * Process PDF download job
 */
async function processPdfDownload(
  supabase: ReturnType<typeof createClient>,
  job: BackgroundJob
): Promise<{ result: Record<string, unknown> | null; error: string | null }> {
  const { pmcid, title, metadata } = job.payload;

  if (!pmcid) {
    return { result: null, error: "Missing pmcid in payload" };
  }

  const normalizedId = pmcid.startsWith("PMC") ? pmcid : `PMC${pmcid}`;
  
  console.log(`[pdf_download] Downloading ${normalizedId}...`);

  // Try multiple PDF sources
  const sources = [
    `https://www.ncbi.nlm.nih.gov/pmc/articles/${normalizedId}/pdf/`,
    `https://europepmc.org/articles/${normalizedId}?pdf=render`,
    `https://www.ncbi.nlm.nih.gov/pmc/articles/${normalizedId}/pdf`,
    `https://europepmc.org/backend/ptpmcrender.fcgi?accid=${normalizedId}&blobtype=pdf`,
  ];

  let pdfBlob: Blob | null = null;
  let contentType = "";

  for (const url of sources) {
    try {
      console.log(`[pdf_download] Trying: ${url}`);
      const response = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          "Accept": "application/pdf,*/*",
          "Referer": "https://europepmc.org/",
        },
        redirect: "follow",
      });

      if (response.ok) {
        contentType = response.headers.get("content-type") || "";
        if (contentType.includes("pdf")) {
          pdfBlob = await response.blob();
          console.log(`[pdf_download] Success from: ${url}`);
          break;
        }
      }
    } catch (e) {
      console.log(`[pdf_download] Failed ${url}:`, e);
    }
  }

  if (!pdfBlob) {
    return { result: null, error: "PDF not available from any source" };
  }

  // Create safe filename
  const safeTitle = title
    ? title.replace(/[^a-zA-Z0-9\s-]/g, "").replace(/\s+/g, "_").substring(0, 100)
    : normalizedId;
  
  const fileName = `${normalizedId}_${safeTitle}.pdf`;
  const filePath = `europepmc/${fileName}`;

  // Upload to storage
  const pdfBytes = new Uint8Array(await pdfBlob.arrayBuffer());
  const { data: uploadData, error: uploadError } = await supabase.storage
    .from("guidelines")
    .upload(filePath, pdfBytes, {
      contentType: "application/pdf",
      upsert: true,
    });

  if (uploadError) {
    return { result: null, error: `Storage upload failed: ${uploadError.message}` };
  }

  // Create guideline entry
  if (title) {
    const { error: guidelineErr } = await supabase.from("guidelines").insert({
      title: title,
      description: (metadata?.abstract as string) || `Downloaded from Europe PMC (${normalizedId})`,
      source: `Europe PMC - ${normalizedId}`,
      file_name: fileName,
      file_path: filePath,
      file_size: pdfBytes.length,
      mime_type: "application/pdf",
      embedding_status: "pending",
    });
    if (guidelineErr) console.warn("[pdf_download] Guideline insert warning:", guidelineErr);
  }

  return {
    result: {
      filePath: uploadData.path,
      fileSize: pdfBytes.length,
    },
    error: null,
  };
}

/**
 * Process content load job (fetch abstract from Europe PMC)
 */
async function processContentLoad(
  supabase: ReturnType<typeof createClient>,
  job: BackgroundJob,
  lovableApiKey?: string
): Promise<{ result: Record<string, unknown> | null; error: string | null }> {
  const { sourceId, targetLanguage = "de" } = job.payload;

  if (!sourceId) {
    return { result: null, error: "Missing sourceId in payload" };
  }

  // Get source
  const { data: source, error: fetchError } = await supabase
    .from("knowledge_sources")
    .select("*")
    .eq("id", sourceId)
    .single();

  if (fetchError || !source) {
    return { result: null, error: `Source not found: ${fetchError?.message}` };
  }

  // Update status
  await supabase
    .from("knowledge_sources")
    .update({ content_status: "loading" })
    .eq("id", sourceId);

  let content = source.original_content;
  let contentType = source.content_type || "abstract";

  // Fetch content if needed
  if ((source.content_status === "pending" || !content) && source.source_type === "europepmc" && source.external_id) {
    const externalId = source.external_id;
    
    // Step 1: Try fulltext XML if PMCID is available
    const pmcid = source.metadata?.pmcid || (externalId.startsWith("PMC") ? externalId : null);
    
    if (pmcid) {
      const normalizedPmcid = (pmcid as string).startsWith("PMC") ? pmcid as string : `PMC${pmcid}`;
      const xmlUrl = `https://www.ebi.ac.uk/europepmc/webservices/rest/${normalizedPmcid}/fullTextXML`;
      console.log(`[content_load] Fetching fulltext XML from: ${xmlUrl}`);
      
      try {
        const xmlResponse = await fetch(xmlUrl, {
          headers: {
            "Accept": "application/xml, text/xml",
            "User-Agent": "MedAssist/1.0 (academic research tool)",
          },
        });
        
        if (xmlResponse.ok) {
          const xmlContentType = xmlResponse.headers.get("content-type") || "";
          if (xmlContentType.includes("xml")) {
            const xml = await xmlResponse.text();
            if (xml.length > 500) {
              const fullText = extractTextFromJatsXmlInRunner(xml);
              if (fullText && fullText.length > 200) {
                content = fullText;
                contentType = "fulltext";
                console.log(`[content_load] Full text extracted: ${fullText.length} chars for ${externalId}`);
              }
            }
          } else {
            await xmlResponse.text(); // consume
          }
        }
      } catch (e) {
        console.warn(`[content_load] Fulltext fetch error for ${externalId}:`, e);
      }
    }
    
    // Step 2: Fallback to abstract if no fulltext
    if (!content || contentType === "abstract") {
      let searchQuery: string;
      if (externalId.startsWith("PMC")) {
        searchQuery = `PMCID:${externalId}`;
      } else {
        searchQuery = `EXT_ID:${externalId} AND SRC:MED`;
      }

      const pmcUrl = `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${encodeURIComponent(searchQuery)}&format=json&resultType=core`;
      
      try {
        const response = await fetch(pmcUrl);
        if (response.ok) {
          const data = await response.json();
          const result = data.resultList?.result?.[0];
          if (result?.abstractText) {
            content = result.abstractText;
            contentType = "abstract";
          }
        }
      } catch (e) {
        console.warn(`[content_load] Abstract fetch failed for ${externalId}:`, e);
      }
    }
  }

  const updateData: Record<string, unknown> = {
    content_status: content ? "loaded" : "error",
    content_type: contentType,
    updated_at: new Date().toISOString(),
  };

  if (content) {
    updateData.original_content = content;
  }

  // Handle translation if needed
  const needsTranslation = source.translation_status === "pending" && source.original_language !== targetLanguage;
  const contentToTranslate = content || source.original_content;

  if (needsTranslation && lovableApiKey && contentToTranslate) {
    const maxTokens = contentType === "fulltext" ? 16000 : 4000;
    const translationResult = await translateContent(
      source.title,
      contentToTranslate,
      source.original_language || "en",
      targetLanguage,
      lovableApiKey,
      maxTokens
    );

    if (translationResult.success) {
      updateData.translated_title = translationResult.title;
      updateData.translated_content = translationResult.content;
      updateData.translation_status = "completed";
    } else {
      updateData.translation_status = "error";
    }
  } else if (source.original_language === targetLanguage) {
    updateData.translation_status = "skipped";
    if (contentToTranslate) {
      updateData.translated_content = contentToTranslate;
    }
  }

  await supabase
    .from("knowledge_sources")
    .update(updateData)
    .eq("id", sourceId);

  // Queue PDF generation if content was loaded successfully
  if (content && !source.pdf_path) {
    const { error: queueErr } = await supabase.from("background_jobs").insert({
      job_type: "generate_pdf",
      search_id: source.search_id,
      source_id: sourceId,
      payload: { sourceId },
      batch_id: job.batch_id,
      status: "pending",
    });
    if (queueErr) console.warn("[content_load] Failed to queue generate_pdf:", queueErr);
    else console.log(`[content_load] Queued generate_pdf for source ${sourceId}`);
  }

  return {
    result: { loaded: true, contentType, translated: updateData.translation_status === "completed" },
    error: null,
  };
}

/**
 * Process translation-only job
 */
async function processTranslation(
  supabase: ReturnType<typeof createClient>,
  job: BackgroundJob,
  lovableApiKey?: string
): Promise<{ result: Record<string, unknown> | null; error: string | null }> {
  const { sourceId, targetLanguage = "de" } = job.payload;

  if (!sourceId) {
    return { result: null, error: "Missing sourceId in payload" };
  }

  if (!lovableApiKey) {
    return { result: null, error: "Missing LOVABLE_API_KEY" };
  }

  const { data: source, error: fetchError } = await supabase
    .from("knowledge_sources")
    .select("*")
    .eq("id", sourceId)
    .single();

  if (fetchError || !source) {
    return { result: null, error: `Source not found: ${fetchError?.message}` };
  }

  const contentToTranslate = source.original_content;
  if (!contentToTranslate) {
    return { result: null, error: "No content to translate" };
  }

  await supabase
    .from("knowledge_sources")
    .update({ translation_status: "loading" })
    .eq("id", sourceId);

  const translationResult = await translateContent(
    source.title,
    contentToTranslate,
    source.original_language || "en",
    targetLanguage,
    lovableApiKey
  );

  if (translationResult.success) {
    await supabase
      .from("knowledge_sources")
      .update({
        translated_title: translationResult.title,
        translated_content: translationResult.content,
        translation_status: "completed",
        updated_at: new Date().toISOString(),
      })
      .eq("id", sourceId);

    return { result: { translated: true }, error: null };
  } else {
    await supabase
      .from("knowledge_sources")
      .update({ translation_status: "error" })
      .eq("id", sourceId);

    return { result: null, error: translationResult.error || "Translation failed" };
  }
}

/**
 * Helper: Translate title and content using AI
 */
/**
 * Extract plain text from JATS XML full text (inline version for background-job-runner).
 */
function extractTextFromJatsXmlInRunner(xml: string): string | null {
  try {
    const bodyMatch = xml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (!bodyMatch) return null;

    const body = bodyMatch[1];
    const sections: string[] = [];
    const secRegex = /<sec[^>]*>([\s\S]*?)<\/sec>/gi;
    let secMatch;

    while ((secMatch = secRegex.exec(body)) !== null) {
      const secContent = secMatch[1];
      const titleMatch = secContent.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const title = titleMatch ? stripTagsInRunner(titleMatch[1]).trim() : "";

      let text = secContent
        .replace(/<sec[^>]*>[\s\S]*?<\/sec>/gi, "")
        .replace(/<title[^>]*>[\s\S]*?<\/title>/i, "");
      text = stripTagsInRunner(text).trim();

      if (title || text) {
        sections.push(title ? `\n## ${title}\n\n${text}` : text);
      }
    }

    if (sections.length === 0) {
      const plainText = stripTagsInRunner(body).trim();
      return plainText.length > 100 ? plainText : null;
    }

    return sections.join("\n").trim();
  } catch (e) {
    console.warn("[extractTextFromJatsXml] Parse error:", e);
    return null;
  }
}

function stripTagsInRunner(html: string): string {
  return html
    .replace(/<xref[^>]*>[\s\S]*?<\/xref>/gi, "")
    .replace(/<ext-link[^>]*>([\s\S]*?)<\/ext-link>/gi, "$1")
    .replace(/<[^>]+>/g, " ")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

async function translateContent(
  title: string,
  content: string,
  fromLang: string,
  toLang: string,
  apiKey: string,
  maxTokens = 4000
): Promise<{ success: boolean; title?: string; content?: string; error?: string }> {
  try {
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: `Translate the following JSON object from ${fromLang} to ${toLang}. 
Preserve all technical terms, citations, and formatting. Return ONLY a valid JSON object with the same keys.`,
          },
          { role: "user", content: JSON.stringify({ title, content }) },
        ],
        temperature: 0.1,
        max_tokens: maxTokens,
      }),
    });

    if (!response.ok) {
      return { success: false, error: `API returned ${response.status}` };
    }

    const data = await response.json();
    let text = data.choices?.[0]?.message?.content || "";
    text = text.replace(/^```json\s*\n?/i, "").replace(/\n?```$/i, "").trim();

    const parsed = JSON.parse(text);
    return {
      success: true,
      title: parsed.title,
      content: parsed.content,
    };
  } catch (e) {
    return { success: false, error: e.message || "Translation error" };
  }
}

/**
 * Process PDF generation job (generate PDF from fulltext content)
 */
async function processGeneratePdf(
  supabase: ReturnType<typeof createClient>,
  supabaseUrl: string,
  supabaseServiceKey: string,
  job: BackgroundJob
): Promise<{ result: Record<string, unknown> | null; error: string | null }> {
  const { sourceId } = job.payload;

  if (!sourceId) {
    return { result: null, error: "Missing sourceId in payload" };
  }

  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/knowledge-generate-pdf`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${supabaseServiceKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ sourceId }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      return { result: null, error: errorData.error || `PDF generation returned ${response.status}` };
    }

    const data = await response.json();
    return { result: data, error: null };
  } catch (e) {
    return { result: null, error: e.message || "PDF generation failed" };
  }
}

/**
 * Re-queue orphaned knowledge_sources that have pending/loading/stalled statuses
 */
async function handleRequeue(
  supabase: ReturnType<typeof createClient>,
  supabaseUrl: string,
  supabaseServiceKey: string,
  searchId?: string,
  targetLanguage = "de"
): Promise<Response> {
  console.log(`[background-job-runner] Requeue mode. searchId=${searchId}`);

  // Fix stuck "loading" states (stalled for > 5 min)
  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
  await supabase
    .from("knowledge_sources")
    .update({ content_status: "pending" })
    .eq("content_status", "loading")
    .lt("updated_at", fiveMinAgo);
  
  await supabase
    .from("knowledge_sources")
    .update({ translation_status: "pending" })
    .eq("translation_status", "loading")
    .lt("updated_at", fiveMinAgo);

  // Reset errored content sources back to pending for retry
  let errorContentQuery = supabase
    .from("knowledge_sources")
    .select("id")
    .eq("content_status", "error");
  if (searchId) errorContentQuery = errorContentQuery.eq("search_id", searchId);
  const { data: errorContent } = await errorContentQuery.limit(200);

  if (errorContent && errorContent.length > 0) {
    await supabase
      .from("knowledge_sources")
      .update({ content_status: "pending" })
      .in("id", errorContent.map(s => s.id));
    console.log(`[background-job-runner] Reset ${errorContent.length} error content sources to pending`);
  }

  // Find sources needing content load
  let contentQuery = supabase
    .from("knowledge_sources")
    .select("id, search_id, original_language")
    .eq("content_status", "pending");
  if (searchId) contentQuery = contentQuery.eq("search_id", searchId);
  const { data: pendingContent } = await contentQuery.limit(200);

  // Find sources needing translation (content loaded but not translated)
  let transQuery = supabase
    .from("knowledge_sources")
    .select("id, search_id, original_language")
    .eq("content_status", "loaded")
    .eq("translation_status", "pending")
    .neq("original_language", targetLanguage);
  if (searchId) transQuery = transQuery.eq("search_id", searchId);
  const { data: pendingTranslation } = await transQuery.limit(200);

  // Also retry error translations
  let errorTransQuery = supabase
    .from("knowledge_sources")
    .select("id, search_id, original_language")
    .eq("content_status", "loaded")
    .eq("translation_status", "error");
  if (searchId) errorTransQuery = errorTransQuery.eq("search_id", searchId);
  const { data: errorTranslation } = await errorTransQuery.limit(200);

  if (errorTranslation && errorTranslation.length > 0) {
    await supabase
      .from("knowledge_sources")
      .update({ translation_status: "pending" })
      .in("id", errorTranslation.map(s => s.id));
  }

  // Find sources needing PDF generation (loaded content, no pdf_path)
  let pdfQuery = supabase
    .from("knowledge_sources")
    .select("id, search_id, original_language")
    .eq("content_status", "loaded")
    .is("pdf_path", null);
  if (searchId) pdfQuery = pdfQuery.eq("search_id", searchId);
  const { data: needsPdf } = await pdfQuery.limit(200);

  const allPending = [
    ...(pendingContent || []).map(s => ({ ...s, jobType: "content_load" as const })),
    ...(pendingTranslation || []).map(s => ({ ...s, jobType: "content_load" as const })),
    ...(errorTranslation || []).map(s => ({ ...s, jobType: "content_load" as const })),
    ...(needsPdf || []).map(s => ({ ...s, jobType: "generate_pdf" as const })),
  ];

  if (allPending.length === 0) {
    console.log("[background-job-runner] No orphaned sources found.");
    return new Response(JSON.stringify({ requeued: 0 }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const uniqueMap = new Map(allPending.map(s => [s.id, s]));
  const unique = [...uniqueMap.values()];

  const batchId = crypto.randomUUID();
  const jobs = unique.map(s => ({
    job_type: s.jobType,
    search_id: s.search_id,
    source_id: s.id,
    payload: { sourceId: s.id, targetLanguage },
    batch_id: batchId,
    status: "pending",
  }));

  const { error: insertError } = await supabase
    .from("background_jobs")
    .insert(jobs);

  if (insertError) {
    console.error("[background-job-runner] Requeue insert error:", insertError);
    return new Response(JSON.stringify({ error: insertError.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  console.log(`[background-job-runner] Requeued ${jobs.length} jobs (batch: ${batchId})`);

  // Start processing
  fetch(`${supabaseUrl}/functions/v1/background-job-runner`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${supabaseServiceKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ batchId, batchSize: 5 }),
  }).catch(err => console.warn("[background-job-runner] Self-invoke failed:", err));

  return new Response(
    JSON.stringify({ requeued: jobs.length, batchId }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}
