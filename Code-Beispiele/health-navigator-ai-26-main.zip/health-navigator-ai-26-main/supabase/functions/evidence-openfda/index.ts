import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// openFDA API base URLs
const OPENFDA_BASE = "https://api.fda.gov";

interface AdverseEventRequest {
  drugName?: string;
  genericName?: string;
  reactionTerm?: string;
  serious?: boolean;
  limit?: number;
}

interface DrugLabelRequest {
  drugName?: string;
  genericName?: string;
  brandName?: string;
  limit?: number;
}

interface AdverseEvent {
  safetyReportId: string;
  receiveDate: string;
  serious: boolean;
  seriousReasons: string[];
  patientAge: number | null;
  patientSex: string | null;
  drugs: Array<{
    name: string;
    indication: string;
    route: string;
    dosage: string;
  }>;
  reactions: string[];
  outcome: string | null;
}

interface DrugLabel {
  id: string;
  brandName: string[];
  genericName: string[];
  manufacturer: string;
  dosageForm: string;
  route: string[];
  indications: string;
  warnings: string;
  adverseReactions: string;
  contraindications: string;
  drugInteractions: string;
  boxedWarning: string | null;
}

interface AdverseEventResponse {
  events: AdverseEvent[];
  totalCount: number;
  query: string;
}

interface DrugLabelResponse {
  labels: DrugLabel[];
  totalCount: number;
  query: string;
}

/**
 * Search FDA Adverse Event Reporting System (FAERS)
 */
async function searchAdverseEvents(request: AdverseEventRequest): Promise<AdverseEventResponse> {
  const searchTerms: string[] = [];

  if (request.drugName) {
    searchTerms.push(`patient.drug.medicinalproduct:"${request.drugName}"`);
  }
  if (request.genericName) {
    searchTerms.push(`patient.drug.openfda.generic_name:"${request.genericName}"`);
  }
  if (request.reactionTerm) {
    searchTerms.push(`patient.reaction.reactionmeddrapt:"${request.reactionTerm}"`);
  }
  if (request.serious === true) {
    searchTerms.push("serious:1");
  }

  const query = searchTerms.join("+AND+");
  const limit = Math.min(request.limit || 10, 100);

  const url = `${OPENFDA_BASE}/drug/event.json?search=${encodeURIComponent(query)}&limit=${limit}`;
  console.log("openFDA Adverse Events URL:", url);

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    if (response.status === 404) {
      return { events: [], totalCount: 0, query };
    }
    const errorText = await response.text();
    console.error("openFDA API error:", response.status, errorText);
    throw new Error(`openFDA API error: ${response.status}`);
  }

  const data = await response.json();

  const events: AdverseEvent[] = (data.results || []).map((result: any) => {
    const seriousReasons: string[] = [];
    if (result.seriousnessdeath === "1") seriousReasons.push("death");
    if (result.seriousnesslifethreatening === "1") seriousReasons.push("life-threatening");
    if (result.seriousnesshospitalization === "1") seriousReasons.push("hospitalization");
    if (result.seriousnessdisabling === "1") seriousReasons.push("disabling");
    if (result.seriousnesscongenitalanomali === "1") seriousReasons.push("congenital anomaly");
    if (result.seriousnessother === "1") seriousReasons.push("other");

    return {
      safetyReportId: result.safetyreportid || "",
      receiveDate: result.receivedate || "",
      serious: result.serious === "1",
      seriousReasons,
      patientAge: result.patient?.patientonsetage ? parseFloat(result.patient.patientonsetage) : null,
      patientSex: result.patient?.patientsex === "1" ? "male" : result.patient?.patientsex === "2" ? "female" : null,
      drugs: (result.patient?.drug || []).map((d: any) => ({
        name: d.medicinalproduct || "",
        indication: d.drugindication || "",
        route: d.drugadministrationroute || "",
        dosage: d.drugdosagetext || "",
      })),
      reactions: (result.patient?.reaction || []).map((r: any) => r.reactionmeddrapt),
      outcome: result.patient?.patientdeath ? "death" : result.patient?.patientoutcome || null,
    };
  });

  return {
    events,
    totalCount: data.meta?.results?.total || events.length,
    query,
  };
}

/**
 * Search FDA Drug Labels (SPL - Structured Product Labeling)
 */
async function searchDrugLabels(request: DrugLabelRequest): Promise<DrugLabelResponse> {
  const searchTerms: string[] = [];

  if (request.drugName) {
    searchTerms.push(`(openfda.brand_name:"${request.drugName}"+openfda.generic_name:"${request.drugName}")`);
  }
  if (request.genericName) {
    searchTerms.push(`openfda.generic_name:"${request.genericName}"`);
  }
  if (request.brandName) {
    searchTerms.push(`openfda.brand_name:"${request.brandName}"`);
  }

  const query = searchTerms.join("+AND+") || "*";
  const limit = Math.min(request.limit || 10, 100);

  const url = `${OPENFDA_BASE}/drug/label.json?search=${encodeURIComponent(query)}&limit=${limit}`;
  console.log("openFDA Drug Labels URL:", url);

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    if (response.status === 404) {
      return { labels: [], totalCount: 0, query };
    }
    const errorText = await response.text();
    console.error("openFDA API error:", response.status, errorText);
    throw new Error(`openFDA API error: ${response.status}`);
  }

  const data = await response.json();

  const labels: DrugLabel[] = (data.results || []).map((result: any) => {
    const openfda = result.openfda || {};
    
    // Helper to get first item from array or extract text
    const getText = (field: any): string => {
      if (!field) return "";
      if (Array.isArray(field)) return field[0] || "";
      return String(field);
    };

    // Truncate long text fields
    const truncate = (text: string, maxLen: number = 500): string => {
      if (text.length <= maxLen) return text;
      return text.substring(0, maxLen) + "...";
    };

    return {
      id: result.id || openfda.spl_id?.[0] || "",
      brandName: openfda.brand_name || [],
      genericName: openfda.generic_name || [],
      manufacturer: openfda.manufacturer_name?.[0] || "",
      dosageForm: openfda.dosage_form?.[0] || "",
      route: openfda.route || [],
      indications: truncate(getText(result.indications_and_usage)),
      warnings: truncate(getText(result.warnings)),
      adverseReactions: truncate(getText(result.adverse_reactions)),
      contraindications: truncate(getText(result.contraindications)),
      drugInteractions: truncate(getText(result.drug_interactions)),
      boxedWarning: result.boxed_warning ? truncate(getText(result.boxed_warning)) : null,
    };
  });

  return {
    labels,
    totalCount: data.meta?.results?.total || labels.length,
    query,
  };
}

/**
 * Get drug recall information
 */
async function searchDrugRecalls(drugName: string, limit: number = 10): Promise<any> {
  const query = `product_description:"${drugName}"`;
  const url = `${OPENFDA_BASE}/drug/enforcement.json?search=${encodeURIComponent(query)}&limit=${limit}`;

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    if (response.status === 404) {
      return { recalls: [], totalCount: 0 };
    }
    const errorText = await response.text();
    console.error("openFDA Recalls API error:", response.status, errorText);
    throw new Error(`openFDA API error: ${response.status}`);
  }

  const data = await response.json();

  const recalls = (data.results || []).map((result: any) => ({
    recallNumber: result.recall_number || "",
    status: result.status || "",
    classification: result.classification || "",
    productDescription: result.product_description || "",
    reason: result.reason_for_recall || "",
    recallingFirm: result.recalling_firm || "",
    voluntaryMandated: result.voluntary_mandated || "",
    reportDate: result.report_date || "",
    city: result.city || "",
    state: result.state || "",
    country: result.country || "",
  }));

  return {
    recalls,
    totalCount: data.meta?.results?.total || recalls.length,
  };
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "events";

    // GET requests
    if (req.method === "GET") {
      const drugName = url.searchParams.get("drug") || "";
      const limit = parseInt(url.searchParams.get("limit") || "10", 10);

      if (action === "events") {
        const result = await searchAdverseEvents({ drugName, limit });
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "labels") {
        const result = await searchDrugLabels({ drugName, limit });
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "recalls") {
        const result = await searchDrugRecalls(drugName, limit);
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // POST requests for advanced search
    if (req.method === "POST") {
      const authHeader = req.headers.get("Authorization");
      if (!authHeader) {
        return new Response(
          JSON.stringify({ error: "Missing authorization header" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

      const supabase = createClient(supabaseUrl, supabaseAnonKey, {
        global: { headers: { Authorization: authHeader } },
      });

      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) {
        return new Response(
          JSON.stringify({ error: "Unauthorized" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const body = await req.json();
      const { type, sessionId, ...searchParams } = body;

      let result;
      if (type === "labels") {
        result = await searchDrugLabels(searchParams as DrugLabelRequest);
      } else if (type === "recalls") {
        result = await searchDrugRecalls(searchParams.drugName, searchParams.limit);
      } else {
        result = await searchAdverseEvents(searchParams as AdverseEventRequest);
      }

      // Log to evidence_requests for audit if sessionId provided
      if (sessionId) {
        const { error: insertError } = await supabase.from("evidence_requests").insert({
          session_id: sessionId,
          query_context: searchParams,
          query_strings: { openfda: body },
          sources: ["openfda"],
        });

        if (insertError) {
          console.error("Error logging evidence request:", insertError);
        }
      }

      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("openFDA error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
