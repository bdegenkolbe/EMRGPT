import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface MappingNode {
  code: string;
  system: string;
  label: string;
}

interface MappingEdge {
  id: string;
  source: MappingNode;
  target: MappingNode;
  confidence: number;
  mappingType: string;
  validationStatus: string;
  conflictType?: string;
  conflictSeverity?: string;
}

interface ConflictInfo {
  type: 'transitive_inconsistency' | 'bidirectional_asymmetry' | 'circular_reference' | 'orphan_mapping' | 'multiple_exact_targets';
  severity: 'error' | 'warning' | 'info';
  description: string;
  involvedMappings: string[];
  suggestedResolution?: string;
  path?: string[];
}

interface GraphResult {
  nodes: MappingNode[];
  edges: MappingEdge[];
  conflicts: ConflictInfo[];
  stats: {
    totalNodes: number;
    totalEdges: number;
    maxDepth: number;
    systemCounts: Record<string, number>;
  };
}

interface ValidationSummary {
  totalMappings: number;
  validatedAt: string;
  conflicts: ConflictInfo[];
  byType: Record<string, number>;
  bySeverity: Record<string, number>;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const body = await req.json();
    const { action, code, system, mappingId, resolution, userId } = body;

    switch (action) {
      case "get-graph":
        return handleGetGraph(supabase, code, system);
      
      case "validate-all":
        return handleValidateAll(supabase);
      
      case "validate-single":
        return handleValidateSingle(supabase, mappingId);
      
      case "detect-cycles":
        return handleDetectCycles(supabase, code, system);
      
      case "resolve-conflict":
        return handleResolveConflict(supabase, mappingId, resolution, userId);
      
      case "get-conflicts":
        return handleGetConflicts(supabase);
      
      case "get-stats":
        return handleGetStats(supabase);
      
      case "find-orphans":
        return handleFindOrphans(supabase);
      
      case "link-bidirectional":
        return handleLinkBidirectional(supabase);
      
      default:
        return new Response(
          JSON.stringify({ error: "Unknown action. Available: get-graph, validate-all, validate-single, detect-cycles, resolve-conflict, get-conflicts, get-stats, find-orphans, link-bidirectional" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error) {
    console.error("Validation error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// ============ Action Handlers ============

async function handleGetGraph(supabase: any, code: string, system: string) {
  if (!code || !system) {
    return new Response(
      JSON.stringify({ error: "code and system required" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const result = await buildMappingGraph(supabase, code, system);
  
  return new Response(
    JSON.stringify(result),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleValidateAll(supabase: any) {
  const summary = await validateAllMappings(supabase);
  
  return new Response(
    JSON.stringify(summary),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleValidateSingle(supabase: any, mappingId: string) {
  if (!mappingId) {
    return new Response(
      JSON.stringify({ error: "mappingId required" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  // Get the mapping
  const { data: mapping, error } = await supabase
    .from("ontology_mappings")
    .select("*")
    .eq("id", mappingId)
    .single();

  if (error || !mapping) {
    return new Response(
      JSON.stringify({ error: "Mapping not found" }),
      { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  // Build graph from this mapping's source
  const graph = await buildMappingGraph(supabase, mapping.source_code, mapping.source_system);
  const relevantConflicts = graph.conflicts.filter(c => c.involvedMappings.includes(mappingId));

  // Update mapping status
  const newStatus = relevantConflicts.length > 0 ? "conflict" : "valid";
  const conflictDetails = relevantConflicts.length > 0 ? relevantConflicts[0] : null;

  await supabase
    .from("ontology_mappings")
    .update({
      validation_status: newStatus,
      conflict_type: conflictDetails?.type || null,
      conflict_severity: conflictDetails?.severity || null,
      conflict_details: conflictDetails,
      last_validated_at: new Date().toISOString(),
    })
    .eq("id", mappingId);

  return new Response(
    JSON.stringify({ 
      status: newStatus, 
      conflicts: relevantConflicts,
      graph: { nodes: graph.nodes.length, edges: graph.edges.length }
    }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleDetectCycles(supabase: any, code: string, system: string) {
  if (!code || !system) {
    return new Response(
      JSON.stringify({ error: "code and system required for cycle detection" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  // Use the database function for efficient cycle detection
  const { data: cycles, error } = await supabase
    .rpc('find_circular_mappings', {
      start_code: code,
      start_system: system,
      max_depth: 6
    });

  if (error) {
    console.error("Cycle detection error:", error);
    // Fallback to in-memory detection
    const graph = await buildMappingGraph(supabase, code, system, 6);
    const circularConflicts = graph.conflicts.filter(c => c.type === 'circular_reference');
    
    return new Response(
      JSON.stringify({ cycles: circularConflicts, source: 'in-memory' }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  return new Response(
    JSON.stringify({ cycles: cycles || [], source: 'database' }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleResolveConflict(supabase: any, mappingId: string, resolution: string, userId?: string) {
  if (!mappingId || !resolution) {
    return new Response(
      JSON.stringify({ error: "mappingId and resolution required" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const validResolutions = ['valid', 'exception', 'delete'];
  if (!validResolutions.includes(resolution)) {
    return new Response(
      JSON.stringify({ error: `Invalid resolution. Must be one of: ${validResolutions.join(', ')}` }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (resolution === 'delete') {
    const { error } = await supabase
      .from("ontology_mappings")
      .delete()
      .eq("id", mappingId);

    if (error) throw error;
    return new Response(
      JSON.stringify({ success: true, action: 'deleted' }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const { error } = await supabase
    .from("ontology_mappings")
    .update({
      validation_status: resolution,
      resolved_by: userId || null,
      resolved_at: new Date().toISOString(),
      conflict_details: null,
      conflict_type: null,
      conflict_severity: null,
    })
    .eq("id", mappingId);

  if (error) throw error;

  return new Response(
    JSON.stringify({ success: true, action: 'resolved', newStatus: resolution }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleGetConflicts(supabase: any) {
  const { data, error } = await supabase
    .from("ontology_mappings")
    .select("*")
    .eq("validation_status", "conflict")
    .order("conflict_severity", { ascending: true })
    .order("created_at", { ascending: false })
    .limit(200);

  if (error) throw error;

  // Group by conflict type
  const byType: Record<string, any[]> = {};
  for (const m of data || []) {
    const type = m.conflict_type || 'unknown';
    if (!byType[type]) byType[type] = [];
    byType[type].push(m);
  }

  return new Response(
    JSON.stringify({ 
      conflicts: data || [], 
      total: data?.length || 0,
      byType 
    }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleGetStats(supabase: any) {
  const { data: allMappings, error } = await supabase
    .from("ontology_mappings")
    .select("validation_status, source_system, target_system, mapping_type, conflict_type, is_bidirectional");

  if (error) throw error;

  const stats = {
    total: allMappings?.length || 0,
    byStatus: {} as Record<string, number>,
    byDirection: {} as Record<string, number>,
    byMappingType: {} as Record<string, number>,
    byConflictType: {} as Record<string, number>,
    bidirectionalCount: 0,
  };

  for (const m of allMappings || []) {
    stats.byStatus[m.validation_status] = (stats.byStatus[m.validation_status] || 0) + 1;
    
    const dir = `${m.source_system}→${m.target_system}`;
    stats.byDirection[dir] = (stats.byDirection[dir] || 0) + 1;
    
    stats.byMappingType[m.mapping_type] = (stats.byMappingType[m.mapping_type] || 0) + 1;
    
    if (m.conflict_type) {
      stats.byConflictType[m.conflict_type] = (stats.byConflictType[m.conflict_type] || 0) + 1;
    }
    
    if (m.is_bidirectional) {
      stats.bidirectionalCount++;
    }
  }

  return new Response(
    JSON.stringify(stats),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleFindOrphans(supabase: any) {
  // Find mappings where the reverse doesn't exist but probably should
  const { data: mappings, error } = await supabase
    .from("ontology_mappings")
    .select("*")
    .eq("mapping_type", "exact")
    .is("reverse_mapping_id", null)
    .limit(100);

  if (error) throw error;

  const orphans: any[] = [];
  
  for (const m of mappings || []) {
    // Check if reverse exists
    const { data: reverse } = await supabase
      .from("ontology_mappings")
      .select("id")
      .eq("source_code", m.target_code)
      .eq("source_system", m.target_system)
      .eq("target_code", m.source_code)
      .eq("target_system", m.source_system)
      .maybeSingle();

    if (!reverse) {
      orphans.push({
        ...m,
        suggestedReverse: {
          source_code: m.target_code,
          source_system: m.target_system,
          source_label: m.target_label,
          target_code: m.source_code,
          target_system: m.source_system,
          target_label: m.source_label,
        }
      });
    }
  }

  return new Response(
    JSON.stringify({ orphans, total: orphans.length }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function handleLinkBidirectional(supabase: any) {
  // Find and link bidirectional mappings
  const { data: mappings, error } = await supabase
    .from("ontology_mappings")
    .select("*")
    .is("reverse_mapping_id", null);

  if (error) throw error;

  let linkedCount = 0;

  for (const m of mappings || []) {
    const { data: reverse } = await supabase
      .from("ontology_mappings")
      .select("id")
      .eq("source_code", m.target_code)
      .eq("source_system", m.target_system)
      .eq("target_code", m.source_code)
      .eq("target_system", m.source_system)
      .maybeSingle();

    if (reverse) {
      // Link both directions
      await supabase
        .from("ontology_mappings")
        .update({ 
          reverse_mapping_id: reverse.id,
          is_bidirectional: true 
        })
        .eq("id", m.id);

      await supabase
        .from("ontology_mappings")
        .update({ 
          reverse_mapping_id: m.id,
          is_bidirectional: true 
        })
        .eq("id", reverse.id);

      linkedCount++;
    }
  }

  return new Response(
    JSON.stringify({ linkedCount, message: `Linked ${linkedCount} bidirectional mapping pairs` }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

// ============ Graph Building & Conflict Detection ============

async function buildMappingGraph(
  supabase: any,
  startCode: string,
  startSystem: string,
  maxDepth: number = 3
): Promise<GraphResult> {
  const nodes: Map<string, MappingNode> = new Map();
  const edges: MappingEdge[] = [];
  const conflicts: ConflictInfo[] = [];
  const visited = new Set<string>();
  const pathStack: string[] = []; // For cycle detection
  let currentMaxDepth = 0;

  async function traverse(code: string, system: string, depth: number) {
    const nodeKey = `${system}:${code}`;
    
    // Check for cycles
    if (pathStack.includes(nodeKey)) {
      conflicts.push({
        type: 'circular_reference',
        severity: 'error',
        description: `Zirkuläre Referenz erkannt: ${[...pathStack, nodeKey].join(' → ')}`,
        involvedMappings: [],
        path: [...pathStack, nodeKey],
      });
      return;
    }
    
    if (visited.has(nodeKey) || depth > maxDepth) return;
    visited.add(nodeKey);
    pathStack.push(nodeKey);
    currentMaxDepth = Math.max(currentMaxDepth, depth);

    // Get outgoing mappings
    const { data: outgoing } = await supabase
      .from("ontology_mappings")
      .select("*")
      .eq("source_code", code)
      .eq("source_system", system);

    // Get incoming mappings
    const { data: incoming } = await supabase
      .from("ontology_mappings")
      .select("*")
      .eq("target_code", code)
      .eq("target_system", system);

    for (const m of outgoing || []) {
      const sourceNode: MappingNode = { code: m.source_code, system: m.source_system, label: m.source_label };
      const targetNode: MappingNode = { code: m.target_code, system: m.target_system, label: m.target_label };
      
      nodes.set(`${sourceNode.system}:${sourceNode.code}`, sourceNode);
      nodes.set(`${targetNode.system}:${targetNode.code}`, targetNode);

      edges.push({
        id: m.id,
        source: sourceNode,
        target: targetNode,
        confidence: m.confidence,
        mappingType: m.mapping_type,
        validationStatus: m.validation_status,
        conflictType: m.conflict_type,
        conflictSeverity: m.conflict_severity,
      });

      await traverse(m.target_code, m.target_system, depth + 1);
    }

    for (const m of incoming || []) {
      const sourceNode: MappingNode = { code: m.source_code, system: m.source_system, label: m.source_label };
      const targetNode: MappingNode = { code: m.target_code, system: m.target_system, label: m.target_label };
      
      nodes.set(`${sourceNode.system}:${sourceNode.code}`, sourceNode);
      nodes.set(`${targetNode.system}:${targetNode.code}`, targetNode);

      const existingEdge = edges.find(e => e.id === m.id);
      if (!existingEdge) {
        edges.push({
          id: m.id,
          source: sourceNode,
          target: targetNode,
          confidence: m.confidence,
          mappingType: m.mapping_type,
          validationStatus: m.validation_status,
          conflictType: m.conflict_type,
          conflictSeverity: m.conflict_severity,
        });
      }

      await traverse(m.source_code, m.source_system, depth + 1);
    }

    pathStack.pop();
  }

  await traverse(startCode, startSystem, 0);

  // Detect additional conflicts
  detectConflicts(edges, conflicts);

  // Calculate system counts
  const systemCounts: Record<string, number> = {};
  for (const node of nodes.values()) {
    systemCounts[node.system] = (systemCounts[node.system] || 0) + 1;
  }

  return {
    nodes: Array.from(nodes.values()),
    edges,
    conflicts,
    stats: {
      totalNodes: nodes.size,
      totalEdges: edges.length,
      maxDepth: currentMaxDepth,
      systemCounts,
    },
  };
}

function detectConflicts(edges: MappingEdge[], conflicts: ConflictInfo[]) {
  // Group edges by source
  const bySource = new Map<string, MappingEdge[]>();
  for (const edge of edges) {
    const key = `${edge.source.system}:${edge.source.code}`;
    if (!bySource.has(key)) bySource.set(key, []);
    bySource.get(key)!.push(edge);
  }

  // Check for multiple exact mappings to same target system
  for (const [sourceKey, sourceEdges] of bySource) {
    const targetsBySystem = new Map<string, MappingEdge[]>();
    
    for (const edge of sourceEdges) {
      const targetSystem = edge.target.system;
      if (!targetsBySystem.has(targetSystem)) targetsBySystem.set(targetSystem, []);
      targetsBySystem.get(targetSystem)!.push(edge);
    }

    for (const [targetSystem, systemEdges] of targetsBySystem) {
      if (systemEdges.length > 1) {
        const exactMappings = systemEdges.filter(e => e.mappingType === 'exact');
        if (exactMappings.length > 1) {
          conflicts.push({
            type: 'multiple_exact_targets',
            severity: 'warning',
            description: `${sourceKey} hat ${exactMappings.length} exakte Zuordnungen zu ${targetSystem}: ${exactMappings.map(e => e.target.code).join(', ')}`,
            involvedMappings: exactMappings.map(e => e.id),
            suggestedResolution: 'Prüfen Sie, ob eine Zuordnung auf "broad" oder "narrow" geändert werden sollte',
          });
        }
      }
    }
  }

  // Check for bidirectional asymmetries
  const edgesByPair = new Map<string, MappingEdge[]>();
  for (const edge of edges) {
    const pairKey = [
      `${edge.source.system}:${edge.source.code}`,
      `${edge.target.system}:${edge.target.code}`
    ].sort().join('|');
    
    if (!edgesByPair.has(pairKey)) edgesByPair.set(pairKey, []);
    edgesByPair.get(pairKey)!.push(edge);
  }

  for (const [_, pairEdges] of edgesByPair) {
    if (pairEdges.length === 2) {
      const [e1, e2] = pairEdges;
      // Check if one is exact and other is not
      if ((e1.mappingType === 'exact') !== (e2.mappingType === 'exact')) {
        conflicts.push({
          type: 'bidirectional_asymmetry',
          severity: 'info',
          description: `Asymmetrische Zuordnung: ${e1.source.code} (${e1.mappingType}) ↔ ${e2.source.code} (${e2.mappingType})`,
          involvedMappings: [e1.id, e2.id],
          suggestedResolution: 'Überprüfen Sie, ob beide Richtungen denselben Mapping-Typ haben sollten',
        });
      }
      
      // Check for significant confidence difference
      if (Math.abs(e1.confidence - e2.confidence) > 0.2) {
        conflicts.push({
          type: 'bidirectional_asymmetry',
          severity: 'info',
          description: `Konfidenzdifferenz: ${e1.source.code} (${e1.confidence}) ↔ ${e2.source.code} (${e2.confidence})`,
          involvedMappings: [e1.id, e2.id],
        });
      }
    }
  }

  // Detect transitive inconsistencies (A→B, B→C implies A→C)
  detectTransitiveInconsistencies(edges, bySource, conflicts);
}

function detectTransitiveInconsistencies(
  edges: MappingEdge[], 
  bySource: Map<string, MappingEdge[]>,
  conflicts: ConflictInfo[]
) {
  // For each A→B, check if there's also B→C and A→C
  for (const edge of edges) {
    if (edge.mappingType !== 'exact') continue;
    
    const targetKey = `${edge.target.system}:${edge.target.code}`;
    const sourceKey = `${edge.source.system}:${edge.source.code}`;
    
    const transitiveEdges = bySource.get(targetKey) || [];
    
    for (const transEdge of transitiveEdges) {
      if (transEdge.mappingType !== 'exact') continue;
      
      // We have A→B (exact) and B→C (exact)
      // Check if A→C exists and is consistent
      const sourceEdges = bySource.get(sourceKey) || [];
      const directEdge = sourceEdges.find(e => 
        e.target.system === transEdge.target.system && 
        e.target.code === transEdge.target.code
      );
      
      if (directEdge && directEdge.mappingType !== 'exact') {
        // A→B (exact), B→C (exact), but A→C is not exact
        conflicts.push({
          type: 'transitive_inconsistency',
          severity: 'warning',
          description: `Transitive Inkonsistenz: ${sourceKey}→${targetKey} (exact) + ${targetKey}→${transEdge.target.system}:${transEdge.target.code} (exact), aber direktes Mapping ist "${directEdge.mappingType}"`,
          involvedMappings: [edge.id, transEdge.id, directEdge.id],
          suggestedResolution: 'Das direkte Mapping sollte möglicherweise auch "exact" sein',
        });
      }
    }
  }
}

async function validateAllMappings(supabase: any): Promise<ValidationSummary> {
  const { data: allMappings, error } = await supabase
    .from("ontology_mappings")
    .select("*")
    .limit(2000);

  if (error) throw error;

  const edges: MappingEdge[] = (allMappings || []).map((m: any) => ({
    id: m.id,
    source: { code: m.source_code, system: m.source_system, label: m.source_label },
    target: { code: m.target_code, system: m.target_system, label: m.target_label },
    confidence: m.confidence,
    mappingType: m.mapping_type,
    validationStatus: m.validation_status,
  }));

  const conflicts: ConflictInfo[] = [];
  detectConflicts(edges, conflicts);

  // Also use database function for transitive validation
  const { data: transitiveConflicts } = await supabase
    .rpc('validate_transitive_mappings', { p_limit: 100 });

  for (const tc of transitiveConflicts || []) {
    conflicts.push({
      type: tc.conflict_type as any,
      severity: 'warning',
      description: tc.description,
      involvedMappings: [tc.mapping_id, ...(tc.related_ids || [])],
    });
  }

  // Update mappings with conflict status
  const conflictMappingIds = new Set<string>();
  const byType: Record<string, number> = {};
  const bySeverity: Record<string, number> = {};

  for (const conflict of conflicts) {
    byType[conflict.type] = (byType[conflict.type] || 0) + 1;
    bySeverity[conflict.severity] = (bySeverity[conflict.severity] || 0) + 1;
    
    for (const mappingId of conflict.involvedMappings) {
      if (!conflictMappingIds.has(mappingId)) {
        conflictMappingIds.add(mappingId);
        
        await supabase
          .from("ontology_mappings")
          .update({
            validation_status: "conflict",
            conflict_type: conflict.type,
            conflict_severity: conflict.severity,
            conflict_details: {
              type: conflict.type,
              severity: conflict.severity,
              description: conflict.description,
            },
            last_validated_at: new Date().toISOString(),
          })
          .eq("id", mappingId)
          .in("validation_status", ["pending", "conflict"]);
      }
    }
  }

  // Mark remaining pending as valid
  await supabase
    .from("ontology_mappings")
    .update({
      validation_status: "valid",
      last_validated_at: new Date().toISOString(),
    })
    .eq("validation_status", "pending");

  return {
    totalMappings: allMappings?.length || 0,
    validatedAt: new Date().toISOString(),
    conflicts,
    byType,
    bySeverity,
  };
}
