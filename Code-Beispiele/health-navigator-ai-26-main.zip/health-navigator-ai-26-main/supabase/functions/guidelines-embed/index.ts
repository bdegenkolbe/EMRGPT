import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface EmbedRequest {
  guideline_id: string;
  content: string;
  sync?: boolean; // If true, process synchronously instead of background
}

// Fixed-size chunking with overlap for reliable token limits
// text-embedding-3-small has 8192 token limit - use ~1500 chars per chunk (~400 tokens) for safety
const MAX_CHUNK_CHARS = 1500;
const CHUNK_OVERLAP = 150; // Overlap for context continuity

function fixedSizeChunk(text: string): { content: string; sectionTitle?: string }[] {
  const chunks: { content: string; sectionTitle?: string }[] = [];
  
  // Clean up text
  const cleanText = text.replace(/\s+/g, ' ').trim();
  
  if (cleanText.length <= MAX_CHUNK_CHARS) {
    return [{ content: cleanText }];
  }
  
  let position = 0;
  
  while (position < cleanText.length) {
    let end = Math.min(position + MAX_CHUNK_CHARS, cleanText.length);
    
    // Try to break at sentence boundary for cleaner chunks
    if (end < cleanText.length) {
      const sentenceEnd = cleanText.lastIndexOf('. ', end);
      const paragraphEnd = cleanText.lastIndexOf('\n', end);
      const breakPoint = Math.max(sentenceEnd, paragraphEnd);
      
      // Only use break point if it's not too far back
      if (breakPoint > position + MAX_CHUNK_CHARS * 0.5) {
        end = breakPoint + 1;
      }
    }
    
    const chunkContent = cleanText.slice(position, end).trim();
    
    if (chunkContent.length > 0) {
      // Try to extract a section title from the start
      const titleMatch = chunkContent.match(/^(?:(\d+\.?\s+[^\n.]{5,60})|([A-ZÄÖÜ][^\n.]{5,40}):?)/);
      const sectionTitle = titleMatch ? titleMatch[0].trim().slice(0, 80) : undefined;
      
      chunks.push({ content: chunkContent, sectionTitle });
    }
    
    // Move position with overlap (except for last chunk)
    position = end < cleanText.length ? end - CHUNK_OVERLAP : cleanText.length;
  }
  
  return chunks;
}

// Validate and truncate text to stay within token limits
function validateChunkForEmbedding(text: string): string {
  // text-embedding-3-small: 8192 tokens max
  // Conservative estimate: ~4 chars per token, use 6000 tokens max (~24000 chars)
  const MAX_CHARS = 6000;
  if (text.length > MAX_CHARS) {
    console.warn(`Truncating chunk from ${text.length} to ${MAX_CHARS} chars`);
    return text.slice(0, MAX_CHARS);
  }
  return text;
}

async function getEmbedding(text: string, apiKey: string): Promise<number[]> {
  const response = await fetch("https://api.openai.com/v1/embeddings", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "text-embedding-3-small",
      input: text,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenAI Embedding error: ${response.status} - ${error}`);
  }

  const data = await response.json();
  return data.data[0].embedding;
}

// Batch embedding - up to 100 texts at once for efficiency
async function getBatchEmbeddings(texts: string[], apiKey: string): Promise<number[][]> {
  // OpenAI supports batch embedding - much faster than individual calls
  const response = await fetch("https://api.openai.com/v1/embeddings", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "text-embedding-3-small",
      input: texts,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenAI Batch Embedding error: ${response.status} - ${error}`);
  }

  const data = await response.json();
  // Sort by index to maintain order
  const sorted = data.data.sort((a: { index: number }, b: { index: number }) => a.index - b.index);
  return sorted.map((d: { embedding: number[] }) => d.embedding);
}

// Background processing function
async function processEmbedding(guidelineId: string, content: string) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");

  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  const updateStatus = async (status: string, progress: number, error?: string, totalChunks?: number) => {
    const updateData: Record<string, unknown> = {
      embedding_status: status,
      embedding_progress: progress,
    };
    if (error !== undefined) updateData.embedding_error = error;
    if (totalChunks !== undefined) updateData.total_chunks = totalChunks;
    
    await supabase.from("guidelines").update(updateData).eq("id", guidelineId);
  };

  try {
    console.log(`[Background] Starting embedding for ${guidelineId}, content length: ${content.length}`);

    // Delete existing chunks
    await supabase.from("guideline_chunks").delete().eq("guideline_id", guidelineId);

    // Chunk the content with fixed sizes
    const chunks = fixedSizeChunk(content);
    console.log(`[Background] Created ${chunks.length} fixed-size chunks`);

    if (chunks.length === 0) {
      await updateStatus("failed", 0, "Keine Inhalte zum Vektorisieren gefunden", 0);
      return;
    }

    await updateStatus("processing", 5, null, chunks.length);

    // Batch process embeddings for speed (max 20 per batch to avoid timeouts)
    const BATCH_SIZE = 20;
    const embeddedChunks = [];
    
    for (let batchStart = 0; batchStart < chunks.length; batchStart += BATCH_SIZE) {
      const batchEnd = Math.min(batchStart + BATCH_SIZE, chunks.length);
      const batch = chunks.slice(batchStart, batchEnd);
      const batchTexts = batch.map(c => validateChunkForEmbedding(c.content));

      console.log(`[Background] Processing batch ${batchStart}-${batchEnd} of ${chunks.length}`);

      let embeddings: number[][];
      
      if (openaiKey) {
        embeddings = await getBatchEmbeddings(batchTexts, openaiKey);
      } else if (lovableKey) {
        // Fallback: process individually with Lovable AI (doesn't support batch)
        embeddings = [];
        for (const text of batchTexts) {
          const response = await fetch("https://ai.gateway.lovable.dev/v1/embeddings", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${lovableKey}`,
            },
            body: JSON.stringify({
              model: "text-embedding-3-small",
              input: text,
            }),
          });
          if (!response.ok) throw new Error(`Embedding failed: ${response.status}`);
          const data = await response.json();
          embeddings.push(data.data[0].embedding);
        }
      } else {
        throw new Error("No API key configured for embeddings");
      }

      // Add to results
      for (let i = 0; i < batch.length; i++) {
        const chunkIndex = batchStart + i;
        embeddedChunks.push({
          guideline_id: guidelineId,
          chunk_index: chunkIndex,
          content: batch[i].content,
          section_title: batch[i].sectionTitle,
          token_count: Math.ceil(batch[i].content.split(/\s+/).length * 1.3),
          embedding: JSON.stringify(embeddings[i]),
        });
      }

      // Update progress (5% for chunking, 90% for embedding, 5% for saving)
      const progress = 5 + Math.round((batchEnd / chunks.length) * 90);
      await updateStatus("processing", progress, null);
    }

    // Update to 95% before saving
    await updateStatus("processing", 95, null);

    // Insert chunks in batches to avoid payload limits
    const INSERT_BATCH_SIZE = 50;
    for (let i = 0; i < embeddedChunks.length; i += INSERT_BATCH_SIZE) {
      const insertBatch = embeddedChunks.slice(i, i + INSERT_BATCH_SIZE);
      const { error: insertError } = await supabase
        .from("guideline_chunks")
        .insert(insertBatch);

      if (insertError) {
        console.error(`[Background] Insert error at batch ${i}:`, insertError);
        throw insertError;
      }
    }

    // Mark as complete
    await updateStatus("completed", 100, null, chunks.length);
    console.log(`[Background] Successfully embedded ${chunks.length} chunks for ${guidelineId}`);

  } catch (error) {
    console.error(`[Background] Embedding error for ${guidelineId}:`, error);
    await updateStatus("failed", 0, error.message || "Embedding failed");
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { guideline_id, content, sync = false }: EmbedRequest = await req.json();

    if (!guideline_id || !content) {
      return new Response(
        JSON.stringify({ error: "guideline_id and content are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Immediately set status to processing
    await supabase
      .from("guidelines")
      .update({ 
        embedding_status: "processing",
        embedding_progress: 0,
        embedding_error: null,
      })
      .eq("id", guideline_id);

    console.log(`Starting embedding for ${guideline_id}, sync=${sync}, content length: ${content.length}`);

    // Synchronous mode - process inline and return result
    if (sync) {
      try {
        await processEmbedding(guideline_id, content);
        return new Response(
          JSON.stringify({ 
            success: true, 
            status: "completed",
            message: "Embedding completed successfully."
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      } catch (error) {
        console.error("Sync embedding error:", error);
        return new Response(
          JSON.stringify({ 
            success: false, 
            status: "failed",
            error: error.message || "Embedding failed"
          }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Async mode - use background processing
    // @ts-ignore - EdgeRuntime is available in Supabase Edge Functions
    if (typeof EdgeRuntime !== "undefined" && EdgeRuntime.waitUntil) {
      // @ts-ignore
      EdgeRuntime.waitUntil(processEmbedding(guideline_id, content));
    } else {
      // Fallback: process in background without waitUntil (may timeout for large files)
      processEmbedding(guideline_id, content).catch(err => {
        console.error("Background processing error:", err);
      });
    }

    // Return immediately - processing happens in background
    return new Response(
      JSON.stringify({ 
        success: true, 
        status: "processing",
        message: "Embedding started. Progress will be updated in the database."
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Embedding error:", error);
    
    return new Response(
      JSON.stringify({ error: error.message || "Embedding failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
