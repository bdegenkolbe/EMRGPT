 import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
 import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
 
 const corsHeaders = {
   "Access-Control-Allow-Origin": "*",
   "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
 };
 
 interface ExplainRequest {
   hpo_code: string;
   label_en: string;
   definition?: string;
  synonyms?: string[];
 }
 
 interface ExplanationResult {
   hpo_code: string;
   explanation_de: string;
  explanation_en?: string;
  definition_en?: string;
  definition_de?: string;
  synonyms?: string[];
   cached: boolean;
 }
 
 /**
  * Generate explanations in German and English for an HPO term using AI
  */
async function generateExplanations(
   hpoCode: string,
   labelEn: string,
   definition?: string
): Promise<{ explanation_de: string; explanation_en: string; definition_de?: string }> {
  const prompt = `You are a medical expert for the Human Phenotype Ontology (HPO).

For the following HPO term, provide:
1. A German explanation for medical professionals
2. An English explanation for medical professionals
3. A German translation of the definition (if provided)

Requirements for explanations:
 - Präzise und klinisch korrekt sein
 - Den Begriff in einfachen Worten erklären
 - Typische Erscheinungsformen oder Beispiele nennen
 - Maximal 150 Wörter umfassen
 
 HPO-Code: ${hpoCode}
English Term: "${labelEn}"
 ${definition ? `Definition: ${definition}` : ""}
 
Respond ONLY with a JSON object in this exact format:
{
  "explanation_de": "German explanation here",
  "explanation_en": "English explanation here",
  "definition_de": "German translation of definition (or null if no definition provided)"
}`;
 
   // Try OpenAI first, then Lovable Gateway as fallback
   const openaiKey = Deno.env.get("OPENAI_API_KEY");
   const lovableKey = Deno.env.get("LOVABLE_API_KEY");
 
   let response: Response;
 
   if (openaiKey) {
     response = await fetch("https://api.openai.com/v1/chat/completions", {
       method: "POST",
       headers: {
         "Content-Type": "application/json",
         Authorization: `Bearer ${openaiKey}`,
       },
       body: JSON.stringify({
         model: "gpt-4o-mini",
         messages: [
           {
             role: "system",
            content: "You are an expert in medical terminology and HPO (Human Phenotype Ontology). Always respond with valid JSON.",
           },
           { role: "user", content: prompt },
         ],
         temperature: 0.3,
        max_tokens: 1000,
       }),
     });
   } else if (lovableKey) {
     response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
       method: "POST",
       headers: {
         "Content-Type": "application/json",
         Authorization: `Bearer ${lovableKey}`,
       },
       body: JSON.stringify({
         model: "google/gemini-3-flash-preview",
         messages: [
           {
             role: "system",
            content: "You are an expert in medical terminology and HPO (Human Phenotype Ontology). Always respond with valid JSON.",
           },
           { role: "user", content: prompt },
         ],
         temperature: 0.3,
        max_tokens: 1000,
       }),
     });
   } else {
     throw new Error("No AI API key configured");
   }
 
   if (!response.ok) {
     const errorText = await response.text();
     console.error("AI API error:", response.status, errorText);
     throw new Error(`AI explanation failed: ${response.status}`);
   }
 
   const data = await response.json();
  const content = data.choices?.[0]?.message?.content?.trim() || "";
  
  // Parse JSON from response
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    console.error("Could not parse AI response as JSON:", content);
    // Fallback: use the content as German explanation
    return {
      explanation_de: content,
      explanation_en: "",
      definition_de: undefined,
    };
  }
  
  try {
    const parsed = JSON.parse(jsonMatch[0]);
    return {
      explanation_de: parsed.explanation_de || "",
      explanation_en: parsed.explanation_en || "",
      definition_de: parsed.definition_de || undefined,
    };
  } catch (e) {
    console.error("JSON parse error:", e);
    return {
      explanation_de: content,
      explanation_en: "",
      definition_de: undefined,
    };
  }
 }
 
 serve(async (req) => {
   if (req.method === "OPTIONS") {
     return new Response(null, { headers: corsHeaders });
   }
 
   try {
     const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
     const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
     const supabase = createClient(supabaseUrl, supabaseServiceKey);
 
    const { hpo_code, label_en, definition, synonyms }: ExplainRequest = await req.json();
 
     if (!hpo_code || !label_en) {
       return new Response(
         JSON.stringify({ error: "Missing required fields: hpo_code and label_en" }),
         { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
       );
     }
 
     console.log(`Looking up explanation for ${hpo_code}: ${label_en}`);
 
    // Check if explanation already exists (with all fields)
     const { data: existing } = await supabase
       .from("hpo_translations")
      .select("explanation_de, explanation_en, definition_en, definition_de, synonyms, explanation_generated_at")
       .eq("hpo_code", hpo_code)
       .not("explanation_de", "is", null)
       .maybeSingle();
 
    // If all fields exist, return cached
    if (existing?.explanation_de && existing?.explanation_en) {
       console.log(`Found cached explanation for ${hpo_code}`);
       const result: ExplanationResult = {
         hpo_code,
         explanation_de: existing.explanation_de,
        explanation_en: existing.explanation_en,
        definition_en: existing.definition_en,
        definition_de: existing.definition_de,
        synonyms: existing.synonyms,
         cached: true,
       };
       return new Response(JSON.stringify(result), {
         headers: { ...corsHeaders, "Content-Type": "application/json" },
       });
     }
 
     // Generate new explanation
     console.log(`Generating new explanation for ${hpo_code}`);
    const explanations = await generateExplanations(hpo_code, label_en, definition);
 
    if (!explanations.explanation_de) {
       return new Response(
         JSON.stringify({ error: "Failed to generate explanation" }),
         { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
       );
     }
 
     // Save explanation to database (upsert)
     const { error: upsertError } = await supabase
       .from("hpo_translations")
       .upsert(
         {
           hpo_code,
           label_en,
           label_de: label_en, // Will be updated by hpo-translate if not exists
          definition_en: definition || null,
          definition_de: explanations.definition_de || null,
          explanation_de: explanations.explanation_de,
          explanation_en: explanations.explanation_en,
          synonyms: synonyms || [],
           explanation_generated_at: new Date().toISOString(),
           source: "ai_translated",
         },
         { onConflict: "hpo_code" }
       );
 
     if (upsertError) {
       console.error("Error saving explanation:", upsertError);
       // Still return the explanation even if saving fails
     } else {
       console.log(`Saved explanation for ${hpo_code}`);
     }
 
     const result: ExplanationResult = {
       hpo_code,
      explanation_de: explanations.explanation_de,
      explanation_en: explanations.explanation_en,
      definition_en: definition,
      definition_de: explanations.definition_de,
      synonyms: synonyms,
       cached: false,
     };
 
     return new Response(JSON.stringify(result), {
       headers: { ...corsHeaders, "Content-Type": "application/json" },
     });
   } catch (error) {
     console.error("hpo-explain error:", error);
     return new Response(
       JSON.stringify({ error: error.message || "Internal server error" }),
       { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
     );
   }
 });