import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface DownloadRequest {
  pmcid: string;
  title?: string;
  metadata?: {
    authors?: string[];
    journal?: string;
    publicationDate?: string;
    doi?: string;
    abstract?: string;
  };
}

interface DownloadResponse {
  success: boolean;
  filePath?: string;
  fileSize?: number;
  error?: string;
}

/**
 * Try multiple PDF sources for a PMC article
 * Europe PMC and PMC provide different access points
 */
async function tryDownloadPdf(pmcid: string): Promise<{ blob: Blob; contentType: string } | null> {
  const normalizedId = pmcid.startsWith("PMC") ? pmcid : `PMC${pmcid}`;
  const numericId = normalizedId.replace("PMC", "");
  
  // List of PDF sources to try in order
  const sources = [
    // 1. PMC OA FTP-style URL (most reliable for Open Access)
    `https://www.ncbi.nlm.nih.gov/pmc/articles/${normalizedId}/pdf/`,
    // 2. Europe PMC article page with pdf parameter
    `https://europepmc.org/articles/${normalizedId}?pdf=render`,
    // 3. Direct PMC PDF endpoint
    `https://www.ncbi.nlm.nih.gov/pmc/articles/${normalizedId}/pdf`,
    // 4. Europe PMC backend (often blocked)
    `https://europepmc.org/backend/ptpmcrender.fcgi?accid=${normalizedId}&blobtype=pdf`,
  ];

  for (const url of sources) {
    console.log(`Trying PDF source: ${url}`);
    try {
      const response = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept": "application/pdf,*/*",
          "Accept-Language": "en-US,en;q=0.9",
          "Referer": "https://europepmc.org/",
        },
        redirect: "follow",
      });

      if (response.ok) {
        const contentType = response.headers.get("content-type") || "";
        // Check if we actually got a PDF
        if (contentType.includes("pdf")) {
          console.log(`Successfully downloaded PDF from: ${url}`);
          return { blob: await response.blob(), contentType };
        }
        // Some servers return HTML redirect pages
        if (contentType.includes("html")) {
          console.log(`Got HTML instead of PDF from: ${url}, trying next source`);
          continue;
        }
      } else {
        console.log(`Failed (${response.status}) from: ${url}`);
      }
    } catch (e) {
      console.log(`Error fetching ${url}:`, e);
    }
  }

  return null;
}

/**
 * Download PDF from Europe PMC/PMC and store in Supabase Storage
 */
async function downloadAndStorePdf(
  supabase: ReturnType<typeof createClient>,
  pmcid: string,
  title?: string,
  metadata?: DownloadRequest["metadata"]
): Promise<DownloadResponse> {
  console.log(`Attempting to download PDF for: ${pmcid}`);

  // Try multiple sources
  const result = await tryDownloadPdf(pmcid);

  if (!result) {
    console.error(`Failed to download PDF from any source for: ${pmcid}`);
    return {
      success: false,
      error: `PDF nicht verfügbar. Open Access PDFs sind möglicherweise nur auf der Verlagswebsite zugänglich.`,
    };
  }

  const pdfArrayBuffer = await result.blob.arrayBuffer();
  const pdfBytes = new Uint8Array(pdfArrayBuffer);

  console.log(`Downloaded PDF size: ${pdfBytes.length} bytes`);

  // Create safe filename
  const normalizedPmcid = pmcid.startsWith("PMC") ? pmcid : `PMC${pmcid}`;
  const safeTitle = title
    ? title
        .replace(/[^a-zA-Z0-9\s-]/g, "")
        .replace(/\s+/g, "_")
        .substring(0, 100)
    : normalizedPmcid;
  
  const fileName = `${normalizedPmcid}_${safeTitle}.pdf`;
  const filePath = `europepmc/${fileName}`;

  console.log(`Storing PDF at: ${filePath}`);

  // Upload to storage
  const { data: uploadData, error: uploadError } = await supabase.storage
    .from("guidelines")
    .upload(filePath, pdfBytes, {
      contentType: "application/pdf",
      upsert: true,
    });

  if (uploadError) {
    console.error("Storage upload error:", uploadError);
    return {
      success: false,
      error: `Storage upload failed: ${uploadError.message}`,
    };
  }

  console.log(`PDF stored successfully at: ${uploadData.path}`);

  // Optionally create a guideline entry for the downloaded document
  if (title) {
    const { error: guidelineError } = await supabase.from("guidelines").insert({
      title: title,
      description: metadata?.abstract || `Downloaded from Europe PMC (${normalizedPmcid})`,
      source: `Europe PMC - ${normalizedPmcid}`,
      file_name: fileName,
      file_path: filePath,
      file_size: pdfBytes.length,
      mime_type: "application/pdf",
      embedding_status: "pending",
    });

    if (guidelineError) {
      console.warn("Could not create guideline entry:", guidelineError);
      // Don't fail - PDF is already stored
    } else {
      console.log("Guideline entry created for:", title);
    }
  }

  return {
    success: true,
    filePath: filePath,
    fileSize: pdfBytes.length,
  };
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Require authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Use service role for storage operations
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify user is authenticated
    const supabaseAuth = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await supabaseAuth.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse request
    const body: DownloadRequest = await req.json();

    if (!body.pmcid) {
      return new Response(
        JSON.stringify({ error: "pmcid is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Download and store PDF
    const result = await downloadAndStorePdf(
      supabase,
      body.pmcid,
      body.title,
      body.metadata
    );

    if (!result.success) {
      // Return 200 with success: false for graceful handling
      // This is not a "bad request" - the request was valid, just the PDF wasn't available
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: result.error,
          pmcid: body.pmcid 
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        filePath: result.filePath,
        fileSize: result.fileSize,
        message: `PDF downloaded and stored successfully`,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Europe PMC Download error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
