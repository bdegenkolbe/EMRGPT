import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface UcumRequest {
  action: "validate" | "convert" | "base" | "suggest";
  unit?: string;
  value?: number;
  fromUnit?: string;
  toUnit?: string;
  query?: string;
}

interface UcumValidationResult {
  valid: boolean;
  unit?: string;
  ucumCode?: string;
  message?: string;
}

interface UcumConversionResult {
  success: boolean;
  fromValue?: number;
  fromUnit?: string;
  toValue?: number;
  toUnit?: string;
  message?: string;
}

// Common lab units with their UCUM codes and descriptions
const COMMON_UNITS: Record<string, { ucum: string; display: string; category: string }> = {
  // Blood counts
  "g/dL": { ucum: "g/dL", display: "g/dL (Gramm pro Deziliter)", category: "concentration" },
  "g/L": { ucum: "g/L", display: "g/L (Gramm pro Liter)", category: "concentration" },
  "mg/dL": { ucum: "mg/dL", display: "mg/dL (Milligramm pro Deziliter)", category: "concentration" },
  "mg/L": { ucum: "mg/L", display: "mg/L (Milligramm pro Liter)", category: "concentration" },
  "mmol/L": { ucum: "mmol/L", display: "mmol/L (Millimol pro Liter)", category: "molar" },
  "µmol/L": { ucum: "umol/L", display: "µmol/L (Mikromol pro Liter)", category: "molar" },
  "umol/L": { ucum: "umol/L", display: "µmol/L (Mikromol pro Liter)", category: "molar" },
  "nmol/L": { ucum: "nmol/L", display: "nmol/L (Nanomol pro Liter)", category: "molar" },
  "pmol/L": { ucum: "pmol/L", display: "pmol/L (Pikomol pro Liter)", category: "molar" },
  
  // Cell counts
  "/µL": { ucum: "/uL", display: "/µL (pro Mikroliter)", category: "count" },
  "/uL": { ucum: "/uL", display: "/µL (pro Mikroliter)", category: "count" },
  "10^9/L": { ucum: "10*9/L", display: "10⁹/L (Giga pro Liter)", category: "count" },
  "10^12/L": { ucum: "10*12/L", display: "10¹²/L (Tera pro Liter)", category: "count" },
  "Mio/µL": { ucum: "10*6/uL", display: "Mio/µL (Millionen pro Mikroliter)", category: "count" },
  "Tsd/µL": { ucum: "10*3/uL", display: "Tsd/µL (Tausend pro Mikroliter)", category: "count" },
  
  // Enzyme activity
  "U/L": { ucum: "U/L", display: "U/L (Units pro Liter)", category: "enzyme" },
  "IU/L": { ucum: "[IU]/L", display: "IU/L (Internationale Einheiten pro Liter)", category: "enzyme" },
  "mU/L": { ucum: "mU/L", display: "mU/L (Milli-Units pro Liter)", category: "enzyme" },
  "µU/mL": { ucum: "uU/mL", display: "µU/mL (Mikro-Units pro Milliliter)", category: "enzyme" },
  "uU/mL": { ucum: "uU/mL", display: "µU/mL (Mikro-Units pro Milliliter)", category: "enzyme" },
  
  // Percentages and ratios
  "%": { ucum: "%", display: "% (Prozent)", category: "ratio" },
  "ratio": { ucum: "1", display: "Ratio (dimensionslos)", category: "ratio" },
  "INR": { ucum: "1", display: "INR (International Normalized Ratio)", category: "ratio" },
  
  // Time-related
  "s": { ucum: "s", display: "s (Sekunden)", category: "time" },
  "min": { ucum: "min", display: "min (Minuten)", category: "time" },
  "h": { ucum: "h", display: "h (Stunden)", category: "time" },
  "mm/h": { ucum: "mm/h", display: "mm/h (Millimeter pro Stunde)", category: "rate" },
  
  // Volume
  "mL": { ucum: "mL", display: "mL (Milliliter)", category: "volume" },
  "L": { ucum: "L", display: "L (Liter)", category: "volume" },
  "µL": { ucum: "uL", display: "µL (Mikroliter)", category: "volume" },
  "uL": { ucum: "uL", display: "µL (Mikroliter)", category: "volume" },
  "fL": { ucum: "fL", display: "fL (Femtoliter)", category: "volume" },
  
  // Mass
  "kg": { ucum: "kg", display: "kg (Kilogramm)", category: "mass" },
  "g": { ucum: "g", display: "g (Gramm)", category: "mass" },
  "mg": { ucum: "mg", display: "mg (Milligramm)", category: "mass" },
  "µg": { ucum: "ug", display: "µg (Mikrogramm)", category: "mass" },
  "ug": { ucum: "ug", display: "µg (Mikrogramm)", category: "mass" },
  "ng": { ucum: "ng", display: "ng (Nanogramm)", category: "mass" },
  "pg": { ucum: "pg", display: "pg (Pikogramm)", category: "mass" },
  
  // Pressure
  "mmHg": { ucum: "mm[Hg]", display: "mmHg (Millimeter Quecksilbersäule)", category: "pressure" },
  "kPa": { ucum: "kPa", display: "kPa (Kilopascal)", category: "pressure" },
  
  // Special lab units
  "mEq/L": { ucum: "meq/L", display: "mEq/L (Milliäquivalent pro Liter)", category: "concentration" },
  "ng/mL": { ucum: "ng/mL", display: "ng/mL (Nanogramm pro Milliliter)", category: "concentration" },
  "pg/mL": { ucum: "pg/mL", display: "pg/mL (Pikogramm pro Milliliter)", category: "concentration" },
  "µg/dL": { ucum: "ug/dL", display: "µg/dL (Mikrogramm pro Deziliter)", category: "concentration" },
  "ug/dL": { ucum: "ug/dL", display: "µg/dL (Mikrogramm pro Deziliter)", category: "concentration" },
  "mIU/L": { ucum: "m[IU]/L", display: "mIU/L (Milli-Internationale Einheiten pro Liter)", category: "enzyme" },
  "mIU/mL": { ucum: "m[IU]/mL", display: "mIU/mL (Milli-Internationale Einheiten pro Milliliter)", category: "enzyme" },
};

// NLM UCUM service for validation
async function validateWithNLM(unit: string): Promise<UcumValidationResult> {
  try {
    const encodedUnit = encodeURIComponent(unit);
    const response = await fetch(
      `https://ucum.nlm.nih.gov/ucum-service/v1/isValidUCUM/${encodedUnit}`,
      { headers: { Accept: "application/json" } }
    );

    if (!response.ok) {
      // NLM service may return HTML for invalid, try to parse
      const text = await response.text();
      if (text.includes("valid") || text.includes("Valid")) {
        return { valid: true, unit, ucumCode: unit };
      }
      return { valid: false, unit, message: "Einheit nicht erkannt" };
    }

    const data = await response.json();
    return {
      valid: data.status === "valid" || data.valid === true,
      unit: data.ucumCode || unit,
      ucumCode: data.ucumCode || unit,
      message: data.message,
    };
  } catch (error) {
    console.error("NLM UCUM validation error:", error);
    // Fallback to local validation
    return validateLocally(unit);
  }
}

// Local validation using known units
function validateLocally(unit: string): UcumValidationResult {
  const normalized = unit.trim();
  
  // Check direct match
  if (COMMON_UNITS[normalized]) {
    return {
      valid: true,
      unit: normalized,
      ucumCode: COMMON_UNITS[normalized].ucum,
    };
  }
  
  // Check UCUM code match
  const ucumMatch = Object.entries(COMMON_UNITS).find(([_, info]) => info.ucum === normalized);
  if (ucumMatch) {
    return {
      valid: true,
      unit: ucumMatch[0],
      ucumCode: ucumMatch[1].ucum,
    };
  }
  
  // Basic UCUM syntax validation
  const ucumPattern = /^[a-zA-Z0-9%\[\]\.\/\^\*\-\(\)µ]+$/;
  if (ucumPattern.test(normalized)) {
    return {
      valid: true, // Assume valid if it matches UCUM syntax
      unit: normalized,
      ucumCode: normalized,
      message: "Syntax gültig, aber nicht in lokaler Datenbank",
    };
  }
  
  return {
    valid: false,
    unit: normalized,
    message: "Ungültige Einheit",
  };
}

// Convert units using NLM service
async function convertUnits(value: number, fromUnit: string, toUnit: string): Promise<UcumConversionResult> {
  try {
    const encodedFrom = encodeURIComponent(fromUnit);
    const encodedTo = encodeURIComponent(toUnit);
    
    const response = await fetch(
      `https://ucum.nlm.nih.gov/ucum-service/v1/ucumtransform/${value}/${encodedFrom}/${encodedTo}`,
      { headers: { Accept: "application/json" } }
    );

    if (!response.ok) {
      return {
        success: false,
        message: "Konvertierung nicht möglich",
      };
    }

    const data = await response.json();
    
    if (data.status === "error" || data.error) {
      return {
        success: false,
        message: data.message || "Einheiten nicht kompatibel",
      };
    }

    return {
      success: true,
      fromValue: value,
      fromUnit,
      toValue: parseFloat(data.toValue || data.result),
      toUnit,
    };
  } catch (error) {
    console.error("UCUM conversion error:", error);
    return {
      success: false,
      message: "Konvertierungsfehler",
    };
  }
}

// Suggest units based on partial input
function suggestUnits(query: string): { unit: string; display: string; category: string }[] {
  const q = query.toLowerCase().trim();
  
  if (!q) {
    // Return common lab units when no query
    return [
      { unit: "mg/dL", display: "mg/dL (Milligramm pro Deziliter)", category: "concentration" },
      { unit: "mmol/L", display: "mmol/L (Millimol pro Liter)", category: "molar" },
      { unit: "g/dL", display: "g/dL (Gramm pro Deziliter)", category: "concentration" },
      { unit: "U/L", display: "U/L (Units pro Liter)", category: "enzyme" },
      { unit: "%", display: "% (Prozent)", category: "ratio" },
    ];
  }
  
  const suggestions: { unit: string; display: string; category: string }[] = [];
  
  for (const [unit, info] of Object.entries(COMMON_UNITS)) {
    const unitLower = unit.toLowerCase();
    const displayLower = info.display.toLowerCase();
    
    if (unitLower.includes(q) || displayLower.includes(q) || info.category.includes(q)) {
      suggestions.push({
        unit,
        display: info.display,
        category: info.category,
      });
    }
  }
  
  // Sort by relevance (exact match first, then starts with, then contains)
  suggestions.sort((a, b) => {
    const aLower = a.unit.toLowerCase();
    const bLower = b.unit.toLowerCase();
    
    if (aLower === q) return -1;
    if (bLower === q) return 1;
    if (aLower.startsWith(q)) return bLower.startsWith(q) ? 0 : -1;
    if (bLower.startsWith(q)) return 1;
    return 0;
  });
  
  return suggestions.slice(0, 10);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, unit, value, fromUnit, toUnit, query }: UcumRequest = await req.json();

    switch (action) {
      case "validate": {
        if (!unit) {
          return new Response(
            JSON.stringify({ error: "unit is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        // Try local validation first for speed
        const localResult = validateLocally(unit);
        if (localResult.valid) {
          return new Response(
            JSON.stringify(localResult),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        // Fall back to NLM API
        const nlmResult = await validateWithNLM(unit);
        return new Response(
          JSON.stringify(nlmResult),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "convert": {
        if (value === undefined || !fromUnit || !toUnit) {
          return new Response(
            JSON.stringify({ error: "value, fromUnit, and toUnit are required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        const result = await convertUnits(value, fromUnit, toUnit);
        return new Response(
          JSON.stringify(result),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "suggest": {
        const suggestions = suggestUnits(query || "");
        return new Response(
          JSON.stringify({ suggestions }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "base": {
        if (!unit) {
          return new Response(
            JSON.stringify({ error: "unit is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        try {
          const encodedUnit = encodeURIComponent(unit);
          const response = await fetch(
            `https://ucum.nlm.nih.gov/ucum-service/v1/toBaseUnits/${encodedUnit}`,
            { headers: { Accept: "application/json" } }
          );
          
          if (!response.ok) {
            return new Response(
              JSON.stringify({ unit, baseUnits: null, message: "Basiseinheiten nicht verfügbar" }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }
          
          const data = await response.json();
          return new Response(
            JSON.stringify({ unit, baseUnits: data.baseUnits || data.result }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        } catch (error) {
          return new Response(
            JSON.stringify({ unit, baseUnits: null, message: "Basiseinheiten nicht verfügbar" }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }

      default:
        return new Response(
          JSON.stringify({ error: "Invalid action. Use: validate, convert, suggest, or base" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error) {
    console.error("UCUM error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "UCUM validation failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
