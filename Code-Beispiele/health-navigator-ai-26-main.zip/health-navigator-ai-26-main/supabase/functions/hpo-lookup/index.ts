import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Supabase admin client for persisting codes
function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  return createClient(supabaseUrl, supabaseKey);
}

/**
 * Persist HPO codes to hpo_codes table for local caching
 */
async function persistHPOCodes(results: HPOSearchResult[]): Promise<void> {
  if (results.length === 0) return;
  
  const supabase = getSupabaseAdmin();
  
  const codesToInsert = results.map(r => ({
    hpo_code: r.id,
    label: r.label,
    definition: r.definition || null,
    synonyms: r.synonyms || [],
    labels: { en: r.label },
    source: 'ols4_api',
  }));
  
  try {
    const { data, error } = await supabase
      .from('hpo_codes')
      .upsert(codesToInsert, { onConflict: 'hpo_code' });
    
    if (error) {
      console.error('[HPO Persist] Database error:', error.message, error.details, error.hint);
    } else {
      console.log(`[HPO Persist] Successfully persisted ${codesToInsert.length} codes`);
    }
  } catch (error) {
    console.error('[HPO Persist] Exception:', error);
  }
}

// OLS4 API (EMBL-EBI Ontology Lookup Service) - free, no API key required
const OLS_BASE_URL = "https://www.ebi.ac.uk/ols4/api";

interface HPOSearchResult {
  id: string;           // e.g., "HP:0001250"
  label: string;        // e.g., "Seizure"
  synonyms: string[];
  definition?: string;
  isObsolete: boolean;
   foundViaFallback?: boolean;  // true if found via German-to-English fallback
}

interface OLSSearchResponse {
  response: {
    numFound: number;
    docs: Array<{
      id: string;
      iri: string;
      label: string;
      description?: string[];
      synonym?: string[];
      is_obsolete: boolean;
      obo_id: string;
      short_form: string;
    }>;
  };
}

interface OLSTermResponse {
  iri: string;
  label: string;
  description?: string[];
  synonyms?: string[];
  is_obsolete: boolean;
  obo_id: string;
}

/**
 * Search HPO terms by text query
 */
 async function searchHPOTerms(query: string, limit = 10, lang = "en", markAsFallback = false): Promise<HPOSearchResult[]> {
  const url = new URL(`${OLS_BASE_URL}/search`);
  url.searchParams.set("q", query);
  url.searchParams.set("ontology", "hp");
  url.searchParams.set("rows", limit.toString());
  url.searchParams.set("lang", lang);
  url.searchParams.set("type", "class");
  
  const response = await fetch(url.toString(), {
    headers: { "Accept": "application/json" },
  });

  if (!response.ok) {
    throw new Error(`OLS API error: ${response.status} ${response.statusText}`);
  }

  const data: OLSSearchResponse = await response.json();
  
  const results = data.response.docs.map(doc => ({
    id: doc.obo_id || doc.short_form,
    label: doc.label,
    synonyms: doc.synonym || [],
    definition: doc.description?.[0],
    isObsolete: doc.is_obsolete,
    foundViaFallback: markAsFallback,
  })).filter(term => !term.isObsolete);
  
  // Persist results to hpo_codes table (async, don't wait)
  persistHPOCodes(results).catch(err => console.error('Persist error:', err));
  
  return results;
}

/**
 * Validate an HPO code and get its details - with persistence
 */
async function validateHPOCode(hpoCode: string, lang = "en"): Promise<HPOSearchResult | null> {
  // Normalize code format (HP:0001250 or HP_0001250)
  const normalizedCode = hpoCode.replace("_", ":").toUpperCase();
  
  if (!/^HP:\d{7}$/.test(normalizedCode)) {
    return null;
  }

  const iri = encodeURIComponent(encodeURIComponent(`http://purl.obolibrary.org/obo/${normalizedCode.replace(":", "_")}`));
  const url = `${OLS_BASE_URL}/ontologies/hp/terms/${iri}?lang=${lang}`;
  
  try {
    const response = await fetch(url, {
      headers: { "Accept": "application/json" },
    });

    if (!response.ok) {
      if (response.status === 404) {
        return null;
      }
      throw new Error(`OLS API error: ${response.status}`);
    }

    const data: OLSTermResponse = await response.json();
    
    const result: HPOSearchResult = {
      id: data.obo_id,
      label: data.label,
      synonyms: data.synonyms || [],
      definition: data.description?.[0],
      isObsolete: data.is_obsolete,
    };
    
    // Persist validated code to database
    persistHPOCodes([result]).catch(err => console.error('[HPO Validate Persist] Error:', err));
    
    return result;
  } catch (error) {
    console.error("Error validating HPO code:", error);
    return null;
  }
}

/**
 * Map symptom text to HPO codes using AI-enhanced matching
 */
async function mapSymptomToHPO(
  symptomText: string,
  language: string = "de"
): Promise<{
  matches: HPOSearchResult[];
  confidence: number;
  originalText: string;
}> {
  // Use native German labels from HPO if available
  // The OLS4 API supports lang=de for German translations
  let matches = await searchHPOTerms(symptomText, 5, language);
  
  // Common German-to-English medical term mappings for better matching
  const germanToEnglish: Record<string, string> = {
    "kopfschmerzen": "headache",
    "kopfschmerz": "headache",
    "migräne": "migraine",
    "schwindel": "vertigo dizziness",
    "übelkeit": "nausea",
    "erbrechen": "vomiting",
    "fieber": "fever",
    "husten": "cough",
    "atemnot": "dyspnea shortness of breath",
    "brustschmerzen": "chest pain",
    "bauchschmerzen": "abdominal pain",
    "durchfall": "diarrhea",
    "verstopfung": "constipation",
    "müdigkeit": "fatigue tiredness",
    "schlafstörung": "insomnia sleep disturbance",
    "angst": "anxiety",
    "depression": "depression",
    "hautausschlag": "rash skin eruption",
    "juckreiz": "pruritus itching",
    "schwellung": "swelling edema",
    "schmerz": "pain",
    "gelenkschmerzen": "joint pain arthralgia",
    "rückenschmerzen": "back pain",
    "herzrasen": "tachycardia palpitations",
    "bluthochdruck": "hypertension",
    "diabetes": "diabetes mellitus",
    "allergie": "allergy hypersensitivity",
    "asthma": "asthma",
    "epilepsie": "epilepsy seizure",
    "krampfanfall": "seizure convulsion",
    "bewusstlosigkeit": "unconsciousness syncope",
    "sehstörung": "visual impairment",
    "hörverlust": "hearing loss",
    "taubheit": "numbness paresthesia",
    "lähmung": "paralysis",
    "tremor": "tremor",
    "gewichtsverlust": "weight loss",
    "appetitlosigkeit": "anorexia loss of appetite",
     // Neurologie
     "gedächtnisstörung": "memory impairment amnesia",
     "konzentrationsstörung": "impaired concentration attention deficit",
     "sprachstörung": "speech disorder dysarthria aphasia",
     "gangstörung": "gait disturbance ataxia",
     "gleichgewichtsstörung": "balance disorder vertigo",
     "zittern": "tremor shaking",
     "muskelschwäche": "muscle weakness myasthenia",
     "muskelzuckungen": "muscle twitching fasciculation",
     "muskelkrämpfe": "muscle cramps spasm",
     "tinnitus": "tinnitus",
     "doppeltsehen": "diplopia double vision",
     "verschwommensehen": "blurred vision",
     // Kardiologie
     "herzstolpern": "palpitations arrhythmia",
     "herzinsuffizienz": "heart failure cardiac insufficiency",
     "angina pectoris": "angina pectoris chest pain",
     "ödeme": "edema swelling",
     "beinödeme": "leg edema peripheral edema",
     "kurzatmigkeit": "shortness of breath dyspnea",
     "zyanose": "cyanosis",
     "blässe": "pallor pale skin",
     // Gastroenterologie
     "sodbrennen": "heartburn pyrosis",
     "schluckstörung": "dysphagia swallowing difficulty",
     "blähungen": "bloating flatulence",
     "völlegefühl": "early satiety fullness",
     "magenschmerzen": "stomach pain gastric pain epigastric",
     "blutstuhl": "blood in stool melena hematochezia",
     "blutiges erbrechen": "hematemesis vomiting blood",
     "gelbsucht": "jaundice icterus",
     "lebervergrößerung": "hepatomegaly enlarged liver",
     // Pneumologie
     "auswurf": "sputum expectoration",
     "bluthusten": "hemoptysis coughing blood",
     "pfeifende atmung": "wheezing",
     "brustenge": "chest tightness",
     "nachtschweiß": "night sweats",
     // Rheumatologie / Bewegungsapparat
     "morgensteifigkeit": "morning stiffness",
     "gelenkschwellung": "joint swelling arthritis",
     "knochenschmerzen": "bone pain",
     "hüftschmerzen": "hip pain",
     "knieschmerzen": "knee pain",
     "schulterschmerzen": "shoulder pain",
     "nackenschmerzen": "neck pain cervicalgia",
     "fingersteifigkeit": "finger stiffness",
     // Dermatologie
     "ekzem": "eczema dermatitis",
     "schuppenflechte": "psoriasis",
     "nesselsucht": "urticaria hives",
     "haarausfall": "alopecia hair loss",
     "nagelveränderung": "nail abnormality dystrophy",
     "hautrötung": "erythema skin redness",
     "pigmentstörung": "pigmentation disorder hyperpigmentation",
     "warzen": "warts verruca",
     "geschwür": "ulcer lesion",
     // Urologie / Nephrologie
     "blut im urin": "hematuria blood in urine",
     "häufiges wasserlassen": "polyuria frequent urination",
     "schmerzhaftes wasserlassen": "dysuria painful urination",
     "inkontinenz": "incontinence urinary",
     "nierenschmerzen": "kidney pain renal colic",
     "flankenschmerzen": "flank pain",
     // Gynäkologie
     "menstruationsstörung": "menstrual irregularity dysmenorrhea",
     "regelschmerzen": "menstrual pain dysmenorrhea",
     "zwischenblutung": "intermenstrual bleeding metrorrhagia",
     "wechseljahresbeschwerden": "menopausal symptoms hot flashes",
     "brustknoten": "breast lump mass",
     // Endokrinologie
     "schilddrüsenvergrößerung": "goiter thyroid enlargement",
     "überfunktion schilddrüse": "hyperthyroidism thyrotoxicosis",
     "unterfunktion schilddrüse": "hypothyroidism",
     "starkes schwitzen": "hyperhidrosis excessive sweating",
     "kälteintoleranz": "cold intolerance",
     "wärmeintoleranz": "heat intolerance",
     "polydipsie": "polydipsia excessive thirst",
     // Hämatologie
     "blutarmut": "anemia",
     "blutungsneigung": "bleeding tendency hemorrhagic diathesis",
     "lymphknotenschwellung": "lymphadenopathy swollen lymph nodes",
     "milzvergrößerung": "splenomegaly enlarged spleen",
     // Psychiatrie
     "panikattacke": "panic attack",
     "schlaflosigkeit": "insomnia sleeplessness",
     "albträume": "nightmares",
     "halluzination": "hallucination",
     "wahnvorstellung": "delusion",
     "antriebslosigkeit": "apathy lack of motivation",
     "reizbarkeit": "irritability",
     "stimmungsschwankungen": "mood swings lability",
     "essstörung": "eating disorder anorexia bulimia",
     "zwangsstörung": "obsessive compulsive disorder OCD",
     // Pädiatrie
     "entwicklungsverzögerung": "developmental delay",
     "gedeihstörung": "failure to thrive",
     "wachstumsstörung": "growth retardation short stature",
     "sprachentwicklungsverzögerung": "speech delay language disorder",
     "lernstörung": "learning disability",
     "hyperaktivität": "hyperactivity ADHD",
     // Allgemein
     "fieberschübe": "recurrent fever periodic fever",
     "gewichtszunahme": "weight gain obesity",
     "kraftlosigkeit": "weakness asthenia",
     "unwohlsein": "malaise",
     "leistungsminderung": "decreased exercise tolerance",
     "chronische schmerzen": "chronic pain",
     "infektanfälligkeit": "recurrent infections immunodeficiency",
     "wundheilungsstörung": "impaired wound healing",
     "narbenbildung": "scarring keloid",
     // Sinnesorgane
     "augenschmerzen": "eye pain ocular pain",
     "rote augen": "red eye conjunctival injection",
     "ohrenschmerzen": "ear pain otalgia",
     "nasenbluten": "epistaxis nosebleed",
     "geruchsstörung": "anosmia smell disorder",
     "geschmacksstörung": "dysgeusia taste disorder",
     "mundtrockenheit": "xerostomia dry mouth",
     "heiserkeit": "hoarseness dysphonia",
  };

  // If no matches found with native language, try fallback to English translation
  if (matches.length === 0) {
    const lowerText = symptomText.toLowerCase().trim();
    const englishTerm = germanToEnglish[lowerText];
    
    if (englishTerm) {
       // Search with English term but still request German labels, mark as fallback
       matches = await searchHPOTerms(englishTerm, 5, language, true);
    }
  }

  // Calculate confidence based on match quality
  let confidence = 0;
  if (matches.length > 0) {
    const topMatch = matches[0];
    const labelLower = topMatch.label.toLowerCase();
    const queryLower = symptomText.toLowerCase();
    
    if (labelLower === queryLower) {
      confidence = 0.95;
    } else if (labelLower.includes(queryLower) || queryLower.includes(labelLower)) {
      confidence = 0.85;
    } else if (topMatch.synonyms.some(s => s.toLowerCase().includes(queryLower))) {
      confidence = 0.75;
    } else {
      confidence = 0.6;
    }
  }

  return {
    matches,
    confidence,
    originalText: symptomText,
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const urlAction = url.searchParams.get("action") || "search";

    let result: unknown;

    if (req.method === "GET") {
      const query = url.searchParams.get("q");
      const code = url.searchParams.get("code");
      const limit = parseInt(url.searchParams.get("limit") || "10");
      const lang = url.searchParams.get("lang") || "de"; // Default to German

      if (urlAction === "validate" && code) {
        result = await validateHPOCode(code, lang);
      } else if (urlAction === "search" && query) {
          // Try direct search first
          let searchResults = await searchHPOTerms(query, limit, lang, false);
          
          // If no results and using German, try fallback translation from database
          if (searchResults.length === 0 && lang === 'de') {
            const lowerQuery = query.toLowerCase().trim();
            
            // Create Supabase client to check database translations
            const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
            const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
            const supabase = createClient(supabaseUrl, supabaseKey);
            
            // Check database for translation
            const { data: translation } = await supabase
              .from('term_translations')
              .select('english_term, id')
              .ilike('german_term', lowerQuery)
              .maybeSingle();
            
            if (translation) {
              // Found translation in database - use it and increment usage count
              searchResults = await searchHPOTerms(translation.english_term, limit, lang, true);
              
              // Increment usage count asynchronously (don't wait for it)
              supabase
                .from('term_translations')
                .update({ usage_count: supabase.rpc ? undefined : undefined })
                .eq('id', translation.id)
                .then(() => {
                  // Also increment via raw increment
                  supabase.rpc('increment_term_usage', { term_id: translation.id }).catch(() => {});
                })
                .catch(() => {});
            }
          }
          
          result = searchResults;
      } else {
        return new Response(
          JSON.stringify({ error: "Missing required parameters: q (for search) or code (for validate)" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    } else if (req.method === "POST") {
      const body = await req.json();
      // Support action from body OR URL params
      const action = body.action || urlAction;
      const lang = body.lang || "de";
      const limit = body.limit || 10;
      
      if (action === "search" && body.q) {
        // Handle search via POST (from supabase.functions.invoke)
        let searchResults = await searchHPOTerms(body.q, limit, lang, false);
        
        // If no results and using German, try fallback translation from database
        if (searchResults.length === 0 && lang === 'de') {
          const lowerQuery = body.q.toLowerCase().trim();
          
          const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
          const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
          const supabase = createClient(supabaseUrl, supabaseKey);
          
          const { data: translation } = await supabase
            .from('term_translations')
            .select('english_term, id')
            .ilike('german_term', lowerQuery)
            .maybeSingle();
          
          if (translation) {
            searchResults = await searchHPOTerms(translation.english_term, limit, lang, true);
            supabase.rpc('increment_term_usage', { term_id: translation.id }).catch(() => {});
          }
        }
        
        result = searchResults;
      } else if (action === "map" && body.symptom) {
        result = await mapSymptomToHPO(body.symptom, body.language || "de");
      } else if (action === "batch-map" && Array.isArray(body.symptoms)) {
        const mappings = await Promise.all(
          body.symptoms.map((s: string) => mapSymptomToHPO(s, body.language || "de"))
        );
        result = { mappings };
      } else if (action === "validate" && body.codes) {
        const validations = await Promise.all(
          (Array.isArray(body.codes) ? body.codes : [body.codes]).map(validateHPOCode)
        );
        result = { validations };
      } else {
        return new Response(
          JSON.stringify({ error: "Invalid action or missing parameters" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    } else {
      return new Response(
        JSON.stringify({ error: "Method not allowed" }),
        { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("HPO lookup error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
