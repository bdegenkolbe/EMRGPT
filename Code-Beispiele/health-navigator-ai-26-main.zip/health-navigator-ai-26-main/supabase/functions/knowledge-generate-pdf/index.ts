import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface GeneratePdfRequest {
  sourceId: string;
}

/**
 * Generate a simple text-based PDF from fulltext content.
 * Uses a minimal PDF structure (no external library needed in Deno).
 */
function generateSimplePdf(title: string, authors: string, content: string, metadata: Record<string, string>): Uint8Array {
  // Build page content as plain text lines
  const lines: string[] = [];
  
  // Title
  lines.push(title);
  lines.push("");
  
  // Authors
  if (authors) {
    lines.push(`Authors: ${authors}`);
    lines.push("");
  }
  
  // Metadata
  if (metadata.journal) lines.push(`Journal: ${metadata.journal}`);
  if (metadata.doi) lines.push(`DOI: ${metadata.doi}`);
  if (metadata.pmid) lines.push(`PMID: ${metadata.pmid}`);
  if (metadata.pmcid) lines.push(`PMCID: ${metadata.pmcid}`);
  if (metadata.year) lines.push(`Year: ${metadata.year}`);
  lines.push("");
  lines.push("---");
  lines.push("");
  
  // Content - split into lines at ~80 chars
  const contentLines = content.split("\n");
  for (const line of contentLines) {
    if (line.length <= 80) {
      lines.push(line);
    } else {
      // Word-wrap long lines
      const words = line.split(" ");
      let currentLine = "";
      for (const word of words) {
        if (currentLine.length + word.length + 1 > 80) {
          lines.push(currentLine);
          currentLine = word;
        } else {
          currentLine = currentLine ? `${currentLine} ${word}` : word;
        }
      }
      if (currentLine) lines.push(currentLine);
    }
  }

  // Build minimal PDF
  const encoder = new TextEncoder();
  const pageContent = lines.join("\n");
  
  // Escape special PDF characters
  const escapedContent = pageContent
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/[^\x20-\x7E\n]/g, " "); // Replace non-ASCII with space for safety
  
  // Split into pages (~60 lines per page)
  const LINES_PER_PAGE = 55;
  const allLines = escapedContent.split("\n");
  const pages: string[][] = [];
  
  for (let i = 0; i < allLines.length; i += LINES_PER_PAGE) {
    pages.push(allLines.slice(i, i + LINES_PER_PAGE));
  }
  
  if (pages.length === 0) pages.push([""]);

  // Build PDF objects
  const objects: string[] = [];
  let objectCount = 0;
  const offsets: number[] = [];
  
  const addObject = (content: string): number => {
    objectCount++;
    objects.push(content);
    return objectCount;
  };

  // Object 1: Catalog
  addObject(`1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj`);
  
  // Object 2: Pages (placeholder - will be updated)
  const pagesObjIdx = addObject(`2 0 obj\n<< /Type /Pages /Kids [${pages.map((_, i) => `${3 + i * 2} 0 R`).join(" ")}] /Count ${pages.length} >>\nendobj`);
  
  // Object for font
  const fontObjNum = objectCount + pages.length * 2 + 1;
  
  // Create page objects and content streams
  for (let i = 0; i < pages.length; i++) {
    const pageLines = pages[i];
    const pageObjNum = 3 + i * 2;
    const contentObjNum = 4 + i * 2;
    
    // Build text content with positioning
    let streamContent = "BT\n/F1 10 Tf\n";
    let y = 770;
    for (const line of pageLines) {
      streamContent += `1 0 0 1 40 ${y} Tm\n(${line}) Tj\n`;
      y -= 13;
    }
    
    // Add page number
    streamContent += `1 0 0 1 280 30 Tm\n(Page ${i + 1} of ${pages.length}) Tj\n`;
    streamContent += "ET";
    
    // Page object
    addObject(`${pageObjNum} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents ${contentObjNum} 0 R /Resources << /Font << /F1 ${fontObjNum} 0 R >> >> >>\nendobj`);
    
    // Content stream
    const streamBytes = encoder.encode(streamContent);
    addObject(`${contentObjNum} 0 obj\n<< /Length ${streamBytes.length} >>\nstream\n${streamContent}\nendstream\nendobj`);
  }
  
  // Font object
  addObject(`${fontObjNum} 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj`);
  
  // Build final PDF
  let pdf = "%PDF-1.4\n";
  
  for (const obj of objects) {
    offsets.push(encoder.encode(pdf).length);
    pdf += obj + "\n";
  }
  
  // Cross-reference table
  const xrefOffset = encoder.encode(pdf).length;
  pdf += `xref\n0 ${objectCount + 1}\n`;
  pdf += "0000000000 65535 f \n";
  for (const offset of offsets) {
    pdf += `${offset.toString().padStart(10, "0")} 00000 n \n`;
  }
  
  // Trailer
  pdf += `trailer\n<< /Size ${objectCount + 1} /Root 1 0 R >>\n`;
  pdf += `startxref\n${xrefOffset}\n%%EOF`;
  
  return encoder.encode(pdf);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: GeneratePdfRequest = await req.json();
    const { sourceId } = body;

    if (!sourceId) {
      return new Response(JSON.stringify({ error: "sourceId required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get source with content
    const { data: source, error: fetchError } = await supabase
      .from("knowledge_sources")
      .select("*")
      .eq("id", sourceId)
      .single();

    if (fetchError || !source) {
      return new Response(JSON.stringify({ error: "Source not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const content = source.translated_content || source.original_content;
    if (!content) {
      return new Response(JSON.stringify({ error: "No content to generate PDF from" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[knowledge-generate-pdf] Generating PDF for source ${sourceId}, content length: ${content.length}`);

    // Build metadata
    const meta: Record<string, string> = {};
    if (source.metadata?.journal) meta.journal = source.metadata.journal as string;
    if (source.metadata?.doi) meta.doi = source.metadata.doi as string;
    if (source.metadata?.pmid) meta.pmid = source.metadata.pmid as string;
    if (source.metadata?.pmcid) meta.pmcid = source.metadata.pmcid as string;
    if (source.year) meta.year = String(source.year);

    const title = source.translated_title || source.title;
    const authors = source.authors || "";

    // Generate PDF
    const pdfBytes = generateSimplePdf(title, authors, content, meta);

    // Create filename
    const pmcid = source.metadata?.pmcid || source.external_id || sourceId.slice(0, 8);
    const safeTitle = title
      .replace(/[^a-zA-Z0-9\s-]/g, "")
      .replace(/\s+/g, "_")
      .substring(0, 80);
    const fileName = `${pmcid}_${safeTitle}.pdf`;
    const filePath = `europepmc/${fileName}`;

    // Upload to storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("guidelines")
      .upload(filePath, pdfBytes, {
        contentType: "application/pdf",
        upsert: true,
      });

    if (uploadError) {
      console.error(`[knowledge-generate-pdf] Upload error:`, uploadError);
      return new Response(JSON.stringify({ error: `Upload failed: ${uploadError.message}` }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Update source with pdf_path
    await supabase
      .from("knowledge_sources")
      .update({ 
        pdf_path: filePath,
        updated_at: new Date().toISOString(),
      })
      .eq("id", sourceId);

    console.log(`[knowledge-generate-pdf] PDF generated: ${filePath} (${pdfBytes.length} bytes)`);

    return new Response(
      JSON.stringify({
        success: true,
        filePath: uploadData.path,
        fileSize: pdfBytes.length,
        fileName,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("[knowledge-generate-pdf] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
