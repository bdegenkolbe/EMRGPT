import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ChatRequest {
  messages: { role: "user" | "assistant" | "system"; content: string }[];
  provider?: "gemini" | "openai";
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

interface ChatResponse {
  content: string;
  provider: string;
  model: string;
  usage?: {
    promptTokens?: number;
    completionTokens?: number;
    totalTokens?: number;
  };
}

async function callGemini(
  apiKey: string,
  messages: ChatRequest["messages"],
  model = "gemini-2.0-flash",
  temperature = 0.7,
  maxTokens = 2048
): Promise<ChatResponse> {
  const systemPrompt = messages.find((m) => m.role === "system")?.content || "";
  const conversationMessages = messages.filter((m) => m.role !== "system");

  const contents = conversationMessages.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents,
        systemInstruction: systemPrompt ? { parts: [{ text: systemPrompt }] } : undefined,
        generationConfig: {
          temperature,
          maxOutputTokens: maxTokens,
        },
      }),
    }
  );

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Gemini API error: ${response.status} - ${error}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";

  return {
    content: text,
    provider: "gemini",
    model,
    usage: {
      promptTokens: data.usageMetadata?.promptTokenCount,
      completionTokens: data.usageMetadata?.candidatesTokenCount,
      totalTokens: data.usageMetadata?.totalTokenCount,
    },
  };
}

async function callOpenAI(
  apiKey: string,
  messages: ChatRequest["messages"],
  model = "gpt-4o-mini",
  temperature = 0.7,
  maxTokens = 2048
): Promise<ChatResponse> {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenAI API error: ${response.status} - ${error}`);
  }

  const data = await response.json();

  return {
    content: data.choices?.[0]?.message?.content || "",
    provider: "openai",
    model,
    usage: {
      promptTokens: data.usage?.prompt_tokens,
      completionTokens: data.usage?.completion_tokens,
      totalTokens: data.usage?.total_tokens,
    },
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    
    // Verify authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: ChatRequest = await req.json();
    const { messages, provider, model, temperature, maxTokens } = body;

    if (!messages || messages.length === 0) {
      return new Response(JSON.stringify({ error: "Messages are required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get active integrations
    const { data: integrations, error: intError } = await supabase
      .from("integrations")
      .select("*")
      .eq("is_active", true);

    if (intError) {
      console.error("Error fetching integrations:", intError);
    }

    const geminiIntegration = integrations?.find((i) => i.provider === "gemini");
    const openaiIntegration = integrations?.find((i) => i.provider === "openai");

    // Determine which provider to use
    let selectedProvider = provider;
    if (!selectedProvider) {
      if (geminiIntegration) selectedProvider = "gemini";
      else if (openaiIntegration) selectedProvider = "openai";
    }

    // Try to get API key from environment (set via Supabase secrets)
    let apiKey: string | undefined;
    
    if (selectedProvider === "gemini") {
      apiKey = Deno.env.get("GEMINI_API_KEY");
    } else if (selectedProvider === "openai") {
      apiKey = Deno.env.get("OPENAI_API_KEY");
    }

    // Fallback: Try Lovable AI Gateway if no API key is configured
    if (!apiKey) {
      const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
      if (lovableApiKey) {
        console.log("Using Lovable AI Gateway as fallback");
        
        const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${lovableApiKey}`,
          },
          body: JSON.stringify({
            model: model || "google/gemini-3-flash-preview",
            messages,
            temperature: temperature ?? 0.7,
            max_tokens: maxTokens ?? 2048,
          }),
        });

        if (!response.ok) {
          const error = await response.text();
          throw new Error(`Lovable AI Gateway error: ${response.status} - ${error}`);
        }

        const data = await response.json();
        
        return new Response(
          JSON.stringify({
            content: data.choices?.[0]?.message?.content || "",
            provider: "lovable-gateway",
            model: model || "google/gemini-3-flash-preview",
            usage: {
              promptTokens: data.usage?.prompt_tokens,
              completionTokens: data.usage?.completion_tokens,
              totalTokens: data.usage?.total_tokens,
            },
          } as ChatResponse),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: "No AI provider configured. Please configure an API key." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let result: ChatResponse;
    const aiStartTime = Date.now();

    if (selectedProvider === "gemini") {
      result = await callGemini(apiKey, messages, model, temperature, maxTokens);
    } else if (selectedProvider === "openai") {
      result = await callOpenAI(apiKey, messages, model, temperature, maxTokens);
    } else {
      return new Response(
        JSON.stringify({ error: "No valid AI provider available" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const latencyMs = Date.now() - aiStartTime;

    // Log AI usage to ai_usage_logs
    try {
      await supabase
        .from("ai_usage_logs")
        .insert({
          user_id: user.id,
          source_type: "chat",
          source_detail: "ai-chat",
          provider: result.provider,
          model: result.model,
          prompt_tokens: result.usage?.promptTokens || 0,
          completion_tokens: result.usage?.completionTokens || 0,
          latency_ms: latencyMs,
          request_metadata: { 
            message_count: messages.length,
            has_system_prompt: messages.some(m => m.role === "system")
          },
          status: "success",
        });
    } catch (logError) {
      console.error("Failed to log AI usage:", logError);
      // Don't fail the request if logging fails
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("AI Chat error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
