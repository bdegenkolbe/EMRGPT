import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface FhirResource {
  resourceType: string;
  id?: string;
  [key: string]: unknown;
}

interface FhirBundle {
  resourceType: "Bundle";
  type: string;
  entry?: { resource: FhirResource; fullUrl?: string }[];
}

function extractPatient(r: FhirResource) {
  const name = (r.name as any[])?.[0] || {};
  return {
    fhir_id: r.id || crypto.randomUUID(),
    active: r.active !== false,
    given_name: (name.given as string[])?.join(" ") || "Unbekannt",
    family_name: name.family || "Unbekannt",
    birth_date: r.birthDate || null,
    gender: r.gender || "unknown",
    identifier_mrn: (r.identifier as any[])?.find((i: any) => i.type?.coding?.[0]?.code === "MR")?.value || (r.identifier as any[])?.[0]?.value || null,
    telecom: r.telecom || [],
    address: r.address || [],
    fhir_resource: r,
  };
}

function extractEncounter(r: FhirResource, patientRef: string) {
  return {
    fhir_id: r.id || crypto.randomUUID(),
    status: (r as any).status || "unknown",
    class: (r as any).class?.code || (r as any).class?.display || null,
    type_code: (r as any).type?.[0]?.coding?.[0]?.code || null,
    type_display: (r as any).type?.[0]?.coding?.[0]?.display || (r as any).type?.[0]?.text || null,
    period_start: (r as any).period?.start || null,
    period_end: (r as any).period?.end || null,
    reason_codes: (r as any).reasonCode || [],
    diagnosis_codes: (r as any).diagnosis || [],
    service_provider: (r as any).serviceProvider?.display || null,
    fhir_resource: r,
    _patient_ref: patientRef,
  };
}

function extractCondition(r: FhirResource, patientRef: string, encounterRef: string | null) {
  const coding = (r as any).code?.coding?.[0];
  return {
    fhir_id: r.id || crypto.randomUUID(),
    clinical_status: (r as any).clinicalStatus?.coding?.[0]?.code || null,
    verification_status: (r as any).verificationStatus?.coding?.[0]?.code || null,
    category: (r as any).category?.[0]?.coding?.[0]?.code || null,
    code_system: coding?.system || null,
    code: coding?.code || null,
    code_display: coding?.display || (r as any).code?.text || null,
    severity: (r as any).severity?.coding?.[0]?.code || null,
    onset_datetime: (r as any).onsetDateTime || null,
    abatement_datetime: (r as any).abatementDateTime || null,
    fhir_resource: r,
    _patient_ref: patientRef,
    _encounter_ref: encounterRef,
  };
}

function extractObservation(r: FhirResource, patientRef: string, encounterRef: string | null) {
  const coding = (r as any).code?.coding?.[0];
  const vq = (r as any).valueQuantity;
  const rr = (r as any).referenceRange?.[0];
  return {
    fhir_id: r.id || crypto.randomUUID(),
    status: (r as any).status || "final",
    category: (r as any).category?.[0]?.coding?.[0]?.code || null,
    loinc_code: coding?.system?.includes("loinc") ? coding.code : coding?.code || null,
    code_display: coding?.display || (r as any).code?.text || null,
    value_quantity: vq?.value ?? null,
    value_unit: vq?.unit || vq?.code || null,
    value_string: (r as any).valueString || (r as any).valueCodeableConcept?.text || null,
    reference_range_low: rr?.low?.value ?? null,
    reference_range_high: rr?.high?.value ?? null,
    interpretation: (r as any).interpretation?.[0]?.coding?.[0]?.code || null,
    effective_datetime: (r as any).effectiveDateTime || null,
    fhir_resource: r,
    _patient_ref: patientRef,
    _encounter_ref: encounterRef,
  };
}

function extractMedicationRequest(r: FhirResource, patientRef: string, encounterRef: string | null) {
  const medCoding = (r as any).medicationCodeableConcept?.coding?.[0];
  return {
    fhir_id: r.id || crypto.randomUUID(),
    status: (r as any).status || "active",
    intent: (r as any).intent || "order",
    medication_code: medCoding?.code || null,
    medication_display: medCoding?.display || (r as any).medicationCodeableConcept?.text || null,
    dosage_text: (r as any).dosageInstruction?.[0]?.text || null,
    dosage_route: (r as any).dosageInstruction?.[0]?.route?.coding?.[0]?.display || null,
    authored_on: (r as any).authoredOn || null,
    requester_display: (r as any).requester?.display || null,
    reason_codes: (r as any).reasonCode || [],
    fhir_resource: r,
    _patient_ref: patientRef,
    _encounter_ref: encounterRef,
  };
}

function extractAllergy(r: FhirResource, patientRef: string) {
  const coding = (r as any).code?.coding?.[0];
  return {
    fhir_id: r.id || crypto.randomUUID(),
    clinical_status: (r as any).clinicalStatus?.coding?.[0]?.code || null,
    verification_status: (r as any).verificationStatus?.coding?.[0]?.code || null,
    type: (r as any).type || null,
    category: (r as any).category?.[0] || null,
    criticality: (r as any).criticality || null,
    code: coding?.code || null,
    code_display: coding?.display || (r as any).code?.text || null,
    onset_datetime: (r as any).onsetDateTime || null,
    reactions: (r as any).reaction || [],
    fhir_resource: r,
    _patient_ref: patientRef,
  };
}

function extractProcedure(r: FhirResource, patientRef: string, encounterRef: string | null) {
  const coding = (r as any).code?.coding?.[0];
  return {
    fhir_id: r.id || crypto.randomUUID(),
    status: (r as any).status || "completed",
    category: (r as any).category?.coding?.[0]?.display || null,
    code_system: coding?.system || null,
    code: coding?.code || null,
    code_display: coding?.display || (r as any).code?.text || null,
    performed_datetime: (r as any).performedDateTime || (r as any).performedPeriod?.start || null,
    performer_display: (r as any).performer?.[0]?.actor?.display || null,
    body_site: (r as any).bodySite?.[0]?.coding?.[0]?.display || (r as any).bodySite?.[0]?.text || null,
    note: (r as any).note?.[0]?.text || null,
    reason_codes: (r as any).reasonCode || [],
    fhir_resource: r,
    _patient_ref: patientRef,
    _encounter_ref: encounterRef,
  };
}

function extractDocumentReference(r: FhirResource, patientRef: string, encounterRef: string | null) {
  const typeCoding = (r as any).type?.coding?.[0];
  return {
    fhir_id: r.id || crypto.randomUUID(),
    status: (r as any).status || "current",
    type_code: typeCoding?.code || null,
    type_display: typeCoding?.display || (r as any).type?.text || null,
    description: (r as any).description || null,
    date: (r as any).date || null,
    author_display: (r as any).author?.[0]?.display || null,
    content_type: (r as any).content?.[0]?.attachment?.contentType || null,
    fhir_resource: r,
    _patient_ref: patientRef,
    _encounter_ref: encounterRef,
  };
}

function getRef(r: FhirResource): string {
  return `${r.resourceType}/${r.id}`;
}

function resolvePatientRef(r: FhirResource): string | null {
  const subject = (r as any).subject?.reference || (r as any).patient?.reference;
  return subject || null;
}

function resolveEncounterRef(r: FhirResource): string | null {
  return (r as any).encounter?.reference || (r as any).context?.reference || null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const bundle: FhirBundle = body.bundle || body;

    if (bundle.resourceType !== "Bundle" || !bundle.entry) {
      return new Response(JSON.stringify({ error: "Invalid FHIR Bundle" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const resources = bundle.entry.map(e => e.resource);
    
    // Phase 1: Insert patients
    const patients = resources.filter(r => r.resourceType === "Patient");
    const patientIdMap = new Map<string, string>(); // fhir ref -> db id

    for (const p of patients) {
      const data = extractPatient(p);
      const { data: inserted, error } = await supabase
        .from("fhir_patients")
        .upsert({ ...data, created_by: user.id }, { onConflict: "fhir_id" })
        .select("id, fhir_id")
        .single();
      if (error) {
        console.error("Patient insert error:", error);
        continue;
      }
      patientIdMap.set(getRef(p), inserted.id);
    }

    // Phase 2: Insert encounters
    const encounters = resources.filter(r => r.resourceType === "Encounter");
    const encounterIdMap = new Map<string, string>();

    for (const e of encounters) {
      const data = extractEncounter(e, resolvePatientRef(e) || "");
      const patientDbId = patientIdMap.get(data._patient_ref);
      if (!patientDbId) continue;
      
      const { _patient_ref, ...insertData } = data;
      const { data: inserted, error } = await supabase
        .from("fhir_encounters")
        .upsert({ ...insertData, patient_id: patientDbId }, { onConflict: "fhir_id" })
        .select("id, fhir_id")
        .single();
      if (error) { console.error("Encounter insert error:", error); continue; }
      encounterIdMap.set(getRef(e), inserted.id);
    }

    // Phase 3: Insert conditions, observations, meds, allergies, procedures, documents
    const conditions = resources.filter(r => r.resourceType === "Condition");
    const observations = resources.filter(r => r.resourceType === "Observation");
    const medRequests = resources.filter(r => r.resourceType === "MedicationRequest");
    const allergies = resources.filter(r => r.resourceType === "AllergyIntolerance");
    const procedures = resources.filter(r => r.resourceType === "Procedure");
    const documents = resources.filter(r => r.resourceType === "DocumentReference");
    const diagnosticReports = resources.filter(r => r.resourceType === "DiagnosticReport");
    const carePlans = resources.filter(r => r.resourceType === "CarePlan");
    const immunizations = resources.filter(r => r.resourceType === "Immunization");

    let stats = { 
      patients: patients.length, encounters: encounters.length, 
      conditions: 0, observations: 0, medications: 0, allergies: 0, 
      procedures: 0, documents: 0, 
      skipped: { diagnosticReports: diagnosticReports.length, carePlans: carePlans.length, immunizations: immunizations.length }
    };

    for (const c of conditions) {
      const data = extractCondition(c, resolvePatientRef(c) || "", resolveEncounterRef(c) || null);
      const patientDbId = patientIdMap.get(data._patient_ref);
      if (!patientDbId) continue;
      const encounterDbId = data._encounter_ref ? encounterIdMap.get(data._encounter_ref) : null;
      const { _patient_ref, _encounter_ref, ...insertData } = data;
      const { error } = await supabase
        .from("fhir_conditions")
        .upsert({ ...insertData, patient_id: patientDbId, encounter_id: encounterDbId || null }, { onConflict: "fhir_id" });
      if (!error) stats.conditions++;
    }

    for (const o of observations) {
      const data = extractObservation(o, resolvePatientRef(o) || "", resolveEncounterRef(o) || null);
      const patientDbId = patientIdMap.get(data._patient_ref);
      if (!patientDbId) continue;
      const encounterDbId = data._encounter_ref ? encounterIdMap.get(data._encounter_ref) : null;
      const { _patient_ref, _encounter_ref, ...insertData } = data;
      const { error } = await supabase
        .from("fhir_observations")
        .upsert({ ...insertData, patient_id: patientDbId, encounter_id: encounterDbId || null }, { onConflict: "fhir_id" });
      if (!error) stats.observations++;
    }

    for (const m of medRequests) {
      const data = extractMedicationRequest(m, resolvePatientRef(m) || "", resolveEncounterRef(m) || null);
      const patientDbId = patientIdMap.get(data._patient_ref);
      if (!patientDbId) continue;
      const encounterDbId = data._encounter_ref ? encounterIdMap.get(data._encounter_ref) : null;
      const { _patient_ref, _encounter_ref, ...insertData } = data;
      const { error } = await supabase
        .from("fhir_medication_requests")
        .upsert({ ...insertData, patient_id: patientDbId, encounter_id: encounterDbId || null }, { onConflict: "fhir_id" });
      if (!error) stats.medications++;
    }

    for (const a of allergies) {
      const data = extractAllergy(a, resolvePatientRef(a) || "");
      const patientDbId = patientIdMap.get(data._patient_ref);
      if (!patientDbId) continue;
      const { _patient_ref, ...insertData } = data;
      const { error } = await supabase
        .from("fhir_allergies")
        .upsert({ ...insertData, patient_id: patientDbId }, { onConflict: "fhir_id" });
      if (!error) stats.allergies++;
    }

    for (const p of procedures) {
      const data = extractProcedure(p, resolvePatientRef(p) || "", resolveEncounterRef(p) || null);
      const patientDbId = patientIdMap.get(data._patient_ref);
      if (!patientDbId) continue;
      const encounterDbId = data._encounter_ref ? encounterIdMap.get(data._encounter_ref) : null;
      const { _patient_ref, _encounter_ref, ...insertData } = data;
      const { error } = await supabase
        .from("fhir_procedures")
        .upsert({ ...insertData, patient_id: patientDbId, encounter_id: encounterDbId || null }, { onConflict: "fhir_id" });
      if (!error) stats.procedures++;
      else console.error("Procedure insert error:", error);
    }

    for (const d of documents) {
      const data = extractDocumentReference(d, resolvePatientRef(d) || "", resolveEncounterRef(d) || null);
      const patientDbId = patientIdMap.get(data._patient_ref);
      if (!patientDbId) continue;
      const encounterDbId = data._encounter_ref ? encounterIdMap.get(data._encounter_ref) : null;
      const { _patient_ref, _encounter_ref, ...insertData } = data;
      const { error } = await supabase
        .from("fhir_document_references")
        .upsert({ ...insertData, patient_id: patientDbId, encounter_id: encounterDbId || null }, { onConflict: "fhir_id" });
      if (!error) stats.documents++;
      else console.error("Document insert error:", error);
    }

    return new Response(JSON.stringify({ success: true, stats }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("FHIR import error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
