import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SOURCE_NAME = "snomed";
const PAGE_SIZE = 200;
const SNOWSTORM_BASE = "https://browser.ihtsdotools.org/snowstorm/snomed-ct";
// Use MAIN for latest international edition
const BRANCH = "MAIN";
const SNOWSTORM_VERSION_URL = `${SNOWSTORM_BASE}/codesystems/SNOMEDCT`;

// Delay between self-invocations to avoid rate limiting (ms)
const SELF_INVOKE_DELAY_MS = 500;
// Maximum pages per single invocation before self-invoking (to stay within timeout)
const MAX_PAGES_PER_INVOCATION = 5;

/**
 * Fetch the current SNOMED CT release version from Snowstorm API
 * Returns version string like "20240701" or null on failure
 */
async function fetchRemoteVersion(): Promise<string | null> {
  try {
    const response = await fetch(SNOWSTORM_VERSION_URL, {
      headers: {
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      console.error(`[SNOMED Sync] Failed to fetch version: ${response.status}`);
      return null;
    }

    const data = await response.json();
    // Snowstorm returns version in latestVersion field
    const version = data?.latestVersion?.effectiveDate?.toString() || null;
    console.log(`[SNOMED Sync] Remote SNOMED version: ${version}`);
    return version;
  } catch (err: any) {
    console.error(`[SNOMED Sync] Error fetching version:`, err?.message || String(err));
    return null;
  }
}

/**
 * Compare versions - returns true if remote is newer than local
 * SNOMED versions are date-based like "20240701"
 */
function isNewerVersion(remoteVersion: string | null, localVersion: string | null): boolean {
  if (!remoteVersion) return false;
  if (!localVersion) return true;
  return remoteVersion > localVersion;
}

function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(supabaseUrl, supabaseKey);
}

/**
 * Self-invoke this function to continue the sync in the background
 */
async function invokeSelfAsync(action: string): Promise<void> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  
  // Fire-and-forget: don't await, let it run in background
  fetch(`${supabaseUrl}/functions/v1/snomed-sync`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${serviceRoleKey}`,
    },
    body: JSON.stringify({ action }),
  }).catch((err) => {
    console.error("[SNOMED Sync] Self-invoke failed:", err);
  });
}

interface SnomedConcept {
  conceptId: string;
  fsn: { term: string };
  pt: { term: string };
  active: boolean;
  definitionStatus: string;
  moduleId: string;
  effectiveTime?: string; // Format: YYYYMMDD - Release date of the concept
}

class SnowstormApiError extends Error {
  status: number;
  responseText: string;

  constructor(status: number, message: string, responseText: string) {
    super(message);
    this.name = "SnowstormApiError";
    this.status = status;
    this.responseText = responseText;
  }
}

function isLikelySearchAfterToken(token: string) {
  // Snowstorm uses base64(JSON.stringify(Object[])) tokens in the `searchAfter` header.
  // Example for a JSON array starts with "Wy" after base64 ("[" -> "Wy").
  // We keep this heuristic permissive to avoid false negatives.
  return /^[A-Za-z0-9+/=]+$/.test(token) && token.length >= 8;
}

async function parseJsonSafely(responseText: string) {
  if (!responseText) return {};
  try {
    return JSON.parse(responseText);
  } catch {
    return null;
  }
}

/**
 * Fetch a page of SNOMED concepts using Snowstorm's searchAfter token.
 * IMPORTANT: The `searchAfter` request parameter expects a base64 token (header `searchAfter`),
 * NOT the raw `searchAfterArray` values.
 */
async function fetchSnomedPage(searchAfterToken?: string): Promise<{
  concepts: SnomedConcept[];
  total: number;
  hasMore: boolean;
  nextSearchAfterToken: string | null;
}> {
  let url = `${SNOWSTORM_BASE}/${BRANCH}/concepts?activeFilter=true&limit=${PAGE_SIZE}&returnIdOnly=false`;

  if (searchAfterToken) {
    url += `&searchAfter=${encodeURIComponent(searchAfterToken)}`;
  }

  console.log(
    `[SNOMED Sync] Fetching: ${url}${searchAfterToken ? ` (tokenLen=${searchAfterToken.length})` : ""}`,
  );

  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
      "Accept-Language": "en",
    },
  });

  const responseText = await response.text();
  const data = await parseJsonSafely(responseText);

  if (!response.ok) {
    const msg =
      (data && (data.message || data.error))
        ? `${data.error || "ERROR"} - ${data.message || ""}`
        : responseText;

    console.error(`[SNOMED Sync] API Error ${response.status}: ${String(msg).slice(0, 400)}`);
    throw new SnowstormApiError(
      response.status,
      `Snowstorm API error: ${response.status} - ${String(msg).slice(0, 200)}`,
      responseText,
    );
  }

  if (!data) {
    console.error(`[SNOMED Sync] Non-JSON response (first 400 chars): ${responseText.slice(0, 400)}`);
    throw new Error(`Snowstorm API returned non-JSON response: ${responseText.slice(0, 120)}`);
  }

  const concepts = data.items || [];
  const total = data.total || 0;

  // Snowstorm returns the pagination token in a response header.
  const nextSearchAfterToken = response.headers.get("searchAfter");

  console.log(
    `[SNOMED Sync] Received ${concepts.length} concepts, total: ${total}, hasNextToken: ${!!nextSearchAfterToken}`,
  );

  return {
    concepts,
    total,
    hasMore: concepts.length === PAGE_SIZE && !!nextSearchAfterToken,
    nextSearchAfterToken,
  };
}

/**
 * Persist SNOMED concepts to database
 */
async function persistSnomedConcepts(supabase: any, concepts: SnomedConcept[]): Promise<number> {
  if (concepts.length === 0) return 0;

  const codesToInsert = concepts.map((c) => ({
    sctid: c.conceptId,
    fsn: c.fsn?.term || c.conceptId,
    pt: c.pt?.term || c.conceptId,
    is_active: c.active,
    definition_status: c.definitionStatus,
    module_id: c.moduleId,
    // Parse effectiveTime (YYYYMMDD) to date format for the database
    effective_time: c.effectiveTime 
      ? `${c.effectiveTime.slice(0, 4)}-${c.effectiveTime.slice(4, 6)}-${c.effectiveTime.slice(6, 8)}`
      : null,
    labels: { en: c.pt?.term || c.fsn?.term },
    source: "snowstorm_bulk_sync",
  }));

  const { error } = await supabase
    .from("snomed_codes")
    .upsert(codesToInsert, { onConflict: "sctid" });

  if (error) {
    console.error("[SNOMED Sync] Persist error:", error);
    return 0;
  }

  return concepts.length;
}

/**
 * Get or create sync status
 */
async function getSyncStatus(supabase: any) {
  const { data } = await supabase
    .from("sync_status")
    .select("*")
    .eq("source_name", SOURCE_NAME)
    .maybeSingle();
  
  return data;
}

/**
 * Update sync status
 */
async function updateSyncStatus(supabase: any, updates: Record<string, any>) {
  await supabase
    .from("sync_status")
    .upsert({
      source_name: SOURCE_NAME,
      ...updates,
      updated_at: new Date().toISOString(),
    }, { onConflict: "source_name" });
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = getSupabaseAdmin();

  try {
    const body = await req.json();
    const action = body.action || "sync_page";

    switch (action) {
      case "init": {
        await updateSyncStatus(supabase, {
          status: "running",
          total_synced: 0,
          total_available: null,
          last_cursor: null,
          error_message: null,
          started_at: new Date().toISOString(),
          completed_at: null,
        });

        return new Response(
          JSON.stringify({ success: true, message: "Sync initialized" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "sync_page": {
        const status = await getSyncStatus(supabase);

        let baseTotalSynced = status?.total_synced || 0;
        let searchAfterToken = status?.last_cursor || undefined;

        // Cursor tokens must be base64. If we find a legacy value (e.g., old offsets), clear it.
        if (searchAfterToken && !isLikelySearchAfterToken(searchAfterToken)) {
          console.warn(`[SNOMED Sync] Invalid/legacy cursor detected, clearing: ${searchAfterToken}`);
          searchAfterToken = undefined;
          baseTotalSynced = 0;

          await updateSyncStatus(supabase, {
            status: "running",
            total_synced: 0,
            last_cursor: null,
            error_message: null,
            completed_at: null,
            started_at: status?.started_at || new Date().toISOString(),
          });
        }

        let pageResult: {
          concepts: SnomedConcept[];
          total: number;
          hasMore: boolean;
          nextSearchAfterToken: string | null;
        };

        try {
          pageResult = await fetchSnomedPage(searchAfterToken);
        } catch (err: any) {
          // If the stored cursor is bad, clear and retry once from the start.
          if (err instanceof SnowstormApiError && err.status === 400 && searchAfterToken) {
            console.warn(`[SNOMED Sync] searchAfter token rejected (400). Clearing cursor and retrying from start.`);

            searchAfterToken = undefined;
            baseTotalSynced = 0;

            await updateSyncStatus(supabase, {
              status: "running",
              total_synced: 0,
              last_cursor: null,
              error_message: null,
              completed_at: null,
              started_at: status?.started_at || new Date().toISOString(),
            });

            pageResult = await fetchSnomedPage(undefined);
          } else if (err instanceof SnowstormApiError && (err.status === 429 || err.status >= 500)) {
            // Provider instability / rate limit -> pause gracefully so the UI doesn't blank-screen.
            await updateSyncStatus(supabase, {
              status: "paused",
              error_message: err.message,
            });

            return new Response(
              JSON.stringify({ paused: true, error: err.message }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } },
            );
          } else {
            throw err;
          }
        }

        const { concepts, total, hasMore, nextSearchAfterToken } = pageResult;

        // Persist concepts
        const synced = await persistSnomedConcepts(supabase, concepts);

        // Update status with new cursor
        const newTotalSynced = baseTotalSynced + synced;

        await updateSyncStatus(supabase, {
          status: hasMore ? "running" : "completed",
          total_synced: newTotalSynced,
          total_available: total,
          last_cursor: hasMore ? nextSearchAfterToken : null,
          completed_at: hasMore ? null : new Date().toISOString(),
          error_message: null,
        });

        console.log(`[SNOMED Sync] ${synced} concepts synced. Total: ${newTotalSynced}/${total}`);

        return new Response(
          JSON.stringify({
            hasMore,
            syncedCount: synced,
            totalSynced: newTotalSynced,
            totalAvailable: total,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      case "pause": {
        await updateSyncStatus(supabase, { status: "paused" });
        return new Response(
          JSON.stringify({ success: true, message: "Sync paused" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "reset": {
        await updateSyncStatus(supabase, {
          status: "pending",
          total_synced: 0,
          total_available: null,
          last_cursor: null,
          error_message: null,
          started_at: null,
          completed_at: null,
        });
        return new Response(
          JSON.stringify({ success: true, message: "Sync reset" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "status": {
        const status = await getSyncStatus(supabase);
        return new Response(
          JSON.stringify(status || { status: "pending", total_synced: 0 }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "check_version": {
        const status = await getSyncStatus(supabase);
        const remoteVersion = await fetchRemoteVersion();
        const localVersion = status?.local_version || null;
        const needsSync = isNewerVersion(remoteVersion, localVersion);

        // Update remote_version in sync_status
        if (remoteVersion) {
          await updateSyncStatus(supabase, {
            remote_version: remoteVersion,
          });
        }

        return new Response(
          JSON.stringify({
            remoteVersion,
            localVersion,
            needsSync,
            message: needsSync 
              ? `New version available: ${remoteVersion} (current: ${localVersion || 'none'})`
              : `Already up to date: ${localVersion}`,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // ============================================================
      // FULL SYNC: Backend-driven autonomous synchronization
      // ============================================================
      case "full_sync": {
        // Initialize if not already running
        let status = await getSyncStatus(supabase);
        
        if (!status || status.status === "pending" || status.status === "error") {
          await updateSyncStatus(supabase, {
            status: "running",
            total_synced: 0,
            total_available: null,
            last_cursor: null,
            error_message: null,
            started_at: new Date().toISOString(),
            completed_at: null,
          });
          status = await getSyncStatus(supabase);
        }

        // Check if paused or completed - don't continue
        if (status?.status === "paused") {
          return new Response(
            JSON.stringify({ success: false, message: "Sync is paused. Use 'resume_sync' to continue." }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        if (status?.status === "completed") {
          return new Response(
            JSON.stringify({ success: true, message: "Sync already completed", totalSynced: status.total_synced }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        let baseTotalSynced = status?.total_synced || 0;
        let searchAfterToken = status?.last_cursor || undefined;
        let pagesProcessed = 0;
        let hasMore = true;

        // Process multiple pages in this invocation
        while (hasMore && pagesProcessed < MAX_PAGES_PER_INVOCATION) {
          // Re-check status in case user paused or marked completed
          const currentStatus = await getSyncStatus(supabase);
          if (currentStatus?.status === "paused" || currentStatus?.status === "completed") {
            console.log(`[SNOMED Full Sync] Status is ${currentStatus?.status}, stopping.`);
            return new Response(
              JSON.stringify({ success: true, message: `Sync ${currentStatus?.status}`, totalSynced: baseTotalSynced }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          // Validate cursor
          if (searchAfterToken && !isLikelySearchAfterToken(searchAfterToken)) {
            console.warn(`[SNOMED Full Sync] Invalid cursor, resetting: ${searchAfterToken}`);
            searchAfterToken = undefined;
            baseTotalSynced = 0;
          }

          let pageResult: {
            concepts: SnomedConcept[];
            total: number;
            hasMore: boolean;
            nextSearchAfterToken: string | null;
          };

          try {
            pageResult = await fetchSnomedPage(searchAfterToken);
          } catch (err: any) {
            if (err instanceof SnowstormApiError && err.status === 400 && searchAfterToken) {
              // Bad cursor, reset and retry
              searchAfterToken = undefined;
              baseTotalSynced = 0;
              pageResult = await fetchSnomedPage(undefined);
            } else if (err instanceof SnowstormApiError && (err.status === 429 || err.status >= 500)) {
              // Rate limit or server error - pause and schedule retry
              await updateSyncStatus(supabase, {
                status: "running", // Keep running, will retry
                error_message: `Temporary error (${err.status}), will retry...`,
              });
              
              // Wait a bit and self-invoke to retry
              await new Promise(resolve => setTimeout(resolve, 5000));
              invokeSelfAsync("full_sync");
              
              return new Response(
                JSON.stringify({ success: true, message: "Rate limited, scheduled retry", totalSynced: baseTotalSynced }),
                { headers: { ...corsHeaders, "Content-Type": "application/json" } }
              );
            } else {
              throw err;
            }
          }

          // Persist concepts
          const synced = await persistSnomedConcepts(supabase, pageResult.concepts);
          baseTotalSynced += synced;
          hasMore = pageResult.hasMore;
          searchAfterToken = pageResult.nextSearchAfterToken || undefined;
          pagesProcessed++;

          // Update status
          await updateSyncStatus(supabase, {
            status: hasMore ? "running" : "completed",
            total_synced: baseTotalSynced,
            total_available: pageResult.total,
            last_cursor: hasMore ? searchAfterToken : null,
            completed_at: hasMore ? null : new Date().toISOString(),
            error_message: null,
          });

          console.log(`[SNOMED Full Sync] Page ${pagesProcessed}: ${synced} concepts. Total: ${baseTotalSynced}/${pageResult.total}`);

          // Small delay between pages
          if (hasMore && pagesProcessed < MAX_PAGES_PER_INVOCATION) {
            await new Promise(resolve => setTimeout(resolve, 200));
          }
        }

        // If there's more data, check status before scheduling next invocation
        if (hasMore) {
          // Re-check if paused/completed before self-invoking
          const latestStatus = await getSyncStatus(supabase);
          if (latestStatus?.status === "paused" || latestStatus?.status === "completed") {
            console.log(`[SNOMED Full Sync] Status changed to ${latestStatus?.status}, stopping self-invoke loop.`);
            return new Response(
              JSON.stringify({ 
                success: true, 
                message: `Sync ${latestStatus?.status}`,
                totalSynced: baseTotalSynced,
                hasMore: true,
              }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          await new Promise(resolve => setTimeout(resolve, SELF_INVOKE_DELAY_MS));
          invokeSelfAsync("full_sync");
          
          return new Response(
            JSON.stringify({ 
              success: true, 
              message: "Batch complete, continuing in background",
              totalSynced: baseTotalSynced,
              hasMore: true,
            }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        return new Response(
          JSON.stringify({ 
            success: true, 
            message: "Full sync completed!",
            totalSynced: baseTotalSynced,
            hasMore: false,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "resume_sync": {
        const status = await getSyncStatus(supabase);
        
        if (status?.status === "completed") {
          return new Response(
            JSON.stringify({ success: true, message: "Already completed", totalSynced: status.total_synced }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        // Set status back to running and trigger full_sync
        await updateSyncStatus(supabase, {
          status: "running",
          error_message: null,
        });

        invokeSelfAsync("full_sync");

        return new Response(
          JSON.stringify({ success: true, message: "Sync resumed in background" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // ============================================================
      // FIX COUNT: Correct sync_status with actual DB count
      // ============================================================
      case "fix_count": {
        const { count: actualCount } = await supabase
          .from("snomed_codes")
          .select("sctid", { count: "exact", head: true });

        await updateSyncStatus(supabase, {
          status: "completed",
          total_synced: actualCount || 0,
          total_available: actualCount || 0,
          last_cursor: null,
          completed_at: new Date().toISOString(),
          error_message: null,
        });

        return new Response(
          JSON.stringify({ success: true, message: "Count fixed", actualCount }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // ============================================================
      // BACKFILL DATES: Update codes missing effective_time
      // ============================================================
      case "backfill_dates": {
        const BATCH_SIZE = 20; // Smaller batch size for faster response
        
        // Get codes missing effective_time
        const { data: missingCodes, error: fetchError } = await supabase
          .from("snomed_codes")
          .select("sctid")
          .is("effective_time", null)
          .limit(BATCH_SIZE);

        if (fetchError) {
          throw new Error(`Failed to fetch codes: ${fetchError.message}`);
        }

        if (!missingCodes || missingCodes.length === 0) {
          return new Response(
            JSON.stringify({ success: true, message: "All codes have effective_time", updated: 0, remaining: 0 }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        console.log(`[SNOMED Backfill] Processing ${missingCodes.length} codes`);

        // Process codes in parallel (5 at a time)
        const CONCURRENCY = 5;
        let updatedCount = 0;
        const errors: string[] = [];

        async function processCode(sctid: string): Promise<void> {
          try {
            // Try MAIN branch first
            let response = await fetch(
              `${SNOWSTORM_BASE}/${BRANCH}/concepts/${sctid}`,
              { headers: { Accept: "application/json" } }
            );

            let concept = null;
            if (response.ok) {
              concept = await response.json();
            } else if (response.status === 404 || response.status === 400) {
              // Try German branch
              response = await fetch(
                `${SNOWSTORM_BASE}/MAIN%2FSNOMEDCT-DE/concepts/${sctid}`,
                { headers: { Accept: "application/json" } }
              );
              if (response.ok) {
                concept = await response.json();
              }
            }

            if (!concept || !concept.effectiveTime) {
              // Not found or no date - mark with placeholder
              await supabase
                .from("snomed_codes")
                .update({ effective_time: "1970-01-01" })
                .eq("sctid", sctid);
            } else {
              const effectiveDate = `${concept.effectiveTime.slice(0, 4)}-${concept.effectiveTime.slice(4, 6)}-${concept.effectiveTime.slice(6, 8)}`;
              await supabase
                .from("snomed_codes")
                .update({ 
                  effective_time: effectiveDate,
                  is_active: concept.active,
                  definition_status: concept.definitionStatus,
                })
                .eq("sctid", sctid);
            }
            updatedCount++;
          } catch (err: any) {
            errors.push(`${sctid}: ${err.message}`);
          }
        }

        // Process in batches of CONCURRENCY
        for (let i = 0; i < missingCodes.length; i += CONCURRENCY) {
          const batch = missingCodes.slice(i, i + CONCURRENCY);
          await Promise.all(batch.map(c => processCode(c.sctid)));
        }

        // Check how many remain
        const { count: remaining } = await supabase
          .from("snomed_codes")
          .select("sctid", { count: "exact", head: true })
          .is("effective_time", null);

        console.log(`[SNOMED Backfill] Updated ${updatedCount}, remaining: ${remaining}`);

        // If there are more, schedule next batch immediately
        if (remaining && remaining > 0) {
          invokeSelfAsync("backfill_dates");
        }

        return new Response(
          JSON.stringify({ 
            success: true, 
            message: remaining && remaining > 0 ? "Batch complete, continuing..." : "Backfill complete!",
            updated: updatedCount, 
            remaining: remaining || 0,
            errors: errors.length > 0 ? errors.slice(0, 5) : undefined,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${action}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error: any) {
    console.error("[SNOMED Sync] Error:", error);

    await updateSyncStatus(supabase, {
      status: "error",
      error_message: error.message,
    });

    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
