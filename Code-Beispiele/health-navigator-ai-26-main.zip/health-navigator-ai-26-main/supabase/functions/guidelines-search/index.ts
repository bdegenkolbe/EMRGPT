 import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
 import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
 
 const corsHeaders = {
   "Access-Control-Allow-Origin": "*",
   "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
 };
 
interface SearchRequest {
  query: string;
  hpo_codes?: string[];
  icd10_codes?: string[];
  snomed_codes?: string[];
  match_count?: number;
  match_threshold?: number;
}

interface SearchResult {
  chunk_id: string;
  guideline_id: string;
  guideline_title: string;
  section_title: string | null;
  content: string;
  page_number: number | null;
  similarity: number;
}

interface GuidelineWithCodes {
  id: string;
  title: string;
  detected_icd10_codes: string[] | null;
  detected_hpo_codes: string[] | null;
  detected_snomed_codes: string[] | null;
}
 
 async function getEmbedding(text: string, apiKey: string): Promise<number[]> {
   const response = await fetch("https://api.openai.com/v1/embeddings", {
     method: "POST",
     headers: {
       "Content-Type": "application/json",
       Authorization: `Bearer ${apiKey}`,
     },
     body: JSON.stringify({
       model: "text-embedding-3-small",
       input: text,
     }),
   });
 
   if (!response.ok) {
     const error = await response.text();
     throw new Error(`OpenAI Embedding error: ${response.status} - ${error}`);
   }
 
   const data = await response.json();
   return data.data[0].embedding;
 }
 
 serve(async (req) => {
   if (req.method === "OPTIONS") {
     return new Response(null, { headers: corsHeaders });
   }
 
   try {
     const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
     const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
     const openaiKey = Deno.env.get("OPENAI_API_KEY");
 
     if (!openaiKey) {
       throw new Error("OPENAI_API_KEY not configured");
     }
 
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { 
      query, 
      hpo_codes,
      icd10_codes,
      snomed_codes,
      match_count = 5, 
      match_threshold = 0.5 
    }: SearchRequest = await req.json();

    if (!query) {
      return new Response(
        JSON.stringify({ error: "query is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Searching guidelines for: "${query.slice(0, 100)}..."`, { hpo_codes, icd10_codes, snomed_codes });

    // Pre-filter guidelines by detected codes if provided
    let filterGuidelineIds: string[] | null = null;
    
    const hasCodeFilters = (icd10_codes?.length || 0) > 0 || (hpo_codes?.length || 0) > 0 || (snomed_codes?.length || 0) > 0;
    
    if (hasCodeFilters) {
      // Find guidelines that have any of the specified codes
      let codeQuery = supabase
        .from("guidelines")
        .select("id, title, detected_icd10_codes, detected_hpo_codes, detected_snomed_codes")
        .eq("embedding_status", "completed");
      
      // Build OR filter for code matching
      const orConditions: string[] = [];
      
      if (icd10_codes?.length) {
        // Check if any ICD-10 code overlaps
        orConditions.push(`detected_icd10_codes.ov.{${icd10_codes.join(',')}}`);
      }
      if (hpo_codes?.length) {
        orConditions.push(`detected_hpo_codes.ov.{${hpo_codes.join(',')}}`);
      }
      if (snomed_codes?.length) {
        orConditions.push(`detected_snomed_codes.ov.{${snomed_codes.join(',')}}`);
      }
      
      if (orConditions.length > 0) {
        codeQuery = codeQuery.or(orConditions.join(','));
      }
      
      const { data: matchingGuidelines, error: filterError } = await codeQuery;
      
      if (filterError) {
        console.error("Code filter error:", filterError);
        // Continue without code filtering
      } else if (matchingGuidelines?.length) {
        filterGuidelineIds = matchingGuidelines.map(g => g.id);
        console.log(`Pre-filtered to ${filterGuidelineIds.length} guidelines by code match`);
      } else {
        // No guidelines match the codes - fall back to unfiltered semantic search
        console.log("No guidelines match the specified codes, falling back to unfiltered search");
        filterGuidelineIds = null;
      }
    }

    // Build the search query - include HPO context if provided
    let searchText = query;
    if (hpo_codes?.length) {
      // Fetch HPO labels for context
      const { data: hpoLabels } = await supabase
        .from("hpo_translations")
        .select("hpo_code, label_de, label_en")
        .in("hpo_code", hpo_codes);
      
      if (hpoLabels?.length) {
        const symptomContext = hpoLabels.map(h => `${h.label_de} (${h.hpo_code})`).join(", ");
        searchText = `${query}\n\nRelevante Symptome: ${symptomContext}`;
      }
    }

    // Get embedding for the search query
    const queryEmbedding = await getEmbedding(searchText, openaiKey);
    console.log(`Embedding generated: ${queryEmbedding.length} dimensions`);

    // Search using the database function
    const rpcParams = {
      query_embedding: JSON.stringify(queryEmbedding),
      match_threshold: match_threshold,
      match_count: match_count,
      filter_guideline_ids: filterGuidelineIds,
    };
    console.log(`RPC params: threshold=${match_threshold}, count=${match_count}, filter=${filterGuidelineIds}`);
    
    const { data: results, error: searchError } = await supabase.rpc(
      "search_guidelines",
      rpcParams
    );
 
     if (searchError) {
       console.error("Search error:", searchError);
       throw searchError;
     }
 
     const searchResults: SearchResult[] = results || [];
     console.log(`Found ${searchResults.length} relevant chunks`);
 
      // Group results by guideline for better organization
      const groupedResults = searchResults.reduce((acc, result) => {
        if (!acc[result.guideline_id]) {
          acc[result.guideline_id] = {
            guideline_id: result.guideline_id,
            guideline_title: result.guideline_title,
            chunks: [],
          };
        }
        acc[result.guideline_id].chunks.push({
          chunk_id: result.chunk_id,
          section_title: result.section_title,
          content: result.content,
          page_number: result.page_number,
          similarity: result.similarity,
        });
        return acc;
      }, {} as Record<string, any>);

      // Enrich groups with file_path for PDF links
      const guidelineIds = Object.keys(groupedResults);
      if (guidelineIds.length > 0) {
        const { data: guidelineMeta } = await supabase
          .from("guidelines")
          .select("id, file_path, file_name, source, description")
          .in("id", guidelineIds);
        
        for (const meta of (guidelineMeta || [])) {
          if (groupedResults[meta.id]) {
            groupedResults[meta.id].file_path = meta.file_path;
            groupedResults[meta.id].file_name = meta.file_name;
            groupedResults[meta.id].source = meta.source;
            groupedResults[meta.id].description = meta.description;
          }
        }
      }
 
     return new Response(
       JSON.stringify({
         success: true,
         results: searchResults,
         grouped: Object.values(groupedResults),
         total_chunks: searchResults.length,
         code_filter_applied: hasCodeFilters,
         matching_guidelines: filterGuidelineIds?.length || null,
       }),
       { headers: { ...corsHeaders, "Content-Type": "application/json" } }
     );
   } catch (error) {
     console.error("Search error:", error);
     return new Response(
       JSON.stringify({ error: error.message || "Search failed" }),
       { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
     );
   }
 });