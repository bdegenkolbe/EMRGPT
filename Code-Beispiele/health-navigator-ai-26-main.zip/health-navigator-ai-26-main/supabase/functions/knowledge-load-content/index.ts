import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface LoadRequest {
  searchId: string;
  sourceIds: string[];
  targetLanguage?: string;
}

/**
 * Extract plain text from JATS XML full text.
 * Parses <body> content, extracts <sec> sections with titles.
 */
function extractTextFromJatsXml(xml: string): string | null {
  try {
    // Extract <body> content
    const bodyMatch = xml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (!bodyMatch) return null;

    const body = bodyMatch[1];

    // Extract sections with titles
    const sections: string[] = [];
    const secRegex = /<sec[^>]*>([\s\S]*?)<\/sec>/gi;
    let secMatch;

    while ((secMatch = secRegex.exec(body)) !== null) {
      const secContent = secMatch[1];

      // Extract section title
      const titleMatch = secContent.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const title = titleMatch ? stripTags(titleMatch[1]).trim() : "";

      // Get section text (remove nested <sec> to avoid duplication)
      let text = secContent
        .replace(/<sec[^>]*>[\s\S]*?<\/sec>/gi, "") // remove nested sections
        .replace(/<title[^>]*>[\s\S]*?<\/title>/i, ""); // remove title tag

      text = stripTags(text).trim();

      if (title || text) {
        if (title) {
          sections.push(`\n## ${title}\n\n${text}`);
        } else if (text) {
          sections.push(text);
        }
      }
    }

    // If no sections found, try to get all text from body
    if (sections.length === 0) {
      const plainText = stripTags(body).trim();
      return plainText.length > 100 ? plainText : null;
    }

    return sections.join("\n").trim();
  } catch (e) {
    console.warn("[extractTextFromJatsXml] Parse error:", e);
    return null;
  }
}

/**
 * Strip HTML/XML tags and clean up whitespace.
 */
function stripTags(html: string): string {
  return html
    .replace(/<xref[^>]*>[\s\S]*?<\/xref>/gi, "") // remove citation references
    .replace(/<ext-link[^>]*>([\s\S]*?)<\/ext-link>/gi, "$1") // keep link text
    .replace(/<[^>]+>/g, " ") // remove all tags
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ") // normalize whitespace
    .trim();
}

/**
 * Try to fetch full text XML from Europe PMC for a given PMCID.
 */
async function fetchFullTextXml(pmcid: string): Promise<string | null> {
  const normalizedId = pmcid.startsWith("PMC") ? pmcid : `PMC${pmcid}`;
  const url = `https://www.ebi.ac.uk/europepmc/webservices/rest/${normalizedId}/fullTextXML`;

  console.log(`[knowledge-load-content] Fetching fulltext XML from: ${url}`);

  try {
    const response = await fetch(url, {
      headers: {
        "Accept": "application/xml, text/xml",
        "User-Agent": "MedAssist/1.0 (academic research tool)",
      },
    });

    if (!response.ok) {
      console.log(`[knowledge-load-content] Fulltext XML returned ${response.status} for ${normalizedId}`);
      return null;
    }

    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("xml")) {
      console.log(`[knowledge-load-content] Unexpected content-type: ${contentType}`);
      await response.text(); // consume body
      return null;
    }

    const xml = await response.text();
    if (xml.length < 500) {
      console.log(`[knowledge-load-content] XML too short (${xml.length} chars), likely empty`);
      return null;
    }

    return xml;
  } catch (e) {
    console.warn(`[knowledge-load-content] Fulltext fetch error for ${normalizedId}:`, e);
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: LoadRequest = await req.json();
    const { searchId, sourceIds, targetLanguage = 'de' } = body;

    if (!searchId || !sourceIds?.length) {
      return new Response(JSON.stringify({ error: "searchId and sourceIds required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[knowledge-load-content] Loading ${sourceIds.length} sources for search ${searchId}, target: ${targetLanguage}`);

    // Get sources to load - include those needing content OR translation
    const { data: sources, error: fetchError } = await supabase
      .from("knowledge_sources")
      .select("*")
      .in("id", sourceIds)
      .or("content_status.eq.pending,translation_status.eq.pending");

    if (fetchError || !sources?.length) {
      console.log("[knowledge-load-content] No pending sources found");
      return new Response(JSON.stringify({ loaded: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let loadedCount = 0;

    for (const source of sources) {
      try {
        let content = source.original_content;
        let contentType = source.content_type || "abstract";
        const needsContent = source.content_status === "pending";
        const needsTranslation = source.translation_status === "pending" && source.original_language !== targetLanguage;
        
        // Load content if needed
        if (needsContent && source.source_type === "europepmc" && source.external_id) {
          // Mark as loading
          await supabase
            .from("knowledge_sources")
            .update({ content_status: "loading" })
            .eq("id", source.id);

          const externalId = source.external_id;
          
          // Step 1: Try to get full text XML if PMCID is available
          const pmcid = source.metadata?.pmcid || (externalId.startsWith("PMC") ? externalId : null);
          
          if (pmcid) {
            const xml = await fetchFullTextXml(pmcid);
            if (xml) {
              const fullText = extractTextFromJatsXml(xml);
              if (fullText && fullText.length > 200) {
                content = fullText;
                contentType = "fulltext";
                console.log(`[knowledge-load-content] Full text extracted: ${fullText.length} chars for ${externalId}`);
              }
            }
          }

          // Step 2: Fallback to abstract if no fulltext
          if (!content || contentType === "abstract") {
            let searchQuery: string;
            if (externalId.startsWith("PMC")) {
              searchQuery = `PMCID:${externalId}`;
            } else {
              searchQuery = `EXT_ID:${externalId} AND SRC:MED`;
            }
            
            const pmcUrl = `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${encodeURIComponent(searchQuery)}&format=json&resultType=core`;
            
            console.log(`[knowledge-load-content] Fetching abstract from: ${pmcUrl}`);
            const response = await fetch(pmcUrl);
            
            if (response.ok) {
              const data = await response.json();
              const result = data.resultList?.result?.[0];
              const abstractText = result?.abstractText || null;
              if (abstractText) {
                content = abstractText;
                contentType = "abstract";
                console.log(`[knowledge-load-content] Abstract found: ${abstractText.length} chars for ${externalId}`);
              }
            } else {
              console.warn(`[knowledge-load-content] API returned ${response.status} for ${externalId}`);
            }
          }
        }

        // Update source with content
        const updateData: Record<string, unknown> = {
          content_status: content ? "loaded" : (needsContent ? "error" : source.content_status),
          content_type: contentType,
          updated_at: new Date().toISOString(),
        };
        
        if (content && needsContent) {
          updateData.original_content = content;
        }

        // If content exists and needs translation (title + content)
        const contentToTranslate = content || source.original_content;
        if (needsTranslation && lovableApiKey) {
          updateData.translation_status = "loading";
          
          await supabase
            .from("knowledge_sources")
            .update({ translation_status: "loading" })
            .eq("id", source.id);

          try {
            console.log(`[knowledge-load-content] Translating source ${source.id} from ${source.original_language} to ${targetLanguage}`);
            
            // Build translation payload - include title and content
            const itemsToTranslate: { key: string; text: string }[] = [];
            
            // Always translate title if original language differs
            if (source.title) {
              itemsToTranslate.push({ key: "title", text: source.title });
            }
            
            if (contentToTranslate) {
              itemsToTranslate.push({ key: "content", text: contentToTranslate });
            }
            
            if (itemsToTranslate.length > 0) {
              // Use higher max_tokens for fulltext
              const maxTokens = contentType === "fulltext" ? 16000 : 4000;
              
              const translateResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
                method: "POST",
                headers: {
                  "Authorization": `Bearer ${lovableApiKey}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  model: "google/gemini-3-flash-preview",
                  messages: [
                    {
                      role: "system",
                      content: `Translate the following JSON object from ${source.original_language} to ${targetLanguage}. 
Preserve all technical terms, citations, and formatting. Return ONLY a valid JSON object with the same keys, containing the translated text.
Example input: {"title": "Heart failure", "content": "Abstract text..."}
Example output: {"title": "Herzinsuffizienz", "content": "Abstrakt-Text..."}`,
                    },
                    { role: "user", content: JSON.stringify(Object.fromEntries(itemsToTranslate.map(i => [i.key, i.text]))) },
                  ],
                  temperature: 0.1,
                  max_tokens: maxTokens,
                }),
              });

              if (translateResponse.ok) {
                const translateData = await translateResponse.json();
                let translatedText = translateData.choices?.[0]?.message?.content || "";
                
                // Clean up potential markdown code blocks
                translatedText = translatedText.replace(/^```json\s*\n?/i, "").replace(/\n?```$/i, "").trim();
                
                try {
                  const translated = JSON.parse(translatedText);
                  
                  if (translated.title) {
                    updateData.translated_title = translated.title;
                  }
                  if (translated.content) {
                    updateData.translated_content = translated.content;
                  }
                  updateData.translation_status = "completed";
                  console.log(`[knowledge-load-content] Translation completed for ${source.id}`);
                } catch (parseErr) {
                  // Fallback: if not JSON, treat as content translation only
                  console.warn(`[knowledge-load-content] JSON parse failed, using raw response for ${source.id}`);
                  if (translatedText) {
                    updateData.translated_content = translatedText;
                    updateData.translation_status = "completed";
                  } else {
                    updateData.translation_status = "error";
                  }
                }
              } else {
                console.warn(`[knowledge-load-content] Translation API returned ${translateResponse.status}`);
                updateData.translation_status = "error";
              }
            } else {
              updateData.translation_status = "skipped";
            }
          } catch (translateError) {
            console.warn(`[knowledge-load-content] Translation failed for ${source.id}:`, translateError);
            updateData.translation_status = "error";
          }
        } else if (source.original_language === targetLanguage) {
          updateData.translation_status = "skipped";
          if (contentToTranslate) {
            updateData.translated_content = contentToTranslate;
          }
        }

        await supabase
          .from("knowledge_sources")
          .update(updateData)
          .eq("id", source.id);

        loadedCount++;
        console.log(`[knowledge-load-content] Loaded source ${source.id} (${contentType})`);
      } catch (sourceError) {
        console.error(`[knowledge-load-content] Failed to load source ${source.id}:`, sourceError);
        
        await supabase
          .from("knowledge_sources")
          .update({ content_status: "error" })
          .eq("id", source.id);
      }
    }

    return new Response(
      JSON.stringify({ loaded: loadedCount, total: sources.length }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("[knowledge-load-content] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
