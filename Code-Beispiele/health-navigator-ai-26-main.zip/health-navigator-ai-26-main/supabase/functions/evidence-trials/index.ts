import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TrialSearchRequest {
  query: string;
  conditions?: string[];
  interventions?: string[];
  status?: string[];
  phase?: string[];
  limit?: number;
  sessionId?: string;
}

interface ClinicalTrial {
  nctId: string;
  title: string;
  status: string;
  phase: string;
  conditions: string[];
  interventions: string[];
  sponsor: string;
  startDate: string | null;
  completionDate: string | null;
  enrollment: number | null;
  studyType: string;
  briefSummary: string;
  url: string;
}

interface TrialSearchResponse {
  trials: ClinicalTrial[];
  totalCount: number;
  query: string;
}

// ClinicalTrials.gov API v2 base URL
const CT_API_BASE = "https://clinicaltrials.gov/api/v2";

/**
 * Build search query for ClinicalTrials.gov API
 */
function buildSearchQuery(request: TrialSearchRequest): string {
  const parts: string[] = [];

  // Main query term
  if (request.query) {
    parts.push(request.query);
  }

  // Add conditions
  if (request.conditions && request.conditions.length > 0) {
    const conditionQuery = request.conditions
      .map((c) => `AREA[Condition]${c}`)
      .join(" OR ");
    if (conditionQuery) parts.push(`(${conditionQuery})`);
  }

  // Add interventions
  if (request.interventions && request.interventions.length > 0) {
    const interventionQuery = request.interventions
      .map((i) => `AREA[Intervention]${i}`)
      .join(" OR ");
    if (interventionQuery) parts.push(`(${interventionQuery})`);
  }

  return parts.join(" AND ") || "*";
}

/**
 * Map status filter to API format
 */
function mapStatusFilter(status: string[]): string[] {
  const statusMap: Record<string, string> = {
    recruiting: "RECRUITING",
    "not-recruiting": "NOT_YET_RECRUITING",
    completed: "COMPLETED",
    active: "ACTIVE_NOT_RECRUITING",
    terminated: "TERMINATED",
    suspended: "SUSPENDED",
    withdrawn: "WITHDRAWN",
  };

  return status.map((s) => statusMap[s.toLowerCase()] || s.toUpperCase());
}

/**
 * Search ClinicalTrials.gov studies
 */
async function searchTrials(request: TrialSearchRequest): Promise<TrialSearchResponse> {
  const query = buildSearchQuery(request);
  const limit = Math.min(request.limit || 10, 50);

  // Build API URL with parameters
  const params = new URLSearchParams({
    "query.term": query,
    pageSize: limit.toString(),
    format: "json",
    fields: [
      "NCTId",
      "BriefTitle",
      "OfficialTitle",
      "OverallStatus",
      "Phase",
      "Condition",
      "InterventionName",
      "LeadSponsorName",
      "StartDate",
      "PrimaryCompletionDate",
      "EnrollmentCount",
      "StudyType",
      "BriefSummary",
    ].join(","),
  });

  // Add status filter if specified
  if (request.status && request.status.length > 0) {
    const mappedStatus = mapStatusFilter(request.status);
    params.set("filter.overallStatus", mappedStatus.join(","));
  }

  // Add phase filter if specified
  if (request.phase && request.phase.length > 0) {
    params.set("filter.phase", request.phase.join(","));
  }

  const url = `${CT_API_BASE}/studies?${params.toString()}`;
  console.log("ClinicalTrials.gov API URL:", url);

  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error("ClinicalTrials.gov API error:", response.status, errorText);
    throw new Error(`ClinicalTrials.gov API error: ${response.status}`);
  }

  const data = await response.json();

  // Parse studies from response
  const trials: ClinicalTrial[] = (data.studies || []).map((study: any) => {
    const protocol = study.protocolSection || {};
    const identification = protocol.identificationModule || {};
    const status = protocol.statusModule || {};
    const design = protocol.designModule || {};
    const conditions = protocol.conditionsModule || {};
    const interventions = protocol.armsInterventionsModule || {};
    const sponsor = protocol.sponsorCollaboratorsModule || {};
    const description = protocol.descriptionModule || {};

    return {
      nctId: identification.nctId || "",
      title: identification.briefTitle || identification.officialTitle || "",
      status: status.overallStatus || "",
      phase: design.phases?.join(", ") || "N/A",
      conditions: conditions.conditions || [],
      interventions: (interventions.interventions || []).map((i: any) => i.name),
      sponsor: sponsor.leadSponsor?.name || "",
      startDate: status.startDateStruct?.date || null,
      completionDate: status.primaryCompletionDateStruct?.date || null,
      enrollment: design.enrollmentInfo?.count || null,
      studyType: design.studyType || "",
      briefSummary: description.briefSummary || "",
      url: `https://clinicaltrials.gov/study/${identification.nctId}`,
    };
  });

  return {
    trials,
    totalCount: data.totalCount || trials.length,
    query,
  };
}

/**
 * Get details for a specific trial by NCT ID
 */
async function getTrialDetails(nctId: string): Promise<ClinicalTrial | null> {
  const url = `${CT_API_BASE}/studies/${nctId}?format=json`;

  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
    },
  });

  if (!response.ok) {
    if (response.status === 404) {
      return null;
    }
    const errorText = await response.text();
    console.error("ClinicalTrials.gov API error:", response.status, errorText);
    throw new Error(`ClinicalTrials.gov API error: ${response.status}`);
  }

  const study = await response.json();
  const protocol = study.protocolSection || {};
  const identification = protocol.identificationModule || {};
  const status = protocol.statusModule || {};
  const design = protocol.designModule || {};
  const conditions = protocol.conditionsModule || {};
  const interventions = protocol.armsInterventionsModule || {};
  const sponsor = protocol.sponsorCollaboratorsModule || {};
  const description = protocol.descriptionModule || {};

  return {
    nctId: identification.nctId || "",
    title: identification.briefTitle || identification.officialTitle || "",
    status: status.overallStatus || "",
    phase: design.phases?.join(", ") || "N/A",
    conditions: conditions.conditions || [],
    interventions: (interventions.interventions || []).map((i: any) => i.name),
    sponsor: sponsor.leadSponsor?.name || "",
    startDate: status.startDateStruct?.date || null,
    completionDate: status.primaryCompletionDateStruct?.date || null,
    enrollment: design.enrollmentInfo?.count || null,
    studyType: design.studyType || "",
    briefSummary: description.briefSummary || "",
    url: `https://clinicaltrials.gov/study/${identification.nctId}`,
  };
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "search";

    // For GET requests with NCT ID
    if (req.method === "GET" && action === "details") {
      const nctId = url.searchParams.get("nctId");
      if (!nctId) {
        return new Response(
          JSON.stringify({ error: "nctId parameter required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const trial = await getTrialDetails(nctId);
      if (!trial) {
        return new Response(
          JSON.stringify({ error: "Trial not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(JSON.stringify(trial), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // For POST requests (search)
    if (req.method === "POST") {
      const authHeader = req.headers.get("Authorization");
      if (!authHeader) {
        return new Response(
          JSON.stringify({ error: "Missing authorization header" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

      const supabase = createClient(supabaseUrl, supabaseAnonKey, {
        global: { headers: { Authorization: authHeader } },
      });

      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) {
        return new Response(
          JSON.stringify({ error: "Unauthorized" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const body: TrialSearchRequest = await req.json();

      if (!body.query && (!body.conditions || body.conditions.length === 0)) {
        return new Response(
          JSON.stringify({ error: "query or conditions required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const result = await searchTrials(body);

      // If sessionId provided, store in evidence_requests for audit
      if (body.sessionId) {
        const { error: insertError } = await supabase.from("evidence_requests").insert({
          session_id: body.sessionId,
          query_context: {
            conditions: body.conditions,
            interventions: body.interventions,
            status: body.status,
            phase: body.phase,
          },
          query_strings: { clinicaltrials: body.query },
          sources: ["clinicaltrials.gov"],
        });

        if (insertError) {
          console.error("Error logging evidence request:", insertError);
        }
      }

      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // GET request for simple search
    if (req.method === "GET") {
      const query = url.searchParams.get("query") || "";
      const limit = parseInt(url.searchParams.get("limit") || "10", 10);
      const status = url.searchParams.get("status")?.split(",") || undefined;
      const phase = url.searchParams.get("phase")?.split(",") || undefined;

      const result = await searchTrials({ query, limit, status, phase });

      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Evidence-trials error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
