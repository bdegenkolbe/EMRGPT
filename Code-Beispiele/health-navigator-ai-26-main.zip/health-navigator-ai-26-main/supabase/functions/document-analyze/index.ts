import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import pdfParse from "npm:pdf-parse@1.1.1/lib/pdf-parse.js";
import { Buffer } from "node:buffer";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { documentId } = await req.json();
    if (!documentId) throw new Error("documentId required");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableKey = Deno.env.get("LOVABLE_API_KEY");
    if (!lovableKey) throw new Error("LOVABLE_API_KEY not configured");

    const supabase = createClient(supabaseUrl, serviceKey);

    const { data: doc, error: docErr } = await supabase
      .from("fhir_document_references")
      .select("*")
      .eq("id", documentId)
      .single();

    if (docErr || !doc) throw new Error("Document not found: " + docErr?.message);

    await supabase
      .from("fhir_document_references")
      .update({ analysis_status: "analyzing" })
      .eq("id", documentId);

    let extractedText = "";
    if (doc.storage_path) {
      const { data: fileData, error: dlErr } = await supabase.storage
        .from("patient-documents")
        .download(doc.storage_path);

      if (dlErr) {
        console.error("Download error:", dlErr);
        throw new Error("Could not download file");
      }

      const contentType = doc.content_type || "application/pdf";
      const arrayBuf = await fileData.arrayBuffer();
      const bytes = new Uint8Array(arrayBuf);

      console.log(`Processing file: type=${contentType}, size=${bytes.length} bytes`);

      if (contentType.startsWith("image/")) {
        extractedText = await extractTextFromImage(lovableKey, bytes, contentType);
      } else if (contentType === "application/pdf") {
        // Strategy 1: Native PDF text extraction
        extractedText = await extractPdfTextNative(bytes);
        console.log(`Native PDF extraction: ${extractedText.length} chars`);

        // Strategy 2: If native extraction is poor, use Vision API with page screenshots
        if (!extractedText || extractedText.trim().length < 50) {
          console.log("Native extraction insufficient, falling back to Vision API...");
          extractedText = await extractTextFromImage(lovableKey, bytes, contentType);
        }
      } else {
        // For other document types, try vision
        extractedText = await extractTextFromImage(lovableKey, bytes, contentType);
      }
    }

    if (!extractedText || extractedText.length < 20) {
      await supabase
        .from("fhir_document_references")
        .update({
          analysis_status: "error",
          analysis_result: { error: "Kein Text konnte extrahiert werden" },
        })
        .eq("id", documentId);
      return new Response(
        JSON.stringify({ error: "No text extracted" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const analysisResult = await analyzeDocument(lovableKey, extractedText, doc.description || "Arztbrief");

    await supabase
      .from("fhir_document_references")
      .update({
        analysis_status: "completed",
        analysis_result: analysisResult,
        extracted_text: extractedText.slice(0, 50000),
      })
      .eq("id", documentId);

    return new Response(
      JSON.stringify({ success: true, result: analysisResult }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("document-analyze error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function extractPdfTextNative(bytes: Uint8Array): Promise<string> {
  try {
    const data = await pdfParse(Buffer.from(bytes));
    const text = data.text || "";
    // Quality check: enough real text content?
    const letterCount = (text.match(/[a-zA-ZäöüÄÖÜß]/g) || []).length;
    console.log(`PDF native parse: ${text.length} chars, ${letterCount} letters, ${data.numpages} pages`);
    if (letterCount > 50) {
      return text;
    }
    return ""; // Likely scanned PDF without embedded text
  } catch (err) {
    console.error("PDF native parse error:", err);
    return "";
  }
}

function toBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

async function extractTextFromImage(apiKey: string, bytes: Uint8Array, contentType: string): Promise<string> {
  // For the vision API, we must use an image MIME type
  // If it's a PDF, we can't directly send it as image_url - this is a fallback for scanned PDFs
  const mimeType = contentType.startsWith("image/") ? contentType : "image/png";
  const base64 = toBase64(bytes);

  console.log(`Vision extraction: sending ${base64.length} base64 chars as ${mimeType}`);

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-3-flash-preview",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Extrahiere den gesamten Text aus diesem medizinischen Dokument/Bild. Gib den Text vollständig und strukturiert wieder, ohne Zusammenfassung. Behalte die Struktur bei (Überschriften, Absätze, Listen).",
            },
            {
              type: "image_url",
              image_url: { url: `data:${mimeType};base64,${base64}` },
            },
          ],
        },
      ],
    }),
  });

  if (!resp.ok) {
    const t = await resp.text();
    console.error("Vision extraction error:", resp.status, t);
    throw new Error("Vision extraction failed: " + resp.status);
  }

  const data = await resp.json();
  return data.choices?.[0]?.message?.content || "";
}

async function analyzeDocument(apiKey: string, text: string, title: string): Promise<Record<string, unknown>> {
  const systemPrompt = `Du bist ein klinischer Dokumentations-Assistent. Analysiere den folgenden Arztbrief/medizinischen Befund und extrahiere strukturierte Informationen.

Antworte AUSSCHLIESSLICH im folgenden JSON-Format (kein Markdown, kein Text drumherum):

{
  "abstract": "Kurze klinische Zusammenfassung (3-5 Sätze) mit Hauptdiagnose, wesentlichen Befunden und Therapieempfehlung",
  "structured_summary": {
    "anamnese": "Kurze Anamnese",
    "befund": "Wesentliche Befunde",
    "diagnosen": "Hauptdiagnosen",
    "therapie": "Therapie/Medikation",
    "procedere": "Weiteres Vorgehen/Empfehlungen"
  },
  "ontology_codes": {
    "icd10": [{"code": "E11.9", "display": "Diabetes mellitus Typ 2", "confidence": 0.95}],
    "snomed": [{"code": "73211009", "display": "Diabetes mellitus", "confidence": 0.90}],
    "hpo": [{"code": "HP:0000819", "display": "Diabetes mellitus", "confidence": 0.85}],
    "loinc": [{"code": "4548-4", "display": "HbA1c", "confidence": 0.90}],
    "ops": [{"code": "5-469.21", "display": "Koloskopie", "confidence": 0.80}]
  },
  "extracted_fhir": {
    "conditions": [
      {"code": "E11.9", "code_system": "http://fhir.de/CodeSystem/bfarm/icd-10-gm", "display": "Diabetes mellitus Typ 2", "clinical_status": "active", "onset_datetime": null}
    ],
    "medications": [
      {"code": null, "display": "Metformin 1000mg", "dosage_text": "1-0-1", "status": "active"}
    ],
    "allergies": [
      {"code": null, "display": "Penicillin", "category": "medication", "criticality": "high", "clinical_status": "active"}
    ],
    "observations": [
      {"loinc_code": "4548-4", "display": "HbA1c", "value": 7.2, "unit": "%", "effective_datetime": null}
    ],
    "procedures": [
      {"code": "5-469.21", "code_system": "http://fhir.de/CodeSystem/bfarm/ops", "display": "Koloskopie", "performed_datetime": null}
    ]
  }
}

Wichtige Regeln:
- Nur Informationen extrahieren, die TATSÄCHLICH im Text stehen
- Confidence-Werte realistisch einschätzen
- Leere Arrays wenn keine Daten vorhanden
- Datumswerte im ISO-Format wenn im Text erkennbar
- ICD-10-GM Codes bevorzugen (deutsche Version)
- Bei Medikamenten: Wirkstoff + Dosis + Schema wenn vorhanden`;

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-3-flash-preview",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Analysiere diesen Arztbrief "${title}":\n\n${text.slice(0, 30000)}` },
      ],
      temperature: 0.1,
    }),
  });

  if (!resp.ok) {
    if (resp.status === 429) throw new Error("Rate limit exceeded");
    if (resp.status === 402) throw new Error("Payment required");
    const t = await resp.text();
    console.error("Analysis error:", resp.status, t);
    throw new Error("Analysis failed");
  }

  const data = await resp.json();
  const content = data.choices?.[0]?.message?.content || "{}";

  let jsonStr = content;
  const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (jsonMatch) jsonStr = jsonMatch[1];
  jsonStr = jsonStr.trim();

  try {
    return JSON.parse(jsonStr);
  } catch {
    console.error("Failed to parse analysis JSON:", jsonStr.slice(0, 500));
    return {
      abstract: content,
      structured_summary: {},
      ontology_codes: {},
      extracted_fhir: { conditions: [], medications: [], allergies: [], observations: [], procedures: [] },
      parse_error: true,
    };
  }
}
