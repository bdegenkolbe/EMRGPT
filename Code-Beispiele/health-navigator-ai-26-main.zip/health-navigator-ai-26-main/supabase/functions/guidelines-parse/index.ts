import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { extractText, getDocumentProxy } from "https://esm.sh/unpdf@0.12.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ParseRequest {
  file_base64: string;
  file_name: string;
  file_size: number;
}

interface ExtractedMetadata {
  title?: string;
  description?: string;
  source?: string;
  version?: string;
  validFrom?: string;
  validUntil?: string;
  pageCount?: number;
  author?: string;
  keywords?: string[];
  textContent: string;
  icd10Codes?: string[];
  hpoCodes?: string[];
  snomedCodes?: string[];
}

// Extract metadata from text using AI
async function extractMetadataWithAI(
  textContent: string,
  fileName: string,
  apiKey: string,
  gatewayUrl: string,
  model: string
): Promise<Partial<ExtractedMetadata>> {
  const sampleText = textContent.slice(0, 3000);

  const systemPrompt = `Du bist ein Experte für medizinische Leitlinien. Analysiere den Text und extrahiere Metadaten.

EXTRAHIERE (falls vorhanden):
1. title: Offizieller Titel
2. description: Kurze Zusammenfassung (max 200 Zeichen)
3. source: Herausgebende Organisation (AWMF, DEGAM, DGK, etc.)
4. version: Version oder Datum
5. validFrom: Gültigkeitsbeginn (YYYY-MM-DD)
6. validUntil: Gültigkeitsende (YYYY-MM-DD)
7. author: Autoren/Fachgesellschaft
8. keywords: Medizinische Schlagworte (max 10)
9. icd10Codes: ICD-10 Codes (z.B. "F32.1", "I10")
10. hpoCodes: HPO Codes (z.B. "HP:0001250")
11. snomedCodes: SNOMED CT Codes (z.B. "73211009")

Antworte NUR mit einem JSON-Objekt.`;

  try {
    const response = await fetch(gatewayUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Dateiname: ${fileName}\n\nTextauszug:\n${sampleText}` },
        ],
        temperature: 0.2,
        max_tokens: 800,
      }),
    });

    if (!response.ok) {
      console.error("AI metadata extraction failed:", response.status);
      return { title: fileName.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ") };
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content?.trim() || "";

    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      let jsonStr = jsonMatch[0]
        .replace(/\\u(?![0-9a-fA-F]{4})/g, "\\\\u")
        .replace(/\\x[0-9a-fA-F]{2}/g, "")
        .replace(/[\x00-\x1f]/g, " ");
      return JSON.parse(jsonStr);
    }
  } catch (e) {
    console.error("Failed to parse AI metadata:", e);
  }

  return { title: fileName.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ") };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    const lovableKey = Deno.env.get("LOVABLE_API_KEY");
    const { file_base64, file_name, file_size }: ParseRequest = await req.json();

    if (!file_base64 || !file_name) {
      return new Response(
        JSON.stringify({ error: "file_base64 and file_name are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Parsing: ${file_name} (${file_size} bytes)`);

    // Decode base64
    const binaryString = atob(file_base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const isPdf = file_name.toLowerCase().endsWith(".pdf");
    let textContent = "";
    let pageCount = 1;

    if (isPdf) {
      // Use unpdf (Mozilla PDF.js) for proper text extraction
      try {
        console.log("Extracting text with unpdf (PDF.js)...");
        const pdf = await getDocumentProxy(bytes);
        const result = await extractText(pdf, { mergePages: true });
        textContent = result.text;
        pageCount = result.totalPages;
        console.log(`unpdf extracted ${textContent.length} chars from ${pageCount} pages`);
      } catch (e) {
        console.error("unpdf extraction failed:", e);
        // Fallback: just read as text
        textContent = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
      }

      if (textContent.length < 100) {
        console.warn("Text extraction yielded minimal content - PDF may be scanned/image-based");
      }
    } else {
      textContent = new TextDecoder("utf-8").decode(bytes);
    }

    // Extract metadata using AI
    let metadata: Partial<ExtractedMetadata> = {};

    const metaApiKey = lovableKey || openaiKey;
    if (metaApiKey && textContent.length > 50) {
      const gatewayUrl = lovableKey
        ? "https://ai.gateway.lovable.dev/v1/chat/completions"
        : "https://api.openai.com/v1/chat/completions";
      const model = lovableKey ? "google/gemini-2.5-flash" : "gpt-4o-mini";

      metadata = await extractMetadataWithAI(textContent, file_name, metaApiKey, gatewayUrl, model);
    } else {
      metadata = { title: file_name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ") };
    }

    const result: ExtractedMetadata = {
      ...metadata,
      pageCount,
      textContent,
    };

    console.log(`Done: title="${result.title}", ${textContent.length} chars`);

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("PDF parsing error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "PDF parsing failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
