import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ICD11Code {
  code: string;
  title: string;
  title_short?: string;
  definition?: string;
  chapter?: string;
  block?: string;
  category?: string;
  parent_code?: string;
  is_terminal: boolean;
  foundation_uri?: string;
  linearization_uri?: string;
  class_kind?: string;
  // Multilingual data from WHO API (en, fr)
  labels?: Record<string, string>;
  definitions?: Record<string, string>;
}

interface LookupRequest {
  action?: "search" | "lookup" | "children" | "chapters";
  q?: string;
  code?: string;
  parent?: string;
  limit?: number;
}

// WHO ICD-11 API configuration
const ICD11_API_BASE = "https://id.who.int/icd";
const TOKEN_ENDPOINT = "https://icdaccessmanagement.who.int/connect/token";
// Use latest release version (updated yearly)
const RELEASE_VERSION = "2025-01";

// Languages supported by WHO API that match our i18n system
// Our system: DE, EN, FR, IT
// API supports: ar, cs, en, es, fr, kk, la, pt, ru, sk, sv, tr, uz, zh
// Matching: EN, FR (DE and IT need AI translation)
const API_SUPPORTED_LANGUAGES = ["en", "fr"] as const;

// Cache token in memory (edge functions are short-lived, but this helps during a single invocation)
let cachedToken: { token: string; expires: number } | null = null;

async function getAccessToken(): Promise<string> {
  // Check if we have a valid cached token
  if (cachedToken && cachedToken.expires > Date.now()) {
    return cachedToken.token;
  }

  const clientId = Deno.env.get("ICD11_CLIENT_ID");
  const clientSecret = Deno.env.get("ICD11_CLIENT_SECRET");

  if (!clientId || !clientSecret) {
    throw new Error("ICD-11 API credentials not configured. Please add ICD11_CLIENT_ID and ICD11_CLIENT_SECRET secrets.");
  }

  const credentials = btoa(`${clientId}:${clientSecret}`);
  
  const response = await fetch(TOKEN_ENDPOINT, {
    method: "POST",
    headers: {
      "Authorization": `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=icdapi_access",
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Token request failed: ${response.status} - ${error}`);
  }

  const data = await response.json();
  
  // Cache token (subtract 60 seconds for safety margin)
  cachedToken = {
    token: data.access_token,
    expires: Date.now() + (data.expires_in - 60) * 1000,
  };

  return data.access_token;
}

async function icd11Request(endpoint: string, token: string, language = "en"): Promise<unknown> {
  const url = `${ICD11_API_BASE}${endpoint}`;
  console.log(`[ICD-11] Requesting (${language}): ${url}`);
  
  const response = await fetch(url, {
    headers: {
      "Authorization": `Bearer ${token}`,
      "Accept": "application/json",
      "Accept-Language": language,
      "API-Version": "v2",
    },
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`ICD-11 API error: ${response.status} - ${error}`);
  }

  return response.json();
}

// Fetch entity in multiple languages and merge labels/definitions
async function fetchMultilingualEntity(
  path: string, 
  token: string, 
  parentCode?: string
): Promise<ICD11Code> {
  // Fetch all supported languages in parallel
  const results = await Promise.all(
    API_SUPPORTED_LANGUAGES.map(async (lang) => {
      try {
        const data = await icd11Request(path, token, lang) as Record<string, unknown>;
        return { lang, data };
      } catch (err) {
        console.warn(`[ICD-11] Failed to fetch ${lang} for ${path}:`, err);
        return { lang, data: null };
      }
    })
  );

  // Use English as base
  const enResult = results.find(r => r.lang === "en");
  if (!enResult?.data) {
    throw new Error(`Failed to fetch English version for ${path}`);
  }

  const baseEntity = parseEntity(enResult.data, parentCode);
  
  // Build multilingual labels and definitions
  const labels: Record<string, string> = {};
  const definitions: Record<string, string> = {};

  for (const { lang, data } of results) {
    if (!data) continue;
    
    const title = (data.title as Record<string, string>)?.["@value"];
    const definition = (data.definition as Record<string, string>)?.["@value"];
    
    if (title) labels[lang] = title;
    if (definition) definitions[lang] = definition;
  }

  return {
    ...baseEntity,
    labels: Object.keys(labels).length > 0 ? labels : undefined,
    definitions: Object.keys(definitions).length > 0 ? definitions : undefined,
  };
}

// Parse ICD-11 entity response into our format
function parseEntity(data: Record<string, unknown>, parentCode?: string): ICD11Code {
  const code = (data.code as string) || (data.codeRange as string) || extractCodeFromUri(data["@id"] as string);
  const title = (data.title as Record<string, string>)?.["@value"] || "";
  const definition = (data.definition as Record<string, string>)?.["@value"];
  
  return {
    code,
    title,
    title_short: title.length > 100 ? title.substring(0, 97) + "..." : undefined,
    definition,
    parent_code: parentCode,
    is_terminal: !(data.child as unknown[])?.length,
    foundation_uri: data.foundationChildElsewhere as string,
    linearization_uri: data["@id"] as string,
    class_kind: data.classKind as string,
  };
}

function extractCodeFromUri(uri: string): string {
  // Extract code from URI like http://id.who.int/icd/release/11/2024-01/mms/1435254666
  const match = uri?.match(/\/mms\/(\d+)$/);
  return match ? match[1] : uri?.split("/").pop() || "";
}

// Normalize URI to use current release version and extract path only
function normalizeUriToPath(uri: string): string {
  if (!uri) return uri;
  // Remove the base URL (handles both http and https)
  const path = uri.replace(/^https?:\/\/id\.who\.int\/icd/, "");
  // Replace any release version with current one
  return path.replace(/\/release\/11\/[\d-]+\//, `/release/11/${RELEASE_VERSION}/`);
}

// Persist codes to database with multilingual data
async function persistCodes(supabase: ReturnType<typeof createClient>, codes: ICD11Code[]): Promise<void> {
  if (codes.length === 0) return;
  
  for (const code of codes) {
    const { error } = await supabase.from("icd11_codes").upsert({
      code: code.code,
      title: code.title,
      title_short: code.title_short,
      definition: code.definition,
      parent_code: code.parent_code,
      is_terminal: code.is_terminal,
      foundation_uri: code.foundation_uri,
      linearization_uri: code.linearization_uri,
      class_kind: code.class_kind,
      // Store multilingual data from API
      labels: code.labels || null,
      definitions: code.definitions || null,
    }, { onConflict: "code" });
    
    if (error) {
      console.error(`[ICD-11 Persist] Error for ${code.code}:`, error.message);
    }
  }
  console.log(`[ICD-11 Persist] Saved ${codes.length} codes with multilingual data`);
}

// Get ICD-11 chapters (top-level structure) with multilingual data
async function getChapters(token: string, supabase: ReturnType<typeof createClient>): Promise<ICD11Code[]> {
  // Use MMS linearization for clinical use
  const data = await icd11Request(`/release/11/${RELEASE_VERSION}/mms`, token) as Record<string, unknown>;
  const children = data.child as string[] || [];
  
  const chapters: ICD11Code[] = [];
  
  // Fetch each chapter with multilingual data
  for (const childUri of children.slice(0, 30)) { // Limit for performance
    try {
      const path = normalizeUriToPath(childUri);
      const chapter = await fetchMultilingualEntity(path, token);
      chapter.linearization_uri = childUri;
      chapters.push(chapter);
    } catch (err) {
      console.error(`Error fetching chapter ${childUri}:`, err);
    }
  }
  
  // Persist chapters with multilingual data
  await persistCodes(supabase, chapters);
  
  return chapters;
}

// Search ICD-11 codes
async function searchCodes(token: string, supabase: ReturnType<typeof createClient>, query: string, limit = 20): Promise<ICD11Code[]> {
  // Use the search endpoint
  const encodedQuery = encodeURIComponent(query);
  const data = await icd11Request(
    `/release/11/${RELEASE_VERSION}/mms/search?q=${encodedQuery}&subtreeFilterUsesFoundationDescendants=false&includeKeywordResult=true&chapterFilter=&flexiSearch=true&flatResults=true&propertiesToBeSearched=Title,Definition,FullySpecifiedName&highlightingEnabled=false`,
    token
  ) as Record<string, unknown>;
  
  const results = (data.destinationEntities as unknown[] || []).slice(0, limit);
  
  const codes = results.map((item: Record<string, unknown>) => ({
    code: item.theCode as string || extractCodeFromUri(item.id as string),
    title: (item.title as string) || "",
    is_terminal: item.isLeaf as boolean || false,
    linearization_uri: item.id as string,
  }));
  
  // Persist search results to database
  await persistCodes(supabase, codes);
  
  return codes;
}

// Get children of a code with multilingual data - accepts code OR URI
async function getChildren(token: string, supabase: ReturnType<typeof createClient>, parentCodeOrUri: string): Promise<ICD11Code[]> {
  let path: string;
  
  // Check if it's a URI or just a code
  if (parentCodeOrUri.startsWith("http")) {
    path = normalizeUriToPath(parentCodeOrUri);
  } else {
    // It's a code - first look up the URI from the database or search
    const { data: dbCode } = await supabase
      .from("icd11_codes")
      .select("linearization_uri")
      .eq("code", parentCodeOrUri)
      .maybeSingle();
    
    if (dbCode?.linearization_uri) {
      path = normalizeUriToPath(dbCode.linearization_uri);
    } else {
      // Search for the code to get URI
      const searchResult = await searchCodes(token, supabase, parentCodeOrUri, 5);
      const match = searchResult.find(r => r.code === parentCodeOrUri);
      if (match?.linearization_uri) {
        path = normalizeUriToPath(match.linearization_uri);
      } else {
        console.error(`[ICD-11] Could not find URI for code: ${parentCodeOrUri}`);
        return [];
      }
    }
  }
  
  const data = await icd11Request(path, token) as Record<string, unknown>;
  const children = data.child as string[] || [];
  const parentCode = (data.code as string) || extractCodeFromUri(data["@id"] as string);
  
  const result: ICD11Code[] = [];
  
  // Fetch children with multilingual data
  for (const childUri of children) {
    try {
      const childPath = normalizeUriToPath(childUri);
      const child = await fetchMultilingualEntity(childPath, token, parentCode);
      child.linearization_uri = childUri;
      result.push(child);
    } catch (err) {
      console.error(`Error fetching child ${childUri}:`, err);
    }
  }
  
  // Persist children with multilingual data
  await persistCodes(supabase, result);
  
  return result;
}

// Lookup specific code
async function lookupCode(token: string, supabase: ReturnType<typeof createClient>, code: string): Promise<ICD11Code | null> {
  try {
    // Search by code first
    const searchResult = await searchCodes(token, supabase, code, 5);
    const match = searchResult.find(r => r.code === code);
    
    if (match && match.linearization_uri) {
      const path = normalizeUriToPath(match.linearization_uri);
      const data = await icd11Request(path, token) as Record<string, unknown>;
      const codeData = parseEntity(data);
      codeData.linearization_uri = match.linearization_uri;
      
      // Persist to database
      await persistCodes(supabase, [codeData]);
      
      return codeData;
    }
    
    return match || null;
  } catch (err) {
    console.error(`Error looking up code ${code}:`, err);
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Merge URL params and body for flexibility
    const url = new URL(req.url);
    const urlParams = Object.fromEntries(url.searchParams);
    
    let bodyParams: LookupRequest = {};
    if (req.method === "POST") {
      bodyParams = await req.json().catch(() => ({}));
    }
    
    const params: LookupRequest = { ...urlParams, ...bodyParams };
    const { action = "search", q, code, parent, limit = 20 } = params;

    // Get OAuth token
    let token: string;
    try {
      token = await getAccessToken();
    } catch (tokenError) {
      // Return helpful error for missing credentials
      return new Response(
        JSON.stringify({ 
          error: "ICD-11 API not configured", 
          message: tokenError.message,
          help: "Register at https://icd.who.int/icdapi to get API credentials"
        }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    let result: unknown;

    switch (action) {
      case "chapters": {
        result = await getChapters(token, supabase);
        break;
      }
      
      case "search": {
        if (!q || q.length < 2) {
          return new Response(
            JSON.stringify({ error: "Query must be at least 2 characters" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await searchCodes(token, supabase, q, Number(limit));
        break;
      }
      
      case "lookup": {
        if (!code) {
          return new Response(
            JSON.stringify({ error: "Code is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await lookupCode(token, supabase, code);
        break;
      }
      
      case "children": {
        if (!parent) {
          return new Response(
            JSON.stringify({ error: "Parent code or URI is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await getChildren(token, supabase, parent);
        break;
      }
      
      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${action}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }

    return new Response(
      JSON.stringify({ success: true, data: result }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("ICD-11 lookup error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
