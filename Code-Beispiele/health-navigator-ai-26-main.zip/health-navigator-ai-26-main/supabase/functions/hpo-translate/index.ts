import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface HPOTermInput {
  id: string;
  label_en: string;
  definition?: string;
}

interface TranslationResult {
  hpo_code: string;
  label_en: string;
  label_de: string;
  definition_de?: string;
  source: "official" | "ai_translated";
  confidence: number;
}

async function translateWithAI(
  terms: HPOTermInput[],
  apiKey: string
): Promise<TranslationResult[]> {
  const prompt = `Du bist ein medizinischer Übersetzer für die Human Phenotype Ontology (HPO).
Übersetze die folgenden englischen HPO-Begriffe ins Deutsche.
Verwende korrekte deutsche medizinische Fachterminologie.
Die Übersetzungen müssen präzise, klinisch korrekt und konsistent sein.

Begriffe zur Übersetzung:
${terms.map((t) => `- ${t.id}: "${t.label_en}"${t.definition ? ` (Definition: ${t.definition.slice(0, 200)})` : ""}`).join("\n")}

Antworte NUR mit einem JSON-Array in diesem Format:
[
  {"hpo_code": "HP:XXXXXXX", "label_de": "Deutsche Übersetzung", "confidence": 0.95}
]`;

  const openaiKey = apiKey || Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");

  let response: Response;
  let usedProvider = "openai";

  if (openaiKey) {
    response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "Du bist ein Experte für medizinische Terminologie und HPO-Übersetzungen.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 2000,
      }),
    });
  } else if (lovableKey) {
    usedProvider = "lovable-gateway";
    response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: "Du bist ein Experte für medizinische Terminologie und HPO-Übersetzungen.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 2000,
      }),
    });
  } else {
    throw new Error("No AI API key configured");
  }

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`AI API error (${usedProvider}):`, response.status, errorText);
    throw new Error(`AI translation failed: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";

  const jsonMatch = content.match(/\[[\s\S]*\]/);
  if (!jsonMatch) {
    console.error("Could not parse AI response:", content);
    throw new Error("Invalid AI response format");
  }

  const translations: Array<{ hpo_code: string; label_de: string; confidence?: number }> =
    JSON.parse(jsonMatch[0]);

  return translations.map((t) => {
    const originalTerm = terms.find((term) => term.id === t.hpo_code);
    return {
      hpo_code: t.hpo_code,
      label_en: originalTerm?.label_en || "",
      label_de: t.label_de,
      source: "ai_translated" as const,
      confidence: t.confidence || 0.9,
    };
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const { terms }: { terms: HPOTermInput[] } = await req.json();

    if (!terms || !Array.isArray(terms) || terms.length === 0) {
      return new Response(JSON.stringify({ error: "No terms provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const MAX_BATCH_SIZE = 20;
    const termsToProcess = terms.slice(0, MAX_BATCH_SIZE);

    console.log(`Processing ${termsToProcess.length} terms for translation`);

    // Check hpo_codes table for existing translations in JSONB labels
    const hpoCodes = termsToProcess.map((t) => t.id);
    const { data: existingCodes, error: lookupError } = await supabaseAdmin
      .from("hpo_codes")
      .select("hpo_code, labels, definitions, explanations")
      .in("hpo_code", hpoCodes);

    if (lookupError) {
      console.error("HPO codes lookup error:", lookupError);
    }

    // Find codes with valid German translations
    const cachedMap = new Map<string, TranslationResult>();
    for (const code of existingCodes || []) {
      const labelDe = code.labels?.de;
      const labelEn = code.labels?.en;
      if (labelDe && labelDe !== labelEn) {
        cachedMap.set(code.hpo_code, {
          hpo_code: code.hpo_code,
          label_en: labelEn || "",
          label_de: labelDe,
          definition_de: code.definitions?.de,
          source: "official",
          confidence: 1.0,
        });
      }
    }

    // Find terms that need translation
    const toTranslate = termsToProcess.filter((t) => !cachedMap.has(t.id));

    console.log(`Found ${cachedMap.size} cached, ${toTranslate.length} need translation`);

    let newTranslations: TranslationResult[] = [];

    if (toTranslate.length > 0) {
      try {
        newTranslations = await translateWithAI(toTranslate, "");

        // Upsert hpo_codes table with new translations (creates if not exists)
        for (const t of newTranslations) {
          const existingCode = existingCodes?.find((c) => c.hpo_code === t.hpo_code);
          const currentLabels = existingCode?.labels || {};
          const currentDefinitions = existingCode?.definitions || {};
          const originalTerm = terms.find((term) => term.id === t.hpo_code);

          const { error: upsertError } = await supabaseAdmin
            .from("hpo_codes")
            .upsert({
              hpo_code: t.hpo_code,
              label: originalTerm?.label_en || t.label_en,
              labels: { ...currentLabels, de: t.label_de, en: t.label_en },
              definitions: currentDefinitions,
              source: existingCode?.source || 'hpo-translate',
            }, { onConflict: "hpo_code" });

          if (upsertError) {
            console.error(`Error upserting HPO code ${t.hpo_code}:`, upsertError);
          }
        }

        console.log(`Upserted ${newTranslations.length} HPO codes with translations`);
      } catch (aiError) {
        console.error("AI translation error:", aiError);
      }
    }

    // Combine results
    const allTranslations: TranslationResult[] = termsToProcess.map((term) => {
      const cached = cachedMap.get(term.id);
      if (cached) return cached;

      const translated = newTranslations.find((t) => t.hpo_code === term.id);
      if (translated) return translated;

      // Fallback: return original English
      return {
        hpo_code: term.id,
        label_en: term.label_en,
        label_de: term.label_en,
        source: "official" as const,
        confidence: 0,
      };
    });

    return new Response(JSON.stringify({ translations: allTranslations }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("hpo-translate error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
