import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SOURCE_NAME = "orphanet";

// Static Orphanet root classifications - API requires registration so we use static data
const ORPHANET_ROOT_CLASSIFICATIONS = [
  { orphaCode: "557", name: "Rare genetic disease", nameDE: "Seltene genetische Erkrankung", classification: "Group" },
  { orphaCode: "68367", name: "Rare developmental defect during embryogenesis", nameDE: "Seltener Entwicklungsdefekt während der Embryogenese", classification: "Group" },
  { orphaCode: "101435", name: "Rare immune disease", nameDE: "Seltene Immunerkrankung", classification: "Group" },
  { orphaCode: "182222", name: "Rare hepatic disease", nameDE: "Seltene Lebererkrankung", classification: "Group" },
  { orphaCode: "68340", name: "Rare cardiac disease", nameDE: "Seltene Herzerkrankung", classification: "Group" },
  { orphaCode: "68347", name: "Rare gastroenterologic disease", nameDE: "Seltene gastroenterologische Erkrankung", classification: "Group" },
  { orphaCode: "68361", name: "Rare skin disease", nameDE: "Seltene Hauterkrankung", classification: "Group" },
  { orphaCode: "156638", name: "Rare bone disease", nameDE: "Seltene Knochenerkrankung", classification: "Group" },
  { orphaCode: "156638", name: "Rare connective tissue disease", nameDE: "Seltene Bindegewebserkrankung", classification: "Group" },
  { orphaCode: "71859", name: "Rare respiratory disease", nameDE: "Seltene Atemwegserkrankung", classification: "Group" },
  { orphaCode: "68366", name: "Rare renal disease", nameDE: "Seltene Nierenerkrankung", classification: "Group" },
  { orphaCode: "98027", name: "Rare systemic or rheumatologic disease", nameDE: "Seltene systemische oder rheumatologische Erkrankung", classification: "Group" },
  { orphaCode: "156610", name: "Rare neurological disease", nameDE: "Seltene neurologische Erkrankung", classification: "Group" },
  { orphaCode: "101997", name: "Rare eye disease", nameDE: "Seltene Augenerkrankung", classification: "Group" },
  { orphaCode: "98007", name: "Rare circulatory system disease", nameDE: "Seltene Erkrankung des Kreislaufsystems", classification: "Group" },
  { orphaCode: "98006", name: "Rare hematologic disease", nameDE: "Seltene hämatologische Erkrankung", classification: "Group" },
  { orphaCode: "97987", name: "Rare neoplastic disease", nameDE: "Seltene neoplastische Erkrankung", classification: "Group" },
  { orphaCode: "156629", name: "Rare endocrine disease", nameDE: "Seltene endokrine Erkrankung", classification: "Group" },
  { orphaCode: "163587", name: "Rare otorhinolaryngologic disease", nameDE: "Seltene HNO-Erkrankung", classification: "Group" },
  { orphaCode: "182073", name: "Rare infertility", nameDE: "Seltene Unfruchtbarkeit", classification: "Group" },
  { orphaCode: "182220", name: "Rare urogenital disease", nameDE: "Seltene urogenitale Erkrankung", classification: "Group" },
];

function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(supabaseUrl, supabaseKey);
}

interface OrphanetEntry {
  orphaCode: string;
  name: string;
  nameDE?: string;
  definition?: string;
  classification?: string;
  isTerminal?: boolean;
  parentCode?: string;
}

/**
 * Persist Orphanet entries to database
 */
async function persistOrphanetEntries(supabase: any, entries: OrphanetEntry[]): Promise<number> {
  if (entries.length === 0) return 0;

  const codesToInsert = entries.map((e) => ({
    orpha_code: e.orphaCode,
    name: e.nameDE || e.name,
    definition: e.definition || null,
    classification: e.classification || "Disorder",
    is_terminal: e.isTerminal ?? false,
    parent_code: e.parentCode || null,
    labels: { 
      en: e.name,
      de: e.nameDE || e.name,
    },
    source: "static_bulk_sync",
  }));

  const { error } = await supabase
    .from("orphanet_codes")
    .upsert(codesToInsert, { onConflict: "orpha_code" });

  if (error) {
    console.error("[Orphanet Sync] Persist error:", error);
    return 0;
  }

  return entries.length;
}

/**
 * Get or create sync status
 */
async function getSyncStatus(supabase: any) {
  const { data } = await supabase
    .from("sync_status")
    .select("*")
    .eq("source_name", SOURCE_NAME)
    .maybeSingle();
  
  return data;
}

/**
 * Update sync status
 */
async function updateSyncStatus(supabase: any, updates: Record<string, any>) {
  await supabase
    .from("sync_status")
    .upsert({
      source_name: SOURCE_NAME,
      ...updates,
      updated_at: new Date().toISOString(),
    }, { onConflict: "source_name" });
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = getSupabaseAdmin();

  try {
    const body = await req.json();
    const action = body.action || "sync_page";

    switch (action) {
      case "init": {
        await updateSyncStatus(supabase, {
          status: "running",
          total_synced: 0,
          total_available: ORPHANET_ROOT_CLASSIFICATIONS.length,
          last_cursor: "0",
          error_message: null,
          started_at: new Date().toISOString(),
          completed_at: null,
        });

        return new Response(
          JSON.stringify({ success: true, message: "Sync initialized", totalClassifications: ORPHANET_ROOT_CLASSIFICATIONS.length }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "sync_page": {
        const status = await getSyncStatus(supabase);
        const currentIndex = parseInt(status?.last_cursor || "0", 10);

        // Since ORPHAcode API requires registration, we sync static classifications
        // In a real implementation, this would paginate through the API
        const batchSize = 10;
        const batch = ORPHANET_ROOT_CLASSIFICATIONS.slice(currentIndex, currentIndex + batchSize);

        const entries: OrphanetEntry[] = batch.map((c) => ({
          orphaCode: c.orphaCode,
          name: c.name,
          nameDE: c.nameDE,
          classification: c.classification,
          isTerminal: false,
        }));

        const synced = await persistOrphanetEntries(supabase, entries);

        const newTotalSynced = (status?.total_synced || 0) + synced;
        const nextIndex = currentIndex + batchSize;
        const hasMore = nextIndex < ORPHANET_ROOT_CLASSIFICATIONS.length;

        await updateSyncStatus(supabase, {
          status: hasMore ? "running" : "completed",
          total_synced: newTotalSynced,
          last_cursor: String(nextIndex),
          completed_at: hasMore ? null : new Date().toISOString(),
        });

        console.log(`[Orphanet Sync] Synced ${synced} entries. Total: ${newTotalSynced}/${ORPHANET_ROOT_CLASSIFICATIONS.length}`);

        return new Response(
          JSON.stringify({
            hasMore,
            syncedCount: synced,
            totalSynced: newTotalSynced,
            totalAvailable: ORPHANET_ROOT_CLASSIFICATIONS.length,
            note: "Using static classifications. Full API sync requires ORPHAcode API registration.",
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "pause": {
        await updateSyncStatus(supabase, { status: "paused" });
        return new Response(
          JSON.stringify({ success: true, message: "Sync paused" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "reset": {
        await updateSyncStatus(supabase, {
          status: "pending",
          total_synced: 0,
          total_available: null,
          last_cursor: null,
          error_message: null,
          started_at: null,
          completed_at: null,
        });
        return new Response(
          JSON.stringify({ success: true, message: "Sync reset" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "status": {
        const status = await getSyncStatus(supabase);
        return new Response(
          JSON.stringify(status || { status: "pending", total_synced: 0 }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${action}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error: any) {
    console.error("[Orphanet Sync] Error:", error);

    await updateSyncStatus(supabase, {
      status: "error",
      error_message: error.message,
    });

    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
