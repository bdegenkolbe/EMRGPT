import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface FhirSource {
  name: string;
  label: string;
  baseUrl: string;
}

const SOURCES: FhirSource[] = [
  {
    name: "smart",
    label: "SMART Health IT",
    baseUrl: "https://r4.smarthealthit.org",
  },
  {
    name: "hapi",
    label: "HAPI FHIR (Synthea)",
    baseUrl: "https://hapi.fhir.org/baseR4",
  },
];

async function fetchWithTimeout(url: string, timeoutMs = 20000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchPatientEverything(baseUrl: string, patientId: string): Promise<any[]> {
  try {
    const url = `${baseUrl}/Patient/${patientId}/$everything?_count=200`;
    console.log(`  $everything for ${patientId}`);
    const res = await fetchWithTimeout(url, 15000);
    if (!res.ok) {
      const body = await res.text();
      console.warn(`  $everything failed (${res.status}): ${body.slice(0, 200)}`);
      return [];
    }
    const bundle = await res.json();
    return (bundle.entry || []).map((e: any) => e.resource).filter(Boolean);
  } catch (err) {
    console.warn(`  $everything error for ${patientId}: ${err.message}`);
    return [];
  }
}

function isRealPatient(p: any): boolean {
  const name = (p.name || [])[0] || {};
  const family = name.family || "";
  const given = ((name.given || []) as string[]).join(" ");
  // Filter out obviously fake/test names (random strings, too short, etc.)
  if (!family || family.length < 2 || !given || given.length < 2) return false;
  // Filter random strings (many uppercase, no vowels pattern)
  if (/^Family\s/.test(family)) return false;
  if (/^[A-Z][a-z]{15,}$/.test(family)) return false;
  // Must have a birth date
  if (!p.birthDate) return false;
  return true;
}

async function fetchPatientsFromSource(source: FhirSource, count: number): Promise<any> {
  console.log(`Fetching from ${source.name}: ${source.baseUrl}`);

  // Fetch more patients than needed so we can filter
  const fetchCount = Math.min(count * 3, 50);
  const patientUrl = `${source.baseUrl}/Patient?_count=${fetchCount}&_sort=-_lastUpdated`;
  const patientRes = await fetchWithTimeout(patientUrl);
  if (!patientRes.ok) {
    throw new Error(`${source.name} Patient fetch failed: ${patientRes.status}`);
  }
  const patientBundle = await patientRes.json();
  
  let patients = (patientBundle.entry || [])
    .map((e: any) => e.resource)
    .filter((r: any) => r?.resourceType === "Patient");

  // For HAPI, filter real-looking patients
  if (source.name === "hapi") {
    patients = patients.filter(isRealPatient);
  }

  patients = patients.slice(0, count);

  if (patients.length === 0) {
    throw new Error(`${source.name}: Keine brauchbaren Patienten gefunden`);
  }

  console.log(`  Found ${patients.length} usable patients, fetching $everything...`);

  // Use $everything to get complete data per patient
  const allEntries: any[] = [];
  
  for (const patient of patients) {
    // Add patient itself
    allEntries.push({
      resource: patient,
      fullUrl: `${source.baseUrl}/Patient/${patient.id}`,
    });

    // Fetch all related resources via $everything
    const resources = await fetchPatientEverything(source.baseUrl, patient.id);
    
    for (const r of resources) {
      if (r.resourceType === "Patient") continue; // Already added
      allEntries.push({
        resource: r,
        fullUrl: `${source.baseUrl}/${r.resourceType}/${r.id}`,
      });
    }

    // Small delay to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 200));
  }

  // Count resource types for logging
  const typeCounts: Record<string, number> = {};
  for (const e of allEntries) {
    const t = e.resource.resourceType;
    typeCounts[t] = (typeCounts[t] || 0) + 1;
  }
  console.log(`  Total: ${allEntries.length} resources`, JSON.stringify(typeCounts));

  return {
    resourceType: "Bundle",
    type: "collection",
    entry: allEntries,
    meta: { source: source.name, label: source.label },
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { sources: requestedSources, count = 5 } = await req.json().catch(() => ({}));
    
    const sourcesToFetch = requestedSources?.length
      ? SOURCES.filter((s) => requestedSources.includes(s.name))
      : SOURCES;

    if (sourcesToFetch.length === 0) {
      return new Response(
        JSON.stringify({ error: "No valid sources. Available: smart, hapi" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const results: any[] = [];
    const errors: string[] = [];

    for (const source of sourcesToFetch) {
      try {
        const bundle = await fetchPatientsFromSource(source, Math.min(count, 10));
        const patientCount = bundle.entry.filter((e: any) => e.resource?.resourceType === "Patient").length;
        results.push({
          source: source.name,
          label: source.label,
          bundle,
          patientCount,
          resourceCount: bundle.entry.length,
        });
      } catch (err) {
        console.error(`Error fetching from ${source.name}:`, err);
        errors.push(`${source.label}: ${err.message}`);
      }
    }

    return new Response(
      JSON.stringify({ results, errors }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Demo data error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
