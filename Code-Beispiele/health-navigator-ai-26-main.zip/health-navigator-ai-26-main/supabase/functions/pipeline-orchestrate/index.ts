import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface OrchestrationRequest {
  user_input: string;
  session_id?: string;
  clinical_view?: string;
  conversation_history?: string;
  force_domain?: string; // Optional: skip domain classification
}

interface PromptTemplate {
  id: string;
  name: string;
  phase: string;
  system_prompt: string;
  user_prompt_template: string | null;
  model_config: {
    model: string;
    temperature: number;
    max_tokens: number;
  };
}

interface Pipeline {
  id: string;
  name: string;
  slug: string;
  phase_order: string[];
  domain_id: string;
}

interface PipelineDomain {
  id: string;
  slug: string;
  name: string;
}

interface PhaseResult {
  phase: string;
  output: unknown;
  latency_ms: number;
  prompt_tokens?: number;
  completion_tokens?: number;
  raw_content?: string;
}

// Render template with parameters
function renderTemplate(template: string, params: Record<string, string>): string {
  let result = template;
  for (const [key, value] of Object.entries(params)) {
    result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value || '');
  }
  return result;
}

// Call AI model via Lovable Gateway
async function callAI(
  systemPrompt: string,
  userPrompt: string,
  modelConfig: { model: string; temperature: number; max_tokens: number },
  apiKey: string
): Promise<{ content: string; prompt_tokens?: number; completion_tokens?: number }> {
  const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: modelConfig.model || "google/gemini-3-flash-preview",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: modelConfig.temperature || 0.3,
      max_tokens: modelConfig.max_tokens || 2000,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`AI Gateway error ${response.status}: ${errorText}`);
  }

  const data = await response.json();
  return {
    content: data.choices?.[0]?.message?.content || "",
    prompt_tokens: data.usage?.prompt_tokens,
    completion_tokens: data.usage?.completion_tokens,
  };
}

// Parse JSON from AI response (handles markdown code blocks)
function parseJsonResponse(content: string): unknown {
  // Try to extract JSON from markdown code block
  const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
  const jsonString = jsonMatch ? jsonMatch[1].trim() : content.trim();
  
  try {
    return JSON.parse(jsonString);
  } catch {
    // Return raw content if not valid JSON
    return { raw_response: content };
  }
}

// Execute a single pipeline phase
async function executePhase(
  phase: string,
  pipeline: Pipeline,
  phaseContext: Record<string, unknown>,
  executionId: string,
  supabase: ReturnType<typeof createClient>,
  apiKey: string
): Promise<PhaseResult | null> {
  // Get active template for this phase
  const { data: template } = await supabase
    .from("prompt_templates")
    .select("*")
    .eq("pipeline_id", pipeline.id)
    .eq("phase", phase)
    .eq("is_active", true)
    .single();

  if (!template) {
    console.log(`[Pipeline] No template found for phase ${phase}, skipping`);
    return null;
  }

  console.log(`[Pipeline] Executing Phase ${phase}: ${template.name}`);
  
  const phaseStart = Date.now();

  // Log phase start
  const { data: phaseLog } = await supabase
    .from("pipeline_phase_logs")
    .insert({
      execution_id: executionId,
      phase,
      template_id: template.id,
      input_data: phaseContext,
      status: "running",
    })
    .select()
    .single();

  try {
    // Render prompts with context
    const systemPrompt = renderTemplate(
      template.system_prompt,
      phaseContext as Record<string, string>
    );
    
    const userPrompt = renderTemplate(
      template.user_prompt_template || "{{USER_INPUT}}",
      phaseContext as Record<string, string>
    );

    const aiResult = await callAI(
      systemPrompt,
      userPrompt,
      template.model_config,
      apiKey
    );

    const parsed = parseJsonResponse(aiResult.content);
    const latencyMs = Date.now() - phaseStart;

    // Update phase log
    await supabase
      .from("pipeline_phase_logs")
      .update({
        status: "completed",
        output_data: parsed,
        latency_ms: latencyMs,
        prompt_tokens: aiResult.prompt_tokens || 0,
        completion_tokens: aiResult.completion_tokens || 0,
        completed_at: new Date().toISOString(),
      })
      .eq("id", phaseLog?.id);

    console.log(`[Pipeline] Phase ${phase} completed in ${latencyMs}ms`);

    return {
      phase,
      output: parsed,
      latency_ms: latencyMs,
      prompt_tokens: aiResult.prompt_tokens,
      completion_tokens: aiResult.completion_tokens,
      raw_content: aiResult.content,
    };

  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    
    await supabase
      .from("pipeline_phase_logs")
      .update({
        status: "failed",
        error_message: errorMsg,
        completed_at: new Date().toISOString(),
      })
      .eq("id", phaseLog?.id);

    console.error(`[Pipeline] Phase ${phase} failed:`, errorMsg);
    throw err;
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  let executionId: string | null = null;
  
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");

    if (!lovableApiKey) {
      throw new Error("LOVABLE_API_KEY not configured");
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const body: OrchestrationRequest = await req.json();

    const { 
      user_input, 
      session_id, 
      clinical_view = "hausarztpraxis",
      conversation_history = "",
      force_domain 
    } = body;

    if (!user_input) {
      return new Response(
        JSON.stringify({ error: "user_input is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[Pipeline] Starting orchestration for input: "${user_input.slice(0, 100)}..."`);

    // Create execution record
    const { data: execution, error: execError } = await supabase
      .from("pipeline_executions")
      .insert({
        session_id: session_id || null,
        input_data: { user_input, clinical_view, conversation_history },
        status: "running",
        domain: force_domain || "PENDING",
      })
      .select()
      .single();

    if (execError) {
      console.error("Failed to create execution record:", execError);
      throw execError;
    }
    executionId = execution.id;

    const phaseResults: PhaseResult[] = [];
    let currentDomain = force_domain || "MEDICAL"; // Default fallback
    let selectedPipeline: Pipeline | null = null;

    // ========== PHASE -1: Domain Classification (if not forced) ==========
    if (!force_domain) {
      const { data: domainTemplate } = await supabase
        .from("prompt_templates")
        .select("*")
        .eq("phase", "-1")
        .eq("is_active", true)
        .single();

      if (domainTemplate) {
        console.log("[Pipeline] Executing Phase -1: Domain Classification");
        
        const phaseStart = Date.now();
        
        // Log phase start
        const { data: phaseLog } = await supabase
          .from("pipeline_phase_logs")
          .insert({
            execution_id: executionId,
            phase: "-1",
            template_id: domainTemplate.id,
            input_data: { user_input },
            status: "running",
          })
          .select()
          .single();

        try {
          const userPrompt = renderTemplate(
            domainTemplate.user_prompt_template || "{{USER_INPUT}}",
            { USER_INPUT: user_input }
          );

          const aiResult = await callAI(
            domainTemplate.system_prompt,
            userPrompt,
            domainTemplate.model_config,
            lovableApiKey
          );

          const parsed = parseJsonResponse(aiResult.content);
          const latencyMs = Date.now() - phaseStart;

          // Extract domain from response
          if (typeof parsed === 'object' && parsed !== null && 'domain' in parsed) {
            currentDomain = (parsed as { domain: string }).domain;
          }

          // Update execution with domain classification
          await supabase
            .from("pipeline_executions")
            .update({ 
              domain: currentDomain,
              domain_classification: parsed,
            })
            .eq("id", executionId);

          // Update phase log
          await supabase
            .from("pipeline_phase_logs")
            .update({
              status: "completed",
              output_data: parsed,
              latency_ms: latencyMs,
              prompt_tokens: aiResult.prompt_tokens || 0,
              completion_tokens: aiResult.completion_tokens || 0,
              completed_at: new Date().toISOString(),
            })
            .eq("id", phaseLog?.id);

          phaseResults.push({
            phase: "-1",
            output: parsed,
            latency_ms: latencyMs,
            prompt_tokens: aiResult.prompt_tokens,
            completion_tokens: aiResult.completion_tokens,
          });

          console.log(`[Pipeline] Domain classified as: ${currentDomain}`);

        } catch (err) {
          await supabase
            .from("pipeline_phase_logs")
            .update({
              status: "failed",
              error_message: err instanceof Error ? err.message : String(err),
              completed_at: new Date().toISOString(),
            })
            .eq("id", phaseLog?.id);
          
          console.error("[Pipeline] Phase -1 failed, using default domain MEDICAL");
          currentDomain = "MEDICAL";
        }
      }
    }

    // ========== Load Pipeline for Domain ==========
    const { data: domain } = await supabase
      .from("pipeline_domains")
      .select("*")
      .eq("slug", currentDomain)
      .eq("is_active", true)
      .single();

    if (domain) {
      const { data: pipeline } = await supabase
        .from("pipelines")
        .select("*")
        .eq("domain_id", domain.id)
        .eq("is_active", true)
        .single();

      if (pipeline) {
        selectedPipeline = pipeline;
        
        await supabase
          .from("pipeline_executions")
          .update({ pipeline_id: pipeline.id })
          .eq("id", executionId);
      }
    }

    // ========== Execute Pipeline Phases ==========
    if (selectedPipeline) {
      console.log(`[Pipeline] Executing pipeline: ${selectedPipeline.name} with phases: ${selectedPipeline.phase_order.join(", ")}`);

      // Build context that accumulates across phases
      let phaseContext: Record<string, unknown> = {
        USER_INPUT: user_input,
        CLINICAL_VIEW: clinical_view,
        CONVERSATION_HISTORY: conversation_history,
        CURRENT_TIME: new Date().toISOString(),
        DOMAIN: currentDomain,
      };

      // Identify parallel phase groups (e.g., "2" and "2b" run together)
      const parallelGroups: Map<string, string[]> = new Map();
      for (const phase of selectedPipeline.phase_order) {
        // Base phase is the numeric part (e.g., "2" from "2b")
        const basePhase = phase.replace(/[a-z]+$/i, '');
        if (!parallelGroups.has(basePhase)) {
          parallelGroups.set(basePhase, []);
        }
        parallelGroups.get(basePhase)!.push(phase);
      }

      // Execute phases, running parallel groups concurrently
      const processedPhases = new Set<string>();
      
      for (const phase of selectedPipeline.phase_order) {
        // Skip phase -1 if already executed
        if (phase === "-1") continue;
        
        // Skip if already processed as part of a parallel group
        if (processedPhases.has(phase)) continue;

        const basePhase = phase.replace(/[a-z]+$/i, '');
        const parallelPhases = parallelGroups.get(basePhase) || [phase];
        
        // Mark all phases in this group as processed
        parallelPhases.forEach(p => processedPhases.add(p));

        // Check if this is a parallel group (more than one phase)
        if (parallelPhases.length > 1) {
          console.log(`[Pipeline] Executing parallel phases: ${parallelPhases.join(", ")}`);
          
          // Execute all phases in parallel
          const parallelResults = await Promise.allSettled(
            parallelPhases.map(async (parallelPhase) => {
              return executePhase(
                parallelPhase,
                selectedPipeline!,
                phaseContext,
                executionId!,
                supabase,
                lovableApiKey
              );
            })
          );

          // Collect results
          for (let i = 0; i < parallelResults.length; i++) {
            const result = parallelResults[i];
            const parallelPhase = parallelPhases[i];
            
            if (result.status === 'fulfilled' && result.value) {
              phaseResults.push(result.value);
              // Add to context for subsequent phases
              phaseContext[`PHASE_${parallelPhase}_RESULT`] = JSON.stringify(result.value.output);
              
              // Check for emergency flags
              if (typeof result.value.output === 'object' && result.value.output !== null) {
                const output = result.value.output as Record<string, unknown>;
                if (output.urgency_level === 5 || 
                    (Array.isArray(output.red_flags) && output.red_flags.some((f: string) => f !== "NONE"))) {
                  phaseContext["EMERGENCY_FLAG"] = "true";
                }
              }
            } else if (result.status === 'rejected') {
              console.error(`[Pipeline] Parallel phase ${parallelPhase} failed:`, result.reason);
              phaseContext[`PHASE_${parallelPhase}_ERROR`] = String(result.reason);
            }
          }
        } else {
          // Single phase execution (existing logic)
          const result = await executePhase(
            phase,
            selectedPipeline,
            phaseContext,
            executionId!,
            supabase,
            lovableApiKey
          );

          if (result) {
            phaseResults.push(result);
            phaseContext[`PHASE_${phase}_RESULT`] = JSON.stringify(result.output);
            phaseContext[`PHASE_${phase}_RAW`] = result.raw_content || '';

            // Check for abort conditions
            if (typeof result.output === 'object' && result.output !== null) {
              const output = result.output as Record<string, unknown>;
              
              if (output.urgency_level === 5 || 
                  (Array.isArray(output.red_flags) && output.red_flags.some((f: string) => f !== "NONE"))) {
                phaseContext["EMERGENCY_FLAG"] = "true";
              }

              if (output.skip_remaining_phases) {
                console.log("[Pipeline] Phase requested skip of remaining phases");
                break;
              }
            }
          }
        }
      }
    }

    // ========== Complete Execution ==========
    const totalLatency = Date.now() - startTime;
    const totalTokens = phaseResults.reduce(
      (sum, r) => sum + (r.prompt_tokens || 0) + (r.completion_tokens || 0),
      0
    );

    // Build final output
    const finalOutput = {
      domain: currentDomain,
      pipeline: selectedPipeline?.name || "none",
      phases_executed: phaseResults.length,
      results: phaseResults,
      total_latency_ms: totalLatency,
      total_tokens: totalTokens,
    };

    await supabase
      .from("pipeline_executions")
      .update({
        status: "completed",
        output_data: finalOutput,
        total_latency_ms: totalLatency,
        total_tokens: totalTokens,
        completed_at: new Date().toISOString(),
      })
      .eq("id", executionId);

    // Log aggregated pipeline usage to ai_usage_logs
    const totalPromptTokens = phaseResults.reduce((sum, r) => sum + (r.prompt_tokens || 0), 0);
    const totalCompletionTokens = phaseResults.reduce((sum, r) => sum + (r.completion_tokens || 0), 0);
    
    try {
      await supabase
        .from("ai_usage_logs")
        .insert({
          session_id: session_id || null,
          source_type: "pipeline",
          source_detail: selectedPipeline?.slug || currentDomain,
          provider: "lovable-gateway",
          model: "google/gemini-3-flash-preview",
          prompt_tokens: totalPromptTokens,
          completion_tokens: totalCompletionTokens,
          latency_ms: totalLatency,
          request_metadata: { 
            domain: currentDomain,
            pipeline: selectedPipeline?.name || "none",
            phases_executed: phaseResults.length,
            execution_id: executionId
          },
          status: "success",
        });
    } catch (logError) {
      console.error("Failed to log pipeline usage:", logError);
    }

    console.log(`[Pipeline] Orchestration completed in ${totalLatency}ms, ${phaseResults.length} phases, ${totalTokens} tokens`);

    return new Response(
      JSON.stringify(finalOutput),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[Pipeline] Orchestration error:", error);

    // Update execution as failed if we have an ID
    if (executionId) {
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseServiceKey);

      await supabase
        .from("pipeline_executions")
        .update({
          status: "failed",
          error_message: error instanceof Error ? error.message : String(error),
          total_latency_ms: Date.now() - startTime,
          completed_at: new Date().toISOString(),
        })
        .eq("id", executionId);
    }

    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Pipeline orchestration failed" 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
