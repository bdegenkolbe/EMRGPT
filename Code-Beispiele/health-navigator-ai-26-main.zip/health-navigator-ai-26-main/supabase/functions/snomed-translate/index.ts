import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface SnomedTermInput {
  sctid: string;
  fsn: string;
  pt: string;
}

interface TranslationResult {
  sctid: string;
  fsn_en: string;
  pt_en: string;
  pt_de: string;
  definition_de?: string;
  explanation_de?: string;
  source: "official" | "ai_translated";
  confidence: number;
}

async function translateWithAI(
  terms: SnomedTermInput[]
): Promise<TranslationResult[]> {
  const prompt = `Du bist ein medizinischer Übersetzer für SNOMED CT.
Übersetze die folgenden englischen SNOMED CT Begriffe ins Deutsche.
Verwende korrekte deutsche medizinische Fachterminologie.
Die Übersetzungen müssen präzise, klinisch korrekt und konsistent sein.

Wichtig:
- "pt" ist der bevorzugte Begriff (Preferred Term) - übersetze diesen als "pt_de"
- Gib zusätzlich eine kurze deutsche Erklärung (max 100 Wörter) als "explanation_de"

Begriffe zur Übersetzung:
${terms.map((t) => `- ${t.sctid}: PT="${t.pt}" (FSN: ${t.fsn})`).join("\n")}

Antworte NUR mit einem JSON-Array in diesem Format:
[
  {"sctid": "123456789", "pt_de": "Deutsche Übersetzung", "explanation_de": "Kurze Erklärung...", "confidence": 0.95}
]`;

  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");

  let response: Response;
  let usedProvider = "openai";

  if (openaiKey) {
    response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "Du bist ein Experte für medizinische Terminologie und SNOMED CT Übersetzungen.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 3000,
      }),
    });
  } else if (lovableKey) {
    usedProvider = "lovable-gateway";
    response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: "Du bist ein Experte für medizinische Terminologie und SNOMED CT Übersetzungen.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 3000,
      }),
    });
  } else {
    throw new Error("No AI API key configured");
  }

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`AI API error (${usedProvider}):`, response.status, errorText);
    throw new Error(`AI translation failed: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";

  const jsonMatch = content.match(/\[[\s\S]*\]/);
  if (!jsonMatch) {
    console.error("Could not parse AI response:", content);
    throw new Error("Invalid AI response format");
  }

  const translations: Array<{ 
    sctid: string; 
    pt_de: string; 
    explanation_de?: string;
    confidence?: number 
  }> = JSON.parse(jsonMatch[0]);

  return translations.map((t) => {
    const originalTerm = terms.find((term) => term.sctid === t.sctid);
    return {
      sctid: t.sctid,
      fsn_en: originalTerm?.fsn || "",
      pt_en: originalTerm?.pt || "",
      pt_de: t.pt_de,
      explanation_de: t.explanation_de,
      source: "ai_translated" as const,
      confidence: t.confidence || 0.9,
    };
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const { terms }: { terms: SnomedTermInput[] } = await req.json();

    if (!terms || !Array.isArray(terms) || terms.length === 0) {
      return new Response(JSON.stringify({ error: "No terms provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const MAX_BATCH_SIZE = 15;
    const termsToProcess = terms.slice(0, MAX_BATCH_SIZE);

    console.log(`Processing ${termsToProcess.length} SNOMED terms for translation`);

    // Check snomed_codes table for existing translations in JSONB labels
    const sctids = termsToProcess.map((t) => t.sctid);
    const { data: existingCodes, error: lookupError } = await supabaseAdmin
      .from("snomed_codes")
      .select("sctid, fsn, pt, labels, definitions, explanations")
      .in("sctid", sctids);

    if (lookupError) {
      console.error("SNOMED codes lookup error:", lookupError);
    }

    // Find codes with valid German translations
    const cachedMap = new Map<string, TranslationResult>();
    for (const code of existingCodes || []) {
      const labelDe = code.labels?.de;
      const labelEn = code.labels?.en || code.pt;
      if (labelDe && labelDe !== labelEn) {
        cachedMap.set(code.sctid, {
          sctid: code.sctid,
          fsn_en: code.fsn,
          pt_en: code.pt,
          pt_de: labelDe,
          definition_de: code.definitions?.de,
          explanation_de: code.explanations?.de,
          source: "official",
          confidence: 1.0,
        });
      }
    }

    // Find terms that need translation
    const toTranslate = termsToProcess.filter((t) => !cachedMap.has(t.sctid));

    console.log(`Found ${cachedMap.size} cached, ${toTranslate.length} need translation`);

    let newTranslations: TranslationResult[] = [];

    if (toTranslate.length > 0) {
      try {
        newTranslations = await translateWithAI(toTranslate);

        // Upsert snomed_codes table with new translations (creates if not exists)
        for (const t of newTranslations) {
          const existingCode = existingCodes?.find((c) => c.sctid === t.sctid);
          const currentLabels = existingCode?.labels || {};
          const currentExplanations = existingCode?.explanations || {};

          const { error: upsertError } = await supabaseAdmin
            .from("snomed_codes")
            .upsert({
              sctid: t.sctid,
              fsn: t.fsn_en,
              pt: t.pt_en,
              labels: { ...currentLabels, de: t.pt_de, en: t.pt_en },
              explanations: t.explanation_de 
                ? { ...currentExplanations, de: t.explanation_de }
                : currentExplanations,
              source: existingCode?.source || 'snomed-translate',
            }, { onConflict: "sctid" });

          if (upsertError) {
            console.error(`Error upserting SNOMED code ${t.sctid}:`, upsertError);
          }
        }

        console.log(`Upserted ${newTranslations.length} SNOMED codes with translations`);
      } catch (aiError) {
        console.error("AI translation error:", aiError);
      }
    }

    // Combine results
    const allTranslations: TranslationResult[] = termsToProcess.map((term) => {
      const cached = cachedMap.get(term.sctid);
      if (cached) return cached;

      const translated = newTranslations.find((t) => t.sctid === term.sctid);
      if (translated) return translated;

      // Fallback: return original English
      return {
        sctid: term.sctid,
        fsn_en: term.fsn,
        pt_en: term.pt,
        pt_de: term.pt,
        source: "official" as const,
        confidence: 0,
      };
    });

    return new Response(JSON.stringify({ translations: allTranslations }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("snomed-translate error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
