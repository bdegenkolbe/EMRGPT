 import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
 import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
 
 const corsHeaders = {
   "Access-Control-Allow-Origin": "*",
   "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
 };
 
// The 7 anamnesis categories that structure every path
const ANAMNESIS_CATEGORIES = [
  { key: "chief_complaint", de: "Hauptbeschwerde", en: "Chief Complaint", icon: "🔍" },
  { key: "hpi", de: "Aktuelle Beschwerden", en: "History of Present Illness", icon: "📋" },
  { key: "ros", de: "Systemübersicht", en: "Review of Systems", icon: "🔬" },
  { key: "pmh", de: "Vorerkrankungen", en: "Past Medical History", icon: "📚" },
  { key: "medications", de: "Medikamente", en: "Medications", icon: "💊" },
  { key: "social", de: "Sozialanamnese", en: "Social History", icon: "👥" },
  { key: "family", de: "Familienanamnese", en: "Family History", icon: "❤️" },
] as const;

 interface PathRequest {
   session_id: string;
   hpo_codes: string[];
   hpo_labels: { code: string; label_de: string; label_en: string }[];
   existing_path_id?: string;
   observations?: { raw_input: string; hpo_codes: string[]; onset?: string; severity?: string }[];
  combine_mode?: 'single' | 'combined' | 'auto';
  force_new?: boolean;
  regenerate_step?: string;
 }
 
 interface SymptomNode {
   id: string;
   label: string;
   type: "symptom" | "question" | "decision" | "diagnosis" | "action";
   children?: SymptomNode[];
 }
 
 interface DifferentialDiagnosis {
   name: string;
   probability: number;
   icd10?: string;
   reasoning: string;
 }
 
 serve(async (req) => {
   if (req.method === "OPTIONS") {
     return new Response(null, { headers: corsHeaders });
   }
 
   try {
     const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
     const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
     const supabase = createClient(supabaseUrl, supabaseServiceKey);
 
     const requestBody = await req.json();
     const { 
       session_id, 
       hpo_codes, 
       hpo_labels, 
       existing_path_id, 
       observations,
       combine_mode = 'auto',
        force_new = false,
        regenerate_step
      } = requestBody as PathRequest & { combine_mode?: string; force_new?: boolean; regenerate_step?: string };
 
     if (!session_id || !hpo_codes?.length) {
       return new Response(
         JSON.stringify({ error: "session_id and hpo_codes are required" }),
         { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
       );
     }
 
     console.log(`Generating anamnesis path for session ${session_id} with HPO codes:`, hpo_codes);
 
    // === SINGLE STEP REGENERATION ===
    if (regenerate_step && existing_path_id) {
      console.log(`🔄 Regenerating step "${regenerate_step}" for path ${existing_path_id}`);
      
      // Fetch the existing path
      const { data: existingPath, error: fetchError } = await supabase
        .from("anamnesis_paths")
        .select("*")
        .eq("id", existing_path_id)
        .single();
      
      if (fetchError || !existingPath) {
        throw new Error("Existing path not found");
      }

      // Build step-specific prompt
      const stepPrompts: Record<string, string> = {
        'differential_diagnoses': `Erstelle NUR neue Differentialdiagnosen für die Symptome: ${symptomsList}

Antworte NUR mit einem JSON-Array:
[{ "name": "...", "probability": 0.0-1.0, "icd10": "...", "reasoning": "..." }]`,
        
        'ai_reasoning': `Erstelle eine NEUE klinische Begründung für den Anamnesepfad mit den Symptomen: ${symptomsList}

Antworte NUR mit einem JSON-Objekt:
{ "ai_reasoning": "..." }`,
        
        'question_tree': `Erstelle einen NEUEN Fragenbaum für die 7 Anamnese-Kategorien basierend auf: ${symptomsList}

Antworte NUR mit einem JSON-Objekt mit den Kategorien als Keys.`,
        
        'mermaid_diagram': `Erstelle ein NEUES Mermaid-Diagramm (flowchart TB) für die Symptome: ${symptomsList}

WICHTIG: Verwende Subgraphs für die 7 Anamnese-Kategorien!
Antworte NUR mit einem JSON-Objekt:
{ "mermaid_diagram": "flowchart TB\\n..." }`,
      };

      const stepPrompt = stepPrompts[regenerate_step];
      if (!stepPrompt) {
        throw new Error(`Unknown regeneration step: ${regenerate_step}`);
      }

      // Call AI for step regeneration
      const openaiKey = Deno.env.get("OPENAI_API_KEY");
      const lovableKey = Deno.env.get("LOVABLE_API_KEY");

      let stepResponse: Response;

      if (openaiKey) {
        stepResponse = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${openaiKey}`,
          },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
              { role: "system", content: "Du bist ein medizinischer Experte. Antworte NUR mit validem JSON." },
              { role: "user", content: stepPrompt },
            ],
            temperature: 0.4,
            max_tokens: 1500,
          }),
        });
      } else if (lovableKey) {
        stepResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${lovableKey}`,
          },
          body: JSON.stringify({
            model: "google/gemini-3-flash-preview",
            messages: [
              { role: "system", content: "Du bist ein medizinischer Experte. Antworte NUR mit validem JSON." },
              { role: "user", content: stepPrompt },
            ],
            temperature: 0.4,
            max_tokens: 1500,
          }),
        });
      } else {
        throw new Error("No AI API key configured");
      }

      if (!stepResponse.ok) {
        const errorText = await stepResponse.text();
        console.error("Step regeneration AI error:", stepResponse.status, errorText);
        throw new Error(`AI API error: ${stepResponse.status}`);
      }

      const stepData = await stepResponse.json();
      const stepContent = stepData.choices?.[0]?.message?.content?.trim() || "";
      
      // Parse step-specific JSON
      const jsonMatch = stepContent.match(/[\[\{][\s\S]*[\]\}]/);
      if (!jsonMatch) {
        console.error("Could not parse step AI response:", stepContent);
        throw new Error("Invalid AI response format for step");
      }

      let stepParsed;
      try {
        stepParsed = JSON.parse(jsonMatch[0]);
      } catch (e) {
        console.error("Step JSON parse error:", e, stepContent);
        throw new Error("Failed to parse step AI response");
      }

      // Build update object for the specific step
      const updateData: Record<string, unknown> = {
        version: (existingPath.version || 0) + 1,
        updated_at: new Date().toISOString(),
      };

      if (regenerate_step === 'differential_diagnoses') {
        updateData.differential_diagnoses = Array.isArray(stepParsed) ? stepParsed : stepParsed.differential_diagnoses || [];
      } else if (regenerate_step === 'ai_reasoning') {
        updateData.ai_reasoning = typeof stepParsed === 'string' ? stepParsed : stepParsed.ai_reasoning || "";
      } else if (regenerate_step === 'question_tree') {
        updateData.question_tree = stepParsed;
      } else if (regenerate_step === 'mermaid_diagram') {
        updateData.mermaid_diagram = typeof stepParsed === 'string' ? stepParsed : stepParsed.mermaid_diagram || "";
      }

      // Update the path
      const { data: updatedPath, error: updateError } = await supabase
        .from("anamnesis_paths")
        .update(updateData)
        .eq("id", existing_path_id)
        .select()
        .single();

      if (updateError) throw updateError;

      console.log(`✅ Step "${regenerate_step}" regenerated for path ${existing_path_id}`);

      return new Response(JSON.stringify({
        ...updatedPath,
        regenerated_step: regenerate_step,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // === DEDUPLICATION: Reuse existing paths for known HPO combinations ===
    if (!force_new && !existing_path_id) {
      const sortedCodes = [...hpo_codes].sort();
      const isSingleCode = hpo_codes.length === 1;
      
      // Query for existing paths - check both single and combined
      const { data: existingPaths } = await supabase
        .from("anamnesis_paths")
        .select("id, hpo_codes, version, is_combined, updated_at")
        .order("updated_at", { ascending: false });
      
      // Find exact match (same HPO codes regardless of order)
      const matchingPath = existingPaths?.find((p: any) => {
        const existingSorted = [...(p.hpo_codes || [])].sort();
        return JSON.stringify(existingSorted) === JSON.stringify(sortedCodes);
      });
      
      if (matchingPath) {
        console.log(`♻️ Reusing existing path ${matchingPath.id} (v${matchingPath.version}) for HPO codes:`, hpo_codes);
        
        // Fetch the full path data
        const { data: fullPath, error: fetchError } = await supabase
          .from("anamnesis_paths")
          .select("*")
          .eq("id", matchingPath.id)
          .single();
        
        if (!fetchError && fullPath) {
          // Link this reused path to the new session if different
          if (fullPath.session_id !== session_id) {
            // Create a reference entry linking the path to this session
            // (We don't update the original path's session_id to preserve history)
            console.log(`Path originally from session ${fullPath.session_id}, reusing for ${session_id}`);
          }
          
          return new Response(JSON.stringify({ 
            ...fullPath, 
            reused: true,
            reused_from_session: fullPath.session_id,
            original_created_at: fullPath.created_at,
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
      }
      
      // For single codes: also check if there's a path that contains this code as part of a larger set
      // This allows reusing diagnostic reasoning from combined paths
      if (isSingleCode && combine_mode === 'auto') {
        const containingPath = existingPaths?.find((p: any) => {
          const pathCodes = p.hpo_codes || [];
          return pathCodes.includes(hpo_codes[0]) && pathCodes.length > 1;
        });
        
        if (containingPath) {
          console.log(`📎 Found containing combined path ${containingPath.id} that includes ${hpo_codes[0]}`);
          // We still create a new single-code path, but log this for potential future use
        }
      }
      
      console.log(`🆕 No existing path found for HPO codes, generating new path...`);
    }

     // Build the prompt for AI
     const symptomsList = hpo_labels.map(h => `- ${h.label_de} (${h.code}): ${h.label_en}`).join("\n");
     const observationsList = observations?.map(o => 
       `- "${o.raw_input}" → HPO: ${o.hpo_codes?.join(", ") || "none"}${o.onset ? `, Beginn: ${o.onset}` : ""}${o.severity ? `, Schwere: ${o.severity}` : ""}`
     ).join("\n") || "Keine zusätzlichen Beobachtungen";
 
     const isCombined = hpo_codes.length > 1;
 
    // Enhanced prompt for combined symptom analysis
    const combinedAnalysisHint = isCombined ? `

WICHTIG - KOMBINIERTE SYMPTOMANALYSE:
Du analysierst ${hpo_codes.length} Symptome GEMEINSAM:
1. Suche nach GEMEINSAMEN Ursachen, die alle Symptome erklären
2. Identifiziere SYMPTOMKOMPLEXE und typische Krankheitsbilder
3. Bewerte, ob die Symptome zusammenhängen oder unabhängig sind
4. Priorisiere Differentialdiagnosen, die MEHRERE Symptome erklären
5. Markiere im Mermaid-Diagramm Verbindungen zwischen den Symptomen` : '';

    // Build category structure for the prompt
    const categoryList = ANAMNESIS_CATEGORIES.map((cat, idx) => 
      `${idx + 1}. ${cat.icon} ${cat.de} (${cat.key})`
    ).join("\n");

    const systemPrompt = `Du bist ein medizinischer Experte für klinische Entscheidungspfade und die Human Phenotype Ontology (HPO).

Deine Aufgabe ist es, einen strukturierten Anamnesepfad zu erstellen, der STRIKT den 7 Anamnese-Kategorien folgt:

${categoryList}

MERMAID-DIAGRAMM REGELN:
1. Verwende flowchart TB
2. Erstelle für JEDE relevante Kategorie einen subgraph
3. Format: subgraph CC["🔍 Hauptbeschwerde"]
4. Innerhalb der Subgraphs: Entscheidungsfragen als Rauten {Frage?}
5. Red Flags mit rotem Styling: style RF fill:#fee2e2,stroke:#dc2626
6. Verknüpfe die Kategorien logisch miteinander
7. Ende mit Differentialdiagnosen und Handlungsempfehlungen
${isCombined ? "8. Bei mehreren Symptomen: Zeige Verbindungen zwischen Kategorien" : ""}
${combinedAnalysisHint}

SYMPTOM_HIERARCHY - Verwende EXAKT diese Struktur mit den 7 Kategorien als Hauptknoten:
{
  "id": "root",
  "label": "Anamnese",
  "children": [
    { "id": "chief_complaint", "label": "🔍 Hauptbeschwerde", "findings": [], "questions": [], "red_flags": [] },
    { "id": "hpi", "label": "📋 Aktuelle Beschwerden", "findings": [], "questions": [], "red_flags": [] },
    { "id": "ros", "label": "🔬 Systemübersicht", "findings": [], "questions": [], "red_flags": [] },
    { "id": "pmh", "label": "📚 Vorerkrankungen", "findings": [], "questions": [], "red_flags": [] },
    { "id": "medications", "label": "💊 Medikamente", "findings": [], "questions": [], "red_flags": [] },
    { "id": "social", "label": "👥 Sozialanamnese", "findings": [], "questions": [], "red_flags": [] },
    { "id": "family", "label": "❤️ Familienanamnese", "findings": [], "questions": [], "red_flags": [] }
  ]
}

Antworte NUR mit einem JSON-Objekt:
{
  "mermaid_diagram": "flowchart TB\\n  subgraph CC[\\"🔍 Hauptbeschwerde\\"]\\n    ...",
  "symptom_hierarchy": { ... wie oben ... },
  "differential_diagnoses": [{ "name": "...", "probability": 0.0-1.0, "icd10": "...", "reasoning": "..." }],
  "question_tree": { 
    "chief_complaint": { "questions": [...], "completed": false },
    "hpi": { "questions": [...], "completed": false },
    "ros": { "questions": [...], "completed": false },
    "pmh": { "questions": [...], "completed": false },
    "medications": { "questions": [...], "completed": false },
    "social": { "questions": [...], "completed": false },
    "family": { "questions": [...], "completed": false },
    "red_flags": [...]
  },
  "ai_reasoning": "Kurze Erklärung der Pfadlogik..."
}`;

    const userPrompt = `Erstelle einen klinischen Anamnesepfad für folgende${isCombined ? ' KOMBINIERTE' : ''} Symptome:

HPO-Symptome:
${symptomsList}

Beobachtungen aus der Anamnese:
${observationsList}

${existing_path_id ? "Dies ist eine ERWEITERUNG eines bestehenden Pfads. Integriere die neuen Symptome." : isCombined ? "Erstelle einen KOMBINIERTEN Pfad, der ALLE Symptome gemeinsam analysiert. Zeige Verbindungen und gemeinsame Differentialdiagnosen." : "Erstelle einen neuen Pfad mit allen 7 Anamnese-Kategorien als Subgraphs."}

WICHTIG: Das Mermaid-Diagramm MUSS Subgraphs für die relevanten Kategorien enthalten!`;
 
     // Try OpenAI first, then Lovable Gateway
     const openaiKey = Deno.env.get("OPENAI_API_KEY");
     const lovableKey = Deno.env.get("LOVABLE_API_KEY");
 
     let response: Response;
 
     if (openaiKey) {
       response = await fetch("https://api.openai.com/v1/chat/completions", {
         method: "POST",
         headers: {
           "Content-Type": "application/json",
           Authorization: `Bearer ${openaiKey}`,
         },
         body: JSON.stringify({
           model: "gpt-4o-mini",
           messages: [
             { role: "system", content: systemPrompt },
             { role: "user", content: userPrompt },
           ],
           temperature: 0.4,
           max_tokens: 3000,
         }),
       });
     } else if (lovableKey) {
       response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
         method: "POST",
         headers: {
           "Content-Type": "application/json",
           Authorization: `Bearer ${lovableKey}`,
         },
         body: JSON.stringify({
           model: "google/gemini-3-flash-preview",
           messages: [
             { role: "system", content: systemPrompt },
             { role: "user", content: userPrompt },
           ],
           temperature: 0.4,
           max_tokens: 3000,
         }),
       });
     } else {
       throw new Error("No AI API key configured");
     }
 
     if (!response.ok) {
       const errorText = await response.text();
       console.error("AI API error:", response.status, errorText);
       
       if (response.status === 429) {
         return new Response(
           JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
           { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
         );
       }
       if (response.status === 402) {
         return new Response(
           JSON.stringify({ error: "Payment required. Please add funds to your workspace." }),
           { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
         );
       }
       
       throw new Error(`AI API error: ${response.status}`);
     }
 
     const data = await response.json();
     const content = data.choices?.[0]?.message?.content?.trim() || "";
 
     // Parse JSON from response
     const jsonMatch = content.match(/\{[\s\S]*\}/);
     if (!jsonMatch) {
       console.error("Could not parse AI response as JSON:", content);
       throw new Error("Invalid AI response format");
     }
 
     let parsed;
     try {
       parsed = JSON.parse(jsonMatch[0]);
     } catch (e) {
       console.error("JSON parse error:", e, content);
       throw new Error("Failed to parse AI response");
     }
 
     // Get observation IDs for linking
     const { data: obsData } = await supabase
       .from("observations")
       .select("id")
       .eq("session_id", session_id)
       .overlaps("hpo_codes", hpo_codes);
 
     const observationIds = obsData?.map(o => o.id) || [];
 
     // Determine version number
     let version = 1;
     let previousVersionData = null;
     if (existing_path_id) {
       const { data: existingPath } = await supabase
         .from("anamnesis_paths")
         .select("*")
         .eq("id", existing_path_id)
         .single();
       version = (existingPath?.version || 0) + 1;
       
       // Store previous version as a snapshot before updating
       if (existingPath) {
         previousVersionData = {
           ...existingPath,
           id: undefined, // Remove id so it creates a new record
           parent_path_id: existing_path_id,
           is_snapshot: true,
         };
       }
     }
 
     // Insert or update the path
     const pathData = {
       session_id,
       hpo_codes,
       symptom_hierarchy: parsed.symptom_hierarchy || {},
       temporal_sequence: observations?.map((o, i) => ({
         order: i,
         raw_input: o.raw_input,
         hpo_codes: o.hpo_codes,
         onset: o.onset,
       })) || [],
       differential_diagnoses: parsed.differential_diagnoses || [],
       question_tree: parsed.question_tree || {},
       mermaid_diagram: parsed.mermaid_diagram || "",
       ai_reasoning: parsed.ai_reasoning || "",
       version,
       is_combined: isCombined,
       source_observation_ids: observationIds,
     };
 
     let result;
     if (existing_path_id) {
       // First, create a snapshot of the previous version if it exists
       if (previousVersionData) {
         const snapshotData = {
           session_id: previousVersionData.session_id,
           hpo_codes: previousVersionData.hpo_codes,
           symptom_hierarchy: previousVersionData.symptom_hierarchy,
           temporal_sequence: previousVersionData.temporal_sequence,
           differential_diagnoses: previousVersionData.differential_diagnoses,
           question_tree: previousVersionData.question_tree,
           mermaid_diagram: previousVersionData.mermaid_diagram,
           ai_reasoning: previousVersionData.ai_reasoning,
           version: previousVersionData.version,
           is_combined: previousVersionData.is_combined,
           source_observation_ids: previousVersionData.source_observation_ids,
         };
         
         const { error: snapshotError } = await supabase
           .from("anamnesis_paths")
           .insert(snapshotData);
         
         if (snapshotError) {
           console.warn("Could not create version snapshot:", snapshotError);
         } else {
           console.log(`📸 Created snapshot of v${previousVersionData.version} before updating to v${version}`);
         }
       }
       
       const { data, error } = await supabase
         .from("anamnesis_paths")
         .update(pathData)
         .eq("id", existing_path_id)
         .select()
         .single();
       if (error) throw error;
       result = data;
     } else {
       const { data, error } = await supabase
         .from("anamnesis_paths")
         .insert(pathData)
         .select()
         .single();
       if (error) throw error;
       result = data;
     }
 
     console.log(`Successfully created/updated anamnesis path ${result.id}`);
 
     return new Response(JSON.stringify(result), {
       headers: { ...corsHeaders, "Content-Type": "application/json" },
     });
   } catch (error) {
     console.error("generate-anamnesis-path error:", error);
     return new Response(
       JSON.stringify({ error: error.message || "Internal server error" }),
       { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
     );
   }
 });