import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface OrphanetAnalysis {
  orpha_code: string;
  content: {
    explanation?: string;
    symptoms?: string[];
    diagnosis?: string;
    therapy?: string;
    prognosis?: string;
    notes?: string;
  };
  hpo_mappings: Array<{ code: string; label: string; confidence: number }>;
  snomed_mappings: Array<{ code: string; label: string; confidence: number }>;
  icd10_mappings: Array<{ code: string; label: string; confidence: number }>;
  omim_mappings: Array<{ code: string; label: string; confidence: number }>;
  generated_at: string;
  source_language: string;
}

async function generateAnalysisWithAI(
  orphaCode: string,
  name: string,
  definition: string | undefined,
  language: string
): Promise<OrphanetAnalysis["content"]> {
  const prompt = `Du bist ein Experte für seltene Erkrankungen (Orphanet).

Erstelle eine strukturierte klinische Analyse für diese seltene Erkrankung:
- ORPHA-Code: ${orphaCode}
- Name: ${name}
${definition ? `- Definition: ${definition}` : ""}

Antworte NUR mit einem JSON-Objekt in diesem Format:
{
  "explanation": "Verständliche Erklärung der Erkrankung (max 100 Wörter)",
  "symptoms": ["Symptom 1", "Symptom 2", ...],
  "diagnosis": "Diagnostische Kriterien und Verfahren",
  "therapy": "Behandlungsoptionen und Management",
  "prognosis": "Prognose und Verlauf",
  "notes": "Wichtige klinische Hinweise"
}`;

  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");

  let response: Response;

  if (openaiKey) {
    response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Du bist ein Experte für seltene Erkrankungen." },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 1500,
      }),
    });
  } else if (lovableKey) {
    response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "Du bist ein Experte für seltene Erkrankungen." },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 1500,
      }),
    });
  } else {
    throw new Error("No AI API key configured");
  }

  if (!response.ok) {
    throw new Error(`AI API error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";

  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error("Invalid AI response format");
  }

  return JSON.parse(jsonMatch[0]);
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const body = await req.json();
    const action = body.action || "get";
    const orphaCode = body.orphaCode || body.code || "";
    const language = body.lang || "de";
    const forceRegenerate = body.forceRegenerate || false;

    if (!orphaCode) {
      return new Response(JSON.stringify({ error: "Missing orphaCode" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`orphanet-analyze: action=${action}, code=${orphaCode}`);

    if (action === "get") {
      // Check existing analysis
      const { data: existing } = await supabaseAdmin
        .from("orphanet_analyses")
        .select("*")
        .eq("orpha_code", orphaCode)
        .maybeSingle();

      if (existing && !forceRegenerate) {
        return new Response(JSON.stringify({ analysis: existing }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Check for cached mappings in ontology_mappings
      const { data: cachedMappings } = await supabaseAdmin
        .from("ontology_mappings")
        .select("*")
        .or(`source_code.eq.ORPHA:${orphaCode},target_code.eq.ORPHA:${orphaCode}`)
        .eq("validation_status", "valid");

      if (cachedMappings && cachedMappings.length > 0 && !existing) {
        // Return cached mappings without full analysis
        const hpoMappings: Array<{ code: string; label: string; confidence: number }> = [];
        const snomedMappings: Array<{ code: string; label: string; confidence: number }> = [];
        const icd10Mappings: Array<{ code: string; label: string; confidence: number }> = [];

        for (const m of cachedMappings) {
          const isSource = m.source_code === `ORPHA:${orphaCode}`;
          const targetCode = isSource ? m.target_code : m.source_code;
          const targetLabel = isSource ? m.target_label : m.source_label;

          if (targetCode.startsWith("HP:")) {
            hpoMappings.push({ code: targetCode, label: targetLabel, confidence: m.confidence });
          } else if (/^\d+$/.test(targetCode)) {
            snomedMappings.push({ code: targetCode, label: targetLabel, confidence: m.confidence });
          } else if (/^[A-Z]\d/.test(targetCode)) {
            icd10Mappings.push({ code: targetCode, label: targetLabel, confidence: m.confidence });
          }
        }

        return new Response(
          JSON.stringify({
            analysis: null,
            cached_mappings: {
              hpo_mappings: hpoMappings,
              snomed_mappings: snomedMappings,
              icd10_mappings: icd10Mappings,
              from_cache: true,
            },
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // No analysis exists, return null (user needs to generate)
      return new Response(JSON.stringify({ analysis: null }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "generate") {
      const name = body.name || "";
      const definition = body.definition || "";

      // Generate AI analysis
      const content = await generateAnalysisWithAI(orphaCode, name, definition, language);

      // Fetch existing code data for mappings
      const { data: codeData } = await supabaseAdmin
        .from("orphanet_codes")
        .select("hpo_codes, icd10_codes, omim_codes")
        .eq("orpha_code", orphaCode)
        .maybeSingle();

      const hpoMappings = (codeData?.hpo_codes || []).map((code: string) => ({
        code,
        label: "",
        confidence: 1.0,
      }));
      const icd10Mappings = (codeData?.icd10_codes || []).map((code: string) => ({
        code,
        label: "",
        confidence: 1.0,
      }));
      const omimMappings = (codeData?.omim_codes || []).map((code: string) => ({
        code,
        label: "",
        confidence: 1.0,
      }));

      const analysis = {
        orpha_code: orphaCode,
        content,
        hpo_mappings: hpoMappings,
        snomed_mappings: [],
        icd10_mappings: icd10Mappings,
        omim_mappings: omimMappings,
        source_language: language,
        generated_at: new Date().toISOString(),
      };

      // Save to database
      const { error: insertError } = await supabaseAdmin
        .from("orphanet_analyses")
        .upsert(analysis, { onConflict: "orpha_code" });

      if (insertError) {
        console.error("Error saving analysis:", insertError);
      }

      // Also persist mappings to ontology_mappings table
      const mappingsToInsert = [
        ...hpoMappings.map((m) => ({
          source_system: "ORPHANET",
          source_code: `ORPHA:${orphaCode}`,
          source_label: name,
          target_system: "HPO",
          target_code: m.code,
          target_label: m.label || m.code,
          mapping_type: "related",
          confidence: m.confidence,
          extraction_source: "orphanet_api",
          validation_status: "pending",
        })),
        ...icd10Mappings.map((m) => ({
          source_system: "ORPHANET",
          source_code: `ORPHA:${orphaCode}`,
          source_label: name,
          target_system: "ICD10GM",
          target_code: m.code,
          target_label: m.label || m.code,
          mapping_type: "related",
          confidence: m.confidence,
          extraction_source: "orphanet_api",
          validation_status: "pending",
        })),
      ];

      if (mappingsToInsert.length > 0) {
        await supabaseAdmin
          .from("ontology_mappings")
          .upsert(mappingsToInsert, {
            onConflict: "source_system,source_code,target_system,target_code",
            ignoreDuplicates: true,
          })
          .catch((err) => console.error("Mapping insert error:", err));
      }

      return new Response(JSON.stringify({ analysis }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "update") {
      const content = body.content;
      if (!content) {
        return new Response(JSON.stringify({ error: "Missing content" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const { error } = await supabaseAdmin
        .from("orphanet_analyses")
        .update({ content, updated_at: new Date().toISOString() })
        .eq("orpha_code", orphaCode);

      if (error) {
        throw error;
      }

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: `Unknown action: ${action}` }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("orphanet-analyze error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
