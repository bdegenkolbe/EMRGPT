import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface LoincRequest {
  action: "search" | "lookup" | "classes" | "validate";
  query?: string;
  loincNum?: string;
  classFilter?: string;
  limit?: number;
}

interface LoincCode {
  loinc_num: string;
  component: string;
  long_common_name: string | null;
  short_name: string | null;
  class: string | null;
  example_ucum_units: string | null;
  property: string | null;
  time_aspect: string | null;
  system: string | null;
  scale_type: string | null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { action, query, loincNum, classFilter, limit = 20 }: LoincRequest = await req.json();

    switch (action) {
      case "search": {
        if (!query || query.trim().length < 2) {
          // Return empty results for empty/short queries
          return new Response(
            JSON.stringify({ codes: [], total: 0 }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        // Build search query using full-text search on component and long_common_name
        let queryBuilder = supabase
          .from("loinc_codes")
          .select("*", { count: "exact" });

        // Use ilike for simple substring search (more predictable than to_tsquery for user input)
        const searchTerm = `%${query.trim()}%`;
        queryBuilder = queryBuilder.or(
          `component.ilike.${searchTerm},long_common_name.ilike.${searchTerm},short_name.ilike.${searchTerm},loinc_num.ilike.${searchTerm}`
        );

        if (classFilter) {
          queryBuilder = queryBuilder.eq("class", classFilter);
        }

        const { data, count, error } = await queryBuilder
          .order("component")
          .limit(limit);

        if (error) throw error;

        return new Response(
          JSON.stringify({ 
            codes: data as LoincCode[],
            total: count || 0 
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "lookup": {
        if (!loincNum) {
          return new Response(
            JSON.stringify({ error: "loincNum is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const { data, error } = await supabase
          .from("loinc_codes")
          .select("*")
          .eq("loinc_num", loincNum)
          .maybeSingle();

        if (error) throw error;

        if (!data) {
          return new Response(
            JSON.stringify({ found: false, loincNum }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        return new Response(
          JSON.stringify({ found: true, code: data as LoincCode }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "classes": {
        // Get distinct class values for filtering
        const { data, error } = await supabase
          .from("loinc_codes")
          .select("class")
          .order("class");

        if (error) throw error;

        const uniqueClasses = [...new Set(data?.map(d => d.class).filter(Boolean))];
        
        return new Response(
          JSON.stringify({ classes: uniqueClasses }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "validate": {
        if (!loincNum) {
          return new Response(
            JSON.stringify({ valid: false, message: "loincNum is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const { data, error } = await supabase
          .from("loinc_codes")
          .select("loinc_num, component, long_common_name")
          .eq("loinc_num", loincNum)
          .maybeSingle();

        if (error) throw error;

        return new Response(
          JSON.stringify({ 
            valid: !!data,
            loincNum,
            component: data?.component,
            name: data?.long_common_name
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: "Invalid action. Use: search, lookup, classes, or validate" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error) {
    console.error("LOINC lookup error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "LOINC lookup failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
