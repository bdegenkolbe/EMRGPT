import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface AnalyzeRequest {
  action?: "get" | "generate";
  code: string;
  title?: string;
  forceRegenerate?: boolean;
}

interface AnalysisContent {
  explanation?: string;
  symptoms?: string[];
  diagnosis?: string;
  therapy?: string;
  notes?: string;
}

async function generateAnalysis(
  code: string,
  title: string,
  definition?: string
): Promise<{
  content: AnalysisContent;
  hpo_mappings: Array<{ code: string; label: string; confidence: number }>;
  snomed_mappings: Array<{ code: string; label: string; confidence: number }>;
  symptom_mappings: Array<{ symptom: string; hpo?: string; snomed?: string }>;
}> {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");

  const apiKey = openaiKey || lovableKey;
  const apiUrl = openaiKey 
    ? "https://api.openai.com/v1/chat/completions"
    : "https://ai.gateway.lovable.dev/v1/chat/completions";

  if (!apiKey) {
    throw new Error("No API key configured for analysis generation");
  }

  const prompt = `Analysiere den ICD-11 Code "${code}" (${title}).
${definition ? `Definition: ${definition}` : ""}

Erstelle eine strukturierte klinische Analyse auf Deutsch:

1. **Erklärung**: Eine verständliche Erklärung für Ärzte und medizinisches Fachpersonal (2-3 Sätze)

2. **Typische Symptome**: Liste der häufigsten Symptome/Anzeichen

3. **Diagnostik**: Wichtigste diagnostische Schritte

4. **Therapie**: Allgemeine Behandlungsansätze

5. **HPO-Mappings**: Relevante HPO-Codes (Human Phenotype Ontology) mit Format:
   - HP:XXXXXXX | Label | Konfidenz (0.0-1.0)

6. **SNOMED-Mappings**: Relevante SNOMED CT Codes mit Format:
   - SCTID | Label | Konfidenz (0.0-1.0)

Antworte im JSON-Format:
{
  "explanation": "...",
  "symptoms": ["Symptom 1", "Symptom 2"],
  "diagnosis": "...",
  "therapy": "...",
  "notes": "Wichtige Hinweise (optional)",
  "hpo_mappings": [{"code": "HP:0000001", "label": "Label", "confidence": 0.9}],
  "snomed_mappings": [{"code": "123456789", "label": "Label", "confidence": 0.85}],
  "symptom_mappings": [{"symptom": "Symptom", "hpo": "HP:XXXXXXX", "snomed": "123456"}]
}`;

  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: openaiKey ? "gpt-4o-mini" : "google/gemini-2.0-flash-001",
      messages: [
        {
          role: "system",
          content: "Du bist ein medizinischer Experte für ICD-11 Klassifikation. Antworte immer in validem JSON.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.3,
      max_tokens: 2000,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`AI API error: ${response.status} - ${error}`);
  }

  const data = await response.json();
  const content = data.choices[0]?.message?.content || "{}";
  
  let parsed;
  try {
    const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/) || [null, content];
    parsed = JSON.parse(jsonMatch[1] || content);
  } catch {
    console.error("Failed to parse AI response:", content);
    parsed = {
      explanation: "Analyse konnte nicht generiert werden.",
      symptoms: [],
      diagnosis: "",
      therapy: "",
      hpo_mappings: [],
      snomed_mappings: [],
      symptom_mappings: [],
    };
  }

  return {
    content: {
      explanation: parsed.explanation,
      symptoms: parsed.symptoms,
      diagnosis: parsed.diagnosis,
      therapy: parsed.therapy,
      notes: parsed.notes,
    },
    hpo_mappings: parsed.hpo_mappings || [],
    snomed_mappings: parsed.snomed_mappings || [],
    symptom_mappings: parsed.symptom_mappings || [],
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const url = new URL(req.url);
    const urlParams = Object.fromEntries(url.searchParams);
    
    let bodyParams: AnalyzeRequest = { code: "" };
    if (req.method === "POST") {
      bodyParams = await req.json().catch(() => ({ code: "" }));
    }
    
    const params: AnalyzeRequest = { ...urlParams, ...bodyParams } as AnalyzeRequest;
    const { action = "get", code, title, forceRegenerate = false } = params;

    if (!code) {
      return new Response(
        JSON.stringify({ error: "Code is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check for existing analysis
    if (!forceRegenerate) {
      const { data: existing } = await supabase
        .from("icd11_analyses")
        .select("*")
        .eq("icd_code", code)
        .maybeSingle();

      if (existing) {
        return new Response(
          JSON.stringify({ success: true, analysis: existing, source: "cache" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    if (action === "get" && !forceRegenerate) {
      return new Response(
        JSON.stringify({ success: true, analysis: null, message: "No analysis found. Use action=generate to create one." }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get code details from icd11_codes table (now with JSONB labels)
    let codeTitle = title;
    let codeDefinition: string | undefined;
    
    // Check if code exists in local DB
    const { data: codeData } = await supabase
      .from("icd11_codes")
      .select("title, definition, labels, definitions")
      .eq("code", code)
      .maybeSingle();
    
    if (codeData) {
      // Prefer German label from JSONB if available
      codeTitle = codeTitle || codeData?.labels?.de || codeData?.title || code;
      codeDefinition = codeData?.definitions?.de || codeData?.definition;
    } else {
      // Code doesn't exist in DB - we need to create a minimal entry first
      // to satisfy the foreign key constraint
      console.log(`Code ${code} not in local DB, creating entry...`);
      
      const { error: insertError } = await supabase
        .from("icd11_codes")
        .upsert({
          code: code,
          title: codeTitle || code,
          title_short: null,
          definition: null,
          is_terminal: true,
        }, { onConflict: "code" });
      
      if (insertError) {
        console.error("Error creating code entry:", insertError);
        throw new Error(`Failed to create code entry: ${insertError.message}`);
      }
    }

    console.log(`Generating analysis for ICD-11 ${code}...`);
    const analysis = await generateAnalysis(code, codeTitle || code, codeDefinition);

    const { data: savedAnalysis, error: saveError } = await supabase
      .from("icd11_analyses")
      .upsert({
        icd_code: code,
        content: analysis.content,
        hpo_mappings: analysis.hpo_mappings,
        snomed_mappings: analysis.snomed_mappings,
        symptom_mappings: analysis.symptom_mappings,
        generated_at: new Date().toISOString(),
        generated_by: "ai",
        source_language: "de",
      }, { onConflict: "icd_code" })
      .select()
      .single();

    if (saveError) {
      console.error("Error saving analysis:", saveError);
      throw saveError;
    }

    return new Response(
      JSON.stringify({ success: true, analysis: savedAnalysis, source: "generated" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("ICD-11 analysis error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
