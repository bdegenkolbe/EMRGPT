import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SNOWSTORM_BASE_URL = "https://browser.ihtsdotools.org/snowstorm/snomed-ct";

// Supabase admin client for persisting codes
function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  return createClient(supabaseUrl, supabaseKey);
}

/**
 * Persist SNOMED codes to snomed_codes table for local caching
 */
async function persistSnomedCodes(concepts: SnomedConcept[]): Promise<void> {
  if (concepts.length === 0) return;
  
  const supabase = getSupabaseAdmin();
  
  const codesToInsert = concepts.map(c => ({
    sctid: c.conceptId,
    fsn: c.fsn?.term || '',
    pt: c.pt?.term || '',
    semantic_tag: extractSemanticTag(c.fsn?.term || ''),
    is_active: c.active,
    definition_status: c.definitionStatus,
    module_id: c.moduleId,
    labels: { 
      en: c.pt?.term || c.fsn?.term || '',
      de: c.pt?.lang === 'de' ? c.pt?.term : undefined 
    },
    source: 'snowstorm_api',
  }));
  
  try {
    const { data, error } = await supabase
      .from('snomed_codes')
      .upsert(codesToInsert, { onConflict: 'sctid' });
    
    if (error) {
      console.error('[SNOMED Persist] Database error:', error.message, error.details, error.hint);
    } else {
      console.log(`[SNOMED Persist] Successfully persisted ${codesToInsert.length} codes`);
    }
  } catch (error) {
    console.error('[SNOMED Persist] Exception:', error);
  }
}

function extractSemanticTag(fsn: string): string | null {
  const match = fsn.match(/\(([^)]+)\)$/);
  return match ? match[1] : null;
}
const DEFAULT_BRANCH = "MAIN";
const GERMAN_BRANCH = "MAIN/SNOMEDCT-DE";

interface SnomedConcept {
  conceptId: string;
  fsn: { term: string; lang: string };
  pt: { term: string; lang: string };
  active: boolean;
  definitionStatus: string;
  moduleId: string;
}

interface SearchResult {
  items: SnomedConcept[];
  total: number;
  limit: number;
  offset: number;
}

// Search SNOMED CT concepts by term
async function searchSnomedConcepts(
  query: string,
  limit: number = 20,
  language: string = "de"
): Promise<{ concepts: SnomedConcept[]; total: number }> {
  const branch = language === "de" ? GERMAN_BRANCH : DEFAULT_BRANCH;
  const encodedBranch = encodeURIComponent(branch);
  
  const params = new URLSearchParams({
    term: query,
    limit: String(limit),
    active: "true",
    conceptActive: "true",
    lang: language === "de" ? "de,en" : "en",
  });

  const response = await fetch(
    `${SNOWSTORM_BASE_URL}/browser/${encodedBranch}/concepts?${params}`,
    {
      headers: {
        Accept: "application/json",
        "Accept-Language": language === "de" ? "de" : "en",
      },
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Snowstorm API error ${response.status}: ${errorText}`);
  }

  const data: SearchResult = await response.json();
  const concepts = data.items || [];
  
  // Persist results to snomed_codes table (async, don't wait)
  persistSnomedCodes(concepts).catch(err => console.error('Persist error:', err));
  
  return {
    concepts,
    total: data.total || 0,
  };
}

// Get single concept by SCTID
async function getSnomedConcept(
  conceptId: string,
  language: string = "de"
): Promise<SnomedConcept | null> {
  const branch = language === "de" ? GERMAN_BRANCH : DEFAULT_BRANCH;
  const encodedBranch = encodeURIComponent(branch);

  const response = await fetch(
    `${SNOWSTORM_BASE_URL}/browser/${encodedBranch}/concepts/${conceptId}`,
    {
      headers: {
        Accept: "application/json",
        "Accept-Language": language === "de" ? "de" : "en",
      },
    }
  );

  if (response.status === 404) {
    return null;
  }

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Snowstorm API error ${response.status}: ${errorText}`);
  }

  return await response.json();
}

// Validate SNOMED CT code
async function validateSnomedCode(
  sctid: string,
  language: string = "de"
): Promise<{ valid: boolean; concept: SnomedConcept | null }> {
  try {
    const concept = await getSnomedConcept(sctid, language);
    return {
      valid: concept !== null && concept.active,
      concept,
    };
  } catch {
    return { valid: false, concept: null };
  }
}

// Execute ECL query
async function executeECL(
  expression: string,
  limit: number = 50,
  language: string = "de"
): Promise<{ concepts: SnomedConcept[]; total: number }> {
  const branch = language === "de" ? GERMAN_BRANCH : DEFAULT_BRANCH;
  const encodedBranch = encodeURIComponent(branch);

  const params = new URLSearchParams({
    ecl: expression,
    limit: String(limit),
    active: "true",
  });

  const response = await fetch(
    `${SNOWSTORM_BASE_URL}/browser/${encodedBranch}/concepts?${params}`,
    {
      headers: {
        Accept: "application/json",
        "Accept-Language": language === "de" ? "de" : "en",
      },
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`ECL query error ${response.status}: ${errorText}`);
  }

  const data: SearchResult = await response.json();
  return {
    concepts: data.items || [],
    total: data.total || 0,
  };
}

// Get concept descriptions (synonyms)
async function getConceptDescriptions(
  conceptId: string,
  language: string = "de"
): Promise<{ descriptions: Array<{ term: string; type: string; lang: string }> }> {
  const branch = language === "de" ? GERMAN_BRANCH : DEFAULT_BRANCH;
  const encodedBranch = encodeURIComponent(branch);

  const response = await fetch(
    `${SNOWSTORM_BASE_URL}/${encodedBranch}/concepts/${conceptId}/descriptions`,
    {
      headers: {
        Accept: "application/json",
        "Accept-Language": language === "de" ? "de" : "en",
      },
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Descriptions error ${response.status}: ${errorText}`);
  }

  const data = await response.json();
  return {
    descriptions: (data.items || []).map((d: { term: string; type: { fsn?: { term: string } }; lang: string }) => ({
      term: d.term,
      type: d.type?.fsn?.term || "Unknown",
      lang: d.lang,
    })),
  };
}

// Get concept hierarchy (parents/children)
async function getConceptHierarchy(
  conceptId: string,
  direction: "parents" | "children",
  language: string = "de"
): Promise<{ parents?: SnomedConcept[]; children?: SnomedConcept[] }> {
  const branch = language === "de" ? GERMAN_BRANCH : DEFAULT_BRANCH;
  const encodedBranch = encodeURIComponent(branch);

  try {
    const response = await fetch(
      `${SNOWSTORM_BASE_URL}/browser/${encodedBranch}/concepts/${conceptId}/${direction}?form=inferred`,
      {
        headers: {
          Accept: "application/json",
          "Accept-Language": language === "de" ? "de" : "en",
        },
      }
    );

    if (!response.ok) {
      // Graceful degradation: return empty arrays for non-existent/inactive concepts
      console.warn(`[SNOMED Hierarchy] Concept ${conceptId} not found or inactive (${response.status})`);
      return direction === "parents" ? { parents: [] } : { children: [] };
    }

    const data = await response.json();
    // Return with the correct key based on direction
    if (direction === "parents") {
      return { parents: data || [] };
    }
    return { children: data || [] };
  } catch (error) {
    console.error(`[SNOMED Hierarchy] Error for ${conceptId}:`, error);
    return direction === "parents" ? { parents: [] } : { children: [] };
  }
}

// Attempt to find HPO mapping for a SNOMED concept
// This uses ECL to find related phenotype concepts
async function mapSnomedToHPO(
  sctid: string,
  language: string = "de"
): Promise<{ mappings: Array<{ hpoCode: string; relationship: string }> }> {
  // SNOMED has limited direct HPO mappings
  // We search for concepts in the "Clinical finding" hierarchy that might map
  // In practice, you'd use a dedicated mapping service like UMLS
  const concept = await getSnomedConcept(sctid, language);
  
  if (!concept) {
    return { mappings: [] };
  }

  // For now, return empty - real implementation would use UMLS or OxO
  // This is a placeholder for cross-reference functionality
  return {
    mappings: [],
  };
}

// Map SNOMED concept to ICD-10 codes using SNOMED's official refsets
async function mapSnomedToICD10(
  sctid: string,
  language: string = "de"
): Promise<{ mappings: Array<{ code: string; name: string }> }> {
  const branch = language === "de" ? GERMAN_BRANCH : DEFAULT_BRANCH;
  const encodedBranch = encodeURIComponent(branch);

  try {
    // Use SNOMED's map API endpoint to get ICD-10 mappings
    // RefSet 447562003 is the ICD-10 complex map reference set
    const response = await fetch(
      `${SNOWSTORM_BASE_URL}/${encodedBranch}/members?referencedComponentId=${sctid}&referenceSet=447562003&active=true&limit=20`,
      {
        headers: {
          Accept: "application/json",
        },
      }
    );

    if (!response.ok) {
      // Try alternative: simple map refset
      const altResponse = await fetch(
        `${SNOWSTORM_BASE_URL}/${encodedBranch}/members?referencedComponentId=${sctid}&referenceSet=900000000000497000&active=true&limit=20`,
        {
          headers: {
            Accept: "application/json",
          },
        }
      );
      
      if (!altResponse.ok) {
        return { mappings: [] };
      }
      
      const altData = await altResponse.json();
      const mappings = (altData.items || [])
        .filter((item: { additionalFields?: { mapTarget?: string } }) => item.additionalFields?.mapTarget)
        .map((item: { additionalFields: { mapTarget: string } }) => ({
          code: item.additionalFields.mapTarget,
          name: item.additionalFields.mapTarget,
        }));
      
      return { mappings };
    }

    const data = await response.json();
    const mappings = (data.items || [])
      .filter((item: { additionalFields?: { mapTarget?: string } }) => item.additionalFields?.mapTarget)
      .map((item: { additionalFields: { mapTarget: string; mapAdvice?: string } }) => ({
        code: item.additionalFields.mapTarget,
        name: item.additionalFields.mapAdvice || item.additionalFields.mapTarget,
      }));

    return { mappings };
  } catch (error) {
    console.error("[SNOMED ICD-10 Mapping] Error:", error);
    return { mappings: [] };
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    
    // Merge URL query params and JSON body params for flexibility
    let bodyParams: Record<string, string> = {};
    if (req.method === "POST") {
      try {
        const body = await req.json();
        if (body && typeof body === "object") {
          bodyParams = Object.fromEntries(
            Object.entries(body).map(([k, v]) => [k, String(v)])
          );
        }
      } catch {
        // No JSON body or invalid JSON - that's fine
      }
    }
    
    // URL params take precedence over body params
    const getParam = (key: string, defaultValue?: string): string | null => {
      return url.searchParams.get(key) ?? bodyParams[key] ?? defaultValue ?? null;
    };
    
    const action = getParam("action", "search")!;
    const language = getParam("lang", "de")!;

    let result: unknown;

    switch (action) {
      case "search": {
        const query = getParam("q");
        if (!query || query.trim().length === 0) {
          // Graceful degradation: return empty results instead of 400 error
          result = { concepts: [], total: 0 };
          break;
        }
        const limit = parseInt(getParam("limit", "20")!, 10);
        result = await searchSnomedConcepts(query, limit, language);
        break;
      }

      case "validate": {
        const code = getParam("code");
        if (!code) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'code' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await validateSnomedCode(code, language);
        break;
      }

      case "lookup": {
        const conceptId = getParam("id");
        if (!conceptId) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'id' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const concept = await getSnomedConcept(conceptId, language);
        if (!concept) {
          return new Response(
            JSON.stringify({ error: "Concept not found" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = { concept };
        break;
      }

      case "descriptions": {
        const conceptId = getParam("id");
        if (!conceptId) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'id' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await getConceptDescriptions(conceptId, language);
        break;
      }

      case "parents": {
        const conceptId = getParam("id");
        if (!conceptId) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'id' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await getConceptHierarchy(conceptId, "parents", language);
        break;
      }

      case "children": {
        const conceptId = getParam("id");
        if (!conceptId) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'id' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await getConceptHierarchy(conceptId, "children", language);
        break;
      }

      case "ecl": {
        const expression = getParam("expression");
        if (!expression) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'expression' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const limit = parseInt(getParam("limit", "50")!, 10);
        result = await executeECL(expression, limit, language);
        break;
      }

      case "map-to-hpo": {
        const sctid = getParam("sctid");
        if (!sctid) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'sctid' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await mapSnomedToHPO(sctid, language);
        break;
      }

      case "icd10": {
        const sctid = getParam("sctid");
        if (!sctid) {
          return new Response(
            JSON.stringify({ error: "Query parameter 'sctid' is required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        result = await mapSnomedToICD10(sctid, language);
        break;
      }

      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${action}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("[SNOMED Lookup] Error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "SNOMED lookup failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
