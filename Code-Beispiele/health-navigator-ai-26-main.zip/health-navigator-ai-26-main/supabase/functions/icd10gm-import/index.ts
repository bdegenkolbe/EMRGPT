import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { ZipReader, Uint8ArrayReader, TextWriter } from "https://esm.sh/@zip.js/zip.js@2.7.52";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ImportResult {
  success: boolean;
  inserted: number;
  updated: number;
  skipped: number;
  errors: string[];
  year: number;
  format: "csv" | "claml";
}

interface ParsedCode {
  code: string;
  title: string;
  title_short: string | null;
  chapter: string | null;
  block: string | null;
  is_terminal: boolean;
  parent_code: string | null;
  year: number;
  notes: string | null;
  inclusions: string[] | null;
  exclusions: string[] | null;
}

// Map chapter ranges to Roman numerals
function getChapterFromCode(code: string): string | null {
  const first = code.charAt(0);
  const first2 = code.substring(0, 2);
  
  const ranges: [string, string, string][] = [
    ['A', 'B', 'I'],
    ['C', 'C', 'II'],
    ['D0', 'D4', 'II'],
    ['D5', 'D9', 'III'],
    ['E', 'E', 'IV'],
    ['F', 'F', 'V'],
    ['G', 'G', 'VI'],
    ['H0', 'H5', 'VII'],
    ['H6', 'H9', 'VIII'],
    ['I', 'I', 'IX'],
    ['J', 'J', 'X'],
    ['K', 'K', 'XI'],
    ['L', 'L', 'XII'],
    ['M', 'M', 'XIII'],
    ['N', 'N', 'XIV'],
    ['O', 'O', 'XV'],
    ['P', 'P', 'XVI'],
    ['Q', 'Q', 'XVII'],
    ['R', 'R', 'XVIII'],
    ['S', 'T', 'XIX'],
    ['V', 'Y', 'XX'],
    ['Z', 'Z', 'XXI'],
    ['U', 'U', 'XXII'],
  ];

  for (const [start, end, chapter] of ranges) {
    if (start.length === 2 || end.length === 2) {
      if (first2 >= start && first2 <= end) return chapter;
    } else {
      if (first >= start && first <= end) return chapter;
    }
  }
  return null;
}

// Derive parent code from ICD code
function deriveParentCode(code: string): string | null {
  let clean = code.replace(/\.$/, '');
  
  if (clean.includes('.')) {
    return clean.split('.')[0];
  }
  
  if (clean.length > 3) {
    return clean.slice(0, -1);
  }
  
  return null;
}

// Parse a single CSV line (handles quoted fields)
function parseCSVLine(line: string, delimiter = ';'): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];
    
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

function looksLikeIcdCode(value: string): boolean {
  if (!value) return false;
  const cleaned = value.trim().toUpperCase();
  return /^[A-Z]\d{2}(\.\d?|-)?$/.test(cleaned) || /^[A-Z]\d{2,3}$/.test(cleaned);
}

function looksLikeTitle(value: string): boolean {
  if (!value || value.length < 3) return false;
  const letterRatio = (value.match(/[a-zA-ZäöüÄÖÜß]/g) || []).length / value.length;
  return letterRatio > 0.5 && value.length >= 5;
}

function normalizeColumnName(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[_\s]+/g, " ")
    .trim();
}

function findColumnIndex(headers: string[], possibleNames: string[]): number {
  const normalizedHeaders = headers.map(h => h ? normalizeColumnName(String(h)) : "");
  const normalizedNames = possibleNames.map(normalizeColumnName);

  for (const name of normalizedNames) {
    const idx = normalizedHeaders.indexOf(name);
    if (idx !== -1) return idx;
  }

  for (const name of normalizedNames) {
    const idx = normalizedHeaders.findIndex(h => h.startsWith(name));
    if (idx !== -1) return idx;
  }

  for (const name of normalizedNames) {
    const idx = normalizedHeaders.findIndex(h => h.includes(name));
    if (idx !== -1) return idx;
  }

  return -1;
}

function detectColumnsFromData(lines: string[], startRow: number): { codeCol: number; titleCol: number } | null {
  const sampleSize = Math.min(10, lines.length - startRow);
  const candidates: Map<number, { codeCount: number; titleCount: number }> = new Map();
  
  for (let i = startRow; i < startRow + sampleSize; i++) {
    const line = lines[i]?.trim();
    if (!line) continue;
    
    const fields = parseCSVLine(line);
    fields.forEach((field, idx) => {
      if (!candidates.has(idx)) {
        candidates.set(idx, { codeCount: 0, titleCount: 0 });
      }
      const stats = candidates.get(idx)!;
      if (looksLikeIcdCode(field)) stats.codeCount++;
      if (looksLikeTitle(field)) stats.titleCount++;
    });
  }
  
  let bestCodeCol = -1;
  let bestCodeCount = 0;
  let bestTitleCol = -1;
  let bestTitleCount = 0;
  
  for (const [col, stats] of candidates) {
    if (stats.codeCount > bestCodeCount) {
      bestCodeCount = stats.codeCount;
      bestCodeCol = col;
    }
  }
  
  for (const [col, stats] of candidates) {
    if (col !== bestCodeCol && stats.titleCount > bestTitleCount) {
      bestTitleCount = stats.titleCount;
      bestTitleCol = col;
    }
  }
  
  if (bestCodeCol >= 0 && bestTitleCol >= 0 && bestCodeCount >= 3 && bestTitleCount >= 3) {
    return { codeCol: bestCodeCol, titleCol: bestTitleCol };
  }
  
  return null;
}

// ================== ClaML/XML Parser (Regex-based for Deno compatibility) ==================

// Simple regex-based XML attribute extractor
function getXmlAttribute(element: string, attrName: string): string | null {
  const regex = new RegExp(`${attrName}=["']([^"']*)["']`, 'i');
  const match = element.match(regex);
  return match ? match[1] : null;
}

// Extract text content between tags
function getTagContent(element: string, tagName: string): string | null {
  const regex = new RegExp(`<${tagName}[^>]*>([\\s\\S]*?)<\\/${tagName}>`, 'i');
  const match = element.match(regex);
  return match ? match[1].replace(/<[^>]*>/g, '').trim() : null;
}

// Get all matching elements
function getAllElements(content: string, tagName: string): string[] {
  const regex = new RegExp(`<${tagName}[\\s>][\\s\\S]*?<\\/${tagName}>`, 'gi');
  return content.match(regex) || [];
}

// Get Rubric label by kind
function getRubricLabelFromXml(classContent: string, kind: string): string | null {
  const rubrics = getAllElements(classContent, 'Rubric');
  for (const rubric of rubrics) {
    const rubricKind = getXmlAttribute(rubric, 'kind');
    if (rubricKind === kind) {
      const label = getTagContent(rubric, 'Label');
      if (label) return label;
    }
  }
  return null;
}

// Get all Rubric labels by kind
function getRubricLabelsFromXml(classContent: string, kind: string): string[] {
  const labels: string[] = [];
  const rubrics = getAllElements(classContent, 'Rubric');
  for (const rubric of rubrics) {
    const rubricKind = getXmlAttribute(rubric, 'kind');
    if (rubricKind === kind) {
      // Get all Label elements within this rubric
      const labelMatches = getAllElements(rubric, 'Label');
      for (const labelEl of labelMatches) {
        const text = labelEl.replace(/<[^>]*>/g, '').trim();
        if (text) labels.push(text);
      }
    }
  }
  return labels;
}

async function parseClaML(content: string, year: number): Promise<ParsedCode[]> {
  const codes: ParsedCode[] = [];
  
  // Extract all Class elements
  const classElements = getAllElements(content, 'Class');
  console.log(`Found ${classElements.length} Class elements in ClaML`);
  
  if (classElements.length === 0) {
    // Try alternative: some ClaML files use different structure
    console.log("No Class elements found, checking XML structure...");
    const sampleContent = content.substring(0, 2000);
    console.log("Sample content:", sampleContent);
    throw new Error("No Class elements found in ClaML XML");
  }
  
  // Build parent-child relationships
  const parentMap = new Map<string, string>();
  
  for (const classEl of classElements) {
    const code = getXmlAttribute(classEl, 'code');
    if (!code) continue;
    
    // Find SuperClass
    const superClassMatch = classEl.match(/<SuperClass[^>]*code=["']([^"']*)["'][^>]*\/?>/i);
    if (superClassMatch) {
      parentMap.set(code, superClassMatch[1]);
    }
  }
  
  for (const classEl of classElements) {
    const code = getXmlAttribute(classEl, 'code');
    const kind = getXmlAttribute(classEl, 'kind');
    
    if (!code) continue;
    
    // Skip chapter entries (I, II, III, etc.) - they don't have standard ICD codes
    if (kind === 'chapter') continue;
    
    // Get the preferred name/title
    const preferredName = getRubricLabelFromXml(classEl, 'preferred') || 
                          getRubricLabelFromXml(classEl, 'preferredLong') ||
                          getRubricLabelFromXml(classEl, 'text');
    
    if (!preferredName) continue;
    
    // Get additional information
    const shortName = getRubricLabelFromXml(classEl, 'preferredAbbreviation') || 
                      getRubricLabelFromXml(classEl, 'abbreviation');
    const definition = getRubricLabelFromXml(classEl, 'definition');
    const note = getRubricLabelFromXml(classEl, 'note');
    
    // Get inclusions and exclusions
    const inclusions = getRubricLabelsFromXml(classEl, 'inclusion');
    const exclusions = getRubricLabelsFromXml(classEl, 'exclusion');
    
    // Determine if terminal (endständig)
    // In ClaML, a code is terminal if it has no SubClass elements
    const hasSubClass = /<SubClass[^>]*>/i.test(classEl);
    const isTerminal = !hasSubClass;
    
    // Get chapter from code pattern
    const chapter = getChapterFromCode(code);
    
    // Determine block (group)
    let block: string | null = null;
    if (kind === 'block') {
      block = code;
    } else {
      // Try to find block from parent chain
      let currentCode = parentMap.get(code);
      while (currentCode) {
        // Blocks typically have format like "A00-A09"
        if (currentCode.includes('-')) {
          block = currentCode;
          break;
        }
        currentCode = parentMap.get(currentCode);
      }
    }
    
    // Build notes from definition and note
    const notes = [definition, note].filter(Boolean).join('\n\n') || null;
    
    const parsed: ParsedCode = {
      code: code.toUpperCase(),
      title: preferredName,
      title_short: shortName,
      chapter,
      block,
      is_terminal: isTerminal,
      parent_code: parentMap.get(code) || deriveParentCode(code),
      year,
      notes,
      inclusions: inclusions.length > 0 ? inclusions : null,
      exclusions: exclusions.length > 0 ? exclusions : null,
    };
    
    codes.push(parsed);
  }
  
  console.log(`Parsed ${codes.length} codes from ClaML`);
  return codes;
}

// ================== CSV Parser ==================

async function parseMetadataCSV(content: string, year: number): Promise<ParsedCode[]> {
  const lines = content.split(/\r?\n/);
  const codes: ParsedCode[] = [];
  
  let firstRow = 0;
  while (firstRow < lines.length && !lines[firstRow].trim()) {
    firstRow++;
  }
  
  if (firstRow >= lines.length) {
    throw new Error("Empty CSV file");
  }
  
  const firstRowFields = parseCSVLine(lines[firstRow].toLowerCase());
  console.log("First row fields:", firstRowFields.slice(0, 15));
  
  const possibleCodeHeaders = ['kode', 'code', 'icd_code', 'schluessel', 'diagnoseschluessel'];
  const possibleTitleHeaders = ['titel', 'title', 'bezeichnung', 'beschreibung', 'text', 'name'];
  
  let codeCol = findColumnIndex(firstRowFields, possibleCodeHeaders);
  let titleCol = findColumnIndex(firstRowFields, possibleTitleHeaders);
  let dataStartRow = firstRow;
  
  if (codeCol >= 0 && titleCol >= 0) {
    dataStartRow = firstRow + 1;
    console.log(`Found headers at row ${firstRow}: code=${codeCol}, title=${titleCol}`);
  } else {
    console.log("No headers detected, analyzing data patterns...");
    const detected = detectColumnsFromData(lines, firstRow);
    
    if (detected) {
      codeCol = detected.codeCol;
      titleCol = detected.titleCol;
      dataStartRow = firstRow;
      console.log(`Detected columns from data: code=${codeCol}, title=${titleCol}`);
    } else {
      console.log("Using fallback BfArM column positions...");
      const testFields = parseCSVLine(lines[firstRow]);
      
      for (let i = 0; i < testFields.length; i++) {
        if (looksLikeIcdCode(testFields[i])) {
          codeCol = i;
          break;
        }
      }
      
      if (codeCol >= 0) {
        for (let i = codeCol + 1; i < testFields.length; i++) {
          if (looksLikeTitle(testFields[i])) {
            titleCol = i;
            break;
          }
        }
      }
      
      if (codeCol < 0 || titleCol < 0) {
        throw new Error(`Could not detect code/title columns. First row: ${firstRowFields.slice(0, 20).join(', ')}`);
      }
      
      dataStartRow = firstRow;
    }
  }
  
  console.log(`Parsing data from row ${dataStartRow}, code col=${codeCol}, title col=${titleCol}`);
  
  for (let i = dataStartRow; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const fields = parseCSVLine(line);
    const code = fields[codeCol]?.trim();
    const title = fields[titleCol]?.trim();
    
    if (!code || !title) continue;
    if (possibleCodeHeaders.some(h => code.toLowerCase().includes(h))) continue;
    if (!looksLikeIcdCode(code)) continue;
    
    const isTerminal = !code.includes('-') && code.length >= 4;
    
    const parsed: ParsedCode = {
      code: code.toUpperCase(),
      title,
      title_short: title.length > 100 ? title.substring(0, 100) + '...' : null,
      chapter: getChapterFromCode(code),
      block: null,
      is_terminal: isTerminal,
      parent_code: deriveParentCode(code),
      year,
      notes: null,
      inclusions: null,
      exclusions: null,
    };
    
    codes.push(parsed);
  }
  
  console.log(`Parsed ${codes.length} codes from CSV`);
  return codes;
}

// ================== Main Handler ==================

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify admin access
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user } } = await userClient.auth.getUser();
    if (!user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: isAdmin } = await userClient.rpc("is_admin", { _user_id: user.id });
    if (!isAdmin) {
      return new Response(
        JSON.stringify({ error: "Admin access required" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse request
    const { file_path, year: requestYear, clear_existing = false } = await req.json();

    if (!file_path) {
      return new Response(
        JSON.stringify({ error: "file_path is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Auto-detect year from filename
    const yearMatch = file_path.match(/icd10gm(\d{4})/i);
    const detectedYear = yearMatch ? parseInt(yearMatch[1], 10) : null;
    const year = requestYear || detectedYear || new Date().getFullYear();

    console.log(`Starting ICD-10-GM import from ${file_path} for year ${year}`);

    // Download ZIP from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("icd10gm-imports")
      .download(file_path);

    if (downloadError || !fileData) {
      console.error("Download error:", downloadError);
      return new Response(
        JSON.stringify({ error: `Failed to download file: ${downloadError?.message}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Read ZIP contents
    const arrayBuffer = await fileData.arrayBuffer();
    const zipReader = new ZipReader(new Uint8ArrayReader(new Uint8Array(arrayBuffer)));
    const entries = await zipReader.getEntries();

    console.log(`ZIP contains ${entries.length} entries:`, entries.map(e => e.filename).join(', '));

    // Determine format: ClaML/XML or CSV
    let format: "csv" | "claml" = "csv";
    let contentEntry: typeof entries[0] | undefined;
    let fileContent = "";

    // Priority 1: Look for ClaML XML file
    const xmlEntry = entries.find(e => {
      const name = e.filename.toLowerCase();
      // Must be an actual .xml file, not PDFs or other files that happen to contain 'claml'
      return name.endsWith('.xml') && !name.startsWith('__macosx') && !name.includes('.xsd');
    });

    if (xmlEntry && xmlEntry.getData) {
      format = "claml";
      contentEntry = xmlEntry;
      console.log(`Found ClaML XML file: ${xmlEntry.filename}`);
    } else {
      // Priority 2: Look for main CSV/TXT file
      const excludePatterns = ['gruppen', 'kapitel', 'dreisteller', 'viersteller', 'ueberleitung', 'umsteiger'];
      
      contentEntry = entries.find(e => {
        const name = e.filename.toLowerCase();
        if (!name.endsWith('.txt')) return false;
        const baseName = name.split('/').pop() || '';
        return /icd10gm\d{4}syst\.txt$/.test(baseName);
      });
      
      if (!contentEntry) {
        contentEntry = entries.find(e => {
          const name = e.filename.toLowerCase();
          if (!name.endsWith('.txt')) return false;
          const hasRequiredPattern = name.includes('syst') || name.includes('kode');
          const hasExcludedPattern = excludePatterns.some(p => name.includes(p));
          return hasRequiredPattern && !hasExcludedPattern;
        });
      }
    }

    if (!contentEntry || !contentEntry.getData) {
      await zipReader.close();
      const availableFiles = entries.map(e => e.filename).join(', ');
      return new Response(
        JSON.stringify({ error: `No ClaML XML or metadata CSV found. Available files: ${availableFiles}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Extracting ${contentEntry.filename} (format: ${format})...`);
    fileContent = await contentEntry.getData(new TextWriter());
    await zipReader.close();

    // Parse based on format
    let rawCodes: ParsedCode[];
    if (format === "claml") {
      rawCodes = await parseClaML(fileContent, year);
    } else {
      rawCodes = await parseMetadataCSV(fileContent, year);
    }

    if (rawCodes.length === 0) {
      return new Response(
        JSON.stringify({ error: `No valid codes parsed from ${format.toUpperCase()}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Deduplicate codes
    const codeMap = new Map<string, ParsedCode>();
    for (const code of rawCodes) {
      codeMap.set(code.code, code);
    }
    const codes = Array.from(codeMap.values());
    console.log(`Deduplicated: ${rawCodes.length} raw -> ${codes.length} unique codes`);

    // Clear existing data if requested
    if (clear_existing) {
      console.log(`Clearing existing codes for year ${year}...`);
      const { error: deleteError } = await supabase
        .from("icd10gm_codes")
        .delete()
        .eq("year", year);

      if (deleteError) {
        console.error("Delete error:", deleteError);
      }
    }

    // Insert in batches
    const result: ImportResult = {
      success: true,
      inserted: 0,
      updated: 0,
      skipped: 0,
      errors: [],
      year,
      format,
    };

    const batchSize = 500;
    for (let i = 0; i < codes.length; i += batchSize) {
      const batch = codes.slice(i, i + batchSize);
      
      // Deduplicate within batch
      const batchMap = new Map<string, ParsedCode>();
      for (const code of batch) {
        batchMap.set(code.code, code);
      }
      const uniqueBatch = Array.from(batchMap.values());
      
      const { error: upsertError, count } = await supabase
        .from("icd10gm_codes")
        .upsert(uniqueBatch, { 
          onConflict: "code",
          ignoreDuplicates: false,
          count: "exact"
        });

      if (upsertError) {
        console.error(`Batch ${i / batchSize + 1} error:`, upsertError);
        result.errors.push(`Batch ${i / batchSize + 1}: ${upsertError.message}`);
      } else {
        result.inserted += count || uniqueBatch.length;
      }

      if (i % 5000 === 0 && i > 0) {
        console.log(`Progress: ${i}/${codes.length} codes processed`);
      }
    }

    result.success = result.errors.length === 0;

    console.log(`Import complete (${format}): ${result.inserted} codes imported, ${result.errors.length} errors`);

    // Clean up uploaded file
    await supabase.storage.from("icd10gm-imports").remove([file_path]);

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("ICD-10-GM import error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
