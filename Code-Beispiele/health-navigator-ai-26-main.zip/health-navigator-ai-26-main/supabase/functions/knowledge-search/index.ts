import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SearchRequest {
  query: string;
  language?: string;
  dateFrom?: string;
  dateTo?: string;
  sourceTypes?: string[];
  forceCategory?: string; // User override after clarification
  pmcLimit?: number; // Limit for Europe PMC results (default 25, max 100)
}

interface QueryClassification {
  category: 'literature' | 'knowledge_base' | 'inventory' | 'explanation' | 'combined';
  confidence: number;
  needs_clarification: boolean;
  clarification_options?: string[];
  suggested_sources: string[];
  extracted_keywords: string[];
  date_filter?: { from?: string; to?: string };
}

interface AuthorDetail {
  given: string;
  family: string;
  fullName: string;
  orcid?: string;
  affiliations?: string[];
}

interface SourcePreview {
  id: string;
  source_type: string;
  external_id?: string;
  title: string;
  authors?: string;
  authorDetails?: AuthorDetail[];
  year?: number;
  relevance_score?: number;
  url?: string;
  content_status: string;
  translation_status: string;
  original_language?: string;
  original_content?: string;
  // Extended metadata
  journal?: string;
  publicationDate?: string;
  doi?: string;
  pmid?: string;
  pmcid?: string;
  citedByCount?: number;
  isOpenAccess?: boolean;
  pdfUrl?: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
    const supabaseUser = createClient(supabaseUrl, supabaseServiceKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await supabaseUser.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: SearchRequest = await req.json();
    const { query, language = "de", dateFrom, dateTo, forceCategory, pmcLimit = 25 } = body;
    const effectivePmcLimit = Math.min(Math.max(pmcLimit, 10), 100); // Clamp between 10 and 100

    if (!query?.trim()) {
      return new Response(JSON.stringify({ error: "Query required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[knowledge-search] User ${user.id} searching: "${query}"`);

    // Get document count for context
    const { count: documentCount } = await supabaseAdmin
      .from("guidelines")
      .select("*", { count: "exact", head: true });

    // Step 1: Classify query using pipeline template
    let classification: QueryClassification = {
      category: 'combined',
      confidence: 0.5,
      needs_clarification: false,
      suggested_sources: ['guideline', 'europepmc'],
      extracted_keywords: query.split(/\s+/).filter(w => w.length > 3),
    };

    // Load classification template
    const { data: template } = await supabaseAdmin
      .from("prompt_templates")
      .select("system_prompt, user_prompt_template, model_config")
      .eq("name", "Wissenssuch-Klassifikation")
      .eq("phase", "classification")
      .eq("is_active", true)
      .single();

    if (template && lovableApiKey) {
      try {
        // Build user prompt from template
        const userPrompt = template.user_prompt_template
          ?.replace("{{query}}", query)
          .replace("{{language}}", language)
          .replace("{{document_count}}", String(documentCount || 0)) || query;

        const modelConfig = template.model_config as { model?: string; temperature?: number; max_tokens?: number } || {};

        const classifyResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${lovableApiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: modelConfig.model || "google/gemini-3-flash-preview",
            messages: [
              { role: "system", content: template.system_prompt },
              { role: "user", content: userPrompt }
            ],
            temperature: modelConfig.temperature || 0.1,
            max_tokens: modelConfig.max_tokens || 500,
          }),
        });

        if (classifyResponse.ok) {
          const classifyData = await classifyResponse.json();
          const content = classifyData.choices?.[0]?.message?.content || "";
          const jsonMatch = content.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]);
            classification = { ...classification, ...parsed };
            console.log(`[knowledge-search] Classification:`, classification);
          }
        }
      } catch (e) {
        console.warn("[knowledge-search] Classification failed, using defaults:", e);
      }
    }

    // Allow user to override category after clarification
    if (forceCategory) {
      classification.category = forceCategory as QueryClassification['category'];
      classification.needs_clarification = false;
      console.log(`[knowledge-search] User forced category: ${forceCategory}`);
    }

    // If clarification needed, return early with options
    if (classification.needs_clarification && classification.clarification_options?.length) {
      return new Response(
        JSON.stringify({
          needsClarification: true,
          classification,
          options: classification.clarification_options,
          query: query.trim(),
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Handle inventory queries
    if (classification.category === 'inventory') {
      console.log("[knowledge-search] Handling inventory query");
      
      const { data: guidelines } = await supabaseAdmin
        .from("guidelines")
        .select("id, title, source, version, embedding_status, total_chunks, created_at");
      
      const guidelinesList = guidelines || [];
      const statusCounts = {
        completed: guidelinesList.filter(g => g.embedding_status === 'completed').length,
        pending: guidelinesList.filter(g => g.embedding_status === 'pending').length,
        processing: guidelinesList.filter(g => g.embedding_status === 'processing').length,
        error: guidelinesList.filter(g => g.embedding_status === 'error').length,
      };
      
      let inventoryResponse = `**Ihre Wissensdatenbank enthält ${guidelinesList.length} Dokument${guidelinesList.length !== 1 ? 'e' : ''}.**\n\n`;
      
      if (guidelinesList.length > 0) {
        inventoryResponse += `**Status-Übersicht:**\n`;
        if (statusCounts.completed > 0) inventoryResponse += `- ✅ ${statusCounts.completed} vollständig verarbeitet\n`;
        if (statusCounts.pending > 0) inventoryResponse += `- ⏳ ${statusCounts.pending} ausstehend\n`;
        if (statusCounts.processing > 0) inventoryResponse += `- 🔄 ${statusCounts.processing} in Bearbeitung\n`;
        if (statusCounts.error > 0) inventoryResponse += `- ❌ ${statusCounts.error} mit Fehlern\n`;
        
        inventoryResponse += `\n**Dokumentenliste:**\n`;
        for (const g of guidelinesList) {
          const statusIcon = g.embedding_status === 'completed' ? '✅' : 
                             g.embedding_status === 'pending' ? '⏳' :
                             g.embedding_status === 'processing' ? '🔄' : '❌';
          inventoryResponse += `- ${statusIcon} **${g.title}** (${g.source || 'Unbekannt'}${g.version ? `, v${g.version}` : ''})`;
          if (g.total_chunks) inventoryResponse += ` - ${g.total_chunks} Textabschnitte`;
          inventoryResponse += `\n`;
        }
      } else {
        inventoryResponse += `\nSie haben noch keine Dokumente hochgeladen. Gehen Sie zum Tab "Verwaltung", um Leitlinien hinzuzufügen.`;
      }

      const { data: searchRecord } = await supabaseAdmin
        .from("knowledge_searches")
        .insert({
          user_id: user.id,
          query: query.trim(),
          query_analysis: { ...classification, intent: 'inventory' },
          language,
          ai_response: inventoryResponse,
          answer_generated_at: new Date().toISOString(),
        })
        .select()
        .single();

      return new Response(
        JSON.stringify({
          searchId: searchRecord?.id,
          query: query.trim(),
          classification,
          queryAnalysis: { intent: 'inventory', topic: query, keywords: [] },
          sources: [],
          totalSources: 0,
          inventoryResponse,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Determine which sources to search based on classification
    let sourceTypes: string[] = [];
    switch (classification.category) {
      case 'literature':
        sourceTypes = ['europepmc'];
        break;
      case 'knowledge_base':
      case 'explanation':
        sourceTypes = ['guideline'];
        break;
      case 'combined':
      default:
        sourceTypes = ['guideline', 'europepmc'];
        break;
    }

    // Apply date filters
    const effectiveDateFrom = dateFrom || classification.date_filter?.from;
    const effectiveDateTo = dateTo || classification.date_filter?.to;

    // Create search record
    const { data: searchRecord, error: searchError } = await supabaseAdmin
      .from("knowledge_searches")
      .insert({
        user_id: user.id,
        query: query.trim(),
        query_analysis: { 
          ...classification,
          intent: classification.category === 'literature' ? 'search' : 'question',
          topic: query,
          keywords: classification.extracted_keywords,
        },
        language,
      })
      .select()
      .single();

    if (searchError) {
      console.error("[knowledge-search] Failed to create search record:", searchError);
      throw searchError;
    }

    const searchId = searchRecord.id;
    const allSources: SourcePreview[] = [];

    // Parallel search
    const searchPromises: Promise<void>[] = [];
    
    // Build intelligent search query for Europe PMC (English, Boolean structured)
    let pmcSearchQuery = query;
    
    if (sourceTypes.includes("europepmc") && lovableApiKey) {
      try {
        console.log("[knowledge-search] Building intelligent PMC query...");
        const queryBuildResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${lovableApiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "google/gemini-3-flash-preview",
            messages: [
              { 
                role: "system", 
                content: `Du bist ein Experte für medizinische Literaturrecherche. Deine Aufgabe ist es, aus einer deutschen Suchanfrage eine optimale Europe PMC Suchanfrage zu generieren.

REGELN:
1. Übersetze alle medizinischen Begriffe ins Englische
2. Verwende MeSH-konforme Begriffe UND gängige Synonyme/Abkürzungen (z.B. "type 2 diabetes" OR "diabetes mellitus type 2" OR T2DM)
3. Gruppiere Synonyme mit OR in Klammern: ("term1" OR "term2" OR term3)
4. Verbinde Hauptkonzepte mit AND
5. Verwende Anführungszeichen für mehrwörtige Begriffe
6. Füge am Ende IMMER hinzu: AND (HAS_FT:Y) - dies filtert auf Artikel mit Volltext
7. Halte die Query kompakt aber vollständig

BEISPIELE:
- Input: "Diagnose von Diabetes Typ 2"
  Output: ("type 2 diabetes" OR "diabetes mellitus type 2" OR T2DM) AND (diagnosis OR diagnostic OR "diagnostic criteria" OR screening) AND (HAS_FT:Y)

- Input: "Hypertonie Behandlung bei älteren Patienten"
  Output: (hypertension OR "high blood pressure" OR "arterial hypertension") AND (treatment OR therapy OR management) AND (elderly OR aged OR "older adults" OR geriatric) AND (HAS_FT:Y)

- Input: "Kopfschmerzen Differentialdiagnose"
  Output: (headache OR cephalalgia OR migraine) AND ("differential diagnosis" OR "differential diagnoses" OR etiology) AND (HAS_FT:Y)

- Input: "Herzinsuffizienz Therapie"
  Output: ("heart failure" OR "cardiac failure" OR "congestive heart failure" OR CHF) AND (treatment OR therapy OR management OR pharmacotherapy) AND (HAS_FT:Y)

WICHTIG: 
- IMMER mit AND (HAS_FT:Y) enden für Volltextzugriff
- Mindestens 2-3 Synonyme pro Hauptbegriff verwenden
- Antworte NUR mit der Query, keine Erklärungen.`
              },
              { role: "user", content: query }
            ],
            temperature: 0.1,
            max_tokens: 400,
          }),
        });

        if (queryBuildResponse.ok) {
          const queryData = await queryBuildResponse.json();
          const builtQuery = queryData.choices?.[0]?.message?.content?.trim();
          if (builtQuery && builtQuery.length > 5) {
            pmcSearchQuery = builtQuery;
            // Ensure HAS_FT:Y is present
            if (!pmcSearchQuery.includes("HAS_FT:Y")) {
              pmcSearchQuery += " AND (HAS_FT:Y)";
            }
            console.log(`[knowledge-search] Built PMC query: ${pmcSearchQuery}`);
          }
        }
      } catch (e) {
        console.warn("[knowledge-search] Query building failed, using original:", e);
        // Fallback: add HAS_FT:Y to original query
        pmcSearchQuery = `(${query}) AND (HAS_FT:Y)`;
      }
    }
    
    const searchKeywords = classification.extracted_keywords.length > 0 
      ? classification.extracted_keywords.join(" ") 
      : query;

    // Search local guidelines (RAG)
    if (sourceTypes.includes("guideline")) {
      searchPromises.push((async () => {
        try {
          const { data: ragData } = await supabaseUser.functions.invoke("guidelines-search", {
            body: {
              query: searchKeywords,
              match_count: 25,
              match_threshold: 0.4,
            },
          });

          if (ragData?.results?.length) {
            const guidelineMap = new Map<string, typeof ragData.results[0]>();
            for (const result of ragData.results) {
              if (!guidelineMap.has(result.guideline_id)) {
                guidelineMap.set(result.guideline_id, result);
              }
            }

            for (const [guidelineId, result] of guidelineMap) {
              allSources.push({
                id: crypto.randomUUID(),
                source_type: "guideline",
                external_id: guidelineId,
                title: result.guideline_title,
                relevance_score: result.similarity,
                content_status: "loaded",
                translation_status: "skipped",
                original_language: "de",
                original_content: result.content,
              });
            }
          }
        } catch (e) {
          console.warn("[knowledge-search] Guidelines search failed:", e);
        }
      })());
    }

    // Search Europe PMC with 80/10/10 strategy: Relevance / Newest / Most Cited
    if (sourceTypes.includes("europepmc")) {
      searchPromises.push((async () => {
        try {
          // Use the intelligent query built earlier
          let pmcQuery = pmcSearchQuery;
          if (effectiveDateFrom || effectiveDateTo) {
            const fromYear = effectiveDateFrom ? new Date(effectiveDateFrom).getFullYear() : 1900;
            const toYear = effectiveDateTo ? new Date(effectiveDateTo).getFullYear() : new Date().getFullYear();
            pmcQuery += ` AND (PUB_YEAR:[${fromYear} TO ${toYear}])`;
          }
          
          console.log(`[knowledge-search] Final Europe PMC query: ${pmcQuery}, limit: ${effectivePmcLimit}`);

          // Calculate quotas: 80% relevance, 10% newest, 10% most cited
          const relevanceQuota = Math.ceil(effectivePmcLimit * 0.8);
          const dateQuota = Math.ceil(effectivePmcLimit * 0.1);
          const citedQuota = effectivePmcLimit - relevanceQuota - dateQuota; // Remainder
          
          console.log(`[knowledge-search] Quotas: relevance=${relevanceQuota}, date=${dateQuota}, cited=${citedQuota}`);

          const seenIds = new Set<string>();
          const pmcSources: SourcePreview[] = [];
          
          // Check for existing sources in database to avoid duplicates and reuse translations
          const checkExistingSource = async (externalId: string): Promise<{ exists: boolean; translatedContent?: string; translatedTitle?: string } | null> => {
            try {
              const { data } = await supabaseAdmin
                .from("knowledge_sources")
                .select("id, translated_content, translated_title, translation_status, target_language")
                .eq("external_id", externalId)
                .eq("target_language", language)
                .order("created_at", { ascending: false })
                .limit(1)
                .maybeSingle();
              
              if (data) {
                return {
                  exists: true,
                  translatedContent: data.translation_status === 'completed' ? data.translated_content : undefined,
                  translatedTitle: data.translation_status === 'completed' ? data.translated_title : undefined,
                };
              }
              return null;
            } catch {
              return null;
            }
          };

          // Helper to convert article to source with cache check
          const articleToSource = async (article: any): Promise<SourcePreview> => {
            const hasAbstract = !!article.abstract?.trim();
            const externalId = article.pmid || article.pmcid || article.id;
            
            // Check if we already have a translation for this article
            const existingData = await checkExistingSource(externalId);
            
            // Build full author list with details if available
            let authorsString = "";
            if (article.authorDetails && article.authorDetails.length > 0) {
              authorsString = article.authorDetails.map((a: AuthorDetail) => a.fullName).join(", ");
            } else if (article.authors && article.authors.length > 0) {
              authorsString = article.authors.join(", ");
            }
            
            // Determine translation status based on cache
            let translationStatus = hasAbstract ? "pending" : "pending";
            let translatedContent: string | undefined;
            let translatedTitle: string | undefined;
            
            if (existingData?.translatedContent) {
              translationStatus = "completed";
              translatedContent = existingData.translatedContent;
              translatedTitle = existingData.translatedTitle;
              console.log(`[knowledge-search] Reusing cached translation for ${externalId}`);
            }
            
            return {
              id: crypto.randomUUID(),
              source_type: "europepmc",
              external_id: externalId,
              title: translatedTitle || article.title,
              authors: authorsString,
              authorDetails: article.authorDetails,
              year: article.year,
              url: article.fullTextUrl || article.pdfUrl || article.europePmcUrl || 
                   (article.pmcid ? `https://europepmc.org/article/PMC/${article.pmcid}` : 
                    article.pmid ? `https://europepmc.org/article/MED/${article.pmid}` : undefined),
              relevance_score: article.citedByCount ? Math.min(1, article.citedByCount / 100) : 0.5,
              content_status: hasAbstract ? "loaded" : "pending",
              translation_status: translationStatus,
              original_language: "en",
              original_content: hasAbstract ? article.abstract : undefined,
              // Extended metadata
              journal: article.journal || undefined,
              publicationDate: article.publicationDate || undefined,
              doi: article.doi || undefined,
              pmid: article.pmid || undefined,
              pmcid: article.pmcid || undefined,
              citedByCount: article.citedByCount || undefined,
              isOpenAccess: article.isOpenAccess || false,
              pdfUrl: article.pdfUrl || 
                (article.pmcid ? `https://europepmc.org/backend/ptpmcrender.fcgi?accid=${article.pmcid.startsWith('PMC') ? article.pmcid : 'PMC' + article.pmcid}&blobtype=pdf` : undefined),
            };
          };

          // Fetch all three sorted results in parallel
          const [relevanceResult, dateResult, citedResult] = await Promise.all([
            // 1. Relevance sort (Europe PMC default relevance ranking)
            supabaseUser.functions.invoke("evidence-europepmc", {
              body: { query: pmcQuery, limit: relevanceQuota + 30, resultType: "core" }, // No sort = relevance
            }),
            // 2. Sort by date (newest first)
            supabaseUser.functions.invoke("evidence-europepmc", {
              body: { query: pmcQuery, limit: dateQuota + 20, resultType: "core", sort: "P_PDATE_D desc" },
            }),
            // 3. Sort by citations (most cited first)
            supabaseUser.functions.invoke("evidence-europepmc", {
              body: { query: pmcQuery, limit: citedQuota + 20, resultType: "core", sort: "CITED desc" },
            }),
          ]);

          // 1. First load relevance results (80%)
          const relevanceArticles = relevanceResult.data?.articles || [];
          console.log(`[knowledge-search] Fetched ${relevanceArticles.length} relevance articles`);
          
          for (const article of relevanceArticles) {
            const externalId = article.pmid || article.pmcid || article.id;
            if (!seenIds.has(externalId) && pmcSources.length < relevanceQuota) {
              seenIds.add(externalId);
              const source = await articleToSource(article);
              pmcSources.push(source);
            }
          }

          // 2. Then add date-sorted results (newest first - 10%)
          const dateArticles = dateResult.data?.articles || [];
          console.log(`[knowledge-search] Fetched ${dateArticles.length} date-sorted articles`);
          
          for (const article of dateArticles) {
            const externalId = article.pmid || article.pmcid || article.id;
            if (!seenIds.has(externalId) && pmcSources.length < relevanceQuota + dateQuota) {
              seenIds.add(externalId);
              const source = await articleToSource(article);
              pmcSources.push(source);
            }
          }

          // 3. Then add cited results (most cited - 10%)
          const citedArticles = citedResult.data?.articles || [];
          console.log(`[knowledge-search] Fetched ${citedArticles.length} citation-sorted articles`);
          
          for (const article of citedArticles) {
            const externalId = article.pmid || article.pmcid || article.id;
            if (!seenIds.has(externalId) && pmcSources.length < effectivePmcLimit) {
              seenIds.add(externalId);
              const source = await articleToSource(article);
              // Boost cited articles slightly
              source.relevance_score = (source.relevance_score || 0.5) + 0.05;
              pmcSources.push(source);
            }
          }

          // 4. If we still need more, alternate between date and cited to fill up
          if (pmcSources.length < effectivePmcLimit) {
            const remainingDateArticles = dateArticles.filter(a => !seenIds.has(a.pmid || a.pmcid || a.id));
            const remainingCitedArticles = citedArticles.filter(a => !seenIds.has(a.pmid || a.pmcid || a.id));
            
            let dateIdx = 0;
            let citedIdx = 0;
            let useDate = true;
            
            while (pmcSources.length < effectivePmcLimit && (dateIdx < remainingDateArticles.length || citedIdx < remainingCitedArticles.length)) {
              if (useDate && dateIdx < remainingDateArticles.length) {
                const article = remainingDateArticles[dateIdx++];
                const externalId = article.pmid || article.pmcid || article.id;
                if (!seenIds.has(externalId)) {
                  seenIds.add(externalId);
                  const source = await articleToSource(article);
                  pmcSources.push(source);
                }
              } else if (!useDate && citedIdx < remainingCitedArticles.length) {
                const article = remainingCitedArticles[citedIdx++];
                const externalId = article.pmid || article.pmcid || article.id;
                if (!seenIds.has(externalId)) {
                  seenIds.add(externalId);
                  const source = await articleToSource(article);
                  source.relevance_score = (source.relevance_score || 0.5) + 0.05;
                  pmcSources.push(source);
                }
              }
              // Alternate between date and cited
              useDate = !useDate;
            }
          }

          // 5. Last resort: fill from remaining relevance articles
          for (const article of relevanceArticles) {
            const externalId = article.pmid || article.pmcid || article.id;
            if (!seenIds.has(externalId) && pmcSources.length < effectivePmcLimit) {
              seenIds.add(externalId);
              const source = await articleToSource(article);
              pmcSources.push(source);
            }
          }

          console.log(`[knowledge-search] Loaded ${pmcSources.length} unique PMC articles (${relevanceArticles.length} relevance, ${dateArticles.length} dated, ${citedArticles.length} cited)`);
          allSources.push(...pmcSources);
        } catch (e) {
          console.warn("[knowledge-search] EuropePMC search failed:", e);
        }
      })());
    }

    await Promise.all(searchPromises);

    // Sort by relevance
    allSources.sort((a, b) => (b.relevance_score || 0) - (a.relevance_score || 0));

    // Store sources
    if (allSources.length > 0) {
      const sourcesToInsert = allSources.map((s) => ({
        id: s.id,
        search_id: searchId,
        source_type: s.source_type,
        external_id: s.external_id,
        title: s.title,
        authors: s.authors || null,
        year: s.year,
        relevance_score: s.relevance_score,
        url: s.url,
        content_status: s.content_status,
        translation_status: s.translation_status,
        original_language: s.original_language,
        original_content: s.original_content,
        target_language: language,
        metadata: {
          authorDetails: s.authorDetails || [],
          journal: s.journal,
          publicationDate: s.publicationDate,
          doi: s.doi,
          pmid: s.pmid,
          pmcid: s.pmcid,
          citedByCount: s.citedByCount,
          isOpenAccess: s.isOpenAccess,
          pdfUrl: s.pdfUrl,
        },
      }));

      const { error: insertError } = await supabaseAdmin
        .from("knowledge_sources")
        .insert(sourcesToInsert);

      if (insertError) {
        console.error("[knowledge-search] Failed to insert sources:", insertError);
      }
    }

    // Create background jobs for content loading, translation, and PDF downloads
    // These run autonomously in the backend even if the user closes the browser
    const batchId = crypto.randomUUID();
    const jobsToInsert: Array<{
      job_type: string;
      search_id: string;
      source_id: string;
      payload: Record<string, unknown>;
      batch_id: string;
    }> = [];

    for (const source of allSources) {
      // Content load + translation job
      if (source.content_status === "pending" || 
          (source.content_status === "loaded" && source.translation_status === "pending" && source.original_language !== language)) {
        jobsToInsert.push({
          job_type: "content_load",
          search_id: searchId,
          source_id: source.id,
          payload: { sourceId: source.id, targetLanguage: language },
          batch_id: batchId,
        });
      }

      // PDF download job for Open Access articles with PMC ID
      if (source.source_type === "europepmc" && source.pmcid && source.isOpenAccess) {
        jobsToInsert.push({
          job_type: "pdf_download",
          search_id: searchId,
          source_id: source.id,
          payload: {
            pmcid: source.pmcid,
            title: source.title,
            metadata: {
              authors: source.authorDetails?.map((a: AuthorDetail) => a.fullName) || [],
              journal: source.journal,
              publicationDate: source.publicationDate,
              doi: source.doi,
              abstract: source.original_content,
            },
          },
          batch_id: batchId,
        });
      }
    }

    if (jobsToInsert.length > 0) {
      console.log(`[knowledge-search] Creating ${jobsToInsert.length} background jobs (batch: ${batchId})`);
      
      const { error: jobInsertError } = await supabaseAdmin
        .from("background_jobs")
        .insert(jobsToInsert);

      if (jobInsertError) {
        console.error("[knowledge-search] Failed to insert background jobs:", jobInsertError);
      } else {
        // Start the background job runner (fire-and-forget)
        fetch(`${supabaseUrl}/functions/v1/background-job-runner`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${supabaseServiceKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ batchId, batchSize: 5 }),
        }).catch(e => console.warn("[knowledge-search] Failed to start job runner:", e));
      }
    }

    // Store pmcQuery in search record for history restoration
    const pmcQueryFinal = sourceTypes.includes("europepmc") ? pmcSearchQuery : undefined;
    if (pmcQueryFinal) {
      await supabaseAdmin
        .from("knowledge_searches")
        .update({
          query_analysis: {
            ...classification,
            intent: classification.category === 'literature' ? 'search' : 'question',
            topic: query,
            keywords: classification.extracted_keywords,
            pmcQuery: pmcQueryFinal,
          }
        })
        .eq("id", searchId);
    }

    // Transform sources to include metadata object for frontend compatibility
    const sourcesWithMetadata = allSources.map(s => ({
      id: s.id,
      source_type: s.source_type,
      external_id: s.external_id,
      title: s.title,
      authors: s.authors,
      year: s.year,
      relevance_score: s.relevance_score,
      url: s.url,
      content_status: s.content_status,
      translation_status: s.translation_status,
      original_language: s.original_language,
      original_content: s.original_content,
      metadata: {
        authorDetails: s.authorDetails || [],
        journal: s.journal,
        publicationDate: s.publicationDate,
        doi: s.doi,
        pmid: s.pmid,
        pmcid: s.pmcid,
        citedByCount: s.citedByCount,
        isOpenAccess: s.isOpenAccess,
        pdfUrl: s.pdfUrl,
      },
    }));

    return new Response(
      JSON.stringify({
        searchId,
        query: query.trim(),
        classification,
        queryAnalysis: {
          intent: classification.category === 'literature' ? 'search' : 'question',
          topic: query,
          keywords: classification.extracted_keywords,
          dateRange: classification.date_filter,
        },
        sources: sourcesWithMetadata,
        totalSources: allSources.length,
        pmcQuery: pmcQueryFinal,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("[knowledge-search] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
