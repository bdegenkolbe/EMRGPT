import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface IntegrationRequest {
  action: "create" | "update" | "delete" | "test";
  integrationId?: string;
  provider?: string;
  name?: string;
  apiKey?: string;
  isActive?: boolean;
}

async function testProvider(provider: string, apiKey: string): Promise<{ success: boolean; message: string }> {
  try {
    if (provider === "gemini") {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: "Hello" }] }],
            generationConfig: { maxOutputTokens: 10 },
          }),
        }
      );
      
      if (response.ok) {
        return { success: true, message: "Gemini API-Verbindung erfolgreich" };
      } else {
        const error = await response.text();
        return { success: false, message: `Gemini Fehler: ${error}` };
      }
    }

    if (provider === "openai") {
      const response = await fetch("https://api.openai.com/v1/models", {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      
      if (response.ok) {
        return { success: true, message: "OpenAI API-Verbindung erfolgreich" };
      } else {
        const error = await response.text();
        return { success: false, message: `OpenAI Fehler: ${error}` };
      }
    }

    if (provider === "ncbi") {
      const response = await fetch(
        `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/einfo.fcgi?api_key=${apiKey}&retmode=json`
      );
      
      if (response.ok) {
        return { success: true, message: "NCBI API-Verbindung erfolgreich" };
      } else {
        return { success: false, message: "NCBI API-Verbindung fehlgeschlagen" };
      }
    }

    return { success: false, message: "Unbekannter Provider" };
  } catch (error) {
    return { success: false, message: `Verbindungsfehler: ${error.message}` };
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify user is admin
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check admin role
    const { data: isAdmin } = await userClient.rpc("is_admin", { _user_id: user.id });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Admin access required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: IntegrationRequest = await req.json();
    const { action, integrationId, provider, name, apiKey, isActive } = body;

    // Use service role for admin operations
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    switch (action) {
      case "test": {
        if (!provider || !apiKey) {
          return new Response(
            JSON.stringify({ error: "Provider and API key required for test" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const result = await testProvider(provider, apiKey);
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "create": {
        if (!provider || !name) {
          return new Response(
            JSON.stringify({ error: "Provider and name required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        // Store API key in vault if provided
        let vaultSecretId: string | null = null;
        if (apiKey) {
          const { data: secretData, error: secretError } = await adminClient.rpc(
            "vault.create_secret",
            { secret: apiKey, name: `${provider}_api_key_${Date.now()}` }
          );
          
          if (secretError) {
            console.error("Vault error:", secretError);
            // Continue without vault - API key won't be stored securely
          } else {
            vaultSecretId = secretData;
          }
        }

        const { data: integration, error: createError } = await adminClient
          .from("integrations")
          .insert({
            provider,
            name,
            is_active: isActive ?? false,
            vault_secret_id: vaultSecretId,
          })
          .select()
          .single();

        if (createError) {
          return new Response(JSON.stringify({ error: createError.message }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        return new Response(JSON.stringify({ integration }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "update": {
        if (!integrationId) {
          return new Response(
            JSON.stringify({ error: "Integration ID required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const updates: Record<string, unknown> = {};
        if (name !== undefined) updates.name = name;
        if (isActive !== undefined) updates.is_active = isActive;

        const { data: integration, error: updateError } = await adminClient
          .from("integrations")
          .update(updates)
          .eq("id", integrationId)
          .select()
          .single();

        if (updateError) {
          return new Response(JSON.stringify({ error: updateError.message }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        return new Response(JSON.stringify({ integration }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "delete": {
        if (!integrationId) {
          return new Response(
            JSON.stringify({ error: "Integration ID required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const { error: deleteError } = await adminClient
          .from("integrations")
          .delete()
          .eq("id", integrationId);

        if (deleteError) {
          return new Response(JSON.stringify({ error: deleteError.message }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      default:
        return new Response(
          JSON.stringify({ error: "Invalid action" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error) {
    console.error("Integration management error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
