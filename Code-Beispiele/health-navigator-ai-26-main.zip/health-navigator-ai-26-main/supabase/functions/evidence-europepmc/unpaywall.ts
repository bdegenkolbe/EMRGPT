// Unpaywall API helper for checking Open Access status via DOI

export interface UnpaywallOaLocation {
  url: string;
  url_for_pdf: string | null;
  url_for_landing_page: string;
  evidence: string;
  license: string | null;
  version: string;
  host_type: string;
  is_best: boolean;
  pmh_id: string | null;
  endpoint_id: string | null;
  repository_institution: string | null;
}

export interface UnpaywallResponse {
  doi: string;
  doi_url: string;
  title: string;
  genre: string;
  is_oa: boolean;
  journal_is_oa: boolean;
  journal_is_in_doaj: boolean;
  journal_issns: string;
  journal_issn_l: string;
  journal_name: string;
  publisher: string;
  published_date: string;
  updated: string;
  oa_status: "gold" | "green" | "hybrid" | "bronze" | "closed";
  best_oa_location: UnpaywallOaLocation | null;
  first_oa_location: UnpaywallOaLocation | null;
  oa_locations: UnpaywallOaLocation[];
  oa_locations_embargoed: UnpaywallOaLocation[];
}

/**
 * Check Open Access status via Unpaywall API
 */
export async function checkUnpaywallOA(doi: string): Promise<{
  isOpenAccess: boolean;
  oaStatus: string | null;
  pdfUrl: string | null;
  landingPageUrl: string | null;
  license: string | null;
  source: string | null;
}> {
  const email = "anamnesis-app@example.com"; // Required by Unpaywall
  const url = `https://api.unpaywall.org/v2/${encodeURIComponent(doi)}?email=${email}`;

  try {
    const response = await fetch(url, {
      headers: { Accept: "application/json" },
    });

    if (!response.ok) {
      if (response.status === 404) {
        return {
          isOpenAccess: false,
          oaStatus: null,
          pdfUrl: null,
          landingPageUrl: null,
          license: null,
          source: null,
        };
      }
      throw new Error(`Unpaywall API error: ${response.status}`);
    }

    const data: UnpaywallResponse = await response.json();

    return {
      isOpenAccess: data.is_oa,
      oaStatus: data.oa_status,
      pdfUrl: data.best_oa_location?.url_for_pdf || null,
      landingPageUrl: data.best_oa_location?.url_for_landing_page || null,
      license: data.best_oa_location?.license || null,
      source: data.best_oa_location?.host_type || null,
    };
  } catch (error) {
    console.error("Unpaywall lookup error:", error);
    return {
      isOpenAccess: false,
      oaStatus: null,
      pdfUrl: null,
      landingPageUrl: null,
      license: null,
      source: null,
    };
  }
}
