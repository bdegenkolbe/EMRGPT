import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { checkUnpaywallOA } from "./unpaywall.ts";
import { fetchCrossRefMetadata } from "./crossref.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Europe PMC API base URL
const EUROPEPMC_BASE = "https://www.ebi.ac.uk/europepmc/webservices/rest";

interface SearchRequest {
  query: string;
  resultType?: "lite" | "core";
  synonym?: boolean;
  cursorMark?: string;
  pageSize?: number;
  limit?: number; // Alias for pageSize (used by knowledge-search)
  sort?: string;
  openAccess?: boolean;
  sessionId?: string;
  checkUnpaywall?: boolean; // Check Unpaywall for additional OA info
}

interface AuthorDetail {
  given: string;
  family: string;
  fullName: string;
  orcid?: string;
  affiliations?: string[];
}

interface Article {
  id: string;
  source: string;
  pmid: string | null;
  pmcid: string | null;
  doi: string | null;
  title: string;
  authors: string[];
  authorDetails?: AuthorDetail[];
  journal: string;
  year: number | null;
  publicationDate: string | null;
  abstract: string;
  isOpenAccess: boolean;
  oaStatus: string | null; // gold, green, hybrid, bronze, closed
  citedByCount: number;
  fullTextUrl: string | null;
  pdfUrl: string | null;
  europePmcUrl: string;
  meshTerms: string[];
  keywords: string[];
  license: string | null;
}

interface SearchResponse {
  articles: Article[];
  totalCount: number;
  nextCursor: string | null;
  query: string;
}

interface CitationResponse {
  citations: Article[];
  totalCount: number;
}

/**
 * Search Europe PMC articles
 */
async function searchArticles(request: SearchRequest): Promise<SearchResponse> {
  // Support both 'pageSize' and 'limit' parameter names
  const pageSize = Math.min(request.pageSize || request.limit || 25, 100);
  
  // Build query with optional open access filter
  let query = request.query;
  if (request.openAccess) {
    query = `(${query}) AND OPEN_ACCESS:y`;
  }

  const params = new URLSearchParams({
    query,
    format: "json",
    resultType: request.resultType || "lite",
    synonym: request.synonym !== false ? "true" : "false",
    pageSize: pageSize.toString(),
  });

  if (request.cursorMark) {
    params.set("cursorMark", request.cursorMark);
  }

  if (request.sort) {
    params.set("sort", request.sort);
  }

  const url = `${EUROPEPMC_BASE}/search?${params.toString()}`;
  console.log("Europe PMC Search URL:", url);

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error("Europe PMC API error:", response.status, errorText);
    throw new Error(`Europe PMC API error: ${response.status}`);
  }

  const data = await response.json();
  const resultList = data.resultList?.result || [];

  const articles: Article[] = resultList.map((result: any) => {
    // Build full text URL for open access articles
    let fullTextUrl: string | null = null;
    let pdfUrl: string | null = null;
    
    if (result.pmcid) {
      // Always generate PDF URL for PMC articles
      const pmcidNormalized = result.pmcid.startsWith("PMC") ? result.pmcid : `PMC${result.pmcid}`;
      fullTextUrl = `https://europepmc.org/articles/${pmcidNormalized}`;
      pdfUrl = `https://europepmc.org/backend/ptpmcrender.fcgi?accid=${pmcidNormalized}&blobtype=pdf`;
    }
    
    // Check for additional full text links in the result (may override defaults)
    if (result.fullTextUrlList?.fullTextUrl) {
      for (const ftUrl of result.fullTextUrlList.fullTextUrl) {
        if (ftUrl.documentStyle === "pdf") {
          pdfUrl = ftUrl.url;
        } else if (ftUrl.documentStyle === "html" && !fullTextUrl) {
          fullTextUrl = ftUrl.url;
        }
      }
    }
    
    // Extract author details when available (resultType: core)
    let authorDetails: AuthorDetail[] | undefined;
    const authorsArray: string[] = [];
    
    if (result.authorList?.author && Array.isArray(result.authorList.author)) {
      authorDetails = result.authorList.author.map((author: any) => {
        const given = author.firstName || author.initials || "";
        const family = author.lastName || "";
        const fullName = author.fullName || `${given} ${family}`.trim();
        authorsArray.push(fullName);
        
        // Extract affiliations
        const affiliations: string[] = [];
        if (author.affiliation) {
          affiliations.push(author.affiliation);
        }
        if (author.affiliationList?.affiliation) {
          for (const aff of author.affiliationList.affiliation) {
            if (typeof aff === 'string') {
              affiliations.push(aff);
            } else if (aff.name) {
              affiliations.push(aff.name);
            }
          }
        }
        
        return {
          given,
          family,
          fullName,
          orcid: author.authorId?.type === "ORCID" ? author.authorId.value : undefined,
          affiliations: affiliations.length > 0 ? affiliations : undefined,
        };
      });
    } else if (result.authorString) {
      // Fallback to authorString parsing
      authorsArray.push(...(result.authorString || "").split(", ").filter(Boolean));
    }

    // Build publication date from available fields
    let publicationDate: string | null = null;
    if (result.firstPublicationDate) {
      publicationDate = result.firstPublicationDate;
    } else if (result.electronicPublicationDate) {
      publicationDate = result.electronicPublicationDate;
    } else if (result.dateOfCreation) {
      publicationDate = result.dateOfCreation;
    } else if (result.pubYear) {
      publicationDate = result.pubYear;
    }

    return {
      id: result.id || "",
      source: result.source || "",
      pmid: result.pmid || null,
      pmcid: result.pmcid || null,
      doi: result.doi || null,
      title: result.title || "",
      authors: authorsArray,
      authorDetails,
      journal: result.journalTitle || result.bookOrReportDetails?.publisher || "",
      year: result.pubYear ? parseInt(result.pubYear, 10) : null,
      publicationDate,
      abstract: result.abstractText || "",
      isOpenAccess: result.isOpenAccess === "Y",
      oaStatus: null,
      citedByCount: result.citedByCount || 0,
      fullTextUrl,
      pdfUrl,
      europePmcUrl: `https://europepmc.org/article/${result.source}/${result.id}`,
      meshTerms: (result.meshHeadingList?.meshHeading || []).map((m: any) => m.descriptorName),
      keywords: result.keywordList?.keyword || [],
      license: null,
    };
  });

  return {
    articles,
    totalCount: data.hitCount || articles.length,
    nextCursor: data.nextCursorMark || null,
    query: request.query,
  };
}

/**
 * Get article details by ID with optional Unpaywall enrichment
 */
async function getArticleDetails(source: string, id: string, checkUnpaywall = true): Promise<Article | null> {
  const url = `${EUROPEPMC_BASE}/search?query=EXT_ID:${id}%20AND%20SRC:${source}&format=json&resultType=core`;

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error("Europe PMC API error:", response.status, errorText);
    throw new Error(`Europe PMC API error: ${response.status}`);
  }

  const data = await response.json();
  const result = data.resultList?.result?.[0];

  if (!result) {
    return null;
  }

  let fullTextUrl: string | null = null;
  let pdfUrl: string | null = null;
  let oaStatus: string | null = null;
  let license: string | null = null;
  let authors: string[] = (result.authorString || "").split(", ").filter(Boolean);
  let authorDetails: AuthorDetail[] | undefined;

  // Europe PMC Open Access via PMC
  if (isOpenAccess && result.pmcid) {
    fullTextUrl = `https://europepmc.org/articles/${result.pmcid}`;
  }

  // Check Unpaywall for additional OA info (especially for publisher-hosted OA like Springer)
  if (checkUnpaywall && result.doi) {
    try {
      const unpaywallData = await checkUnpaywallOA(result.doi);
      if (unpaywallData.isOpenAccess) {
        isOpenAccess = true;
        oaStatus = unpaywallData.oaStatus;
        pdfUrl = unpaywallData.pdfUrl;
        license = unpaywallData.license;
        if (!fullTextUrl && unpaywallData.landingPageUrl) {
          fullTextUrl = unpaywallData.landingPageUrl;
        }
      }
    } catch (error) {
      console.error("Unpaywall enrichment failed:", error);
    }
  }

  // Check CrossRef for additional metadata (full authors list, publisher OA license)
  if (result.doi) {
    try {
      const crossRefData = await fetchCrossRefMetadata(result.doi);
      if (crossRefData) {
        // Use CrossRef authors if we have more complete data (with ORCID/affiliations)
        if (crossRefData.authors.length > 0) {
          authors = crossRefData.authors.map(a => a.fullName);
          authorDetails = crossRefData.authors.map(a => ({
            given: a.given,
            family: a.family,
            fullName: a.fullName,
            orcid: a.orcid,
            affiliations: a.affiliations,
          }));
        }
        // CrossRef license check (Springer OA often shows here even if not in Unpaywall)
        if (crossRefData.isOpenAccess && !isOpenAccess) {
          isOpenAccess = true;
          oaStatus = "crossref";
          if (crossRefData.oaLicense) {
            license = crossRefData.oaLicense;
          }
        }
        // CrossRef PDF URL
        if (crossRefData.pdfUrl && !pdfUrl) {
          pdfUrl = crossRefData.pdfUrl;
        }
        // Publisher URL as fallback for full text
        if (crossRefData.publisherUrl && !fullTextUrl) {
          fullTextUrl = crossRefData.publisherUrl;
        }
      }
    } catch (error) {
      console.error("CrossRef enrichment failed:", error);
    }
  }

  return {
    id: result.id || "",
    source: result.source || "",
    pmid: result.pmid || null,
    pmcid: result.pmcid || null,
    doi: result.doi || null,
    title: result.title || "",
    authors,
    authorDetails,
    journal: result.journalTitle || "",
    year: result.pubYear ? parseInt(result.pubYear, 10) : null,
    abstract: result.abstractText || "",
    isOpenAccess,
    oaStatus,
    citedByCount: result.citedByCount || 0,
    fullTextUrl,
    pdfUrl,
    europePmcUrl: `https://europepmc.org/article/${result.source}/${result.id}`,
    meshTerms: (result.meshHeadingList?.meshHeading || []).map((m: any) => m.descriptorName),
    keywords: result.keywordList?.keyword || [],
    license,
  };
}

/**
 * Get citations for an article
 */
async function getCitations(source: string, id: string, pageSize: number = 10): Promise<CitationResponse> {
  const url = `${EUROPEPMC_BASE}/${source}/${id}/citations?format=json&pageSize=${pageSize}`;

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    if (response.status === 404) {
      return { citations: [], totalCount: 0 };
    }
    const errorText = await response.text();
    console.error("Europe PMC Citations API error:", response.status, errorText);
    throw new Error(`Europe PMC API error: ${response.status}`);
  }

  const data = await response.json();
  const citationList = data.citationList?.citation || [];

  const citations: Article[] = citationList.map((result: any) => ({
    id: result.id || "",
    source: result.source || "",
    pmid: result.pmid || null,
    pmcid: result.pmcid || null,
    doi: result.doi || null,
    title: result.title || "",
    authors: (result.authorString || "").split(", ").filter(Boolean),
    journal: result.journalAbbreviation || "",
    year: result.pubYear ? parseInt(result.pubYear, 10) : null,
    abstract: "",
    isOpenAccess: result.isOpenAccess === "Y",
    citedByCount: result.citedByCount || 0,
    fullTextUrl: null,
    europePmcUrl: `https://europepmc.org/article/${result.source}/${result.id}`,
    meshTerms: [],
    keywords: [],
  }));

  return {
    citations,
    totalCount: data.hitCount || citations.length,
  };
}

/**
 * Get references for an article
 */
async function getReferences(source: string, id: string, pageSize: number = 10): Promise<CitationResponse> {
  const url = `${EUROPEPMC_BASE}/${source}/${id}/references?format=json&pageSize=${pageSize}`;

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    if (response.status === 404) {
      return { citations: [], totalCount: 0 };
    }
    const errorText = await response.text();
    console.error("Europe PMC References API error:", response.status, errorText);
    throw new Error(`Europe PMC API error: ${response.status}`);
  }

  const data = await response.json();
  const referenceList = data.referenceList?.reference || [];

  const references: Article[] = referenceList.map((result: any) => ({
    id: result.id || "",
    source: result.source || "",
    pmid: result.pmid || null,
    pmcid: result.pmcid || null,
    doi: result.doi || null,
    title: result.title || "",
    authors: (result.authorString || "").split(", ").filter(Boolean),
    journal: result.journalAbbreviation || "",
    year: result.pubYear ? parseInt(result.pubYear, 10) : null,
    abstract: "",
    isOpenAccess: result.isOpenAccess === "Y",
    citedByCount: result.citedByCount || 0,
    fullTextUrl: null,
    europePmcUrl: result.id ? `https://europepmc.org/article/${result.source}/${result.id}` : "",
    meshTerms: [],
    keywords: [],
  }));

  return {
    citations: references,
    totalCount: data.hitCount || references.length,
  };
}

/**
 * Get text-mined concepts for an article
 */
async function getTextMinedTerms(source: string, id: string): Promise<any> {
  const url = `${EUROPEPMC_BASE}/${source}/${id}/textMinedTerms/DISEASE?format=json`;

  const response = await fetch(url, {
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    if (response.status === 404) {
      return { terms: [] };
    }
    const errorText = await response.text();
    console.error("Europe PMC Text Mining API error:", response.status, errorText);
    throw new Error(`Europe PMC API error: ${response.status}`);
  }

  const data = await response.json();
  const terms = (data.semanticTypeList?.semanticType || []).flatMap((type: any) =>
    (type.tmSummary || []).map((term: any) => ({
      term: term.term,
      count: term.count,
      altNameList: term.altNameList?.altName || [],
      dbName: term.dbName,
      dbIdList: term.dbIdList?.dbId || [],
    }))
  );

  return { terms };
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "search";

    // GET requests
    if (req.method === "GET") {
      if (action === "search") {
        const query = url.searchParams.get("query") || "";
        const pageSize = parseInt(url.searchParams.get("limit") || "10", 10);
        const openAccess = url.searchParams.get("openAccess") === "true";
        const sort = url.searchParams.get("sort") || undefined;

        if (!query) {
          return new Response(
            JSON.stringify({ error: "query parameter required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const result = await searchArticles({ query, pageSize, openAccess, sort });
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "details") {
        const source = url.searchParams.get("source") || "MED";
        const id = url.searchParams.get("id");

        if (!id) {
          return new Response(
            JSON.stringify({ error: "id parameter required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const article = await getArticleDetails(source, id);
        if (!article) {
          return new Response(
            JSON.stringify({ error: "Article not found" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        return new Response(JSON.stringify(article), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "citations") {
        const source = url.searchParams.get("source") || "MED";
        const id = url.searchParams.get("id");
        const pageSize = parseInt(url.searchParams.get("limit") || "10", 10);

        if (!id) {
          return new Response(
            JSON.stringify({ error: "id parameter required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const result = await getCitations(source, id, pageSize);
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "references") {
        const source = url.searchParams.get("source") || "MED";
        const id = url.searchParams.get("id");
        const pageSize = parseInt(url.searchParams.get("limit") || "10", 10);

        if (!id) {
          return new Response(
            JSON.stringify({ error: "id parameter required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const result = await getReferences(source, id, pageSize);
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "textmined") {
        const source = url.searchParams.get("source") || "MED";
        const id = url.searchParams.get("id");

        if (!id) {
          return new Response(
            JSON.stringify({ error: "id parameter required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const result = await getTextMinedTerms(source, id);
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // POST requests for advanced search with auth
    if (req.method === "POST") {
      const authHeader = req.headers.get("Authorization");
      if (!authHeader) {
        return new Response(
          JSON.stringify({ error: "Missing authorization header" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

      const supabase = createClient(supabaseUrl, supabaseAnonKey, {
        global: { headers: { Authorization: authHeader } },
      });

      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) {
        return new Response(
          JSON.stringify({ error: "Unauthorized" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const body: SearchRequest = await req.json();

      if (!body.query) {
        return new Response(
          JSON.stringify({ error: "query required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const result = await searchArticles(body);

      // Log to evidence_requests for audit if sessionId provided
      if (body.sessionId) {
        const { error: insertError } = await supabase.from("evidence_requests").insert({
          session_id: body.sessionId,
          query_context: {
            openAccess: body.openAccess,
            sort: body.sort,
            resultType: body.resultType,
          },
          query_strings: { europepmc: body.query },
          sources: ["europepmc"],
        });

        if (insertError) {
          console.error("Error logging evidence request:", insertError);
        }
      }

      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Europe PMC error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
