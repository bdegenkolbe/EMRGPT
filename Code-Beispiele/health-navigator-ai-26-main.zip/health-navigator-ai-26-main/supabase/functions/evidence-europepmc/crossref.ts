// CrossRef API helper for fetching additional metadata (authors, license)

export interface CrossRefAuthor {
  given: string;
  family: string;
  sequence: string;
  ORCID?: string;
  affiliation?: Array<{ name: string }>;
}

export interface CrossRefLicense {
  URL: string;
  start: {
    "date-parts": number[][];
    "date-time": string;
    timestamp: number;
  };
  "delay-in-days": number;
  "content-version": string;
}

export interface CrossRefWorkMessage {
  DOI: string;
  title: string[];
  author?: CrossRefAuthor[];
  "container-title"?: string[];
  issued?: {
    "date-parts": number[][];
  };
  license?: CrossRefLicense[];
  "is-referenced-by-count"?: number;
  URL?: string;
  link?: Array<{
    URL: string;
    "content-type": string;
    "intended-application": string;
  }>;
}

export interface CrossRefResponse {
  status: string;
  "message-type": string;
  "message-version": string;
  message: CrossRefWorkMessage;
}

export interface CrossRefMetadata {
  authors: Array<{
    given: string;
    family: string;
    fullName: string;
    orcid?: string;
    affiliations?: string[];
  }>;
  isOpenAccess: boolean;
  oaLicense?: string;
  pdfUrl?: string;
  publisherUrl?: string;
}

/**
 * Fetch metadata from CrossRef API by DOI
 */
export async function fetchCrossRefMetadata(doi: string): Promise<CrossRefMetadata | null> {
  const email = "anamnesis-app@example.com"; // Required for polite pool
  const url = `https://api.crossref.org/works/${encodeURIComponent(doi)}?mailto=${email}`;

  try {
    console.log("Fetching CrossRef metadata for DOI:", doi);
    
    const response = await fetch(url, {
      headers: {
        Accept: "application/json",
        "User-Agent": `Anamnesis-App/1.0 (mailto:${email})`,
      },
    });

    if (!response.ok) {
      if (response.status === 404) {
        console.log("DOI not found in CrossRef:", doi);
        return null;
      }
      throw new Error(`CrossRef API error: ${response.status}`);
    }

    const data: CrossRefResponse = await response.json();
    const work = data.message;

    // Extract authors with affiliations
    const authors = (work.author || []).map((a) => ({
      given: a.given || "",
      family: a.family || "",
      fullName: `${a.given || ""} ${a.family || ""}`.trim(),
      orcid: a.ORCID ? a.ORCID.replace("http://orcid.org/", "").replace("https://orcid.org/", "") : undefined,
      affiliations: a.affiliation?.map(aff => aff.name).filter(Boolean) || [],
    }));

    // Check for open access license
    let isOpenAccess = false;
    let oaLicense: string | undefined;
    let pdfUrl: string | undefined;

    if (work.license && work.license.length > 0) {
      for (const lic of work.license) {
        const licUrl = lic.URL.toLowerCase();
        // Check for CC licenses (Creative Commons = Open Access)
        if (
          licUrl.includes("creativecommons.org") ||
          licUrl.includes("springer.com/tdm") || // Springer text mining license
          licUrl.includes("open") ||
          licUrl.includes("cc-by") ||
          licUrl.includes("cc0")
        ) {
          isOpenAccess = true;
          oaLicense = lic.URL;
          break;
        }
      }
    }

    // Check for PDF links
    if (work.link) {
      for (const link of work.link) {
        if (
          link["content-type"] === "application/pdf" ||
          link["intended-application"] === "text-mining" ||
          link.URL.includes(".pdf")
        ) {
          pdfUrl = link.URL;
          break;
        }
      }
    }

    console.log(`CrossRef result for ${doi}: ${authors.length} authors, isOA=${isOpenAccess}`);

    return {
      authors,
      isOpenAccess,
      oaLicense,
      pdfUrl,
      publisherUrl: work.URL,
    };
  } catch (error) {
    console.error("CrossRef lookup error:", error);
    return null;
  }
}
