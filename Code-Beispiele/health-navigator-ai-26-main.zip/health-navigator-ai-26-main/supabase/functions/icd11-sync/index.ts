import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SOURCE_NAME = "icd11";
const ICD11_API = "https://id.who.int/icd/release/11/2024-01/mms";
const ICD11_INFO_API = "https://id.who.int/icd/release/11";

/**
 * Fetch the current ICD-11 release version from WHO API
 * Returns version string like "2024-01" or null on failure
 */
async function fetchRemoteVersion(token: string): Promise<string | null> {
  try {
    const response = await fetch(ICD11_INFO_API, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
        "API-Version": "v2",
      },
    });

    if (!response.ok) {
      console.error(`[ICD-11 Sync] Failed to fetch version: ${response.status}`);
      return null;
    }

    const data = await response.json();
    // Get the latest release version from the releases array
    const releases = data?.release || [];
    if (releases.length > 0) {
      // Extract version from release URI like "https://id.who.int/icd/release/11/2024-01"
      const latestRelease = releases[releases.length - 1];
      const match = latestRelease?.["@id"]?.match(/\/(\d{4}-\d{2})$/);
      const version = match ? match[1] : null;
      console.log(`[ICD-11 Sync] Remote ICD-11 version: ${version}`);
      return version;
    }
    return null;
  } catch (err: any) {
    console.error(`[ICD-11 Sync] Error fetching version:`, err?.message || String(err));
    return null;
  }
}

/**
 * Compare versions - returns true if remote is newer than local
 * ICD-11 versions are date-based like "2024-01"
 */
function isNewerVersion(remoteVersion: string | null, localVersion: string | null): boolean {
  if (!remoteVersion) return false;
  if (!localVersion) return true;
  return remoteVersion > localVersion;
}

function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(supabaseUrl, supabaseKey);
}

/**
 * Get OAuth token for WHO ICD-11 API
 */
async function getICD11Token(): Promise<string> {
  const clientId = Deno.env.get("ICD11_CLIENT_ID");
  const clientSecret = Deno.env.get("ICD11_CLIENT_SECRET");
  
  if (!clientId || !clientSecret) {
    throw new Error("ICD-11 API credentials not configured");
  }

  const tokenUrl = "https://icdaccessmanagement.who.int/connect/token";
  
  const response = await fetch(tokenUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret,
      scope: "icdapi_access",
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to get ICD-11 token: ${response.status}`);
  }

  const data = await response.json();
  return data.access_token;
}

interface ICD11Entity {
  "@id": string;
  code?: string;
  title?: { "@value": string };
  definition?: { "@value": string };
  classKind?: string;
  child?: string[];
}

/**
 * Fetch children of an ICD-11 entity
 */
async function fetchChildren(token: string, parentUri: string): Promise<ICD11Entity[]> {
  const response = await fetch(parentUri, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/json",
      "Accept-Language": "en",
      "API-Version": "v2",
    },
  });

  if (!response.ok) {
    console.error(`Failed to fetch ${parentUri}: ${response.status}`);
    return [];
  }

  const data = await response.json();
  const children: ICD11Entity[] = [];

  if (data.child && Array.isArray(data.child)) {
    for (const childUri of data.child) {
      try {
        const childResponse = await fetch(childUri, {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
            "Accept-Language": "en",
            "API-Version": "v2",
          },
        });

        if (childResponse.ok) {
          const childData = await childResponse.json();
          children.push(childData);
        }
        
        // Small delay to respect rate limits
        await new Promise(resolve => setTimeout(resolve, 50));
      } catch (err) {
        console.error(`Error fetching child ${childUri}:`, err);
      }
    }
  }

  return children;
}

/**
 * Persist ICD-11 codes to database
 */
async function persistICD11Codes(supabase: any, entities: ICD11Entity[], parentCode?: string): Promise<number> {
  if (entities.length === 0) return 0;

  const codesToInsert = entities.map((e) => {
    // Extract code from URI
    const code = e.code || e["@id"]?.split("/").pop() || "";
    
    return {
      code,
      title: e.title?.["@value"] || code,
      definition: e.definition?.["@value"] || null,
      class_kind: e.classKind || null,
      is_terminal: !e.child || e.child.length === 0,
      parent_code: parentCode || null,
      linearization_uri: e["@id"],
      labels: { en: e.title?.["@value"] },
    };
  });

  const { error } = await supabase
    .from("icd11_codes")
    .upsert(codesToInsert, { onConflict: "code" });

  if (error) {
    console.error("[ICD-11 Sync] Persist error:", error);
    return 0;
  }

  return entities.length;
}

/**
 * Get or create sync status
 */
async function getSyncStatus(supabase: any) {
  const { data } = await supabase
    .from("sync_status")
    .select("*")
    .eq("source_name", SOURCE_NAME)
    .maybeSingle();
  
  return data;
}

/**
 * Update sync status
 */
async function updateSyncStatus(supabase: any, updates: Record<string, any>) {
  await supabase
    .from("sync_status")
    .upsert({
      source_name: SOURCE_NAME,
      ...updates,
      updated_at: new Date().toISOString(),
    }, { onConflict: "source_name" });
}

// Queue of URIs to process (stored in last_cursor as JSON)
interface SyncQueue {
  pending: string[];
  processed: number;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = getSupabaseAdmin();

  try {
    const body = await req.json();
    const action = body.action || "sync_page";

    switch (action) {
      case "init": {
        // Get chapters to initialize queue
        const token = await getICD11Token();
        const response = await fetch(ICD11_API, {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
            "Accept-Language": "en",
            "API-Version": "v2",
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch ICD-11 root: ${response.status}`);
        }

        const data = await response.json();
        const chapterUris = data.child || [];

        const queue: SyncQueue = {
          pending: chapterUris,
          processed: 0,
        };

        await updateSyncStatus(supabase, {
          status: "running",
          total_synced: 0,
          total_available: null,
          last_cursor: JSON.stringify(queue),
          error_message: null,
          started_at: new Date().toISOString(),
          completed_at: null,
        });

        return new Response(
          JSON.stringify({ success: true, message: "Sync initialized", chapters: chapterUris.length }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "sync_page": {
        const status = await getSyncStatus(supabase);
        let queue: SyncQueue;
        
        try {
          queue = JSON.parse(status?.last_cursor || '{"pending":[],"processed":0}');
        } catch {
          queue = { pending: [], processed: 0 };
        }

        if (queue.pending.length === 0) {
          await updateSyncStatus(supabase, {
            status: "completed",
            completed_at: new Date().toISOString(),
          });

          return new Response(
            JSON.stringify({ hasMore: false, syncedCount: 0, totalSynced: status?.total_synced || 0 }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        // Process next batch (up to 5 URIs per call to avoid timeout)
        const batchSize = 5;
        const token = await getICD11Token();
        const batch = queue.pending.splice(0, batchSize);
        let syncedCount = 0;

        for (const uri of batch) {
          try {
            const children = await fetchChildren(token, uri);
            const synced = await persistICD11Codes(supabase, children);
            syncedCount += synced;

            // Add children to queue for recursive processing
            for (const child of children) {
              if (child.child && child.child.length > 0) {
                queue.pending.push(child["@id"]);
              }
            }
          } catch (err) {
            console.error(`Error processing ${uri}:`, err);
          }
        }

        queue.processed += batch.length;
        const newTotalSynced = (status?.total_synced || 0) + syncedCount;
        const hasMore = queue.pending.length > 0;

        await updateSyncStatus(supabase, {
          status: hasMore ? "running" : "completed",
          total_synced: newTotalSynced,
          last_cursor: JSON.stringify(queue),
          completed_at: hasMore ? null : new Date().toISOString(),
        });

        console.log(`[ICD-11 Sync] Processed ${batch.length} URIs, synced ${syncedCount}. Pending: ${queue.pending.length}`);

        return new Response(
          JSON.stringify({
            hasMore,
            syncedCount,
            totalSynced: newTotalSynced,
            pendingCount: queue.pending.length,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "pause": {
        await updateSyncStatus(supabase, { status: "paused" });
        return new Response(
          JSON.stringify({ success: true, message: "Sync paused" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "reset": {
        await updateSyncStatus(supabase, {
          status: "pending",
          total_synced: 0,
          total_available: null,
          last_cursor: null,
          error_message: null,
          started_at: null,
          completed_at: null,
        });
        return new Response(
          JSON.stringify({ success: true, message: "Sync reset" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "status": {
        const status = await getSyncStatus(supabase);
        return new Response(
          JSON.stringify(status || { status: "pending", total_synced: 0 }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "check_version": {
        const token = await getICD11Token();
        const status = await getSyncStatus(supabase);
        const remoteVersion = await fetchRemoteVersion(token);
        const localVersion = status?.local_version || null;
        const needsSync = isNewerVersion(remoteVersion, localVersion);

        // Update remote_version in sync_status
        if (remoteVersion) {
          await updateSyncStatus(supabase, {
            remote_version: remoteVersion,
          });
        }

        return new Response(
          JSON.stringify({
            remoteVersion,
            localVersion,
            needsSync,
            message: needsSync 
              ? `New version available: ${remoteVersion} (current: ${localVersion || 'none'})`
              : `Already up to date: ${localVersion}`,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${action}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error: any) {
    console.error("[ICD-11 Sync] Error:", error);

    await updateSyncStatus(supabase, {
      status: "error",
      error_message: error.message,
    });

    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
