import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Orphanet API base URLs
const ORPHACODE_API = "https://api.orphacode.org";

interface OrphanetConcept {
  orphaCode: string;
  name: string;
  nameEn?: string;
  definition?: string;
  classification?: string;
  synonyms?: string[];
  prevalence?: string;
  inheritance?: string[];
  ageOfOnset?: string[];
  orphaUrl?: string;
  icd10Codes?: string[];
  omimCodes?: string[];
  hpoCodes?: string[];
  isTerminal?: boolean;
  labels?: Record<string, string>;
}

interface TranslationResult {
  orpha_code: string;
  name_en: string;
  name_de: string;
  definition_de?: string;
  explanation_de?: string;
  source: "official" | "ai_translated";
  confidence: number;
}

/**
 * Translate Orphanet terms to German using AI
 */
async function translateWithAI(
  terms: { orphaCode: string; name: string; definition?: string }[]
): Promise<TranslationResult[]> {
  const prompt = `Du bist ein medizinischer Übersetzer für Orphanet (seltene Erkrankungen).
Übersetze die folgenden englischen Krankheitsbezeichnungen ins Deutsche.
Verwende korrekte deutsche medizinische Fachterminologie für seltene Erkrankungen.
Die Übersetzungen müssen präzise, klinisch korrekt und konsistent sein.

Wichtig:
- Verwende die offiziellen deutschen Bezeichnungen wenn bekannt
- Bei unbekannten Begriffen: klinisch korrekte Übersetzung
- Gib zusätzlich eine kurze Erklärung (max 80 Wörter) als "explanation_de"

Begriffe zur Übersetzung:
${terms.map((t) => `- ORPHA:${t.orphaCode}: "${t.name}"${t.definition ? ` (${t.definition.slice(0, 150)}...)` : ""}`).join("\n")}

Antworte NUR mit einem JSON-Array in diesem Format:
[
  {"orpha_code": "166024", "name_de": "Deutsche Übersetzung", "explanation_de": "Kurze Erklärung...", "confidence": 0.95}
]`;

  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");

  let response: Response;

  if (openaiKey) {
    response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Du bist ein Experte für seltene Erkrankungen und Orphanet-Terminologie." },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 2000,
      }),
    });
  } else if (lovableKey) {
    response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "Du bist ein Experte für seltene Erkrankungen und Orphanet-Terminologie." },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 2000,
      }),
    });
  } else {
    throw new Error("No AI API key configured");
  }

  if (!response.ok) {
    const errorText = await response.text();
    console.error("AI API error:", response.status, errorText);
    throw new Error(`AI translation failed: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";

  const jsonMatch = content.match(/\[[\s\S]*\]/);
  if (!jsonMatch) {
    console.error("Could not parse AI response:", content);
    throw new Error("Invalid AI response format");
  }

  const translations: Array<{
    orpha_code: string;
    name_de: string;
    explanation_de?: string;
    confidence?: number;
  }> = JSON.parse(jsonMatch[0]);

  return translations.map((t) => {
    const originalTerm = terms.find((term) => term.orphaCode === t.orpha_code);
    return {
      orpha_code: t.orpha_code,
      name_en: originalTerm?.name || "",
      name_de: t.name_de,
      explanation_de: t.explanation_de,
      source: "ai_translated" as const,
      confidence: t.confidence || 0.9,
    };
  });
}

/**
 * Search Orphanet API for clinical entities
 * Note: Both Orphadata and ORPHAcode APIs may require authentication now
 */
async function searchOrphanet(query: string, lang: string = "en", limit: number = 20): Promise<OrphanetConcept[]> {
  try {
    // Try the Orphadata API for searching
    const searchUrl = `https://api.orphadata.com/rd-cross-referencing/orphacodes?query=${encodeURIComponent(query)}&lang=${lang}`;
    
    const response = await fetch(searchUrl, {
      headers: { "Accept": "application/json" },
    });

    if (!response.ok) {
      console.log(`Orphadata search failed (${response.status}), trying fallback...`);
      return await searchOrphanetFallback(query, lang, limit);
    }

    const data = await response.json();
    
    // Handle different response formats - API might return object or array
    let items: any[] = [];
    if (Array.isArray(data)) {
      items = data;
    } else if (data.data && Array.isArray(data.data)) {
      items = data.data;
    } else if (data.results && Array.isArray(data.results)) {
      items = data.results;
    } else if (typeof data === 'object' && data.error) {
      // API returned an error
      console.log(`Orphadata API error: ${data.error || data.message || 'Unknown error'}`);
      return await searchOrphanetFallback(query, lang, limit);
    }
    
    // Map API response to our format
    const results: OrphanetConcept[] = items.slice(0, limit).map((item: any) => ({
      orphaCode: String(item.ORPHAcode || item.orphaCode || item.code || ""),
      name: item.Preferred_term || item.preferredTerm || item.name || "",
      nameEn: item.Preferred_term_EN || item.name_en || "",
      definition: item.Definition || item.definition || "",
      classification: item.Classification || item.type || "Disorder",
      synonyms: item.Synonyms || item.synonyms || [],
      orphaUrl: item.ORPHAcode ? `https://www.orpha.net/consor/cgi-bin/OC_Exp.php?lng=EN&Expert=${item.ORPHAcode}` : undefined,
    }));

    return results;
  } catch (error) {
    console.error("Orphanet search error:", error);
    return await searchOrphanetFallback(query, lang, limit);
  }
}

/**
 * Fallback search using ORPHAcode API
 */
async function searchOrphanetFallback(query: string, lang: string, limit: number): Promise<OrphanetConcept[]> {
  try {
    // Use the ORPHAcode API with approximative search
    const url = `${ORPHACODE_API}/${lang}/ClinicalEntity/ApproximateName/${encodeURIComponent(query)}`;
    
    const response = await fetch(url, {
      headers: { "Accept": "application/json" },
    });

    if (!response.ok) {
      console.error(`ORPHAcode API failed: ${response.status}`);
      return [];
    }

    const data = await response.json();
    
    // The API returns an array of results
    const results: OrphanetConcept[] = (Array.isArray(data) ? data : data.data || [])
      .slice(0, limit)
      .map((item: any) => ({
        orphaCode: String(item.ORPHAcode || item.orphacode || ""),
        name: item.Preferred_term || item.preferred_term || item.Name || "",
        classification: item.Classification || "Disorder",
        orphaUrl: `https://www.orpha.net/consor/cgi-bin/OC_Exp.php?lng=${lang.toUpperCase()}&Expert=${item.ORPHAcode || item.orphacode}`,
      }));

    return results;
  } catch (error) {
    console.error("Orphanet fallback search error:", error);
    return [];
  }
}

/**
 * Get details for a specific ORPHA code
 */
async function getOrphanetDetails(orphaCode: string, lang: string = "en"): Promise<OrphanetConcept | null> {
  try {
    // Fetch name
    const nameUrl = `${ORPHACODE_API}/${lang}/ClinicalEntity/orphacode/${orphaCode}/Name`;
    const nameRes = await fetch(nameUrl, { headers: { "Accept": "application/json" } });
    
    let name = "";
    if (nameRes.ok) {
      const nameData = await nameRes.json();
      name = nameData.Preferred_term || nameData.preferred_term || nameData.Name || "";
    }

    // Fetch classification
    const classUrl = `${ORPHACODE_API}/${lang}/ClinicalEntity/orphacode/${orphaCode}/Classification`;
    const classRes = await fetch(classUrl, { headers: { "Accept": "application/json" } });
    
    let classification = "Disorder";
    if (classRes.ok) {
      const classData = await classRes.json();
      classification = classData.Classification_level || classData.classification || "Disorder";
    }

    // Fetch ICD-10 mappings
    const icd10Url = `${ORPHACODE_API}/${lang}/ClinicalEntity/orphacode/${orphaCode}/ICD10`;
    const icd10Res = await fetch(icd10Url, { headers: { "Accept": "application/json" } });
    
    let icd10Codes: string[] = [];
    if (icd10Res.ok) {
      const icd10Data = await icd10Res.json();
      if (Array.isArray(icd10Data)) {
        icd10Codes = icd10Data.map((item: any) => item.ICD10_code || item.code).filter(Boolean);
      } else if (icd10Data.ICD10) {
        icd10Codes = icd10Data.ICD10.map((item: any) => item.ICD10_code || item.code).filter(Boolean);
      }
    }

    // Fetch HPO mappings (phenotypes)
    const hpoUrl = `${ORPHACODE_API}/${lang}/ClinicalEntity/orphacode/${orphaCode}/HPO`;
    const hpoRes = await fetch(hpoUrl, { headers: { "Accept": "application/json" } });
    
    let hpoCodes: string[] = [];
    if (hpoRes.ok) {
      const hpoData = await hpoRes.json();
      if (Array.isArray(hpoData)) {
        hpoCodes = hpoData.map((item: any) => item.HPO_id || item.hpo_id).filter(Boolean);
      } else if (hpoData.HPO) {
        hpoCodes = hpoData.HPO.map((item: any) => item.HPO_id || item.hpo_id).filter(Boolean);
      }
    }

    return {
      orphaCode,
      name,
      classification,
      icd10Codes,
      hpoCodes,
      orphaUrl: `https://www.orpha.net/consor/cgi-bin/OC_Exp.php?lng=${lang.toUpperCase()}&Expert=${orphaCode}`,
    };
  } catch (error) {
    console.error("Orphanet details error:", error);
    return null;
  }
}

/**
 * Get children of an Orphanet classification
 * 
 * NOTE: The ORPHAcode API (api.orphacode.org) now requires registration and authentication.
 * This function first checks local database, then returns empty with a note if no local data exists.
 * 
 * To populate the hierarchy:
 * 1. Register at https://api.orphacode.org/ for API access
 * 2. Use the Bulk Import feature to download Orphadata classification files
 */
async function getOrphanetChildren(
  parentCode: string, 
  lang: string = "en",
  supabaseAdmin: any
): Promise<OrphanetConcept[]> {
  try {
    // First: Check local database for children
    const { data: localChildren, error } = await supabaseAdmin
      .from('orphanet_codes')
      .select('*')
      .eq('parent_code', parentCode)
      .order('orpha_code');
    
    if (!error && localChildren && localChildren.length > 0) {
      console.log(`[Orphanet] Found ${localChildren.length} children in DB for ${parentCode}`);
      
      return localChildren.map((code: any) => {
        const labels = code.labels as Record<string, string> | null;
        return {
          orphaCode: code.orpha_code,
          name: labels?.[lang] || labels?.de || code.name,
          nameEn: labels?.en || code.name,
          definition: code.definition,
          classification: code.classification || 'Disorder',
          prevalence: code.prevalence,
          inheritance: code.inheritance,
          ageOfOnset: code.age_of_onset,
          orphaUrl: code.orpha_url,
          icd10Codes: code.icd10_codes,
          omimCodes: code.omim_codes,
          hpoCodes: code.hpo_codes,
          isTerminal: code.is_terminal ?? false,
          labels: code.labels,
        };
      });
    }

    // Note: ORPHAcode API requires registration/auth now
    console.log(`[Orphanet] No children in DB for ${parentCode}. API requires registration.`);
    console.log(`[Orphanet] Register at https://api.orphacode.org/ or use Bulk Import.`);
    
    return [];
  } catch (error) {
    console.error("Orphanet children error:", error);
    return [];
  }
}

/**
 * Get root-level classifications from Orphanet
 * These are stored statically since the API now requires authentication
 */
async function getOrphanetClassifications(lang: string = "en", supabaseAdmin?: any): Promise<OrphanetConcept[]> {
  // Orphanet root classifications (main disease groups)
  const rootClassifications = [
    { code: "557", name: "Rare genetic disease", nameDE: "Seltene genetische Erkrankung" },
    { code: "71859", name: "Rare acquired disease", nameDE: "Seltene erworbene Erkrankung" },
    { code: "68367", name: "Rare developmental defect during embryogenesis", nameDE: "Seltener Entwicklungsdefekt während der Embryogenese" },
    { code: "182222", name: "Rare allergic disease", nameDE: "Seltene allergische Erkrankung" },
    { code: "101954", name: "Rare abdominal surgical disease", nameDE: "Seltene abdominelle chirurgische Erkrankung" },
    { code: "156638", name: "Rare bone disease", nameDE: "Seltene Knochenerkrankung" },
    { code: "98006", name: "Rare cardiac disease", nameDE: "Seltene Herzerkrankung" },
    { code: "68416", name: "Rare disorder due to toxic effects", nameDE: "Seltene Störung durch toxische Effekte" },
    { code: "97929", name: "Rare endocrine disease", nameDE: "Seltene endokrine Erkrankung" },
    { code: "101944", name: "Rare eye disease", nameDE: "Seltene Augenerkrankung" },
    { code: "68347", name: "Rare gynecological/obstetric disease", nameDE: "Seltene gynäkologische/geburtshilfliche Erkrankung" },
    { code: "98028", name: "Rare hematological disease", nameDE: "Seltene hämatologische Erkrankung" },
    { code: "182228", name: "Rare hepatic disease", nameDE: "Seltene Lebererkrankung" },
    { code: "163589", name: "Rare immunodeficiency", nameDE: "Seltene Immundefizienz" },
    { code: "68366", name: "Rare infectious disease", nameDE: "Seltene Infektionskrankheit" },
    { code: "97932", name: "Rare renal disease", nameDE: "Seltene Nierenerkrankung" },
    { code: "68381", name: "Rare neurological disease", nameDE: "Seltene neurologische Erkrankung" },
    { code: "55520", name: "Rare neoplastic disease", nameDE: "Seltene neoplastische Erkrankung" },
    { code: "79369", name: "Rare inborn errors of metabolism", nameDE: "Seltene angeborene Stoffwechselstörung" },
    { code: "98004", name: "Rare pulmonary disease", nameDE: "Seltene Lungenerkrankung" },
    { code: "68348", name: "Rare skin disease", nameDE: "Seltene Hauterkrankung" },
  ];

  // Persist root classifications to DB if supabaseAdmin is provided
  if (supabaseAdmin) {
    const recordsToUpsert = rootClassifications.map(c => ({
      orpha_code: c.code,
      name: c.name,
      classification: 'Group',
      is_terminal: false,
      parent_code: null, // Root level
      labels: { en: c.name, de: c.nameDE },
      orpha_url: `https://www.orpha.net/consor/cgi-bin/OC_Exp.php?lng=EN&Expert=${c.code}`,
      source: 'static_roots',
    }));

    const { error } = await supabaseAdmin
      .from('orphanet_codes')
      .upsert(recordsToUpsert, { onConflict: 'orpha_code', ignoreDuplicates: false });
    
    if (error) {
      console.error('[Orphanet] Error persisting root classifications:', error);
    } else {
      console.log(`[Orphanet] Persisted ${rootClassifications.length} root classifications to DB`);
    }
  }

  return rootClassifications.map(c => ({
    orphaCode: c.code,
    name: lang === "de" ? c.nameDE : c.name,
    nameEn: c.name,
    classification: "Group",
    isTerminal: false,
    orphaUrl: `https://www.orpha.net/consor/cgi-bin/OC_Exp.php?lng=${lang.toUpperCase()}&Expert=${c.code}`,
  }));
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    // Parse parameters from both URL and body (unified handling)
    const url = new URL(req.url);
    let body: Record<string, any> = {};
    
    try {
      if (req.method === "POST") {
        body = await req.json();
      }
    } catch {
      body = {};
    }

    const action = body.action || url.searchParams.get("action") || "search";
    const query = body.q || body.query || url.searchParams.get("q") || "";
    const lang = body.lang || url.searchParams.get("lang") || "de";
    const limit = parseInt(body.limit || url.searchParams.get("limit") || "20", 10);
    const orphaCode = body.orphaCode || body.code || url.searchParams.get("code") || "";

    console.log(`Orphanet lookup: action=${action}, query=${query}, lang=${lang}`);

    // Handle different actions
    switch (action) {
      case "search": {
        if (!query) {
          return new Response(JSON.stringify([]), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Search local database - need raw SQL for JSONB search
        // First try to search in name, orpha_code, and labels
        const searchPattern = `%${query}%`;
        
        const { data: localResults, error: searchError } = await supabaseAdmin
          .from("orphanet_codes")
          .select("*")
          .or(`name.ilike.${searchPattern},orpha_code.ilike.${searchPattern}`)
          .limit(limit);

        // Also search in German labels using raw query
        let labelResults: any[] = [];
        if (!localResults || localResults.length === 0) {
          const { data: jsonbResults } = await supabaseAdmin
            .rpc('search_orphanet_by_label', { search_term: query, search_limit: limit })
            .maybeSingle();
          
          // If RPC doesn't exist, fall back to direct query
          if (!jsonbResults) {
            // Use raw SQL approach via select with textual filter
            const { data: rawResults } = await supabaseAdmin
              .from("orphanet_codes")
              .select("*")
              .limit(limit);
            
            // Filter in-memory for labels (not ideal but works)
            if (rawResults) {
              const queryLower = query.toLowerCase();
              labelResults = rawResults.filter((r: any) => {
                const labels = r.labels as Record<string, string> | null;
                const labelDe = labels?.de?.toLowerCase() || '';
                const labelEn = labels?.en?.toLowerCase() || '';
                return labelDe.includes(queryLower) || labelEn.includes(queryLower);
              });
            }
          } else {
            labelResults = jsonbResults || [];
          }
        }

        const allResults = localResults && localResults.length > 0 ? localResults : labelResults;

        if (allResults && allResults.length > 0) {
          const results: OrphanetConcept[] = allResults.slice(0, limit).map((r: any) => {
            const labels = r.labels as Record<string, string> | null;
            return {
              orphaCode: r.orpha_code,
              name: labels?.[lang] || labels?.de || r.name,
              nameEn: labels?.en || r.name,
              definition: r.definition,
              classification: r.classification || "Disorder",
              icd10Codes: r.icd10_codes,
              hpoCodes: r.hpo_codes,
              isTerminal: r.is_terminal,
              orphaUrl: r.orpha_url,
              source: 'local',
            };
          });
          
          console.log(`[Orphanet] Found ${results.length} local results for "${query}"`);
          return new Response(JSON.stringify(results), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Note: External APIs (Orphadata, ORPHAcode) now require authentication
        console.log(`[Orphanet] No local results for "${query}". External APIs require auth.`);
        
        // Try API as last resort but expect it might fail
        const apiResults = await searchOrphanet(query, lang === "de" ? "de" : "en", limit);
        
        return new Response(JSON.stringify(apiResults), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get":
      case "details": {
        if (!orphaCode) {
          return new Response(JSON.stringify({ error: "Missing orphaCode" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Check local DB first
        const { data: localCode } = await supabaseAdmin
          .from("orphanet_codes")
          .select("*")
          .eq("orpha_code", orphaCode)
          .maybeSingle();

        if (localCode) {
          const result: OrphanetConcept = {
            orphaCode: localCode.orpha_code,
            name: (localCode.labels as any)?.[lang] || localCode.name,
            nameEn: (localCode.labels as any)?.en || localCode.name,
            definition: localCode.definition,
            classification: localCode.classification || "Disorder",
            icd10Codes: localCode.icd10_codes,
            hpoCodes: localCode.hpo_codes,
            omimCodes: localCode.omim_codes,
            isTerminal: localCode.is_terminal,
            prevalence: localCode.prevalence,
            inheritance: localCode.inheritance,
            ageOfOnset: localCode.age_of_onset,
            orphaUrl: localCode.orpha_url,
          };
          
          return new Response(JSON.stringify(result), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Fetch from API and persist
        const details = await getOrphanetDetails(orphaCode, lang === "de" ? "de" : "en");
        
        // Persist to orphanet_codes table if we got data
        if (details && details.name) {
          try {
            await supabaseAdmin.from("orphanet_codes").upsert({
              orpha_code: orphaCode,
              name: details.name,
              definition: details.definition,
              classification: details.classification,
              icd10_codes: details.icd10Codes || [],
              hpo_codes: details.hpoCodes || [],
              omim_codes: details.omimCodes || [],
              prevalence: details.prevalence,
              inheritance: details.inheritance,
              age_of_onset: details.ageOfOnset,
              orpha_url: details.orphaUrl,
              labels: { en: details.nameEn || details.name },
              source: 'orphacode_api',
            }, { onConflict: 'orpha_code' });
            console.log(`Persisted Orphanet code: ${orphaCode}`);
          } catch (persistError) {
            console.error('Error persisting Orphanet code:', persistError);
          }
        }
        
        return new Response(JSON.stringify(details), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "children": {
        if (!orphaCode) {
          return new Response(JSON.stringify({ children: [] }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const children = await getOrphanetChildren(orphaCode, lang === "de" ? "de" : "en", supabaseAdmin);
        
        return new Response(JSON.stringify({ children }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "classifications":
      case "roots": {
        const classifications = await getOrphanetClassifications(lang, supabaseAdmin);
        
        return new Response(JSON.stringify({ classifications }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "translate": {
        const terms = body.terms || [];
        if (!terms.length) {
          return new Response(JSON.stringify({ translations: [] }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Check cache in orphanet_codes table (JSONB labels column)
        const orphaCodes = terms.map((t: any) => t.orphaCode);
        const { data: cached } = await supabaseAdmin
          .from("orphanet_codes")
          .select("orpha_code, name, labels, explanations")
          .in("orpha_code", orphaCodes);

        const cachedMap = new Map((cached || []).map((c: any) => [c.orpha_code, c]));
        const toTranslate = terms.filter((t: any) => {
          const cachedItem = cachedMap.get(t.orphaCode);
          const labels = cachedItem?.labels as Record<string, string> | null;
          // Need translation if no German label or German equals English
          return !labels?.de || labels.de === (labels.en || cachedItem?.name);
        });

        let newTranslations: TranslationResult[] = [];

        if (toTranslate.length > 0) {
          try {
            newTranslations = await translateWithAI(toTranslate);

            // Save translations to orphanet_codes JSONB columns
            for (const t of newTranslations) {
              const existing = cachedMap.get(t.orpha_code);
              const currentLabels = (existing?.labels as Record<string, string>) || {};
              const currentExplanations = (existing?.explanations as Record<string, string>) || {};

              await supabaseAdmin
                .from("orphanet_codes")
                .update({
                  labels: { ...currentLabels, de: t.name_de, en: t.name_en },
                  explanations: t.explanation_de 
                    ? { ...currentExplanations, de: t.explanation_de }
                    : currentExplanations,
                })
                .eq("orpha_code", t.orpha_code);
            }
            console.log(`Updated ${newTranslations.length} Orphanet codes with translations`);
          } catch (aiError) {
            console.error("AI translation error:", aiError);
          }
        }

        // Combine results
        const allTranslations = terms.map((term: any) => {
          const cachedItem = cachedMap.get(term.orphaCode);
          const labels = cachedItem?.labels as Record<string, string> | null;
          const explanations = cachedItem?.explanations as Record<string, string> | null;
          
          // Check if we have a valid German translation
          if (labels?.de && labels.de !== (labels.en || cachedItem?.name)) {
            return {
              orpha_code: cachedItem.orpha_code,
              name_en: labels.en || cachedItem.name,
              name_de: labels.de,
              explanation_de: explanations?.de,
              source: "official" as const,
              confidence: 1.0,
            };
          }
          
          // Check new translations
          const translated = newTranslations.find((t) => t.orpha_code === term.orphaCode);
          if (translated) return translated;
          
          return {
            orpha_code: term.orphaCode,
            name_en: term.name,
            name_de: term.name,
            source: "official" as const,
            confidence: 0,
          };
        });

        return new Response(JSON.stringify({ translations: allTranslations }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      default:
        return new Response(JSON.stringify({ error: `Unknown action: ${action}` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }
  } catch (error) {
    console.error("orphanet-lookup error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
