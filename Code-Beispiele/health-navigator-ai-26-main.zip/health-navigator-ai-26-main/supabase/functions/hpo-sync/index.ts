import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SOURCE_NAME = "hpo";
const OLS_ONTOLOGY_URL = "https://www.ebi.ac.uk/ols4/api/ontologies/hp";

// NOTE: OLS intermittently returns 500 for certain page/size combinations.
// Using smaller page size is more reliable.
const PAGE_SIZE = 50;

// Legacy version stored cursor as *page index* with PAGE_SIZE=100
const LEGACY_PAGE_SIZE = 100;

// We now store cursor as an offset: "o:1234"
const CURSOR_PREFIX = "o:";

// Delay between self-invocations to avoid rate limiting (ms)
const SELF_INVOKE_DELAY_MS = 500;
// Maximum pages per single invocation before self-invoking (to stay within timeout)
const MAX_PAGES_PER_INVOCATION = 5;

function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(supabaseUrl, supabaseKey);
}

/**
 * Fetch the current HPO ontology version from OLS4 API
 * Returns version string like "2026-01-08" or null on failure
 */
async function fetchRemoteVersion(): Promise<string | null> {
  try {
    const response = await fetch(OLS_ONTOLOGY_URL, {
      headers: {
        Accept: "application/json",
        "User-Agent": "Lovable-HPO-Sync/1.2",
      },
    });

    if (!response.ok) {
      console.error(`[HPO Sync] Failed to fetch ontology version: ${response.status}`);
      return null;
    }

    const data = await response.json();
    // OLS4 provides version in config.versionInfo or config.version
    const version = data?.config?.versionInfo || data?.config?.version || null;
    console.log(`[HPO Sync] Remote HPO version: ${version}`);
    return version;
  } catch (err: any) {
    console.error(`[HPO Sync] Error fetching version:`, err?.message || String(err));
    return null;
  }
}

/**
 * Compare versions - returns true if remote is newer than local
 * Versions are typically date-based like "2026-01-08"
 */
function isNewerVersion(remoteVersion: string | null, localVersion: string | null): boolean {
  if (!remoteVersion) return false;
  if (!localVersion) return true; // No local version means we should sync
  
  // Simple string comparison works for ISO date format (YYYY-MM-DD)
  return remoteVersion > localVersion;
}

/**
 * Self-invoke this function to continue the sync in the background
 */
async function invokeSelfAsync(action: string): Promise<void> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  
  // Fire-and-forget: don't await, let it run in background
  fetch(`${supabaseUrl}/functions/v1/hpo-sync`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${serviceRoleKey}`,
    },
    body: JSON.stringify({ action }),
  }).catch((err) => {
    console.error("[HPO Sync] Self-invoke failed:", err);
  });
}

interface HPOTerm {
  obo_id: string;
  label: string;
  description?: string[];
  synonyms?: string[];
  is_obsolete: boolean;
  has_children: boolean;
}

type OlsTermRaw = {
  obo_id?: string;
  label?: string;
  description?: string[];
  synonyms?: string[];
  is_obsolete?: boolean;
  has_children?: boolean;
};

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function formatCursorOffset(offset: number): string {
  return `${CURSOR_PREFIX}${Math.max(0, Math.floor(offset))}`;
}

function parseCursorOffset(lastCursor: string | null, totalAvailable: number | null): number {
  if (!lastCursor) return 0;

  if (lastCursor.startsWith(CURSOR_PREFIX)) {
    const n = parseInt(lastCursor.slice(CURSOR_PREFIX.length), 10);
    return Number.isFinite(n) && n >= 0 ? n : 0;
  }

  // Legacy: last_cursor was page index. Convert to offset.
  const legacyPage = parseInt(lastCursor, 10);
  if (!Number.isFinite(legacyPage) || legacyPage < 0) return 0;

  // Heuristic: HPO has ~32k terms. If cursor is much smaller than total, it's likely a legacy page index.
  if (totalAvailable && totalAvailable > 5000 && legacyPage < totalAvailable / 10) {
    return legacyPage * LEGACY_PAGE_SIZE;
  }

  // Otherwise treat it as already an offset (in case some rows were manually edited)
  return legacyPage;
}

function mapRawToHPOTerm(t: OlsTermRaw): HPOTerm {
  return {
    obo_id: t.obo_id || "",
    label: t.label || "",
    description: t.description,
    synonyms: t.synonyms,
    is_obsolete: Boolean(t.is_obsolete),
    has_children: Boolean(t.has_children),
  };
}

async function fetchOlsTermsPage(
  page: number,
  size: number,
  maxRetries: number = 3,
): Promise<{ items: OlsTermRaw[]; totalElements: number; totalPages: number; currentPage: number }> {
  const url = `${OLS_BASE_URL}/ontologies/hp/terms?page=${page}&size=${size}`;

  let lastError: Error | null = null;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      console.log(`[HPO Sync] Fetching page ${page} (size=${size}), attempt ${attempt + 1}/${maxRetries}`);

      const response = await fetch(url, {
        headers: {
          Accept: "application/json",
          "User-Agent": "Lovable-HPO-Sync/1.1",
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[HPO Sync] API Error ${response.status}: ${errorText.substring(0, 200)}`);

        // Retry on 5xx and 429
        if ((response.status >= 500 || response.status === 429) && attempt < maxRetries - 1) {
          const base = response.status === 429 ? 5000 : 1000;
          const delay = Math.pow(2, attempt) * base + Math.random() * 1000;
          console.log(`[HPO Sync] Retrying in ${Math.round(delay)}ms...`);
          await sleep(delay);
          continue;
        }

        throw new Error(`OLS API error: ${response.status}`);
      }

      const data = await response.json();

      const items: OlsTermRaw[] = data._embedded?.terms || [];
      const totalElements = data.page?.totalElements || 0;
      const totalPages = data.page?.totalPages || 0;
      const currentPage = data.page?.number || 0;

      return { items, totalElements, totalPages, currentPage };
    } catch (err: any) {
      lastError = err;
      console.error(`[HPO Sync] Attempt ${attempt + 1} failed:`, err?.message || String(err));

      if (attempt < maxRetries - 1) {
        const delay = Math.pow(2, attempt) * 1000;
        await sleep(delay);
      }
    }
  }

  throw lastError || new Error("Max retries exceeded");
}

const OLS_BASE_URL = "https://www.ebi.ac.uk/ols4/api";

async function persistHPOTerms(supabase: any, terms: HPOTerm[]): Promise<number> {
  if (terms.length === 0) return 0;

  const codesToInsert = terms.map((t) => ({
    hpo_code: t.obo_id,
    label: t.label,
    definition: t.description?.[0] || null,
    synonyms: t.synonyms || [],
    is_terminal: !t.has_children,
    labels: { en: t.label },
    source: "ols4_bulk_sync",
  }));

  const { error } = await supabase.from("hpo_codes").upsert(codesToInsert, { onConflict: "hpo_code" });

  if (error) {
    console.error("[HPO Sync] Persist error:", error);
    return 0;
  }

  return terms.length;
}

async function getSyncStatus(supabase: any) {
  const { data } = await supabase.from("sync_status").select("*").eq("source_name", SOURCE_NAME).maybeSingle();
  return data;
}

async function updateSyncStatus(supabase: any, updates: Record<string, any>) {
  await supabase
    .from("sync_status")
    .upsert(
      {
        source_name: SOURCE_NAME,
        ...updates,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "source_name" },
    );
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = getSupabaseAdmin();

  try {
    const body = await req.json();
    const action = body.action || "sync_page";

    switch (action) {
      case "init": {
        await updateSyncStatus(supabase, {
          status: "running",
          total_synced: 0,
          total_available: null,
          last_cursor: formatCursorOffset(0),
          error_message: null,
          started_at: new Date().toISOString(),
          completed_at: null,
        });

        return new Response(JSON.stringify({ success: true, message: "Sync initialized" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_page": {
        const status = await getSyncStatus(supabase);
        const totalAvailableFromDb = status?.total_available ?? null;

        const offset = parseCursorOffset(status?.last_cursor ?? null, totalAvailableFromDb);
        const page = Math.floor(offset / PAGE_SIZE);
        const inPageOffset = offset % PAGE_SIZE;

        let pageData: { items: OlsTermRaw[]; totalElements: number; totalPages: number; currentPage: number };

        try {
          pageData = await fetchOlsTermsPage(page, PAGE_SIZE);
        } catch (err: any) {
          const msg = err?.message || String(err);

          // Graceful degradation: pause instead of returning 500.
          await updateSyncStatus(supabase, {
            status: "paused",
            error_message: msg,
            last_cursor: formatCursorOffset(offset),
            completed_at: null,
          });

          return new Response(
            JSON.stringify({ paused: true, hasMore: false, syncedCount: 0, error: msg, offset }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }

        const items = pageData.items || [];
        const totalElements = pageData.totalElements || 0;
        const slice = items.slice(inPageOffset);

        if (slice.length === 0) {
          // No more items in this page; treat as completed.
          await updateSyncStatus(supabase, {
            status: "completed",
            total_available: totalElements || totalAvailableFromDb,
            last_cursor: formatCursorOffset(offset),
            completed_at: new Date().toISOString(),
          });

          return new Response(
            JSON.stringify({ hasMore: false, syncedCount: 0, totalSynced: status?.total_synced || 0, totalAvailable: totalElements, offset }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }

        const terms: HPOTerm[] = slice
          .map(mapRawToHPOTerm)
          .filter((t) => t.obo_id?.startsWith("HP:") && !t.is_obsolete);

        const synced = await persistHPOTerms(supabase, terms);

        const newOffset = offset + slice.length;
        const hasMore = totalElements ? newOffset < totalElements : pageData.currentPage < pageData.totalPages - 1;
        const newTotalSynced = (status?.total_synced || 0) + synced;

        await updateSyncStatus(supabase, {
          status: hasMore ? "running" : "completed",
          total_synced: newTotalSynced,
          total_available: totalElements,
          last_cursor: formatCursorOffset(newOffset),
          error_message: null,
          completed_at: hasMore ? null : new Date().toISOString(),
        });

        console.log(
          `[HPO Sync] offset=${offset} page=${page} inPageOffset=${inPageOffset} items=${slice.length} synced=${synced} total=${newTotalSynced}/${totalElements}`,
        );

        return new Response(
          JSON.stringify({
            hasMore,
            syncedCount: synced,
            totalSynced: newTotalSynced,
            totalAvailable: totalElements,
            offset: newOffset,
            page,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      case "pause": {
        await updateSyncStatus(supabase, { status: "paused" });
        return new Response(JSON.stringify({ success: true, message: "Sync paused" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "reset": {
        await updateSyncStatus(supabase, {
          status: "pending",
          total_synced: 0,
          total_available: null,
          last_cursor: null,
          error_message: null,
          started_at: null,
          completed_at: null,
        });
        return new Response(JSON.stringify({ success: true, message: "Sync reset" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "status": {
        const s = await getSyncStatus(supabase);
        return new Response(JSON.stringify(s || { status: "pending", total_synced: 0 }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "check_version": {
        const status = await getSyncStatus(supabase);
        const remoteVersion = await fetchRemoteVersion();
        const localVersion = status?.local_version || null;
        const needsSync = isNewerVersion(remoteVersion, localVersion);

        // Update remote_version in sync_status
        if (remoteVersion) {
          await updateSyncStatus(supabase, {
            remote_version: remoteVersion,
          });
        }

        return new Response(
          JSON.stringify({
            remoteVersion,
            localVersion,
            needsSync,
            message: needsSync 
              ? `New version available: ${remoteVersion} (current: ${localVersion || 'none'})`
              : `Already up to date: ${localVersion}`,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "fix_count": {
        const { count: actualCount } = await supabase
          .from("hpo_codes")
          .select("hpo_code", { count: "exact", head: true });

        await updateSyncStatus(supabase, {
          status: "completed",
          total_synced: actualCount || 0,
          total_available: actualCount || 0,
          last_cursor: null,
          completed_at: new Date().toISOString(),
          error_message: null,
        });

        return new Response(
          JSON.stringify({ success: true, message: "Count fixed", actualCount }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // ============================================================
      // FULL SYNC: Backend-driven autonomous synchronization
      // ============================================================
      case "full_sync": {
        // Initialize if not already running
        let status = await getSyncStatus(supabase);
        
        // Check version first on fresh start
        if (!status || status.status === "pending" || status.status === "error") {
          const remoteVersion = await fetchRemoteVersion();
          const localVersion = status?.local_version || null;
          
          // Skip sync if already up to date
          if (!isNewerVersion(remoteVersion, localVersion)) {
            return new Response(
              JSON.stringify({ 
                success: true, 
                skipped: true,
                message: `Already up to date: ${localVersion}`,
                localVersion,
                remoteVersion,
              }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          await updateSyncStatus(supabase, {
            status: "running",
            total_synced: 0,
            total_available: null,
            last_cursor: formatCursorOffset(0),
            error_message: null,
            remote_version: remoteVersion,
            started_at: new Date().toISOString(),
            completed_at: null,
          });
          status = await getSyncStatus(supabase);
        }

        // Check if paused or completed - don't continue
        if (status?.status === "paused") {
          return new Response(
            JSON.stringify({ success: false, message: "Sync is paused. Use 'resume_sync' to continue." }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        if (status?.status === "completed") {
          return new Response(
            JSON.stringify({ success: true, message: "Sync already completed", totalSynced: status.total_synced }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        let baseTotalSynced = status?.total_synced || 0;
        let currentOffset = parseCursorOffset(status?.last_cursor ?? null, status?.total_available ?? null);
        let pagesProcessed = 0;
        let hasMore = true;

        // Process multiple pages in this invocation
        while (hasMore && pagesProcessed < MAX_PAGES_PER_INVOCATION) {
          // Re-check status in case user paused
          const currentStatus = await getSyncStatus(supabase);
          if (currentStatus?.status === "paused" || currentStatus?.status === "completed") {
            console.log(`[HPO Full Sync] Status is ${currentStatus?.status}, stopping.`);
            return new Response(
              JSON.stringify({ success: true, message: `Sync ${currentStatus?.status}`, totalSynced: baseTotalSynced }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          const page = Math.floor(currentOffset / PAGE_SIZE);
          const inPageOffset = currentOffset % PAGE_SIZE;

          let pageData: { items: OlsTermRaw[]; totalElements: number; totalPages: number; currentPage: number };

          try {
            pageData = await fetchOlsTermsPage(page, PAGE_SIZE);
          } catch (err: any) {
            const msg = err?.message || String(err);
            
            // Graceful degradation: wait and retry
            console.error(`[HPO Full Sync] Error: ${msg}, will retry...`);
            await updateSyncStatus(supabase, {
              status: "running",
              error_message: `Temporary error, retrying: ${msg}`,
            });
            
            await sleep(5000);
            invokeSelfAsync("full_sync");
            
            return new Response(
              JSON.stringify({ success: true, message: "Error occurred, scheduled retry", totalSynced: baseTotalSynced }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          const items = pageData.items || [];
          const totalElements = pageData.totalElements || 0;
          const slice = items.slice(inPageOffset);

          if (slice.length === 0) {
            // No more items - completed, set local_version to remote_version
            const latestStatus = await getSyncStatus(supabase);
            await updateSyncStatus(supabase, {
              status: "completed",
              total_available: totalElements,
              last_cursor: null,
              completed_at: new Date().toISOString(),
              error_message: null,
              local_version: latestStatus?.remote_version || null,
            });

            return new Response(
              JSON.stringify({ 
                success: true, 
                message: "Full sync completed!",
                totalSynced: baseTotalSynced,
                totalAvailable: totalElements,
                hasMore: false,
                version: latestStatus?.remote_version,
              }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          const terms: HPOTerm[] = slice
            .map(mapRawToHPOTerm)
            .filter((t) => t.obo_id?.startsWith("HP:") && !t.is_obsolete);

          const synced = await persistHPOTerms(supabase, terms);
          baseTotalSynced += synced;
          currentOffset += slice.length;
          hasMore = totalElements ? currentOffset < totalElements : pageData.currentPage < pageData.totalPages - 1;
          pagesProcessed++;

          // Update status
          await updateSyncStatus(supabase, {
            status: hasMore ? "running" : "completed",
            total_synced: baseTotalSynced,
            total_available: totalElements,
            last_cursor: hasMore ? formatCursorOffset(currentOffset) : null,
            completed_at: hasMore ? null : new Date().toISOString(),
            error_message: null,
          });

          console.log(`[HPO Full Sync] Page ${pagesProcessed}: ${synced} terms. Total: ${baseTotalSynced}/${totalElements}`);

          // Small delay between pages
          if (hasMore && pagesProcessed < MAX_PAGES_PER_INVOCATION) {
            await sleep(200);
          }
        }

        // If there's more data, schedule next batch
        if (hasMore) {
          // Re-check if paused/completed before self-invoking
          const latestStatus = await getSyncStatus(supabase);
          if (latestStatus?.status === "paused" || latestStatus?.status === "completed") {
            console.log(`[HPO Full Sync] Status changed to ${latestStatus?.status}, stopping self-invoke loop.`);
            return new Response(
              JSON.stringify({ 
                success: true, 
                message: `Sync ${latestStatus?.status}`,
                totalSynced: baseTotalSynced,
                hasMore: true,
              }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          await sleep(SELF_INVOKE_DELAY_MS);
          invokeSelfAsync("full_sync");
          
          return new Response(
            JSON.stringify({ 
              success: true, 
              message: "Batch complete, continuing in background",
              totalSynced: baseTotalSynced,
              hasMore: true,
            }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        // Final completion - set local_version
        const finalStatus = await getSyncStatus(supabase);
        await updateSyncStatus(supabase, {
          local_version: finalStatus?.remote_version || null,
        });

        return new Response(
          JSON.stringify({ 
            success: true, 
            message: "Full sync completed!",
            totalSynced: baseTotalSynced,
            hasMore: false,
            version: finalStatus?.remote_version,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "resume_sync": {
        const status = await getSyncStatus(supabase);
        
        if (status?.status === "completed") {
          return new Response(
            JSON.stringify({ success: true, message: "Already completed", totalSynced: status.total_synced }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        // Set status back to running and trigger full_sync
        await updateSyncStatus(supabase, {
          status: "running",
          error_message: null,
        });

        invokeSelfAsync("full_sync");

        return new Response(
          JSON.stringify({ success: true, message: "Sync resumed in background" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      default:
        return new Response(JSON.stringify({ error: `Unknown action: ${action}` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }
  } catch (error: any) {
    console.error("[HPO Sync] Error:", error);

    await updateSyncStatus(supabase, {
      status: "error",
      error_message: error?.message || String(error),
    });

    return new Response(JSON.stringify({ error: error?.message || String(error) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
