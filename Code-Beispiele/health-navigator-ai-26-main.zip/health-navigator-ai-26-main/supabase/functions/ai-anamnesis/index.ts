import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
   "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Common symptom mappings for quick HPO lookup
const COMMON_HPO_MAPPINGS: Record<string, { code: string; label_de: string; label_en: string }> = {
  "bauchschmerzen": { code: "HP:0002027", label_de: "Bauchschmerzen", label_en: "Abdominal pain" },
  "abdominal pain": { code: "HP:0002027", label_de: "Bauchschmerzen", label_en: "Abdominal pain" },
  "kopfschmerzen": { code: "HP:0002315", label_de: "Kopfschmerzen", label_en: "Headache" },
  "headache": { code: "HP:0002315", label_de: "Kopfschmerzen", label_en: "Headache" },
  "fieber": { code: "HP:0001945", label_de: "Fieber", label_en: "Fever" },
  "fever": { code: "HP:0001945", label_de: "Fieber", label_en: "Fever" },
  "übelkeit": { code: "HP:0002018", label_de: "Übelkeit", label_en: "Nausea" },
  "nausea": { code: "HP:0002018", label_de: "Übelkeit", label_en: "Nausea" },
  "erbrechen": { code: "HP:0002013", label_de: "Erbrechen", label_en: "Vomiting" },
  "vomiting": { code: "HP:0002013", label_de: "Erbrechen", label_en: "Vomiting" },
  "durchfall": { code: "HP:0002014", label_de: "Durchfall", label_en: "Diarrhea" },
  "diarrhea": { code: "HP:0002014", label_de: "Durchfall", label_en: "Diarrhea" },
  "müdigkeit": { code: "HP:0012378", label_de: "Müdigkeit", label_en: "Fatigue" },
  "fatigue": { code: "HP:0012378", label_de: "Müdigkeit", label_en: "Fatigue" },
  "schwindel": { code: "HP:0002321", label_de: "Schwindel", label_en: "Vertigo" },
  "vertigo": { code: "HP:0002321", label_de: "Schwindel", label_en: "Vertigo" },
  "husten": { code: "HP:0012735", label_de: "Husten", label_en: "Cough" },
  "cough": { code: "HP:0012735", label_de: "Husten", label_en: "Cough" },
  "brustschmerzen": { code: "HP:0100749", label_de: "Brustschmerzen", label_en: "Chest pain" },
  "chest pain": { code: "HP:0100749", label_de: "Brustschmerzen", label_en: "Chest pain" },
  "atemnot": { code: "HP:0002094", label_de: "Atemnot", label_en: "Dyspnea" },
  "dyspnea": { code: "HP:0002094", label_de: "Atemnot", label_en: "Dyspnea" },
  "rückenschmerzen": { code: "HP:0003418", label_de: "Rückenschmerzen", label_en: "Back pain" },
  "back pain": { code: "HP:0003418", label_de: "Rückenschmerzen", label_en: "Back pain" },
  "gelenkschmerzen": { code: "HP:0002829", label_de: "Gelenkschmerzen", label_en: "Arthralgia" },
  "arthralgia": { code: "HP:0002829", label_de: "Gelenkschmerzen", label_en: "Arthralgia" },
  "schlaflosigkeit": { code: "HP:0100785", label_de: "Schlaflosigkeit", label_en: "Insomnia" },
  "insomnia": { code: "HP:0100785", label_de: "Schlaflosigkeit", label_en: "Insomnia" },
  "appetitlosigkeit": { code: "HP:0004396", label_de: "Appetitlosigkeit", label_en: "Anorexia" },
  "anorexia": { code: "HP:0004396", label_de: "Appetitlosigkeit", label_en: "Anorexia" },
  "gewichtsverlust": { code: "HP:0001824", label_de: "Gewichtsverlust", label_en: "Weight loss" },
  "weight loss": { code: "HP:0001824", label_de: "Gewichtsverlust", label_en: "Weight loss" },
  "obstipation": { code: "HP:0002019", label_de: "Obstipation", label_en: "Constipation" },
  "verstopfung": { code: "HP:0002019", label_de: "Verstopfung", label_en: "Constipation" },
  "constipation": { code: "HP:0002019", label_de: "Obstipation", label_en: "Constipation" },
  "halsschmerzen": { code: "HP:0025439", label_de: "Halsschmerzen", label_en: "Pharyngalgia" },
  "sore throat": { code: "HP:0025439", label_de: "Halsschmerzen", label_en: "Pharyngalgia" },
  "schnupfen": { code: "HP:0000458", label_de: "Schnupfen", label_en: "Rhinorrhea" },
  "rhinorrhea": { code: "HP:0000458", label_de: "Schnupfen", label_en: "Rhinorrhea" },
  "herzrasen": { code: "HP:0001962", label_de: "Herzrasen", label_en: "Palpitations" },
  "palpitations": { code: "HP:0001962", label_de: "Herzrasen", label_en: "Palpitations" },
  "schwitzen": { code: "HP:0000975", label_de: "Schwitzen", label_en: "Hyperhidrosis" },
  "hyperhidrosis": { code: "HP:0000975", label_de: "Schwitzen", label_en: "Hyperhidrosis" },
  "zittern": { code: "HP:0001337", label_de: "Zittern", label_en: "Tremor" },
  "tremor": { code: "HP:0001337", label_de: "Zittern", label_en: "Tremor" },
  "taubheit": { code: "HP:0003474", label_de: "Taubheitsgefühl", label_en: "Sensory impairment" },
  "numbness": { code: "HP:0003474", label_de: "Taubheitsgefühl", label_en: "Sensory impairment" },
  "sehstörung": { code: "HP:0000505", label_de: "Sehstörung", label_en: "Visual impairment" },
  "blurred vision": { code: "HP:0000505", label_de: "Sehstörung", label_en: "Visual impairment" },
  "ohrenschmerzen": { code: "HP:0030766", label_de: "Ohrenschmerzen", label_en: "Ear pain" },
  "ear pain": { code: "HP:0030766", label_de: "Ohrenschmerzen", label_en: "Ear pain" },
  "juckreiz": { code: "HP:0000989", label_de: "Juckreiz", label_en: "Pruritus" },
  "itching": { code: "HP:0000989", label_de: "Juckreiz", label_en: "Pruritus" },
  "ausschlag": { code: "HP:0000988", label_de: "Hautausschlag", label_en: "Skin rash" },
  "rash": { code: "HP:0000988", label_de: "Hautausschlag", label_en: "Skin rash" },
  "schwellung": { code: "HP:0001004", label_de: "Schwellung", label_en: "Lymphedema" },
  "swelling": { code: "HP:0001004", label_de: "Schwellung", label_en: "Lymphedema" },
  "blähungen": { code: "HP:0003270", label_de: "Blähungen", label_en: "Abdominal distension" },
  "bloating": { code: "HP:0003270", label_de: "Blähungen", label_en: "Abdominal distension" },
  "sodbrennen": { code: "HP:0031845", label_de: "Sodbrennen", label_en: "Heartburn" },
  "heartburn": { code: "HP:0031845", label_de: "Sodbrennen", label_en: "Heartburn" },
  "angst": { code: "HP:0000739", label_de: "Angst", label_en: "Anxiety" },
  "anxiety": { code: "HP:0000739", label_de: "Angst", label_en: "Anxiety" },
  "depression": { code: "HP:0000716", label_de: "Depression", label_en: "Depressivity" },
  "konzentrationsstörung": { code: "HP:0007018", label_de: "Konzentrationsstörung", label_en: "Attention deficit hyperactivity disorder" },
  // Migräne / Migraine
  "migräne": { code: "HP:0002076", label_de: "Migräne", label_en: "Migraine" },
  "migraine": { code: "HP:0002076", label_de: "Migräne", label_en: "Migraine" },
  // Kribbeln / Paresthesia
  "kribbeln": { code: "HP:0003401", label_de: "Parästhesie", label_en: "Paresthesia" },
  "parästhesie": { code: "HP:0003401", label_de: "Parästhesie", label_en: "Paresthesia" },
  "paresthesia": { code: "HP:0003401", label_de: "Parästhesie", label_en: "Paresthesia" },
  "tingling": { code: "HP:0003401", label_de: "Parästhesie", label_en: "Paresthesia" },
  // Bluthochdruck / Hypertension
  "bluthochdruck": { code: "HP:0000822", label_de: "Bluthochdruck", label_en: "Hypertension" },
  "hypertonie": { code: "HP:0000822", label_de: "Bluthochdruck", label_en: "Hypertension" },
  "hypertension": { code: "HP:0000822", label_de: "Bluthochdruck", label_en: "Hypertension" },
  "high blood pressure": { code: "HP:0000822", label_de: "Bluthochdruck", label_en: "Hypertension" },
  // Niedriger Blutdruck / Hypotension
  "niedriger blutdruck": { code: "HP:0002615", label_de: "Hypotonie", label_en: "Hypotension" },
  "hypotonie": { code: "HP:0002615", label_de: "Hypotonie", label_en: "Hypotension" },
  "hypotension": { code: "HP:0002615", label_de: "Hypotonie", label_en: "Hypotension" },
  "low blood pressure": { code: "HP:0002615", label_de: "Hypotonie", label_en: "Hypotension" },
  // Diabetes-bezogene Symptome
  "diabetes": { code: "HP:0000819", label_de: "Diabetes mellitus", label_en: "Diabetes mellitus" },
  "blutzucker": { code: "HP:0003074", label_de: "Hyperglykämie", label_en: "Hyperglycemia" },
  "hyperglykämie": { code: "HP:0003074", label_de: "Hyperglykämie", label_en: "Hyperglycemia" },
  "hyperglycemia": { code: "HP:0003074", label_de: "Hyperglykämie", label_en: "Hyperglycemia" },
  // Muskelbeschwerden
  "muskelschmerzen": { code: "HP:0003326", label_de: "Myalgie", label_en: "Myalgia" },
  "myalgie": { code: "HP:0003326", label_de: "Myalgie", label_en: "Myalgia" },
  "myalgia": { code: "HP:0003326", label_de: "Myalgie", label_en: "Myalgia" },
  "muscle pain": { code: "HP:0003326", label_de: "Myalgie", label_en: "Myalgia" },
  "muskelschwäche": { code: "HP:0001324", label_de: "Muskelschwäche", label_en: "Muscle weakness" },
  "muscle weakness": { code: "HP:0001324", label_de: "Muskelschwäche", label_en: "Muscle weakness" },
  "muskelkrämpfe": { code: "HP:0003394", label_de: "Muskelkrämpfe", label_en: "Muscle cramps" },
  "muscle cramps": { code: "HP:0003394", label_de: "Muskelkrämpfe", label_en: "Muscle cramps" },
  // Neurologische Symptome
  "schlaganfall": { code: "HP:0001297", label_de: "Schlaganfall", label_en: "Stroke" },
  "stroke": { code: "HP:0001297", label_de: "Schlaganfall", label_en: "Stroke" },
  "lähmung": { code: "HP:0003470", label_de: "Lähmung", label_en: "Paralysis" },
  "paralysis": { code: "HP:0003470", label_de: "Lähmung", label_en: "Paralysis" },
  "krampfanfall": { code: "HP:0001250", label_de: "Krampfanfall", label_en: "Seizure" },
  "seizure": { code: "HP:0001250", label_de: "Krampfanfall", label_en: "Seizure" },
  "epilepsie": { code: "HP:0001250", label_de: "Epilepsie", label_en: "Epilepsy" },
  "epilepsy": { code: "HP:0001250", label_de: "Epilepsie", label_en: "Epilepsy" },
  "bewusstlosigkeit": { code: "HP:0007185", label_de: "Bewusstlosigkeit", label_en: "Loss of consciousness" },
  "ohnmacht": { code: "HP:0001279", label_de: "Synkope", label_en: "Syncope" },
  "syncope": { code: "HP:0001279", label_de: "Synkope", label_en: "Syncope" },
  "fainting": { code: "HP:0001279", label_de: "Synkope", label_en: "Syncope" },
  "gedächtnisstörung": { code: "HP:0002354", label_de: "Gedächtnisstörung", label_en: "Memory impairment" },
  "memory loss": { code: "HP:0002354", label_de: "Gedächtnisstörung", label_en: "Memory impairment" },
  "vergesslichkeit": { code: "HP:0002354", label_de: "Vergesslichkeit", label_en: "Memory impairment" },
  // Herz-Kreislauf
  "herzrhythmusstörung": { code: "HP:0011675", label_de: "Arrhythmie", label_en: "Arrhythmia" },
  "arrhythmie": { code: "HP:0011675", label_de: "Arrhythmie", label_en: "Arrhythmia" },
  "arrhythmia": { code: "HP:0011675", label_de: "Arrhythmie", label_en: "Arrhythmia" },
  "herzinsuffizienz": { code: "HP:0001635", label_de: "Herzinsuffizienz", label_en: "Congestive heart failure" },
  "heart failure": { code: "HP:0001635", label_de: "Herzinsuffizienz", label_en: "Congestive heart failure" },
  // Atemwege
  "asthma": { code: "HP:0002099", label_de: "Asthma", label_en: "Asthma" },
  "kurzatmigkeit": { code: "HP:0002094", label_de: "Kurzatmigkeit", label_en: "Dyspnea" },
  "shortness of breath": { code: "HP:0002094", label_de: "Kurzatmigkeit", label_en: "Dyspnea" },
  "keuchen": { code: "HP:0030828", label_de: "Giemen", label_en: "Wheezing" },
  "wheezing": { code: "HP:0030828", label_de: "Giemen", label_en: "Wheezing" },
  "heiserkeit": { code: "HP:0001609", label_de: "Heiserkeit", label_en: "Hoarseness" },
  "hoarseness": { code: "HP:0001609", label_de: "Heiserkeit", label_en: "Hoarseness" },
  // Magen-Darm
  "magenschmerzen": { code: "HP:0002027", label_de: "Magenschmerzen", label_en: "Abdominal pain" },
  "stomach pain": { code: "HP:0002027", label_de: "Magenschmerzen", label_en: "Abdominal pain" },
  "reflux": { code: "HP:0002020", label_de: "Gastroösophagealer Reflux", label_en: "Gastroesophageal reflux" },
  "gastroesophageal reflux": { code: "HP:0002020", label_de: "Gastroösophagealer Reflux", label_en: "Gastroesophageal reflux" },
  "schluckbeschwerden": { code: "HP:0002015", label_de: "Dysphagie", label_en: "Dysphagia" },
  "dysphagie": { code: "HP:0002015", label_de: "Dysphagie", label_en: "Dysphagia" },
  "dysphagia": { code: "HP:0002015", label_de: "Dysphagie", label_en: "Dysphagia" },
  "blut im stuhl": { code: "HP:0025085", label_de: "Blut im Stuhl", label_en: "Blood in stool" },
  "blood in stool": { code: "HP:0025085", label_de: "Blut im Stuhl", label_en: "Blood in stool" },
  // Urologische Symptome
  "häufiges wasserlassen": { code: "HP:0100515", label_de: "Pollakisurie", label_en: "Urinary frequency" },
  "urinary frequency": { code: "HP:0100515", label_de: "Pollakisurie", label_en: "Urinary frequency" },
  "schmerzen beim wasserlassen": { code: "HP:0100518", label_de: "Dysurie", label_en: "Dysuria" },
  "painful urination": { code: "HP:0100518", label_de: "Dysurie", label_en: "Dysuria" },
  "dysurie": { code: "HP:0100518", label_de: "Dysurie", label_en: "Dysuria" },
  "dysuria": { code: "HP:0100518", label_de: "Dysurie", label_en: "Dysuria" },
  "blut im urin": { code: "HP:0000790", label_de: "Hämaturie", label_en: "Hematuria" },
  "hematuria": { code: "HP:0000790", label_de: "Hämaturie", label_en: "Hematuria" },
  "inkontinenz": { code: "HP:0000020", label_de: "Harninkontinenz", label_en: "Urinary incontinence" },
  "urinary incontinence": { code: "HP:0000020", label_de: "Harninkontinenz", label_en: "Urinary incontinence" },
  // Augen
  "sehverschlechterung": { code: "HP:0000505", label_de: "Sehstörung", label_en: "Visual impairment" },
  "vision loss": { code: "HP:0000505", label_de: "Sehstörung", label_en: "Visual impairment" },
  "doppeltsehen": { code: "HP:0000651", label_de: "Diplopie", label_en: "Diplopia" },
  "diplopia": { code: "HP:0000651", label_de: "Diplopie", label_en: "Diplopia" },
  "double vision": { code: "HP:0000651", label_de: "Diplopie", label_en: "Diplopia" },
  "rote augen": { code: "HP:0025337", label_de: "Konjunktivale Injektion", label_en: "Red eye" },
  "red eye": { code: "HP:0025337", label_de: "Konjunktivale Injektion", label_en: "Red eye" },
  "trockene augen": { code: "HP:0000513", label_de: "Xerophthalmie", label_en: "Dry eye" },
  "dry eyes": { code: "HP:0000513", label_de: "Xerophthalmie", label_en: "Dry eye" },
  // Ohren
  "hörverlust": { code: "HP:0000365", label_de: "Hörverlust", label_en: "Hearing impairment" },
  "hearing loss": { code: "HP:0000365", label_de: "Hörverlust", label_en: "Hearing impairment" },
  "schwerhörigkeit": { code: "HP:0000365", label_de: "Schwerhörigkeit", label_en: "Hearing impairment" },
  "tinnitus": { code: "HP:0000360", label_de: "Tinnitus", label_en: "Tinnitus" },
  "ohrgeräusche": { code: "HP:0000360", label_de: "Tinnitus", label_en: "Tinnitus" },
  // Haut
  "ekzem": { code: "HP:0000964", label_de: "Ekzem", label_en: "Eczema" },
  "eczema": { code: "HP:0000964", label_de: "Ekzem", label_en: "Eczema" },
  "psoriasis": { code: "HP:0033018", label_de: "Psoriasis", label_en: "Psoriasis" },
  "schuppenflechte": { code: "HP:0033018", label_de: "Psoriasis", label_en: "Psoriasis" },
  "akne": { code: "HP:0000989", label_de: "Akne", label_en: "Acne" },
  "acne": { code: "HP:0000989", label_de: "Akne", label_en: "Acne" },
  "haarausfall": { code: "HP:0001596", label_de: "Alopezie", label_en: "Alopecia" },
  "alopecia": { code: "HP:0001596", label_de: "Alopezie", label_en: "Alopecia" },
  "hair loss": { code: "HP:0001596", label_de: "Alopezie", label_en: "Alopecia" },
  "blässe": { code: "HP:0000980", label_de: "Blässe", label_en: "Pallor" },
  "pallor": { code: "HP:0000980", label_de: "Blässe", label_en: "Pallor" },
  "gelbsucht": { code: "HP:0000952", label_de: "Ikterus", label_en: "Jaundice" },
  "ikterus": { code: "HP:0000952", label_de: "Ikterus", label_en: "Jaundice" },
  "jaundice": { code: "HP:0000952", label_de: "Ikterus", label_en: "Jaundice" },
  // Psychische Symptome
  "panikattacke": { code: "HP:0032166", label_de: "Panikattacke", label_en: "Panic attack" },
  "panic attack": { code: "HP:0032166", label_de: "Panikattacke", label_en: "Panic attack" },
  "stress": { code: "HP:0031956", label_de: "Erhöhte Stressempfindlichkeit", label_en: "Stress intolerance" },
  "reizbarkeit": { code: "HP:0000737", label_de: "Reizbarkeit", label_en: "Irritability" },
  "irritability": { code: "HP:0000737", label_de: "Reizbarkeit", label_en: "Irritability" },
  "erschöpfung": { code: "HP:0012378", label_de: "Erschöpfung", label_en: "Fatigue" },
  "exhaustion": { code: "HP:0012378", label_de: "Erschöpfung", label_en: "Fatigue" },
  // Stoffwechsel
  "durst": { code: "HP:0001959", label_de: "Polydipsie", label_en: "Polydipsia" },
  "polydipsia": { code: "HP:0001959", label_de: "Polydipsie", label_en: "Polydipsia" },
  "gewichtszunahme": { code: "HP:0004324", label_de: "Gewichtszunahme", label_en: "Increased body weight" },
  "weight gain": { code: "HP:0004324", label_de: "Gewichtszunahme", label_en: "Increased body weight" },
  // Allergien
  "allergie": { code: "HP:0012393", label_de: "Allergie", label_en: "Allergy" },
  "allergy": { code: "HP:0012393", label_de: "Allergie", label_en: "Allergy" },
  "heuschnupfen": { code: "HP:0003193", label_de: "Allergische Rhinitis", label_en: "Allergic rhinitis" },
  "allergic rhinitis": { code: "HP:0003193", label_de: "Allergische Rhinitis", label_en: "Allergic rhinitis" },
  // Gelenke und Bewegungsapparat
  "arthritis": { code: "HP:0001369", label_de: "Arthritis", label_en: "Arthritis" },
  "steifheit": { code: "HP:0001387", label_de: "Gelenksteifigkeit", label_en: "Joint stiffness" },
  "joint stiffness": { code: "HP:0001387", label_de: "Gelenksteifigkeit", label_en: "Joint stiffness" },
  "nackenschmerzen": { code: "HP:0030836", label_de: "Nackenschmerzen", label_en: "Neck pain" },
  "neck pain": { code: "HP:0030836", label_de: "Nackenschmerzen", label_en: "Neck pain" },
  "schulterschmerzen": { code: "HP:0030835", label_de: "Schulterschmerzen", label_en: "Shoulder pain" },
  "shoulder pain": { code: "HP:0030835", label_de: "Schulterschmerzen", label_en: "Shoulder pain" },
  "knieschmerzen": { code: "HP:0030839", label_de: "Knieschmerzen", label_en: "Knee pain" },
  "knee pain": { code: "HP:0030839", label_de: "Knieschmerzen", label_en: "Knee pain" },
  "hüftschmerzen": { code: "HP:0030838", label_de: "Hüftschmerzen", label_en: "Hip pain" },
  "hip pain": { code: "HP:0030838", label_de: "Hüftschmerzen", label_en: "Hip pain" },
  // Infektionen
  "fieberbläschen": { code: "HP:0031821", label_de: "Herpes labialis", label_en: "Herpes labialis" },
  "herpes": { code: "HP:0031821", label_de: "Herpes labialis", label_en: "Herpes labialis" },
  "erkältung": { code: "HP:0005407", label_de: "Häufige Erkältungen", label_en: "Frequent common colds" },
  "common cold": { code: "HP:0005407", label_de: "Häufige Erkältungen", label_en: "Frequent common colds" },
  "grippe": { code: "HP:0032177", label_de: "Grippeähnliche Symptome", label_en: "Flu-like symptoms" },
  "flu": { code: "HP:0032177", label_de: "Grippeähnliche Symptome", label_en: "Flu-like symptoms" },
  // Sonstiges
  "mundtrockenheit": { code: "HP:0000217", label_de: "Mundtrockenheit", label_en: "Xerostomia" },
  "dry mouth": { code: "HP:0000217", label_de: "Mundtrockenheit", label_en: "Xerostomia" },
  "xerostomia": { code: "HP:0000217", label_de: "Mundtrockenheit", label_en: "Xerostomia" },
  "nachtschweiß": { code: "HP:0030166", label_de: "Nachtschweiß", label_en: "Night sweats" },
  "night sweats": { code: "HP:0030166", label_de: "Nachtschweiß", label_en: "Night sweats" },
  "schüttelfrost": { code: "HP:0025143", label_de: "Schüttelfrost", label_en: "Chills" },
  "chills": { code: "HP:0025143", label_de: "Schüttelfrost", label_en: "Chills" },
  "kälteintoleranz": { code: "HP:0002046", label_de: "Kälteintoleranz", label_en: "Cold intolerance" },
  "cold intolerance": { code: "HP:0002046", label_de: "Kälteintoleranz", label_en: "Cold intolerance" },
  "wärmeintoleranz": { code: "HP:0002045", label_de: "Wärmeintoleranz", label_en: "Heat intolerance" },
  "heat intolerance": { code: "HP:0002045", label_de: "Wärmeintoleranz", label_en: "Heat intolerance" },
};

// Function to find HPO codes for symptoms using multiple strategies
async function findHpoCodes(
  symptomText: string, 
  supabaseUrl: string,
  supabaseKey: string,
  authHeader: string
): Promise<{ code: string; label_de: string; label_en: string }[]> {
  const normalizedText = symptomText.toLowerCase().trim();
  const results: { code: string; label_de: string; label_en: string }[] = [];
  
  // Strategy 1: Check common mappings first (fastest)
  for (const [keyword, mapping] of Object.entries(COMMON_HPO_MAPPINGS)) {
    if (normalizedText.includes(keyword)) {
      results.push(mapping);
    }
  }
  
  if (results.length > 0) {
    console.log(`Found ${results.length} HPO codes via common mappings for: ${symptomText}`);
    return results;
  }
  
  // Strategy 2: Check database for cached translations
  try {
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } },
    });
    
    const { data: cachedTranslations } = await supabase
      .from('hpo_translations')
      .select('hpo_code, label_de, label_en')
      .or(`label_de.ilike.%${normalizedText}%,label_en.ilike.%${normalizedText}%,synonyms.cs.{${normalizedText}}`)
      .limit(5);
    
    if (cachedTranslations && cachedTranslations.length > 0) {
      for (const t of cachedTranslations) {
        results.push({
          code: t.hpo_code,
          label_de: t.label_de,
          label_en: t.label_en,
        });
      }
      console.log(`Found ${results.length} HPO codes via database for: ${symptomText}`);
      return results;
    }
  } catch (err) {
    console.error('Database HPO lookup error:', err);
  }
  
  // Strategy 3: Call hpo-lookup edge function
  try {
    const lookupResponse = await fetch(`${supabaseUrl}/functions/v1/hpo-lookup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader,
      },
      body: JSON.stringify({ query: symptomText, language: 'de' }),
    });
    
    if (lookupResponse.ok) {
      const lookupData = await lookupResponse.json();
      if (lookupData.results && lookupData.results.length > 0) {
        for (const r of lookupData.results.slice(0, 3)) {
          results.push({
            code: r.id || r.obo_id,
            label_de: r.label_de || r.label || symptomText,
            label_en: r.label_en || r.label || symptomText,
          });
        }
        console.log(`Found ${results.length} HPO codes via hpo-lookup for: ${symptomText}`);
        return results;
      }
    }
  } catch (err) {
    console.error('HPO lookup edge function error:', err);
  }
  
  // Strategy 4: OLS4 API fallback
  try {
    const olsResponse = await fetch(
      `https://www.ebi.ac.uk/ols4/api/search?q=${encodeURIComponent(symptomText)}&ontology=hp&rows=3`,
      { headers: { 'Accept': 'application/json' } }
    );
    
    if (olsResponse.ok) {
      const olsData = await olsResponse.json();
      if (olsData.response?.docs) {
        for (const doc of olsData.response.docs) {
          if (doc.obo_id?.startsWith('HP:')) {
            results.push({
              code: doc.obo_id,
              label_de: doc.label || symptomText,
              label_en: doc.label || symptomText,
            });
          }
        }
      }
      if (results.length > 0) {
        console.log(`Found ${results.length} HPO codes via OLS4 for: ${symptomText}`);
        return results;
      }
    }
  } catch (err) {
    console.error('OLS4 API error:', err);
  }
  
  console.log(`No HPO codes found for: ${symptomText}`);
  return results;
}

interface ConversationMessage {
  role: "user" | "assistant";
  content: string;
}

interface AnamnesisRequest {
  sessionId: string;
  userMessage: string;
  conversationHistory?: ConversationMessage[];
  language?: string;
  clinicalView?: string;
  forcedCategory?: string;
}

interface ExtractedObservation {
  rawInput: string;
  normalizedValue?: string;
  hpoCodes?: string[];
  negated: boolean;
  onset?: string;
  duration?: string;
  severity?: string;
  confidence: number;
}

interface AnamnesisResponse {
  assistantMessage: string;
  observations: ExtractedObservation[];
  redFlags: string[];
  nextQuestionCategory?: string;
  isComplete: boolean;
  completedCategories?: string[];
  currentCategory?: string;
}

// Categories with their required information
const ANAMNESIS_CATEGORIES = {
  chief_complaint: {
    name: "Hauptbeschwerde",
    required: ["Was führt Sie heute zu mir?", "Hauptsymptom identifiziert"],
    minQuestions: 1,
    maxQuestions: 2,
  },
  hpi: {
    name: "Aktuelle Beschwerden (OPQRST)",
    required: ["Onset/Beginn", "Qualität", "Lokalisation", "Schweregrad", "Zeitverlauf"],
    minQuestions: 3,
    maxQuestions: 6,
  },
  ros: {
    name: "Systemübersicht",
    required: ["Allgemein", "Relevante Organsysteme"],
    minQuestions: 2,
    maxQuestions: 4,
  },
  pmh: {
    name: "Vorerkrankungen",
    required: ["Chronische Erkrankungen", "Operationen"],
    minQuestions: 1,
    maxQuestions: 2,
  },
  medications: {
    name: "Medikamente & Allergien",
    required: ["Aktuelle Medikation", "Allergien"],
    minQuestions: 1,
    maxQuestions: 2,
  },
  social: {
    name: "Sozialanamnese",
    required: ["Lebensstil-Faktoren"],
    minQuestions: 1,
    maxQuestions: 2,
  },
  family: {
    name: "Familienanamnese",
    required: ["Relevante Familienerkrankungen"],
    minQuestions: 1,
    maxQuestions: 1,
  },
};

const CATEGORY_ORDER = ["chief_complaint", "hpi", "ros", "pmh", "medications", "social", "family"];

const buildSystemPrompt = (
  language: string,
  clinicalView: string,
  completedCategories: string[],
  currentCategory: string,
  questionsInCategory: number,
  collectedInfo: string
) => {
  const remainingCategories = CATEGORY_ORDER.filter(c => !completedCategories.includes(c));
  const currentCatInfo = ANAMNESIS_CATEGORIES[currentCategory as keyof typeof ANAMNESIS_CATEGORIES];
  const isLastCategory = remainingCategories.length <= 1;
  const shouldComplete = completedCategories.length >= 5 || 
    (completedCategories.includes("chief_complaint") && 
     completedCategories.includes("hpi") && 
     questionsInCategory >= (currentCatInfo?.maxQuestions || 3));

  return `Du bist ein medizinischer Anamnese-Assistent. Deine Aufgabe ist eine FOKUSSIERTE, EFFIZIENTE Anamnese.

## KRITISCHE REGELN:
1. Stelle IMMER nur EINE Frage auf einmal
2. WIEDERHOLE NIEMALS Fragen, die bereits beantwortet wurden
3. Wenn eine Kategorie ausreichend erfasst ist, gehe zur nächsten
4. Fasse dich KURZ - keine langen Erklärungen
5. Beende die Anamnese wenn genug Informationen vorliegen
6. EXTRAHIERE IMMER alle Symptome aus der Patienteneingabe als observations!

## SYMPTOM-EXTRAKTION (KRITISCH!):
Bei JEDER Patientenantwort musst du ALLE genannten Symptome/Beschwerden extrahieren:
- "Bauchschmerzen" → observation mit rawInput="Bauchschmerzen", normalizedValue="Bauchschmerzen"
- "Kopfschmerzen seit 2 Tagen" → observation mit rawInput="Kopfschmerzen seit 2 Tagen", normalizedValue="Kopfschmerzen", onset="seit 2 Tagen"
- "Kein Fieber" → observation mit rawInput="Kein Fieber", normalizedValue="Fieber", negated=true
- Auch kurze Antworten wie "Bauchschmerzen" MÜSSEN als observation erfasst werden!

## AKTUELLER STATUS:
- Sprache: ${language === "de" ? "Deutsch" : "English"}
- Klinische Sicht: ${clinicalView}
- Abgeschlossene Kategorien: ${completedCategories.length > 0 ? completedCategories.join(", ") : "keine"}
- Aktuelle Kategorie: ${currentCategory} (${currentCatInfo?.name || currentCategory})
- Fragen in dieser Kategorie: ${questionsInCategory}/${currentCatInfo?.maxQuestions || 3}
- Verbleibende Kategorien: ${remainingCategories.join(", ") || "keine"}

## BEREITS ERFASSTE INFORMATIONEN:
${collectedInfo || "Noch keine Informationen erfasst."}

## ABBRUCHKRITERIEN - Setze isComplete=true wenn:
${shouldComplete ? "⚠️ GENUG INFORMATIONEN GESAMMELT - Beende mit Zusammenfassung!" : ""}
- Mindestens chief_complaint UND hpi abgeschlossen UND 2 weitere Kategorien
- ODER Patient signalisiert Ende ("das wäre alles", "mehr fällt mir nicht ein")
- ODER Red Flags erfordern sofortige Handlung
${isLastCategory ? "- ⚠️ Dies ist die letzte Kategorie - nach dieser Frage zusammenfassen!" : ""}

## KATEGORIEN-FORTSCHRITT:
${CATEGORY_ORDER.map(cat => {
  const info = ANAMNESIS_CATEGORIES[cat as keyof typeof ANAMNESIS_CATEGORIES];
  const status = completedCategories.includes(cat) ? "✅" : (cat === currentCategory ? "🔄" : "⏳");
  return `${status} ${cat}: ${info.name} (${info.minQuestions}-${info.maxQuestions} Fragen)`;
}).join("\n")}

## ANTWORTFORMAT (JSON):
{
  "assistantMessage": "Deine nächste Frage an den Patienten",
  "observations": [
    {
      "rawInput": "Original-Text des Symptoms",
      "normalizedValue": "Standardisierte Beschreibung",
      "negated": false,
      "onset": "seit 2 Tagen",
      "duration": "anhaltend",
      "severity": "mittel",
      "confidence": 0.85
    }
  ],
  "redFlags": ["Liste kritischer Symptome"],
   "nextQuestionCategory": "${remainingCategories[0] || "summary"}",
   "completedCategories": ${JSON.stringify(completedCategories)},
   "isComplete": false
}

WICHTIG: Das observations-Array darf NIEMALS leer sein wenn der Patient ein Symptom nennt!
Beispiel: Patient sagt "Bauchschmerzen" → observations MUSS enthalten:
[{"rawInput": "Bauchschmerzen", "normalizedValue": "Bauchschmerzen", "negated": false, "confidence": 0.9}]

WENN isComplete=true, dann:
- assistantMessage = Kurze Zusammenfassung aller erfassten Symptome und Empfehlung
- nextQuestionCategory = "summary"`;
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: AnamnesisRequest = await req.json();
    const { sessionId, userMessage, conversationHistory = [], language = "de", forcedCategory } = body;

    if (!sessionId || !userMessage) {
      return new Response(
        JSON.stringify({ error: "sessionId and userMessage are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify session belongs to user
    const { data: session, error: sessionError } = await supabase
      .from("anamnesis_sessions")
      .select("*")
      .eq("id", sessionId)
      .single();

    if (sessionError || !session) {
      return new Response(
        JSON.stringify({ error: "Session not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get previous observations for context
    const { data: previousObs } = await supabase
      .from("observations")
       .select("raw_input, normalized_value, negated, onset, duration, severity, created_at")
      .eq("session_id", sessionId)
      .order("created_at", { ascending: true });

     // Build structured context from observations
     const collectedInfo = previousObs?.map(o => {
       const parts = [];
       if (o.negated) parts.push("VERNEINT");
       parts.push(o.normalized_value || o.raw_input);
       if (o.onset) parts.push(`(Beginn: ${o.onset})`);
       if (o.duration) parts.push(`(Dauer: ${o.duration})`);
       if (o.severity) parts.push(`(Schwere: ${o.severity})`);
       return `- ${parts.join(" ")}`;
     }).join("\n") || "";

     // Get conversation history from database for accurate tracking
     const { data: dbMessages } = await supabase
       .from("conversation_messages")
       .select("role, content, created_at")
       .eq("session_id", sessionId)
       .order("created_at", { ascending: true });

     // Analyze conversation to determine progress
     const assistantMessages = dbMessages?.filter(m => m.role === "assistant") || [];
     const totalQuestions = assistantMessages.length;
     
     // Parse previous responses to track completed categories
     let completedCategories: string[] = [];
     let currentCategory = "chief_complaint";
     let questionsInCategory = 0;
     
     // Try to extract category progress from last AI response
     if (assistantMessages.length > 0) {
       for (const msg of assistantMessages) {
         try {
           const jsonMatch = msg.content.match(/```json\s*([\s\S]*?)\s*```/) || 
                            msg.content.match(/\{[\s\S]*\}/);
           if (jsonMatch) {
             const parsed = JSON.parse(jsonMatch[1] || jsonMatch[0]);
             if (parsed.completedCategories) {
               completedCategories = parsed.completedCategories;
             }
             if (parsed.nextQuestionCategory) {
               currentCategory = parsed.nextQuestionCategory;
             }
           }
         } catch {
           // Ignore parse errors
         }
       }
       
       // Count questions in current category
       questionsInCategory = assistantMessages.filter(m => {
         try {
           const jsonMatch = m.content.match(/\{[\s\S]*\}/);
           if (jsonMatch) {
             const parsed = JSON.parse(jsonMatch[0]);
             return parsed.nextQuestionCategory === currentCategory;
           }
         } catch {}
         return false;
       }).length;
     }

     // Auto-advance category if max questions reached
     const currentCatInfo = ANAMNESIS_CATEGORIES[currentCategory as keyof typeof ANAMNESIS_CATEGORIES];
     if (currentCatInfo && questionsInCategory >= currentCatInfo.maxQuestions) {
       if (!completedCategories.includes(currentCategory)) {
         completedCategories.push(currentCategory);
       }
       const nextCatIndex = CATEGORY_ORDER.indexOf(currentCategory) + 1;
       if (nextCatIndex < CATEGORY_ORDER.length) {
         currentCategory = CATEGORY_ORDER[nextCatIndex];
         questionsInCategory = 0;
       }
     }

     // Handle forced category switch (from UI category chips)
     if (forcedCategory && CATEGORY_ORDER.includes(forcedCategory)) {
       console.log(`Forced category switch to: ${forcedCategory}`);
       currentCategory = forcedCategory;
       questionsInCategory = 0;
     }

    // Call AI - Priority: OpenAI > Gemini > Lovable AI Gateway
    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");
    const geminiApiKey = Deno.env.get("GEMINI_API_KEY");
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");

    let aiResponse: string;

     const systemPrompt = buildSystemPrompt(
       language,
       session.clinical_view,
       completedCategories,
       currentCategory,
       questionsInCategory,
       collectedInfo
     );

    // Build messages array with conversation history
    const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
       { role: "system", content: systemPrompt },
    ];

     // Add FULL conversation history from database (not just last 10!)
     // This ensures the AI never forgets what was already discussed
     if (dbMessages && dbMessages.length > 0) {
       for (const msg of dbMessages) {
         // Only add text content, not JSON responses
         let content = msg.content;
         try {
           const jsonMatch = content.match(/\{[\s\S]*\}/);
           if (jsonMatch) {
             const parsed = JSON.parse(jsonMatch[0]);
             content = parsed.assistantMessage || content;
           }
         } catch {}
         messages.push({ role: msg.role as "user" | "assistant", content });
       }
    }

     // Add current user message
     const lastDbMessage = dbMessages?.[dbMessages.length - 1];
     if (!lastDbMessage || lastDbMessage.content !== userMessage || lastDbMessage.role !== "user") {
      messages.push({ role: "user", content: userMessage });
    }

    if (openaiApiKey) {
      // Use OpenAI ChatGPT
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${openaiApiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages,
          temperature: 0.4,
          max_tokens: 2048,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("OpenAI error:", response.status, errorText);
        throw new Error(`OpenAI error: ${response.status}`);
      }

      const data = await response.json();
      aiResponse = data.choices?.[0]?.message?.content || "";
    } else if (geminiApiKey) {
       // Use Google Gemini directly - WITH FULL CONTEXT
       const geminiContents = messages.slice(1).map(m => ({
         role: m.role === "assistant" ? "model" : "user",
         parts: [{ text: m.content }]
       }));
       
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiApiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
             contents: geminiContents,
             systemInstruction: { parts: [{ text: systemPrompt }] },
            generationConfig: { temperature: 0.4, maxOutputTokens: 2048 },
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`Gemini error: ${response.status}`);
      }

      const data = await response.json();
      aiResponse = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    } else if (lovableApiKey) {
      // Fallback to Lovable AI Gateway
      const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${lovableApiKey}`,
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages,
          temperature: 0.4,
          max_tokens: 2048,
        }),
      });

      if (!response.ok) {
        throw new Error(`AI Gateway error: ${response.status}`);
      }

      const data = await response.json();
      aiResponse = data.choices?.[0]?.message?.content || "";
    } else {
      return new Response(
        JSON.stringify({ error: "No AI provider configured" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse AI response
    let parsedResponse: AnamnesisResponse;
    try {
      // Extract JSON from response (handle markdown code blocks)
      const jsonMatch = aiResponse.match(/```json\s*([\s\S]*?)\s*```/) || 
                       aiResponse.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? (jsonMatch[1] || jsonMatch[0]) : aiResponse;
      parsedResponse = JSON.parse(jsonString);
    } catch {
      // Fallback if AI doesn't return valid JSON
      parsedResponse = {
        assistantMessage: aiResponse,
        observations: [],
        redFlags: [],
         completedCategories,
        isComplete: false,
      };
    }

    // CRITICAL: Enrich observations with HPO codes
    if (parsedResponse.observations && parsedResponse.observations.length > 0) {
      console.log(`Processing ${parsedResponse.observations.length} observations for HPO codes`);
      
      for (const obs of parsedResponse.observations) {
        if (!obs.hpoCodes || obs.hpoCodes.length === 0) {
          const searchText = obs.normalizedValue || obs.rawInput;
          if (searchText) {
            const hpoResults = await findHpoCodes(
              searchText,
              supabaseUrl,
              supabaseAnonKey,
              authHeader!
            );
            
            if (hpoResults.length > 0) {
              obs.hpoCodes = hpoResults.map(r => r.code);
              console.log(`Enriched observation "${searchText}" with HPO codes: ${obs.hpoCodes.join(', ')}`);
            }
          }
        }
      }
    }

     // Ensure completedCategories is preserved
     if (!parsedResponse.completedCategories) {
       parsedResponse.completedCategories = completedCategories;
     }

     // Add currentCategory explicitly to response
     if (parsedResponse.nextQuestionCategory) {
       parsedResponse.currentCategory = parsedResponse.nextQuestionCategory;
     } else {
       parsedResponse.currentCategory = currentCategory;
     }

     // Update completedCategories based on category transition
     if (parsedResponse.nextQuestionCategory && 
         parsedResponse.nextQuestionCategory !== currentCategory &&
         !parsedResponse.completedCategories?.includes(currentCategory)) {
       parsedResponse.completedCategories = [...(parsedResponse.completedCategories || []), currentCategory];
     }

     // Force completion after too many questions (safety limit)
     if (totalQuestions >= 15 && !parsedResponse.isComplete) {
       console.log("Force completing anamnesis after 15 questions");
       parsedResponse.isComplete = true;
       parsedResponse.assistantMessage = "Vielen Dank für Ihre Angaben. Ich habe genug Informationen gesammelt. " + 
         (parsedResponse.assistantMessage || "Die Anamnese ist abgeschlossen.");
     }

    // Store observations with HPO validation
    if (parsedResponse.observations && parsedResponse.observations.length > 0) {
      // Try to get real HPO codes for each observation
      const observationsWithHPO = await Promise.all(
        parsedResponse.observations.map(async (obs) => {
          let validatedHpoCodes: string[] = [];
          
          try {
            // Call HPO lookup to map symptom to real HPO codes
            const hpoResponse = await fetch(
              `${supabaseUrl}/functions/v1/hpo-lookup?action=map`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: authHeader,
                },
                body: JSON.stringify({
                  symptom: obs.normalizedValue || obs.rawInput,
                  language,
                }),
              }
            );

            if (hpoResponse.ok) {
              const hpoData = await hpoResponse.json();
              if (hpoData.matches && hpoData.matches.length > 0 && hpoData.confidence >= 0.6) {
                validatedHpoCodes = hpoData.matches.slice(0, 3).map((m: { id: string }) => m.id);
              }
            }
          } catch (hpoError) {
            console.error("HPO lookup failed:", hpoError);
          }

          return {
            session_id: sessionId,
            raw_input: obs.rawInput,
            normalized_value: obs.normalizedValue,
            language,
            hpo_codes: validatedHpoCodes.length > 0 ? validatedHpoCodes : (obs.hpoCodes || []),
            negated: obs.negated,
            onset: obs.onset,
            duration: obs.duration,
            severity: obs.severity,
            confidence: obs.confidence,
            provenance: "ai-anamnesis",
          };
        })
      );

      const { error: insertError } = await supabase
        .from("observations")
        .insert(observationsWithHPO);

      if (insertError) {
        console.error("Error inserting observations:", insertError);
      }
    }

    // Update session if complete
    if (parsedResponse.isComplete) {
      await supabase
        .from("anamnesis_sessions")
        .update({ status: "completed", completed_at: new Date().toISOString() })
        .eq("id", sessionId);
    }

    return new Response(JSON.stringify(parsedResponse), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Anamnesis error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
