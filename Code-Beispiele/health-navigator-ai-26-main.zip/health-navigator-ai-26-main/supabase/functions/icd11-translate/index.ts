import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ICD11TermInput {
  code: string;
  title: string;
  definition?: string;
}

interface TranslationResult {
  code: string;
  title_en: string;
  title_de: string;
  definition_de?: string;
  source: "cached" | "ai_translated";
  confidence: number;
}

async function translateWithAI(
  terms: ICD11TermInput[]
): Promise<TranslationResult[]> {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");
  
  const apiKey = openaiKey || lovableKey;
  const apiUrl = openaiKey 
    ? "https://api.openai.com/v1/chat/completions"
    : "https://ai.gateway.lovable.dev/v1/chat/completions";

  if (!apiKey) {
    throw new Error("No AI API key configured for translations");
  }

  const prompt = `Du bist ein medizinischer Übersetzer für die ICD-11 Klassifikation (WHO).
Übersetze die folgenden englischen ICD-11-Begriffe ins Deutsche.
Verwende korrekte deutsche medizinische Fachterminologie.
Die Übersetzungen müssen präzise, klinisch korrekt und konsistent sein.

Begriffe zur Übersetzung:
${terms.map((t) => `- ${t.code}: "${t.title}"${t.definition ? ` (Definition: ${t.definition.slice(0, 150)})` : ""}`).join("\n")}

Antworte NUR mit einem JSON-Array in diesem Format:
[
  {"code": "01", "title_de": "Deutsche Übersetzung", "definition_de": "Deutsche Definition (optional)", "confidence": 0.95}
]`;

  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: openaiKey ? "gpt-4o-mini" : "google/gemini-2.0-flash-001",
      messages: [
        {
          role: "system",
          content: "Du bist ein Experte für medizinische Terminologie und ICD-11-Übersetzungen.",
        },
        { role: "user", content: prompt },
      ],
      temperature: 0.3,
      max_tokens: 3000,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error("AI API error:", response.status, errorText);
    throw new Error(`AI translation failed: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";

  // Extract JSON from response
  const jsonMatch = content.match(/\[[\s\S]*\]/);
  if (!jsonMatch) {
    console.error("Could not parse AI response:", content);
    throw new Error("Invalid AI response format");
  }

  const translations: Array<{ code: string; title_de: string; definition_de?: string; confidence?: number }> =
    JSON.parse(jsonMatch[0]);

  return translations.map((t) => {
    const originalTerm = terms.find((term) => term.code === t.code);
    return {
      code: t.code,
      title_en: originalTerm?.title || "",
      title_de: t.title_de,
      definition_de: t.definition_de,
      source: "ai_translated" as const,
      confidence: t.confidence || 0.9,
    };
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { terms }: { terms: ICD11TermInput[] } = await req.json();

    if (!terms || !Array.isArray(terms) || terms.length === 0) {
      return new Response(JSON.stringify({ error: "No terms provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const MAX_BATCH_SIZE = 20;
    const termsToProcess = terms.slice(0, MAX_BATCH_SIZE);

    console.log(`Processing ${termsToProcess.length} ICD-11 terms for translation`);

    // Check icd11_codes table for existing translations in JSONB labels
    const codes = termsToProcess.map((t) => t.code);
    const { data: existingCodes, error: lookupError } = await supabase
      .from("icd11_codes")
      .select("code, title, labels, definitions")
      .in("code", codes);

    if (lookupError) {
      console.error("ICD-11 codes lookup error:", lookupError);
    }

    // Find codes with valid German translations
    const cachedMap = new Map<string, TranslationResult>();
    for (const code of existingCodes || []) {
      const labelDe = code.labels?.de;
      const labelEn = code.labels?.en || code.title;
      if (labelDe && labelDe !== labelEn) {
        cachedMap.set(code.code, {
          code: code.code,
          title_en: labelEn || "",
          title_de: labelDe,
          definition_de: code.definitions?.de,
          source: "cached",
          confidence: 1.0,
        });
      }
    }

    // Find terms that need translation
    const toTranslate = termsToProcess.filter((t) => !cachedMap.has(t.code));

    console.log(`Found ${cachedMap.size} cached, ${toTranslate.length} need translation`);

    let newTranslations: TranslationResult[] = [];

    if (toTranslate.length > 0) {
      try {
        newTranslations = await translateWithAI(toTranslate);

        // Upsert icd11_codes table with new translations (creates if not exists)
        for (const t of newTranslations) {
          const existingCode = existingCodes?.find((c) => c.code === t.code);
          const currentLabels = existingCode?.labels || {};
          const currentDefinitions = existingCode?.definitions || {};
          const originalTerm = terms.find((term) => term.code === t.code);

          const { error: upsertError } = await supabase
            .from("icd11_codes")
            .upsert({
              code: t.code,
              title: originalTerm?.title || t.title_en,
              labels: { ...currentLabels, de: t.title_de, en: t.title_en },
              definitions: { ...currentDefinitions, de: t.definition_de },
            }, { onConflict: "code" });

          if (upsertError) {
            console.error(`Error upserting ICD-11 code ${t.code}:`, upsertError);
          }
        }

        console.log(`Upserted ${newTranslations.length} ICD-11 codes with translations`);
      } catch (aiError) {
        console.error("AI translation error:", aiError);
      }
    }

    // Combine results
    const allTranslations: TranslationResult[] = termsToProcess.map((term) => {
      const cached = cachedMap.get(term.code);
      if (cached) return cached;

      const translated = newTranslations.find((t) => t.code === term.code);
      if (translated) return translated;

      // Fallback: return original English
      return {
        code: term.code,
        title_en: term.title,
        title_de: term.title, // Fallback to English
        source: "cached" as const,
        confidence: 0,
      };
    });

    return new Response(JSON.stringify({ translations: allTranslations }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("icd11-translate error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
