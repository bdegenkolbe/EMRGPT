import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface AnalysisRequest {
  action: "generate" | "translate" | "get";
  hpo_code: string;
  hpo_label: string;
  target_language?: string;
  source_language?: string;
}

interface ContentBlock {
  explanation: string;
  symptoms: string;
  therapy: string;
  notes: string;
}

interface ICD10Mapping {
  code: string;
  title_de: string;
  title_en: string;
  relation: string;
}

interface SnomedMapping {
  sctid: string;
  pt_de: string;
  pt_en: string;
  relation: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: AnalysisRequest = await req.json();
    const { action, hpo_code, hpo_label, target_language, source_language } = body;

    if (!hpo_code) {
      return new Response(
        JSON.stringify({ error: "hpo_code is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Action: Get existing analysis (token-optimized: check ontology_mappings first)
    if (action === "get") {
      const { data, error } = await supabase
        .from("hpo_analyses")
        .select("*")
        .eq("hpo_code", hpo_code)
        .maybeSingle();

      if (error) throw error;

      // If analysis exists, check if we can enrich it with cached ontology_mappings
      if (data) {
        // Check for additional mappings in ontology_mappings that might not be in the analysis
        const { data: cachedMappings } = await supabase
          .from("ontology_mappings")
          .select("target_system, target_code, target_label, mapping_type, confidence")
          .eq("source_system", "HPO")
          .eq("source_code", hpo_code);

        if (cachedMappings && cachedMappings.length > 0) {
          const snomedFromCache = cachedMappings
            .filter((m) => m.target_system === "SNOMED")
            .map((m) => ({
              sctid: m.target_code,
              pt_de: m.target_label,
              pt_en: m.target_label,
              relation: m.mapping_type,
            }));

          const icd10FromCache = cachedMappings
            .filter((m) => m.target_system === "ICD10GM")
            .map((m) => ({
              code: m.target_code,
              title_de: m.target_label,
              title_en: m.target_label,
              relation: m.mapping_type,
            }));

          // Merge cached mappings with analysis mappings (prefer analysis if exists)
          const existingSnomed = data.snomed_mappings || [];
          const existingIcd10 = data.icd10_mappings || [];

          const mergedSnomed = [
            ...existingSnomed,
            ...snomedFromCache.filter(
              (c) => !existingSnomed.some((e: SnomedMapping) => e.sctid === c.sctid)
            ),
          ];

          const mergedIcd10 = [
            ...existingIcd10,
            ...icd10FromCache.filter(
              (c) => !existingIcd10.some((e: ICD10Mapping) => e.code === c.code)
            ),
          ];

          return new Response(
            JSON.stringify({
              analysis: {
                ...data,
                snomed_mappings: mergedSnomed,
                icd10_mappings: mergedIcd10,
              },
            }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      } else {
        // No analysis exists - check if we have cached mappings from ontology_mappings
        const { data: cachedMappings } = await supabase
          .from("ontology_mappings")
          .select("target_system, target_code, target_label, mapping_type, confidence")
          .eq("source_system", "HPO")
          .eq("source_code", hpo_code);

        if (cachedMappings && cachedMappings.length > 0) {
          // Return partial data with cached mappings (no content, but mappings available)
          const snomedMappings = cachedMappings
            .filter((m) => m.target_system === "SNOMED")
            .map((m) => ({
              sctid: m.target_code,
              pt_de: m.target_label,
              pt_en: m.target_label,
              relation: m.mapping_type,
            }));

          const icd10Mappings = cachedMappings
            .filter((m) => m.target_system === "ICD10GM")
            .map((m) => ({
              code: m.target_code,
              title_de: m.target_label,
              title_en: m.target_label,
              relation: m.mapping_type,
            }));

          return new Response(
            JSON.stringify({
              analysis: null,
              cached_mappings: {
                snomed_mappings: snomedMappings,
                icd10_mappings: icd10Mappings,
                from_cache: true,
              },
            }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }

      return new Response(
        JSON.stringify({ analysis: data || null }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Action: Translate existing content
    if (action === "translate") {
      if (!target_language || !source_language) {
        return new Response(
          JSON.stringify({ error: "target_language and source_language are required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const { data: existing } = await supabase
        .from("hpo_analyses")
        .select("*")
        .eq("hpo_code", hpo_code)
        .maybeSingle();

      if (!existing || !existing.content[source_language]) {
        return new Response(
          JSON.stringify({ error: "No source content found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const sourceContent = existing.content[source_language] as ContentBlock;
      const translationStartTime = Date.now();

      const translationPrompt = `Translate the following medical content from ${source_language} to ${target_language}. 
Maintain medical accuracy and terminology. Return as JSON with keys: explanation, symptoms, therapy, notes.

Source content:
Explanation: ${sourceContent.explanation}
Symptoms: ${sourceContent.symptoms}
Therapy: ${sourceContent.therapy}
Notes: ${sourceContent.notes}`;

      const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${lovableApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            {
              role: "system",
              content: "You are a medical translator. Translate medical content accurately while maintaining clinical terminology. Return valid JSON only.",
            },
            { role: "user", content: translationPrompt },
          ],
          temperature: 0.2,
        }),
      });

      if (!aiResponse.ok) {
        throw new Error("Translation failed");
      }

      const aiData = await aiResponse.json();
      const translationLatency = Date.now() - translationStartTime;
      let translatedContent: ContentBlock;

      try {
        const content = aiData.choices[0]?.message?.content || "{}";
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        translatedContent = JSON.parse(jsonMatch ? jsonMatch[0] : content);
      } catch {
        throw new Error("Failed to parse translation response");
      }

      // Log translation AI usage
      try {
        await supabase
          .from("ai_usage_logs")
          .insert({
            source_type: "translation",
            source_detail: "hpo-analyze",
            provider: "lovable-gateway",
            model: "google/gemini-3-flash-preview",
            prompt_tokens: aiData.usage?.prompt_tokens || 0,
            completion_tokens: aiData.usage?.completion_tokens || 0,
            latency_ms: translationLatency,
            request_metadata: { 
              hpo_code,
              action: "translate",
              source_language,
              target_language
            },
            status: "success",
          });
      } catch (logError) {
        console.error("Failed to log AI usage:", logError);
      }

      const updatedContent = {
        ...existing.content,
        [target_language]: translatedContent,
      };

      const { data: updated, error: updateError } = await supabase
        .from("hpo_analyses")
        .update({ content: updatedContent })
        .eq("hpo_code", hpo_code)
        .select()
        .single();

      if (updateError) throw updateError;

      return new Response(
        JSON.stringify({ analysis: updated }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Action: Generate new analysis
    if (action === "generate") {
      if (!lovableApiKey) {
        return new Response(
          JSON.stringify({ error: "LOVABLE_API_KEY not configured" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const lang = source_language || "de";
      const analysisStartTime = Date.now();

      const analysisResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${lovableApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            {
              role: "system",
              content: `Du bist ein medizinischer Experte für Phänotypen und klinische Genetik. Erstelle eine umfassende klinische Analyse für den HPO-Begriff.
Die Analyse soll praxisrelevant und für Ärzte nützlich sein. Verwende korrekte medizinische Terminologie.
Nutze das bereitgestellte Tool um die strukturierte Analyse zurückzugeben.`,
            },
            {
              role: "user",
              content: `Erstelle eine detaillierte klinische Analyse für den HPO-Begriff "${hpo_code}" (${hpo_label}).

Die Analyse soll enthalten:
1. Erklärung: Was bedeutet dieser Phänotyp klinisch? Wie manifestiert er sich?
2. Typische Symptome: Welche Symptome und Befunde sind typisch? (Aufzählung mit Bullet Points)
3. Therapie und Management: Wie wird dieser Phänotyp therapiert? Welche Maßnahmen sind sinnvoll?
4. Hinweise: Wichtige Hinweise für die Praxis, Differentialdiagnosen, Vererbungsmuster

Zusätzlich identifiziere:
- Relevante ICD-10-GM Codes mit deutschem und englischem Titel
- Relevante SNOMED CT Codes mit deutschem und englischem Begriff`,
            },
          ],
          tools: [
            {
              type: "function",
              function: {
                name: "create_hpo_analysis",
                description: "Creates a structured HPO analysis with content and mappings",
                parameters: {
                  type: "object",
                  properties: {
                    content: {
                      type: "object",
                      properties: {
                        explanation: { type: "string", description: "Clinical explanation of the phenotype" },
                        symptoms: { type: "string", description: "Typical symptoms as bullet list" },
                        therapy: { type: "string", description: "Treatment and management options" },
                        notes: { type: "string", description: "Important clinical notes and hints" },
                      },
                      required: ["explanation", "symptoms", "therapy", "notes"],
                    },
                    icd10_mappings: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          code: { type: "string", description: "ICD-10-GM code" },
                          title_de: { type: "string", description: "German title" },
                          title_en: { type: "string", description: "English title" },
                          relation: { type: "string", enum: ["exact", "broad", "narrow", "related"] },
                        },
                        required: ["code", "title_de", "title_en", "relation"],
                      },
                    },
                    snomed_mappings: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          sctid: { type: "string", description: "SNOMED CT ID" },
                          pt_de: { type: "string", description: "German preferred term" },
                          pt_en: { type: "string", description: "English preferred term" },
                          relation: { type: "string", enum: ["exact", "broad", "narrow", "related"] },
                        },
                        required: ["sctid", "pt_de", "pt_en", "relation"],
                      },
                    },
                  },
                  required: ["content", "icd10_mappings", "snomed_mappings"],
                },
              },
            },
          ],
          tool_choice: { type: "function", function: { name: "create_hpo_analysis" } },
          temperature: 0.3,
        }),
      });

      if (!analysisResponse.ok) {
        if (analysisResponse.status === 429) {
          return new Response(
            JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
            { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        throw new Error("Analysis generation failed");
      }

      const aiData = await analysisResponse.json();
      const latencyMs = Date.now() - analysisStartTime;
      
      let analysisResult: {
        content: ContentBlock;
        icd10_mappings: ICD10Mapping[];
        snomed_mappings: SnomedMapping[];
      };

      try {
        const toolCall = aiData.choices[0]?.message?.tool_calls?.[0];
        if (toolCall?.function?.arguments) {
          analysisResult = JSON.parse(toolCall.function.arguments);
        } else {
          throw new Error("No tool call response");
        }
      } catch (e) {
        console.error("Parse error:", e);
        throw new Error("Failed to parse AI response");
      }

      // Get user ID from auth header
      const authHeader = req.headers.get("Authorization");
      let userId: string | null = null;
      if (authHeader?.startsWith("Bearer ")) {
        const token = authHeader.substring(7);
        const { data: { user } } = await supabase.auth.getUser(token);
        userId = user?.id || null;
      }

      // Log AI usage to ai_usage_logs
      try {
        await supabase
          .from("ai_usage_logs")
          .insert({
            user_id: userId,
            source_type: "analysis",
            source_detail: "hpo-analyze",
            provider: "lovable-gateway",
            model: "google/gemini-3-flash-preview",
            prompt_tokens: aiData.usage?.prompt_tokens || 0,
            completion_tokens: aiData.usage?.completion_tokens || 0,
            latency_ms: latencyMs,
            request_metadata: { 
              hpo_code,
              action: "generate",
              language: lang
            },
            status: "success",
          });
      } catch (logError) {
        console.error("Failed to log AI usage:", logError);
      }

      // Upsert analysis
      const { data: analysis, error: upsertError } = await supabase
        .from("hpo_analyses")
        .upsert(
          {
            hpo_code,
            content: { [lang]: analysisResult.content },
            source_language: lang,
            icd10_mappings: analysisResult.icd10_mappings,
            snomed_mappings: analysisResult.snomed_mappings,
            generated_at: new Date().toISOString(),
            generated_by: userId,
          },
          { onConflict: "hpo_code" }
        )
        .select()
        .single();

      if (upsertError) throw upsertError;

      // Save mappings to ontology_mappings table
      const mappingsToSave = [
        ...analysisResult.icd10_mappings
          .filter((m) => !!m.code)
          .map((m) => ({
            source_system: "HPO",
            source_code: hpo_code,
            source_label: hpo_label,
            target_system: "ICD10GM",
            target_code: m.code,
            target_label: m.title_de || m.title_en,
            mapping_type: m.relation,
            confidence: 0.85,
            notes: `KI-generiert (Relation: ${m.relation})`,
          })),
        ...analysisResult.snomed_mappings
          .filter((m) => !!m.sctid)
          .map((m) => ({
            source_system: "HPO",
            source_code: hpo_code,
            source_label: hpo_label,
            target_system: "SNOMED",
            target_code: m.sctid,
            target_label: m.pt_de || m.pt_en,
            mapping_type: m.relation,
            confidence: 0.85,
            notes: `KI-generiert (Relation: ${m.relation})`,
          })),
      ];

      if (mappingsToSave.length > 0) {
        const { error: mappingsError } = await supabase
          .from("ontology_mappings")
          .upsert(mappingsToSave, {
            onConflict: "source_code,source_system,target_code,target_system",
            ignoreDuplicates: true,
          });

        if (mappingsError) {
          console.error("Failed to persist ontology mappings:", mappingsError);
        }
      }

      return new Response(
        JSON.stringify({ analysis }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Invalid action" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("hpo-analyze error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
