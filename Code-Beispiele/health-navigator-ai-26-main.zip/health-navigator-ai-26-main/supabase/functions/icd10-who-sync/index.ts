import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SOURCE_NAME = "icd10_who";
const ICD10_API = "https://id.who.int/icd/release/10";
const ICD10_TOKEN_URL = "https://icdaccessmanagement.who.int/connect/token";

interface SyncQueue {
  pending: string[];
  processed: number;
  version: string;
}

function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(supabaseUrl, supabaseKey);
}

/**
 * Get OAuth token for WHO ICD API (same credentials as ICD-11)
 */
async function getICDToken(): Promise<string> {
  const clientId = Deno.env.get("ICD11_CLIENT_ID");
  const clientSecret = Deno.env.get("ICD11_CLIENT_SECRET");

  if (!clientId || !clientSecret) {
    throw new Error("ICD API credentials not configured (ICD11_CLIENT_ID/ICD11_CLIENT_SECRET)");
  }

  const response = await fetch(ICD10_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret,
      scope: "icdapi_access",
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to get ICD token: ${response.status}`);
  }

  const data = await response.json();
  return data.access_token;
}

/**
 * Fetch available ICD-10 releases
 */
async function fetchAvailableReleases(token: string): Promise<string[]> {
  const response = await fetch(ICD10_API, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/json",
      "API-Version": "v2",
    },
  });

  if (!response.ok) {
    console.error(`[ICD-10 WHO Sync] Failed to fetch releases: ${response.status}`);
    return [];
  }

  const data = await response.json();
  const releases: string[] = [];

  // Extract version from release URIs
  for (const release of data.release || []) {
    const uri = release["@id"] || release;
    const match = uri.match(/\/release\/10\/(\d{4})$/);
    if (match) {
      releases.push(match[1]);
    }
  }

  return releases.sort().reverse(); // Most recent first
}

/**
 * Fetch ICD-10 entity with multilingual labels
 */
async function fetchEntity(token: string, uri: string): Promise<any> {
  // Fetch English
  const enResponse = await fetch(uri, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/json",
      "Accept-Language": "en",
      "API-Version": "v2",
    },
  });

  if (!enResponse.ok) {
    console.error(`Failed to fetch ${uri}: ${enResponse.status}`);
    return null;
  }

  const enData = await enResponse.json();

  // Fetch French (available for ICD-10)
  let frTitle = null;
  try {
    const frResponse = await fetch(uri, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
        "Accept-Language": "fr",
        "API-Version": "v2",
      },
    });
    if (frResponse.ok) {
      const frData = await frResponse.json();
      frTitle = frData.title?.["@value"];
    }
  } catch {
    // French not available
  }

  return {
    ...enData,
    labels: {
      en: enData.title?.["@value"],
      fr: frTitle,
    },
  };
}

/**
 * Get or create sync status
 */
async function getSyncStatus(supabase: any) {
  const { data } = await supabase
    .from("sync_status")
    .select("*")
    .eq("source_name", SOURCE_NAME)
    .maybeSingle();
  return data;
}

/**
 * Update sync status
 */
async function updateSyncStatus(supabase: any, updates: Record<string, any>) {
  await supabase
    .from("sync_status")
    .upsert(
      {
        source_name: SOURCE_NAME,
        ...updates,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "source_name" }
    );
}

/**
 * Persist ICD-10 WHO codes to database
 */
async function persistCodes(supabase: any, entities: any[], parentCode: string | null, version: string): Promise<number> {
  if (entities.length === 0) return 0;

  const codesToInsert = entities.map((e) => {
    const code = e.code || e["@id"]?.split("/").pop() || "";
    return {
      code,
      title: e.title?.["@value"] || code,
      title_short: e.titleShort?.["@value"] || null,
      chapter: e.chapter || null,
      block: e.block || null,
      parent_code: parentCode,
      is_terminal: !e.child || e.child.length === 0,
      release_version: version,
      foundation_uri: e.foundationReference || null,
      linearization_uri: e["@id"],
      class_kind: e.classKind || null,
      inclusions: e.inclusion?.map((i: any) => i.label?.["@value"]) || [],
      exclusions: e.exclusion?.map((i: any) => i.label?.["@value"]) || [],
      notes: e.codingNote?.["@value"] || null,
      labels: e.labels || { en: e.title?.["@value"] },
      definitions: e.definition ? { en: e.definition?.["@value"] } : {},
    };
  });

  const { error } = await supabase
    .from("icd10_who_codes")
    .upsert(codesToInsert, { onConflict: "code" });

  if (error) {
    console.error("[ICD-10 WHO Sync] Persist error:", error);
    return 0;
  }

  return entities.length;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = getSupabaseAdmin();

  try {
    const body = await req.json();
    const action = body.action || "sync_page";

    switch (action) {
      case "check_version": {
        const token = await getICDToken();
        const releases = await fetchAvailableReleases(token);
        const status = await getSyncStatus(supabase);
        const remoteVersion = releases[0] || null;
        const localVersion = status?.local_version || null;
        const needsSync = remoteVersion && (!localVersion || remoteVersion > localVersion);

        if (remoteVersion) {
          await updateSyncStatus(supabase, { remote_version: remoteVersion });
        }

        return new Response(
          JSON.stringify({
            remoteVersion,
            localVersion,
            availableReleases: releases,
            needsSync,
            message: needsSync
              ? `New version available: ${remoteVersion} (current: ${localVersion || "none"})`
              : `Already up to date: ${localVersion}`,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "init": {
        const version = body.version || "2019"; // Default to 2019 release
        const token = await getICDToken();

        // Fetch chapters
        const response = await fetch(`${ICD10_API}/${version}`, {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
            "Accept-Language": "en",
            "API-Version": "v2",
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch ICD-10 root: ${response.status}`);
        }

        const data = await response.json();
        const chapterUris = data.child || [];

        const queue: SyncQueue = {
          pending: chapterUris,
          processed: 0,
          version,
        };

        await updateSyncStatus(supabase, {
          status: "running",
          total_synced: 0,
          total_available: null,
          last_cursor: JSON.stringify(queue),
          error_message: null,
          started_at: new Date().toISOString(),
          completed_at: null,
          local_version: version,
        });

        return new Response(
          JSON.stringify({ success: true, message: "Sync initialized", chapters: chapterUris.length, version }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "sync_page": {
        const status = await getSyncStatus(supabase);
        let queue: SyncQueue;

        try {
          queue = JSON.parse(status?.last_cursor || '{"pending":[],"processed":0,"version":"2019"}');
        } catch {
          queue = { pending: [], processed: 0, version: "2019" };
        }

        if (queue.pending.length === 0) {
          await updateSyncStatus(supabase, {
            status: "completed",
            completed_at: new Date().toISOString(),
          });

          return new Response(
            JSON.stringify({ hasMore: false, syncedCount: 0, totalSynced: status?.total_synced || 0 }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const batchSize = 5;
        const token = await getICDToken();
        const batch = queue.pending.splice(0, batchSize);
        let syncedCount = 0;

        for (const uri of batch) {
          try {
            const entity = await fetchEntity(token, uri);
            if (!entity) continue;

            // Persist this entity
            const parentCode = entity.parent?.[0]?.split("/").pop() || null;
            const synced = await persistCodes(supabase, [entity], parentCode, queue.version);
            syncedCount += synced;

            // Add children to queue
            if (entity.child && Array.isArray(entity.child)) {
              for (const childUri of entity.child) {
                queue.pending.push(childUri);
              }
            }

            // Rate limiting
            await new Promise((resolve) => setTimeout(resolve, 100));
          } catch (err) {
            console.error(`Error processing ${uri}:`, err);
          }
        }

        queue.processed += batch.length;
        const newTotalSynced = (status?.total_synced || 0) + syncedCount;
        const hasMore = queue.pending.length > 0;

        await updateSyncStatus(supabase, {
          status: hasMore ? "running" : "completed",
          total_synced: newTotalSynced,
          last_cursor: JSON.stringify(queue),
          completed_at: hasMore ? null : new Date().toISOString(),
        });

        console.log(`[ICD-10 WHO Sync] Processed ${batch.length} URIs, synced ${syncedCount}. Pending: ${queue.pending.length}`);

        return new Response(
          JSON.stringify({
            hasMore,
            syncedCount,
            totalSynced: newTotalSynced,
            pendingCount: queue.pending.length,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "pause": {
        await updateSyncStatus(supabase, { status: "paused" });
        return new Response(
          JSON.stringify({ success: true, message: "Sync paused" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "resume": {
        await updateSyncStatus(supabase, { status: "running" });
        return new Response(
          JSON.stringify({ success: true, message: "Sync resumed" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "reset": {
        await updateSyncStatus(supabase, {
          status: "pending",
          total_synced: 0,
          total_available: null,
          last_cursor: null,
          error_message: null,
          started_at: null,
          completed_at: null,
        });
        return new Response(
          JSON.stringify({ success: true, message: "Sync reset" }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "status": {
        const status = await getSyncStatus(supabase);
        return new Response(
          JSON.stringify(status || { status: "pending", total_synced: 0 }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${action}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error: any) {
    console.error("[ICD-10 WHO Sync] Error:", error);

    await updateSyncStatus(supabase, {
      status: "error",
      error_message: error.message,
    });

    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
