import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface MappingEntry {
  code: string;
  label: string;
  confidence?: number;
  mappingType?: string;
}

interface BackfillStats {
  hpoAnalysesProcessed: number;
  snomedAnalysesProcessed: number;
  icd10AnalysesProcessed: number;
  icd11AnalysesProcessed: number;
  orphanetAnalysesProcessed: number;
  mappingsCreated: number;
  mappingsSkipped: number;
  errors: string[];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  const stats: BackfillStats = {
    hpoAnalysesProcessed: 0,
    snomedAnalysesProcessed: 0,
    icd10AnalysesProcessed: 0,
    icd11AnalysesProcessed: 0,
    orphanetAnalysesProcessed: 0,
    mappingsCreated: 0,
    mappingsSkipped: 0,
    errors: [],
  };

  try {
    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun === true;
    const batchSize = body.batchSize || 100;

    console.log(`Starting mapping backfill (dryRun: ${dryRun}, batchSize: ${batchSize})`);

    // 1. Process HPO analyses
    const { data: hpoAnalyses, error: hpoError } = await supabase
      .from("hpo_analyses")
      .select("hpo_code, content, snomed_mappings, icd10_mappings")
      .limit(batchSize);

    if (hpoError) {
      stats.errors.push(`HPO fetch error: ${hpoError.message}`);
    } else if (hpoAnalyses) {
      for (const analysis of hpoAnalyses) {
        stats.hpoAnalysesProcessed++;
        
        // Get HPO label from translations
        const { data: hpoTrans } = await supabase
          .from("hpo_translations")
          .select("label_de, label_en")
          .eq("hpo_code", analysis.hpo_code)
          .maybeSingle();
        
        const hpoLabel = hpoTrans?.label_de || hpoTrans?.label_en || analysis.hpo_code;

        // Extract SNOMED mappings
        const snomedMappings = analysis.snomed_mappings as MappingEntry[] | null;
        if (snomedMappings && Array.isArray(snomedMappings)) {
          for (const mapping of snomedMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.hpo_code,
              source_label: hpoLabel,
              source_system: "HPO",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "SNOMED",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus hpo_analyses",
              extraction_source: "hpo_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }

        // Extract ICD-10 mappings
        const icd10Mappings = analysis.icd10_mappings as MappingEntry[] | null;
        if (icd10Mappings && Array.isArray(icd10Mappings)) {
          for (const mapping of icd10Mappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.hpo_code,
              source_label: hpoLabel,
              source_system: "HPO",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "ICD10GM",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus hpo_analyses",
              extraction_source: "hpo_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }
      }
    }

    // 2. Process SNOMED analyses
    const { data: snomedAnalyses, error: snomedError } = await supabase
      .from("snomed_analyses")
      .select("sctid, content, hpo_mappings, icd10_mappings")
      .limit(batchSize);

    if (snomedError) {
      stats.errors.push(`SNOMED fetch error: ${snomedError.message}`);
    } else if (snomedAnalyses) {
      for (const analysis of snomedAnalyses) {
        stats.snomedAnalysesProcessed++;
        
        // Get SNOMED label from translations
        const { data: snomedTrans } = await supabase
          .from("snomed_translations")
          .select("pt_de, pt_en")
          .eq("sctid", analysis.sctid)
          .maybeSingle();
        
        const snomedLabel = snomedTrans?.pt_de || snomedTrans?.pt_en || analysis.sctid;

        // Extract HPO mappings
        const hpoMappings = analysis.hpo_mappings as MappingEntry[] | null;
        if (hpoMappings && Array.isArray(hpoMappings)) {
          for (const mapping of hpoMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.sctid,
              source_label: snomedLabel,
              source_system: "SNOMED",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "HPO",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus snomed_analyses",
              extraction_source: "snomed_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }

        // Extract ICD-10 mappings
        const icd10Mappings = analysis.icd10_mappings as MappingEntry[] | null;
        if (icd10Mappings && Array.isArray(icd10Mappings)) {
          for (const mapping of icd10Mappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.sctid,
              source_label: snomedLabel,
              source_system: "SNOMED",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "ICD10GM",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus snomed_analyses",
              extraction_source: "snomed_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }
      }
    }

    // 3. Process ICD-10 analyses
    const { data: icd10Analyses, error: icd10Error } = await supabase
      .from("icd10gm_analyses")
      .select("icd_code, content, hpo_mappings, snomed_mappings")
      .limit(batchSize);

    if (icd10Error) {
      stats.errors.push(`ICD-10 fetch error: ${icd10Error.message}`);
    } else if (icd10Analyses) {
      for (const analysis of icd10Analyses) {
        stats.icd10AnalysesProcessed++;
        
        // Get ICD-10 label
        const { data: icdCode } = await supabase
          .from("icd10gm_codes")
          .select("title")
          .eq("code", analysis.icd_code)
          .maybeSingle();
        
        const icdLabel = icdCode?.title || analysis.icd_code;

        // Extract HPO mappings
        const hpoMappings = analysis.hpo_mappings as MappingEntry[] | null;
        if (hpoMappings && Array.isArray(hpoMappings)) {
          for (const mapping of hpoMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.icd_code,
              source_label: icdLabel,
              source_system: "ICD10GM",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "HPO",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus icd10gm_analyses",
              extraction_source: "icd10gm_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }

        // Extract SNOMED mappings
        const snomedMappings = analysis.snomed_mappings as MappingEntry[] | null;
        if (snomedMappings && Array.isArray(snomedMappings)) {
          for (const mapping of snomedMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.icd_code,
              source_label: icdLabel,
              source_system: "ICD10GM",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "SNOMED",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus icd10gm_analyses",
              extraction_source: "icd10gm_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }
      }
    }

    // 4. Process ICD-11 analyses
    const { data: icd11Analyses, error: icd11Error } = await supabase
      .from("icd11_analyses")
      .select("icd_code, content, hpo_mappings, snomed_mappings")
      .limit(batchSize);

    if (icd11Error) {
      stats.errors.push(`ICD-11 fetch error: ${icd11Error.message}`);
    } else if (icd11Analyses) {
      for (const analysis of icd11Analyses) {
        stats.icd11AnalysesProcessed++;
        
        // Get ICD-11 label
        const { data: icdCode } = await supabase
          .from("icd11_codes")
          .select("title")
          .eq("code", analysis.icd_code)
          .maybeSingle();
        
        const icdLabel = icdCode?.title || analysis.icd_code;

        // Extract HPO mappings
        const hpoMappings = analysis.hpo_mappings as MappingEntry[] | null;
        if (hpoMappings && Array.isArray(hpoMappings)) {
          for (const mapping of hpoMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.icd_code,
              source_label: icdLabel,
              source_system: "ICD11",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "HPO",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus icd11_analyses",
              extraction_source: "icd11_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }

        // Extract SNOMED mappings
        const snomedMappings = analysis.snomed_mappings as MappingEntry[] | null;
        if (snomedMappings && Array.isArray(snomedMappings)) {
          for (const mapping of snomedMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.icd_code,
              source_label: icdLabel,
              source_system: "ICD11",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "SNOMED",
              confidence: mapping.confidence || 0.8,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus icd11_analyses",
              extraction_source: "icd11_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }
      }
    }

    // 5. Process Orphanet analyses
    const { data: orphanetAnalyses, error: orphanetError } = await supabase
      .from("orphanet_analyses")
      .select("orpha_code, content, hpo_mappings, snomed_mappings, icd10_mappings")
      .limit(batchSize);

    if (orphanetError) {
      stats.errors.push(`Orphanet fetch error: ${orphanetError.message}`);
    } else if (orphanetAnalyses) {
      for (const analysis of orphanetAnalyses) {
        stats.orphanetAnalysesProcessed++;
        
        // Get Orphanet label
        const { data: orphaCode } = await supabase
          .from("orphanet_codes")
          .select("name")
          .eq("orpha_code", analysis.orpha_code)
          .maybeSingle();
        
        const orphaLabel = orphaCode?.name || analysis.orpha_code;

        // Extract HPO mappings
        const hpoMappings = analysis.hpo_mappings as MappingEntry[] | null;
        if (hpoMappings && Array.isArray(hpoMappings)) {
          for (const mapping of hpoMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.orpha_code,
              source_label: orphaLabel,
              source_system: "ORPHANET",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "HPO",
              confidence: mapping.confidence || 0.85,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus orphanet_analyses",
              extraction_source: "orphanet_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }

        // Extract SNOMED mappings
        const snomedMappings = analysis.snomed_mappings as MappingEntry[] | null;
        if (snomedMappings && Array.isArray(snomedMappings)) {
          for (const mapping of snomedMappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.orpha_code,
              source_label: orphaLabel,
              source_system: "ORPHANET",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "SNOMED",
              confidence: mapping.confidence || 0.85,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus orphanet_analyses",
              extraction_source: "orphanet_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }

        // Extract ICD-10 mappings
        const icd10Mappings = analysis.icd10_mappings as MappingEntry[] | null;
        if (icd10Mappings && Array.isArray(icd10Mappings)) {
          for (const mapping of icd10Mappings) {
            if (!mapping.code) continue;
            
            const row = {
              source_code: analysis.orpha_code,
              source_label: orphaLabel,
              source_system: "ORPHANET",
              target_code: mapping.code,
              target_label: mapping.label || mapping.code,
              target_system: "ICD10GM",
              confidence: mapping.confidence || 0.85,
              mapping_type: mapping.mappingType || "related",
              notes: "Backfill aus orphanet_analyses",
              extraction_source: "orphanet_analyses",
              validation_status: "pending",
            };

            if (!dryRun) {
              const { error: insertError } = await supabase
                .from("ontology_mappings")
                .upsert(row, {
                  onConflict: "source_code,source_system,target_code,target_system",
                  ignoreDuplicates: true,
                });
              
              if (insertError) {
                stats.mappingsSkipped++;
              } else {
                stats.mappingsCreated++;
              }
            } else {
              stats.mappingsCreated++;
            }
          }
        }
      }
    }

    console.log("Backfill completed:", stats);

    return new Response(
      JSON.stringify({ 
        success: true, 
        dryRun,
        stats 
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Backfill error:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        stats 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
