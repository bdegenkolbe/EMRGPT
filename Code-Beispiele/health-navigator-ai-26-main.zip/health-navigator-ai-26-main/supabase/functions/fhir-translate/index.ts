import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TranslateRequest {
  sourceSystem: string;
  sourceCode: string;
  targetSystem?: string;
  serverIds?: string[];
}

interface FhirMapping {
  code: string;
  display: string;
  equivalence: string;
  system: string;
}

interface FhirServer {
  id: string;
  name: string;
  base_url: string;
  server_type: string;
  supported_systems: string[];
  priority: number;
  is_active: boolean;
  auth_type: string;
  timeout_ms: number;
}

function getSupabaseAdmin() {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(supabaseUrl, supabaseKey);
}

/**
 * Get active FHIR servers sorted by priority
 */
async function getActiveServers(supabase: any, serverIds?: string[]): Promise<FhirServer[]> {
  let query = supabase
    .from("fhir_terminology_servers")
    .select("*")
    .eq("is_active", true)
    .order("priority", { ascending: true });

  if (serverIds && serverIds.length > 0) {
    query = query.in("id", serverIds);
  }

  const { data, error } = await query;

  if (error) {
    console.error("Failed to fetch FHIR servers:", error);
    return [];
  }

  return data || [];
}

/**
 * Call FHIR $translate operation on a server
 */
async function callFhirTranslate(
  server: FhirServer,
  sourceSystem: string,
  sourceCode: string,
  targetSystem?: string
): Promise<FhirMapping[]> {
  const url = new URL(`${server.base_url}/ConceptMap/$translate`);
  url.searchParams.set("system", sourceSystem);
  url.searchParams.set("code", sourceCode);

  if (targetSystem) {
    url.searchParams.set("targetSystem", targetSystem);
  }

  const headers: Record<string, string> = {
    Accept: "application/fhir+json",
  };

  // Add auth if needed
  if (server.auth_type === "bearer") {
    // In production, fetch from vault
    // For now, skip auth for public servers
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), server.timeout_ms || 10000);

  try {
    const response = await fetch(url.toString(), {
      method: "GET",
      headers,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      console.log(`[FHIR $translate] ${server.name} returned ${response.status}`);
      return [];
    }

    const data = await response.json();
    const mappings: FhirMapping[] = [];

    // FHIR Parameters response parsing
    const parameters = data.parameter || [];

    for (const param of parameters) {
      if (param.name === "match") {
        const parts = param.part || [];
        let concept: any = null;
        let equivalence = "equivalent";

        for (const part of parts) {
          if (part.name === "concept" && part.valueCoding) {
            concept = part.valueCoding;
          } else if (part.name === "equivalence" && part.valueCode) {
            equivalence = part.valueCode;
          }
        }

        if (concept && concept.code) {
          mappings.push({
            code: concept.code,
            display: concept.display || concept.code,
            equivalence,
            system: concept.system || targetSystem || "",
          });
        }
      }
    }

    return mappings;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === "AbortError") {
      console.log(`[FHIR $translate] ${server.name} timed out`);
    } else {
      console.error(`[FHIR $translate] ${server.name} error:`, err.message);
    }
    return [];
  }
}

/**
 * Check if server supports the required systems
 */
function serverSupportsTranslation(server: FhirServer, sourceSystem: string, targetSystem?: string): boolean {
  const supported = server.supported_systems || [];

  // Check source system
  const supportsSource = supported.length === 0 || supported.some((s) => sourceSystem.includes(s) || s.includes(sourceSystem));

  if (!supportsSource) return false;

  // If target specified, check it too
  if (targetSystem) {
    const supportsTarget = supported.some((s) => targetSystem.includes(s) || s.includes(targetSystem));
    return supportsTarget;
  }

  return true;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const request: TranslateRequest = await req.json();

    if (!request.sourceSystem || !request.sourceCode) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: sourceSystem, sourceCode" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[FHIR $translate] ${request.sourceSystem}:${request.sourceCode} -> ${request.targetSystem || "any"}`);

    const supabase = getSupabaseAdmin();
    const servers = await getActiveServers(supabase, request.serverIds);

    if (servers.length === 0) {
      return new Response(
        JSON.stringify({ mappings: [], error: "No active FHIR servers configured" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Try servers in priority order
    for (const server of servers) {
      if (!serverSupportsTranslation(server, request.sourceSystem, request.targetSystem)) {
        console.log(`[FHIR $translate] Skipping ${server.name} - doesn't support required systems`);
        continue;
      }

      const mappings = await callFhirTranslate(server, request.sourceSystem, request.sourceCode, request.targetSystem);

      if (mappings.length > 0) {
        console.log(`[FHIR $translate] Found ${mappings.length} mappings from ${server.name}`);
        return new Response(
          JSON.stringify({
            mappings,
            serverUsed: server.name,
            serverUrl: server.base_url,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // No mappings found
    return new Response(
      JSON.stringify({ mappings: [], serversTried: servers.map((s) => s.name) }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[FHIR $translate] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
