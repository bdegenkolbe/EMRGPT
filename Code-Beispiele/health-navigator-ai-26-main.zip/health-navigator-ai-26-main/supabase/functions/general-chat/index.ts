import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function getEmbedding(text: string, apiKey: string): Promise<number[]> {
  const response = await fetch("https://api.openai.com/v1/embeddings", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ model: "text-embedding-3-small", input: text }),
  });
  if (!response.ok) throw new Error(`Embedding error: ${response.status}`);
  const data = await response.json();
  return data.data[0].embedding;
}

async function searchGuidelines(query: string, supabase: any, openaiKey: string): Promise<string> {
  try {
    const embedding = await getEmbedding(query, openaiKey);
    const { data: results } = await supabase.rpc("search_guidelines", {
      query_embedding: JSON.stringify(embedding),
      match_threshold: 0.3,
      match_count: 5,
    });

    if (!results?.length) return "";

    // Group by guideline and format
    const grouped: Record<string, { title: string; chunks: string[] }> = {};
    for (const r of results) {
      if (!grouped[r.guideline_id]) {
        grouped[r.guideline_id] = { title: r.guideline_title, chunks: [] };
      }
      const pageRef = r.page_number ? ` (S. ${r.page_number})` : "";
      grouped[r.guideline_id].chunks.push(`${r.content.slice(0, 500)}${pageRef}`);
    }

    let context = "\n\n## Relevante Leitlinien-Abschnitte\n\n";
    for (const g of Object.values(grouped)) {
      context += `### ${g.title}\n`;
      for (const c of g.chunks) {
        context += `> ${c}\n\n`;
      }
    }
    return context;
  } catch (e) {
    console.error("Guideline search failed:", e);
    return "";
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    if (!messages?.length) {
      return new Response(JSON.stringify({ error: "messages required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "LOVABLE_API_KEY not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Search guidelines for context based on the latest user message
    let guidelineContext = "";
    if (OPENAI_API_KEY) {
      const lastUserMsg = [...messages].reverse().find((m: any) => m.role === "user");
      if (lastUserMsg?.content) {
        const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
        const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        const supabase = createClient(supabaseUrl, supabaseServiceKey);
        guidelineContext = await searchGuidelines(lastUserMsg.content, supabase, OPENAI_API_KEY);
        if (guidelineContext) {
          console.log(`Found guideline context: ${guidelineContext.length} chars`);
        }
      }
    }

    const systemPrompt = `Du bist ein hilfreicher medizinischer KI-Assistent. Du beantwortest Fragen zu Medizin, klinischen Leitlinien, Diagnosen, Laborwerten, Ontologien (ICD-10, ICD-11, SNOMED CT, HPO, LOINC) und verwandten Themen.

Regeln:
- Antworte präzise, medizinisch fundiert und auf Deutsch.
- Verwende Markdown-Formatierung für Übersichtlichkeit.
- Weise bei kritischen medizinischen Fragen immer darauf hin, dass eine ärztliche Beurteilung notwendig ist.
- Du bist ein Entscheidungsunterstützungssystem, KEINE Diagnose-Engine.
- Wenn du dir unsicher bist, sage das klar.
- Wenn dir Leitlinien-Abschnitte zur Verfügung stehen, zitiere sie mit Quellenangabe (Leitlinien-Titel und Seitenzahl).
- Kennzeichne Informationen aus Leitlinien klar als solche.${guidelineContext}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit erreicht. Bitte versuchen Sie es später erneut." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Credits erschöpft. Bitte laden Sie Credits auf." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("General chat error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
