# Unified Knowledge Search - Konzept

## Übersicht

Konsolidierung von RAG-Suche, Literatursuche und KI-Fragen in **ein einziges Interface** mit automatischer Quellengenerierung, asynchronem Content-Loading und Mehrsprachigkeit.

## Architektur

```
┌─────────────────────────────────────────────────────────────────┐
│                    UNIFIED SEARCH INPUT                         │
│  "Suche alle Artikel zu Hypertonie von 2021 bis jetzt"         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    QUERY ANALYZER (KI)                          │
│  - Erkennt Intent: Suche vs. Frage                              │
│  - Extrahiert Filter: Zeitraum, Themen, Sprache                 │
│  - Generiert optimierte Suchbegriffe                            │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│   LOKALE LEITLINIEN     │     │    EUROPE PMC API       │
│   (Vector Search)       │     │    (External Search)    │
│   - Schnelle Ergebnisse │     │    - Mit Datumsfilter   │
│   - Hohe Relevanz       │     │    - Open Access prüfen │
└─────────────────────────┘     └─────────────────────────┘
              │                               │
              └───────────────┬───────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    UNIFIED SOURCE LIST                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Source 1: [Leitlinie] Hypertonie-Management 2023         │  │
│  │ Status: ✓ Geladen | Sprache: DE                          │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ Source 2: [PMC] Blood Pressure Control in Elderly (2022) │  │
│  │ Status: ⏳ Lädt Abstract... | Sprache: EN → DE           │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ Source 3: [PMC] Novel Antihypertensive Agents (2021)     │  │
│  │ Status: ⏳ Übersetzt...                                   │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ (Bei Fragen)
┌─────────────────────────────────────────────────────────────────┐
│                    KI-SYNTHESE                                  │
│  - Nutzt alle geladenen Quellen als Kontext                     │
│  - Generiert evidenzbasierte Antwort                            │
│  - Zitiert Quellen inline                                       │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PERSISTENZ                                   │
│  - Speichert Suchergebnisse in DB                               │
│  - Cached übersetzte Inhalte                                    │
│  - Ermöglicht Wiederverwendung                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Datenmodell

### Neue Tabelle: `knowledge_searches`
```sql
CREATE TABLE knowledge_searches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  query TEXT NOT NULL,
  query_analysis JSONB,  -- {intent, filters, keywords}
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### Neue Tabelle: `knowledge_sources`
```sql
CREATE TABLE knowledge_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  search_id UUID REFERENCES knowledge_searches ON DELETE CASCADE,
  source_type TEXT NOT NULL,  -- 'guideline', 'europepmc', 'pubmed'
  external_id TEXT,  -- PMID, guideline_id, etc.
  title TEXT NOT NULL,
  authors TEXT,
  year INTEGER,
  
  -- Content loading
  content_status TEXT DEFAULT 'pending',  -- pending, loading, loaded, error
  original_content TEXT,
  original_language TEXT,
  
  -- Translation
  translated_content TEXT,
  target_language TEXT,
  translation_status TEXT DEFAULT 'pending',
  
  -- Metadata
  relevance_score NUMERIC,
  url TEXT,
  metadata JSONB,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

## UI-Komponenten

### 1. UnifiedSearchInput
```tsx
- Einzelnes Eingabefeld mit Smart-Suggestions
- Inline-Filter-Pills (Zeitraum, Quelltyp)
- Voice-Input-Support
```

### 2. SourceListPanel
```tsx
- Echtzeit-Ladestatus pro Quelle
- Expandierbare Vorschau
- Übersetzungsindikator
- Relevanz-Score-Visualisierung
```

### 3. AIResponsePanel
```tsx
- Streaming-Antwort
- Inline-Zitationen [1], [2], [3]
- Klickbare Quellenreferenzen
```

## Edge Functions

### 1. `knowledge-search` (Orchestrator)
```typescript
// Hauptfunktion: Koordiniert die Suche
Input: { query, language, filters? }
Output: { searchId, sources: SourcePreview[] }

Steps:
1. Analyze query (intent, filters, keywords)
2. Parallel search: Guidelines + EuropePMC
3. Create search record
4. Return initial sources (ohne Content)
5. Trigger async content loading
```

### 2. `knowledge-load-content` (Async Worker)
```typescript
// Lädt Content asynchron nach
Input: { sourceId }
Output: { content, language }

Steps:
1. Fetch full content (Abstract, PDF-Chunk)
2. Update source record
3. Trigger translation if needed
```

### 3. `knowledge-translate` (Translation Worker)
```typescript
// Übersetzt Content in Zielsprache
Input: { sourceId, targetLanguage }
Output: { translatedContent }

Steps:
1. Load original content
2. Translate via AI
3. Update source record
4. Cache translation
```

## Ablauf: Beispiel

**User Input:** "Suche alle Artikel zu Hypertonie von 2021 bis jetzt"

1. **Query Analysis:**
   ```json
   {
     "intent": "search",
     "topic": "Hypertonie",
     "dateRange": { "from": "2021-01-01", "to": "now" },
     "keywords": ["hypertension", "blood pressure", "antihypertensive"]
   }
   ```

2. **Parallel Search:**
   - Guidelines: 3 relevante Chunks gefunden
   - EuropePMC: 15 Artikel gefunden (gefiltert nach 2021+)

3. **Source List (Initial):**
   - 18 Quellen mit Titel, Jahr, Typ
   - Status: "pending" für Content

4. **Async Loading:**
   - Abstracts werden im Hintergrund geladen
   - Bei Bedarf wird übersetzt (EN → DE)
   - UI aktualisiert sich live

5. **Persistenz:**
   - Suche + Quellen in DB gespeichert
   - Bei erneuter Suche: Cache-Hit möglich

## Vorteile

1. **Einheitliche UX**: Ein Eingabefeld für alles
2. **Vollständige Quellenübersicht**: Immer sichtbar was durchsucht wurde
3. **Schnelle Erstantwort**: Titel sofort, Details async
4. **Mehrsprachig**: Automatische Übersetzung
5. **Audit-Trail**: Alle Suchen dokumentiert
6. **Wiederverwendbar**: Gecachte Ergebnisse

## Nächste Schritte

1. [ ] Datenbank-Migration erstellen
2. [ ] Edge Function `knowledge-search` implementieren
3. [ ] Edge Function `knowledge-load-content` implementieren
4. [ ] Edge Function `knowledge-translate` implementieren
5. [ ] UI-Komponenten erstellen
6. [ ] Real-time Updates via Supabase Realtime
