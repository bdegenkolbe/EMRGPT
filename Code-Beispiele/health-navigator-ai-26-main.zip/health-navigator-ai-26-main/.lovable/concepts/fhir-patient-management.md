# FHIR-basiertes Patientendatenverwaltungssystem

## Vision

Ein professionelles, FHIR R4-konformes Patientendatenverwaltungssystem mit KI-gestütztem Chatbot, das klinische Daten strukturiert speichert, mit den bestehenden Ontologien (HPO, SNOMED, ICD-10/11, LOINC) verknüpft und durch Echtzeit-Evidenzrecherche (Europe PMC + lokale Leitlinien) ergänzt.

---

## Architektur-Übersicht

```
┌──────────────────────────────────────────────────────────────────┐
│                     /patients - Hauptseite                       │
├─────────────┬────────────────────────────────┬───────────────────┤
│  Patienten- │     Patientenakte (Tabs)       │  Evidenz-Panel    │
│  liste      │                                │  (Europe PMC)     │
│  ─────────  │  📋 Übersicht (Demographics)   │  ──────────────   │
│  🔍 Suche   │  🏥 Aufenthalte (Encounters)   │  Automatische     │
│             │  📝 Anamnesen (Conditions)      │  Artikelsuche     │
│  Patient A  │  🧪 Laborwerte (Observations)  │  basierend auf    │
│  Patient B  │  💊 Medikation (MedicationReq) │  aktiven          │
│  Patient C  │  📄 Dokumente (DocumentRef)    │  Diagnosen &      │
│             │  🔗 Ontologie-Mappings         │  Symptomen        │
│             │                                │                   │
│             ├────────────────────────────────┤                   │
│             │     KI-Chatbot (unten)         │                   │
│             │  ┌──────────────────────────┐  │                   │
│             │  │ "Welche Wechselwirkungen │  │                   │
│             │  │  hat Patient A?"         │  │                   │
│             │  └──────────────────────────┘  │                   │
└─────────────┴────────────────────────────────┴───────────────────┘
```

---

## Datenbank-Design (FHIR R4 in Supabase)

### Kernressourcen als Tabellen

Statt FHIR-Ressourcen als rohe JSON-Blobs zu speichern, nutzen wir einen **hybriden Ansatz**: Strukturierte Spalten für durchsuchbare Felder + JSONB für die vollständige FHIR-Ressource.

#### 1. `fhir_patients` (Patient Resource)
```sql
CREATE TABLE fhir_patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,           -- FHIR Resource ID
  active BOOLEAN DEFAULT true,
  given_name TEXT NOT NULL,
  family_name TEXT NOT NULL,
  birth_date DATE,
  gender TEXT CHECK (gender IN ('male','female','other','unknown')),
  identifier_mrn TEXT,                    -- Medical Record Number
  telecom JSONB DEFAULT '[]',             -- Phone, Email etc.
  address JSONB DEFAULT '[]',
  fhir_resource JSONB NOT NULL,           -- Complete FHIR Patient resource
  created_by UUID NOT NULL,               -- User who created this
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

#### 2. `fhir_encounters` (Encounter/Aufenthalte)
```sql
CREATE TABLE fhir_encounters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES fhir_patients(id) ON DELETE CASCADE,
  status TEXT NOT NULL,                   -- planned|arrived|in-progress|finished
  class TEXT,                             -- ambulatory|emergency|inpatient
  type_code TEXT,                         -- SNOMED CT code
  type_display TEXT,
  period_start TIMESTAMPTZ,
  period_end TIMESTAMPTZ,
  reason_codes JSONB DEFAULT '[]',        -- ICD-10/SNOMED codes
  diagnosis_codes JSONB DEFAULT '[]',
  service_provider TEXT,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

#### 3. `fhir_conditions` (Diagnosen/Anamnesen)
```sql
CREATE TABLE fhir_conditions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES fhir_encounters(id),
  clinical_status TEXT,                   -- active|recurrence|relapse|inactive|remission|resolved
  verification_status TEXT,               -- confirmed|provisional|differential
  category TEXT,                          -- problem-list-item|encounter-diagnosis
  code_system TEXT,                       -- ICD-10, SNOMED CT
  code TEXT,                              -- The actual code
  code_display TEXT,                      -- Human-readable
  severity TEXT,                          -- mild|moderate|severe
  onset_datetime TIMESTAMPTZ,
  abatement_datetime TIMESTAMPTZ,
  hpo_codes TEXT[] DEFAULT '{}',          -- Linked HPO codes
  snomed_codes TEXT[] DEFAULT '{}',       -- Linked SNOMED codes
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

#### 4. `fhir_observations` (Laborwerte & Vitalzeichen)
```sql
CREATE TABLE fhir_observations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES fhir_encounters(id),
  status TEXT NOT NULL,                   -- registered|preliminary|final|amended
  category TEXT,                          -- vital-signs|laboratory|social-history
  loinc_code TEXT,                        -- LOINC code
  code_display TEXT,
  value_quantity NUMERIC,
  value_unit TEXT,
  value_string TEXT,
  reference_range_low NUMERIC,
  reference_range_high NUMERIC,
  interpretation TEXT,                    -- normal|abnormal|high|low|critical
  effective_datetime TIMESTAMPTZ,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

#### 5. `fhir_medication_requests` (Medikation)
```sql
CREATE TABLE fhir_medication_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES fhir_encounters(id),
  status TEXT NOT NULL,                   -- active|completed|stopped|cancelled
  intent TEXT DEFAULT 'order',
  medication_code TEXT,                   -- ATC/RxNorm code
  medication_display TEXT,
  dosage_text TEXT,
  dosage_route TEXT,
  authored_on TIMESTAMPTZ,
  requester_display TEXT,
  reason_codes JSONB DEFAULT '[]',
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

#### 6. `fhir_document_references` (Dokumente)
```sql
CREATE TABLE fhir_document_references (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES fhir_patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES fhir_encounters(id),
  status TEXT NOT NULL,
  type_code TEXT,                         -- LOINC document type
  type_display TEXT,
  description TEXT,
  content_type TEXT,                      -- MIME type
  storage_path TEXT,                      -- Supabase Storage path
  date TIMESTAMPTZ,
  author_display TEXT,
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

#### 7. `fhir_allergies` (Allergien/Unverträglichkeiten)
```sql
CREATE TABLE fhir_allergies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fhir_id TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES fhir_patients(id) ON DELETE CASCADE,
  clinical_status TEXT,
  verification_status TEXT,
  type TEXT,                              -- allergy|intolerance
  category TEXT,                          -- food|medication|environment|biologic
  criticality TEXT,                       -- low|high|unable-to-assess
  code TEXT,
  code_display TEXT,
  onset_datetime TIMESTAMPTZ,
  reactions JSONB DEFAULT '[]',
  fhir_resource JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

---

## UI-Konzept: Dreispalten-Layout

### Hauptseite `/patients`

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Header: Patientenverwaltung                            [FHIR Import] │
├──────────┬──────────────────────────────────────┬───────────────────────┤
│          │                                      │                       │
│ PATIENTEN│  PATIENTENAKTE                       │  EVIDENZ-SIDEBAR      │
│ LISTE    │                                      │                       │
│          │  ┌──────────────────────────────┐    │  📚 Aktuelle Studien  │
│ 🔍 Suche │  │ Max Mustermann, *01.03.1985  │    │  zu: Diabetes Typ 2   │
│          │  │ MRN: 12345 │ ♂ │ 39 Jahre   │    │                       │
│ ┌──────┐ │  └──────────────────────────────┘    │  ┌─────────────────┐ │
│ │ Max  │ │                                      │  │ Smith et al 2024│ │
│ │ M.   │ │  [Übersicht][Aufenthalte][Labor]     │  │ "New insights..." │
│ │ ♂ 39 │ │  [Diagnosen][Medikation][Allergien]  │  │ IF: 4.2 │ OA ✓ │ │
│ │ ████ │ │  [Dokumente][Ontologie][Timeline]     │  └─────────────────┘ │
│ └──────┘ │                                      │                       │
│ ┌──────┐ │  ═══════ Aktiver Tab ═══════         │  ┌─────────────────┐ │
│ │ Anna │ │                                      │  │ Lee et al 2023  │ │
│ │ S.   │ │  Tabinhalt...                        │  │ "Treatment..."  │ │
│ │ ♀ 67 │ │                                      │  └─────────────────┘ │
│ └──────┘ │                                      │                       │
│          │                                      │                       │
│          ├──────────────────────────────────────┤                       │
│          │  💬 KI-CHATBOT                       │                       │
│          │  ┌──────────────────────────────┐    │                       │
│          │  │ Nachrichten-Verlauf...        │    │                       │
│          │  │                              │    │                       │
│          │  │ 🤖 Basierend auf den Labor-  │    │                       │
│          │  │ werten und der Diagnose E11  │    │                       │
│          │  │ empfehle ich folgende...     │    │                       │
│          │  ├──────────────────────────────┤    │                       │
│          │  │ Frage eingeben...    [Senden]│    │                       │
│          │  └──────────────────────────────┘    │                       │
│          │                                      │                       │
└──────────┴──────────────────────────────────────┴───────────────────────┘
```

### Key UI Features

1. **Patientenliste (links)**
   - Suchbare/filterbare Patientenkarten
   - Farbkodierte Statusanzeige (aktiv/inaktiv)
   - Quick-Info: Name, Alter, Geschlecht, aktive Diagnosen-Count

2. **Patientenakte (mitte) - Tab-basiert**
   - **Übersicht**: Demographics, aktive Diagnosen, letzte Vitale, Allergien-Warnung
   - **Aufenthalte**: Timeline aller Encounters mit Status-Badges
   - **Diagnosen**: Conditions mit ICD-10/SNOMED-Codes, Verlinkung zu Ontologie-Browser
   - **Laborwerte**: LOINC-kodierte Observations mit Trend-Charts (Recharts)
   - **Medikation**: Aktive/abgesetzte Medikamente mit Wechselwirkungsprüfung
   - **Allergien**: Allergien & Unverträglichkeiten mit Kritikalitäts-Badges
   - **Dokumente**: Hochgeladene Befunde, Arztbriefe
   - **Ontologie**: Alle zugeordneten Codes (HPO, SNOMED, ICD, LOINC) als interaktive Map
   - **Timeline**: Chronologische Gesamtansicht aller Events

3. **KI-Chatbot (unten-mitte, resizable)**
   - Streaming-Antworten via `ai-chat` Edge Function
   - Automatischer Kontext: Alle FHIR-Ressourcen des Patienten
   - RAG: Guidelines-Suche + Europe PMC Evidenz
   - Beispiel-Prompts: "Wechselwirkungen?", "Differentialdiagnosen?", "Leitlinienempfehlungen?"

4. **Evidenz-Sidebar (rechts)**
   - Automatische Europe PMC Suche basierend auf aktiven Diagnosen
   - Echtzeit-Update bei Tab-/Patienten-Wechsel
   - Badges für Open Access, Impact Factor, Studientyp
   - Direktlinks zu Volltext/PDF

---

## KI-Chatbot: Kontext-Architektur

```
Benutzer-Frage
       │
       ▼
┌──────────────────┐
│  Kontext-Builder  │
│  (Edge Function)  │
├──────────────────┤
│ 1. Patient Demo  │ ◄── fhir_patients
│ 2. Diagnosen     │ ◄── fhir_conditions + Ontologie-Mappings
│ 3. Laborwerte    │ ◄── fhir_observations (letzte N)
│ 4. Medikation    │ ◄── fhir_medication_requests
│ 5. Allergien     │ ◄── fhir_allergies
│ 6. Guidelines    │ ◄── guideline_chunks (RAG, Vektor-Suche)
│ 7. Evidenz       │ ◄── Europe PMC (live oder cached)
└───────┬──────────┘
        │
        ▼
   System-Prompt mit
   strukturiertem Kontext
        │
        ▼
   Lovable AI Gateway
   (Streaming Response)
```

### Edge Function: `patient-chat`

- Empfängt: `{ patientId, messages[], context_options? }`
- Baut dynamischen System-Prompt mit allen FHIR-Daten des Patienten
- Führt optionale RAG-Suche in Guidelines durch
- Streamt Antwort zurück

---

## FHIR-Import

### Bundle-Import (für die hochgeladene ZIP)

Eine Edge Function `fhir-import` die:
1. FHIR Bundle JSON parst
2. Ressourcen nach Typ sortiert (Patient → Encounter → Condition → ...)
3. In die entsprechenden Tabellen einfügt
4. Ontologie-Codes extrahiert und mit lokaler DB verknüpft

### Manuelles Erstellen

Formulare für jede Ressource mit:
- Autocomplete für ICD-10, SNOMED, LOINC Codes (bestehende Ontologie-Browser)
- FHIR-Validierung vor dem Speichern
- Automatische FHIR Resource Generation im Hintergrund

---

## Evidenz-Panel: Automatische Literaturrecherche

### Trigger-Logik

```
Patient ausgewählt
       │
       ▼
Aktive Diagnosen extrahieren
       │
       ├── ICD-10 Codes → MeSH-Terms ableiten
       ├── SNOMED Codes → Preferred Terms
       └── Freitext-Diagnosen
       │
       ▼
Europe PMC Parallelsuche
(max. 5 Queries, dedupliziert)
       │
       ▼
Sortierung: 80% Relevanz, 10% Datum, 10% Zitationen
       │
       ▼
Anzeige im Sidebar-Panel mit
Live-Aktualisierung bei Tab-Wechsel
```

---

## Implementierungsreihenfolge

### Phase 1: Datenbank & FHIR-Import
1. Migration: Alle FHIR-Tabellen erstellen (mit RLS)
2. Edge Function: `fhir-import` für Bundle-Import
3. FHIR Bundle aus ZIP importieren

### Phase 2: Patienten-UI
4. Patientenliste mit Suche/Filter
5. Patientenakte mit Tab-Navigation
6. Formulare für CRUD-Operationen
7. Ontologie-Integration (bestehende Hooks)

### Phase 3: KI-Chatbot
8. Edge Function: `patient-chat` mit Kontext-Builder
9. Chat-UI mit Streaming
10. RAG-Integration (Guidelines + Europe PMC)

### Phase 4: Evidenz-Panel
11. Automatische Literatursuche
12. Sidebar-Panel mit Artikelkarten
13. Volltext-Zugang (bestehende Infrastruktur)

### Phase 5: FHIR Export & Interoperabilität
14. FHIR Bundle Export
15. FHIR `$translate` Integration (bestehende Edge Function)

---

## Sicherheit & RLS

Alle FHIR-Tabellen werden mit `created_by`-basiertem RLS geschützt:
- Benutzer sehen nur Patienten, die sie selbst erstellt haben
- Admins haben vollen Zugriff
- Der Chatbot nutzt den Benutzerkontext für die Abfrage

---

## Technologie-Stack Erweiterung

| Komponente | Technologie |
|---|---|
| FHIR-Datenmodell | Supabase Tables (hybrid: SQL + JSONB) |
| Chatbot | Lovable AI Gateway (Streaming) via `patient-chat` |
| Evidenz | Europe PMC API (bestehend) |
| RAG | Guideline Embeddings (bestehend) |
| Lab-Charts | Recharts (bereits installiert) |
| Ontologie | Bestehende Hooks (useSnomed, useIcd10Gm, useLoinc) |
| Layout | ResizablePanelGroup (bereits installiert) |
