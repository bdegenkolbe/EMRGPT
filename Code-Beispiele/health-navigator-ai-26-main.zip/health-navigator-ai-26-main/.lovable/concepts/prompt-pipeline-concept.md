# Clinical Query Orchestration Pipeline - Konzept

## 1. Übersicht

Die Pipeline orchestriert sichere, auditierbare KI-Interaktionen durch modulare Prompt-Stufen mit dynamischer Parametrierung basierend auf:
- **Klinischem Setting** (Hausarzt, Notaufnahme, Telemedizin, Fachambulanz, Klinik)
- **Fragenbaum-Kontext** (aktuelle Position, bereits gestellte Fragen, Antworten)
- **Leitlinien-Retrieval** (RAG aus guideline_chunks)
- **HPO-Phänotypisierung** (erkannte Symptom-Codes)

---

## 2. Pipeline-Architektur

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CLINICAL QUERY ORCHESTRATION                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │   CONTEXT    │───▶│    TRIAGE    │───▶│  ELICITATION │                   │
│  │   LOADER     │    │  (Phase 1)   │    │  (Phase 2)   │                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
│         │                   │                   │                            │
│         ▼                   ▼                   ▼                            │
│  ┌──────────────────────────────────────────────────────┐                   │
│  │              CONTEXT AGGREGATOR                       │                   │
│  │  • Session State    • HPO Codes    • Question Tree    │                   │
│  │  • Clinical Setting • Guidelines   • Red Flags        │                   │
│  └──────────────────────────────────────────────────────┘                   │
│         │                                                                    │
│         ▼                                                                    │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │ NORMALIZATION│───▶│CATEGORIZATION│───▶│  RETRIEVAL   │                   │
│  │  (Phase 3)   │    │  (Phase 4)   │    │  (Phase 5)   │                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
│         │                                      │                             │
│         ▼                                      ▼                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │  VALIDATION  │◀───│   SYNTHESIS  │◀───│  GUIDELINES  │                   │
│  │  (Phase 6)   │    │  (Phase 7)   │    │     RAG      │                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
│         │                                                                    │
│         ▼                                                                    │
│  ┌──────────────────────────────────────────────────────┐                   │
│  │                   AUDIT LOGGER                        │                   │
│  │  • Prompt Versions  • Inputs/Outputs  • Timestamps    │                   │
│  └──────────────────────────────────────────────────────┘                   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Datenbank-Schema

### 3.1 Prompt-Template-Verwaltung

```sql
-- Prompt-Templates mit Versionierung
CREATE TABLE prompt_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Identifikation
  slug TEXT NOT NULL,                    -- z.B. 'triage', 'elicitation', 'validation'
  version INTEGER NOT NULL DEFAULT 1,
  is_active BOOLEAN DEFAULT true,
  
  -- Inhalt
  name TEXT NOT NULL,                    -- Anzeigename
  description TEXT,                      -- Beschreibung für Admins
  system_prompt TEXT NOT NULL,           -- Der eigentliche Prompt
  
  -- Konfiguration
  phase INTEGER NOT NULL,                -- 1-7 für Pipeline-Position
  clinical_views TEXT[],                 -- Für welche Settings? NULL = alle
  
  -- Parameter-Schema (JSON Schema für Validierung)
  parameter_schema JSONB NOT NULL DEFAULT '{}',
  
  -- Modell-Konfiguration
  model TEXT DEFAULT 'google/gemini-3-flash-preview',
  temperature DECIMAL(3,2) DEFAULT 0.3,
  max_tokens INTEGER DEFAULT 1024,
  
  -- Audit
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users,
  
  UNIQUE(slug, version)
);

-- Index für schnellen Lookup
CREATE INDEX idx_prompt_templates_active ON prompt_templates(slug, is_active) 
  WHERE is_active = true;
```

### 3.2 Pipeline-Ausführungslog (Audit Trail)

```sql
-- Protokollierung jeder Pipeline-Ausführung
CREATE TABLE pipeline_executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES anamnesis_sessions(id),
  
  -- Ausführungskontext
  started_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  status TEXT DEFAULT 'running', -- running, completed, failed, aborted
  
  -- Eingabe-Snapshot
  user_input TEXT NOT NULL,
  context_snapshot JSONB NOT NULL,  -- HPO codes, question tree position, etc.
  clinical_view TEXT NOT NULL,
  
  -- Ergebnis
  final_output TEXT,
  red_flags_detected TEXT[],
  urgency_level TEXT,
  
  -- Metriken
  total_tokens_used INTEGER,
  total_latency_ms INTEGER
);

-- Einzelne Phase-Ausführungen
CREATE TABLE pipeline_phase_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  execution_id UUID REFERENCES pipeline_executions(id) ON DELETE CASCADE,
  
  -- Phase-Info
  phase INTEGER NOT NULL,
  template_id UUID REFERENCES prompt_templates(id),
  template_version INTEGER NOT NULL,
  
  -- Timing
  started_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  
  -- Ein-/Ausgabe (für Audit)
  input_params JSONB NOT NULL,
  rendered_prompt TEXT NOT NULL,     -- Der tatsächlich gesendete Prompt
  raw_output TEXT,                   -- LLM-Antwort
  parsed_output JSONB,               -- Strukturierte Extraktion
  
  -- Metriken
  tokens_used INTEGER,
  latency_ms INTEGER,
  
  -- Fehlerbehandlung
  error TEXT,
  retry_count INTEGER DEFAULT 0
);
```

### 3.3 Kontext-Aggregation View

```sql
-- Materialized View für schnellen Kontext-Zugriff
CREATE VIEW session_pipeline_context AS
SELECT 
  s.id as session_id,
  s.clinical_view,
  s.language,
  s.patient_identifier,
  
  -- Observations als Array
  COALESCE(
    (SELECT jsonb_agg(jsonb_build_object(
      'raw_input', o.raw_input,
      'hpo_codes', o.hpo_codes,
      'severity', o.severity,
      'onset', o.onset,
      'negated', o.negated
    ) ORDER BY o.created_at)
    FROM observations o WHERE o.session_id = s.id),
    '[]'::jsonb
  ) as observations,
  
  -- Alle HPO-Codes flach
  COALESCE(
    (SELECT array_agg(DISTINCT unnest) 
     FROM observations o, unnest(o.hpo_codes) 
     WHERE o.session_id = s.id AND o.negated = false),
    '{}'::text[]
  ) as all_hpo_codes,
  
  -- Aktueller Anamnesepfad
  (SELECT jsonb_build_object(
    'id', ap.id,
    'question_tree', ap.question_tree,
    'differential_diagnoses', ap.differential_diagnoses,
    'symptom_hierarchy', ap.symptom_hierarchy
  ) FROM anamnesis_paths ap 
  WHERE ap.session_id = s.id 
  ORDER BY ap.version DESC LIMIT 1) as current_path,
  
  -- Letzte Nachrichten (für Kontext)
  (SELECT jsonb_agg(jsonb_build_object(
    'role', cm.role,
    'content', cm.content,
    'is_red_flag', cm.is_red_flag
  ) ORDER BY cm.created_at DESC)
  FROM (
    SELECT * FROM conversation_messages 
    WHERE session_id = s.id 
    ORDER BY created_at DESC LIMIT 10
  ) cm) as recent_messages

FROM anamnesis_sessions s;
```

---

## 4. Prompt-Template-Definitionen

### 4.1 Phase 1: Triage

```json
{
  "slug": "triage",
  "phase": 1,
  "name": "Intent- & Safety-Triage",
  "parameter_schema": {
    "type": "object",
    "properties": {
      "USER_INPUT": { "type": "string" },
      "CLINICAL_VIEW": { "type": "string" },
      "EXISTING_HPO_CODES": { "type": "array", "items": { "type": "string" } }
    },
    "required": ["USER_INPUT", "CLINICAL_VIEW"]
  },
  "system_prompt": "Du bist ein medizinisches Triage-Modul im Setting: {{CLINICAL_VIEW}}.\n\nAnalysiere die folgende Nutzeranfrage ausschließlich hinsichtlich:\n1) Art der Anfrage (Information / akute Beschwerde / Recherche)\n2) Potenzieller medizinischer Dringlichkeit\n3) Notwendigkeit einer strukturierten Klärung vor jeder Wissensantwort\n\nBereits bekannte Symptome (HPO-Codes): {{EXISTING_HPO_CODES}}\n\nNutzeranfrage:\n{{USER_INPUT}}\n\nAntworte ausschließlich strukturiert im folgenden JSON-Format:\n{\n  \"intent_type\": \"information|acute|research\",\n  \"urgency\": \"low|medium|high|critical\",\n  \"direct_answer_allowed\": true|false,\n  \"reasoning\": \"...\",\n  \"detected_red_flags\": []\n}"
}
```

### 4.2 Phase 2: Klärungsfragen

```json
{
  "slug": "elicitation",
  "phase": 2,
  "name": "Kontext-Klärung",
  "clinical_views": null,
  "parameter_schema": {
    "type": "object",
    "properties": {
      "LEITSYMPTOM": { "type": "string" },
      "QUESTION_TREE": { "type": "object" },
      "ALREADY_ASKED": { "type": "array" },
      "CLINICAL_VIEW": { "type": "string" }
    }
  },
  "system_prompt": "Du bist ein Modul zur strukturierten Erhebung medizinischer Kontextinformationen.\nSetting: {{CLINICAL_VIEW}}\n\nLeitsymptomatik: {{LEITSYMPTOM}}\n\nVerfügbarer Fragenbaum:\n{{QUESTION_TREE}}\n\nBereits gestellte Fragen:\n{{ALREADY_ASKED}}\n\nErstelle die nächsten 3-5 priorisierten Rückfragen basierend auf dem Fragenbaum.\n\nRegeln:\n- Keine Diagnosen\n- Keine Wertungen\n- Fokus auf Zeitverlauf, Lokalisation, Begleitsymptome, Red Flags\n- Fragen aus dem Fragenbaum priorisieren\n- Bereits gestellte Fragen NICHT wiederholen\n\nAusgabe als JSON:\n{\n  \"questions\": [\n    {\"id\": \"q1\", \"text\": \"...\", \"category\": \"timing|location|quality|severity|context|red_flag\", \"priority\": 1-5}\n  ],\n  \"reasoning\": \"...\"\n}"
}
```

### 4.3 Phase 5: Leitlinien-Retrieval

```json
{
  "slug": "retrieval",
  "phase": 5,
  "name": "Leitlinien-Abfrage",
  "parameter_schema": {
    "type": "object",
    "properties": {
      "MEDICAL_CATEGORIES": { "type": "array" },
      "HPO_CODES": { "type": "array" },
      "PATIENT_CONTEXT": { "type": "object" }
    }
  },
  "system_prompt": "Du bist ein Query-Generator für eine medizinische Wissensdatenbank.\n\nMedizinische Kategorien:\n{{MEDICAL_CATEGORIES}}\n\nHPO-Codes:\n{{HPO_CODES}}\n\nPatientenkontext:\n{{PATIENT_CONTEXT}}\n\nErstelle optimierte Suchanfragen für das Leitlinien-RAG-System.\n\nAusgabe als JSON:\n{\n  \"search_queries\": [\n    {\"query\": \"...\", \"priority\": 1, \"focus\": \"differential|treatment|red_flags\"}\n  ],\n  \"filters\": {\n    \"age_relevant\": true|false,\n    \"setting\": \"...\",\n    \"acuity\": \"acute|chronic|unclear\"\n  }\n}"
}
```

---

## 5. Orchestrierungs-Logik

### 5.1 Edge Function: Pipeline Controller

```
supabase/functions/pipeline-orchestrate/
├── index.ts              # Entry point
├── phases/
│   ├── triage.ts        # Phase 1 Logik
│   ├── elicitation.ts   # Phase 2 Logik
│   ├── normalization.ts # Phase 3 Logik
│   ├── categorization.ts# Phase 4 Logik
│   ├── retrieval.ts     # Phase 5 Logik + RAG
│   ├── validation.ts    # Phase 6 Logik
│   └── synthesis.ts     # Phase 7 Logik
├── context/
│   ├── loader.ts        # Session-Kontext laden
│   └── aggregator.ts    # Kontext zusammenführen
├── prompts/
│   ├── renderer.ts      # Template-Parametrierung
│   └── validator.ts     # Output-Parsing & Validierung
└── audit/
    └── logger.ts        # Audit-Trail
```

### 5.2 Phasen-Entscheidungslogik

```typescript
interface PipelineDecision {
  nextPhase: number | 'complete' | 'abort';
  skipPhases?: number[];
  escalate?: boolean;
  reason: string;
}

// Beispiel: Nach Triage-Phase
function decideTriage(triageResult: TriageOutput): PipelineDecision {
  if (triageResult.urgency === 'critical') {
    return {
      nextPhase: 'abort',
      escalate: true,
      reason: 'Kritische Dringlichkeit erkannt - sofortige ärztliche Konsultation'
    };
  }
  
  if (triageResult.direct_answer_allowed && triageResult.intent_type === 'information') {
    return {
      nextPhase: 5, // Direkt zu Retrieval
      skipPhases: [2, 3, 4],
      reason: 'Informationsanfrage ohne akute Symptomatik'
    };
  }
  
  return { nextPhase: 2, reason: 'Strukturierte Klärung erforderlich' };
}
```

---

## 6. Integration mit bestehenden Komponenten

### 6.1 Fragenbaum-Integration

```typescript
// Fragenbaum als Kontext für Elicitation-Phase
interface QuestionTreeContext {
  currentCategory: string;           // z.B. "HPI", "PMH", "ROS"
  answeredQuestions: {
    questionId: string;
    answer: string;
    hpoCodes?: string[];
  }[];
  pendingQuestions: {
    questionId: string;
    text: string;
    priority: number;
    category: string;
  }[];
  completionPercentage: number;
}

// Mapping auf Pipeline-Parameter
function mapQuestionTreeToPromptParams(
  path: AnamnesisPath,
  session: AnamnesisSession
): Record<string, unknown> {
  return {
    QUESTION_TREE: path.question_tree,
    ALREADY_ASKED: getAnsweredQuestions(session.id),
    COMPLETION_STATUS: calculateCompletion(path, session),
    SYMPTOM_HIERARCHY: path.symptom_hierarchy
  };
}
```

### 6.2 Leitlinien-RAG-Integration (Phase 5)

```typescript
// In Phase 5: Retrieval mit bestehendem guidelines-search
async function executeRetrievalPhase(
  categories: string[],
  hpoCodes: string[],
  context: SessionContext
): Promise<RetrievalResult> {
  // 1. Generiere Suchanfragen via LLM
  const queryGenResult = await executePrompt('retrieval', {
    MEDICAL_CATEGORIES: categories,
    HPO_CODES: hpoCodes,
    PATIENT_CONTEXT: context
  });
  
  // 2. Führe RAG-Suche durch
  const guidelineResults = await Promise.all(
    queryGenResult.search_queries.map(q => 
      supabase.functions.invoke('guidelines-search', {
        body: { query: q.query, limit: 5 }
      })
    )
  );
  
  // 3. Dedupliziere und ranke Ergebnisse
  return mergeAndRankGuidelines(guidelineResults);
}
```

### 6.3 Klinisches Setting-Mapping

```typescript
// Setting-spezifische Prompt-Anpassungen
const CLINICAL_VIEW_MODIFIERS: Record<ClinicalView, PromptModifier> = {
  notaufnahme: {
    urgency_weight: 1.5,       // Höhere Gewichtung von Red Flags
    max_questions: 5,          // Weniger, fokussiertere Fragen
    time_context: 'akut',
    additional_rules: [
      'Priorisiere zeitkritische Symptome',
      'ABC-Schema beachten'
    ]
  },
  hausarztpraxis: {
    urgency_weight: 1.0,
    max_questions: 10,
    time_context: 'variabel',
    additional_rules: [
      'Chronische Verläufe berücksichtigen',
      'Präventionsaspekte einbeziehen'
    ]
  },
  telemedizin: {
    urgency_weight: 1.2,
    max_questions: 8,
    time_context: 'akut_bis_subakut',
    additional_rules: [
      'Limitierte körperliche Untersuchung beachten',
      'Klare Eskalationskriterien für Präsenzbesuch'
    ]
  }
  // ... weitere Settings
};
```

---

## 7. Administrations-UI

### 7.1 Prompt-Editor Features

- **Live-Preview**: Template mit Beispieldaten rendern
- **Versionsvergleich**: Diff zwischen Versionen
- **A/B-Testing**: Parallele Prompt-Versionen mit Metrik-Tracking
- **Rollback**: Schnelles Zurücksetzen auf vorherige Version
- **Export/Import**: JSON-basierter Austausch

### 7.2 Audit-Dashboard

- **Execution Timeline**: Visualisierung der Pipeline-Durchläufe
- **Error Tracking**: Fehlerhafte Phasen mit Kontext
- **Token-Usage**: Kosten pro Phase/Template
- **Red-Flag-Statistiken**: Erkannte kritische Fälle

---

## 8. Sicherheitsaspekte

### 8.1 Prompt Injection Prevention

```typescript
// Eingabe-Sanitisierung vor Template-Rendering
function sanitizeForPrompt(input: string): string {
  return input
    .replace(/\{\{/g, '{ {')  // Template-Marker escapen
    .replace(/\}\}/g, '} }')
    .replace(/```/g, '` ` `') // Code-Blöcke escapen
    .slice(0, 10000);         // Längenlimit
}
```

### 8.2 Output-Validierung

```typescript
// Jede Phase hat ein erwartetes Output-Schema
const PHASE_OUTPUT_SCHEMAS: Record<number, z.ZodSchema> = {
  1: z.object({
    intent_type: z.enum(['information', 'acute', 'research']),
    urgency: z.enum(['low', 'medium', 'high', 'critical']),
    direct_answer_allowed: z.boolean(),
    reasoning: z.string().max(500),
    detected_red_flags: z.array(z.string())
  }),
  // ... weitere Phasen
};

// Validierung mit Fallback
function validatePhaseOutput(phase: number, output: unknown): ParsedOutput {
  const result = PHASE_OUTPUT_SCHEMAS[phase].safeParse(output);
  if (!result.success) {
    logValidationError(phase, output, result.error);
    return getDefaultOutput(phase);
  }
  return result.data;
}
```

---

## 9. Nächste Schritte

### Phase 1: Foundation (1-2 Wochen)
- [ ] Datenbank-Migrationen erstellen
- [ ] Basis-Edge-Function für Pipeline-Orchestrierung
- [ ] Prompt-Template CRUD API

### Phase 2: Core Pipeline (2-3 Wochen)
- [ ] Phasen 1-3 implementieren (Triage, Elicitation, Normalization)
- [ ] Integration mit bestehendem ai-anamnesis
- [ ] Audit-Logging

### Phase 3: RAG-Integration (1-2 Wochen)
- [ ] Phasen 4-5 (Categorization, Retrieval)
- [ ] Leitlinien-Kontext in Prompts

### Phase 4: Validation & Synthesis (1-2 Wochen)
- [ ] Phasen 6-7 (Validation, Synthesis)
- [ ] End-to-End Testing

### Phase 5: Admin-UI (2-3 Wochen)
- [ ] Prompt-Editor
- [ ] Audit-Dashboard
- [ ] A/B-Testing Framework

---

## 10. Offene Entscheidungen

1. **Streaming vs. Batch**: Soll die Pipeline streamen oder alle Phasen abwarten?
2. **Parallele Phasen**: Können manche Phasen parallel laufen (z.B. 4+5)?
3. **Caching**: Sollen häufige Kontext-Kombinationen gecached werden?
4. **User-Feedback-Loop**: Wie fließt Nutzer-Feedback in Prompt-Optimierung ein?
