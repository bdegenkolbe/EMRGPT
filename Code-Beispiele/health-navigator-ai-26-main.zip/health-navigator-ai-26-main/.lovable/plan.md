
# Intelligente Evidenz-Sidebar mit Leitlinien- und Europe PMC-Suche

## Ziel
Die Evidenz-Sidebar wird erweitert, um bei Patientenauswahl automatisch zwei parallele Suchquellen zu nutzen:
1. **Lokale Leitlinien** (via `guidelines-search` Edge Function) -- durchsucht selbst hochgeladene Dokumente mit semantischer Vektorsuche
2. **Europe PMC** (via `evidence-europepmc` Edge Function) -- durchsucht wissenschaftliche Literatur mit Metadaten-Enrichment (Unpaywall, CrossRef)

Die Ergebnisse werden in einem Tab-Interface ("Leitlinien" / "Literatur") gruppiert dargestellt.

## Funktionsweise

Die aktiven Diagnosen des Patienten (z.B. "Diabetes mellitus Typ 2", "Fatigue") liefern automatisch:
- **Suchbegriffe** (`code_display`) fuer Europe PMC
- **ICD-10-Codes** (`code`), **HPO-Codes** und **SNOMED-Codes** fuer die Leitlinien-Suche (Code-basiertes Pre-Filtering + semantische Suche)

Beide Suchen laufen parallel und die UI aktualisiert sich inkrementell.

## Aenderungen

### 1. `PatientEvidenceSidebar.tsx` -- Komplett ueberarbeiten

**Neues Layout:**
- Tabs-Interface mit zwei Reitern: "Leitlinien" und "Literatur"
- Header zeigt weiterhin aktive Diagnose-Badges
- Jeder Tab hat eigenen Ladezustand

**Leitlinien-Tab:**
- Ruft `guidelines-search` Edge Function auf mit:
  - `query`: Kombinierte Diagnosenamen als Freitext
  - `icd10_codes`: Extrahierte ICD-10-Codes der Conditions
  - `hpo_codes` / `snomed_codes`: Falls vorhanden
  - `match_count`: 10
- Zeigt gruppierte Ergebnisse: Leitlinien-Titel, darunter relevante Textabschnitte (Chunks) mit Similarity-Score und Seitennummer

**Literatur-Tab:**
- Ruft `evidence-europepmc` Edge Function auf (statt direktem API-Call) mit:
  - `action: search`, `query`: Diagnose-Kombination, `resultType: core`, `limit: 15`
- Zeigt Artikel-Cards wie bisher, aber mit zusaetzlichen Feldern: OA-Status, PDF-Link, Abstract-Preview

### 2. Keine neuen Edge Functions noetig
Beide bestehenden Edge Functions (`guidelines-search`, `evidence-europepmc`) werden direkt genutzt.

---

## Technische Details

### Suchlogik (im Frontend)
```text
Patient ausgewaehlt
  -> Aktive Conditions extrahieren (max 5)
  -> Parallel:
     [1] supabase.functions.invoke('guidelines-search', {
           query: "Diabetes mellitus Typ 2 Fatigue",
           icd10_codes: ["E11"],
           match_count: 10
         })
     [2] supabase.functions.invoke('evidence-europepmc', {
           action: "search",
           query: "(Diabetes mellitus Typ 2) OR (Fatigue) AND (HAS_FT:Y)",
           resultType: "core",
           limit: 15
         })
  -> Ergebnisse in jeweiligem Tab anzeigen
```

### UI-Struktur
- `Tabs` (Radix) mit "Leitlinien" (FileText-Icon) und "Literatur" (BookOpen-Icon)
- Leitlinien-Ergebnisse: Card pro Guideline mit Chunks als Collapsible-Abschnitte, Similarity als farbiger Fortschrittsbalken
- Literatur-Ergebnisse: Bestehende Article-Cards, erweitert um Abstract-Tooltip und PDF-Button bei OA-Artikeln

### Dateiaenderungen
| Datei | Aenderung |
|-------|-----------|
| `src/components/patients/PatientEvidenceSidebar.tsx` | Komplettes Rewrite mit Tabs, zwei Suchquellen, paralleler Ausfuehrung |
