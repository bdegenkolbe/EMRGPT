import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';
import type { Database } from '@/integrations/supabase/types';

type AppRole = Database['public']['Enums']['app_role'];
type ClinicalView = Database['public']['Enums']['clinical_view'];

interface UserWithDetails {
  id: string;
  email: string;
  display_name: string | null;
  role: AppRole;
  views: ClinicalView[];
  created_at: string;
}

interface CreateUserData {
  email: string;
  password: string;
  role: AppRole;
  views: ClinicalView[];
}

export function useUsers() {
  const { t } = useTranslation();
  const queryClient = useQueryClient();

  const { data: users, isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: async () => {
      // Get all profiles
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Get all roles
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('*');

      if (rolesError) throw rolesError;

      // Get all views
      const { data: views, error: viewsError } = await supabase
        .from('user_views')
        .select('*');

      if (viewsError) throw viewsError;

      // Combine data
      const usersWithDetails: UserWithDetails[] = profiles.map((profile) => {
        const userRole = roles.find((r) => r.user_id === profile.user_id);
        const userViews = views
          .filter((v) => v.user_id === profile.user_id)
          .map((v) => v.view);

        return {
          id: profile.user_id,
          email: profile.email,
          display_name: profile.display_name,
          role: userRole?.role || 'user',
          views: userViews,
          created_at: profile.created_at,
        };
      });

      return usersWithDetails;
    },
  });

  const updateUserRole = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: AppRole }) => {
      // Check if role exists
      const { data: existingRole } = await supabase
        .from('user_roles')
        .select('id')
        .eq('user_id', userId)
        .single();

      if (existingRole) {
        const { error } = await supabase
          .from('user_roles')
          .update({ role })
          .eq('user_id', userId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('user_roles')
          .insert({ user_id: userId, role });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast({
        title: t('common.success'),
        description: t('admin.users.roleUpdated', { defaultValue: 'Rolle aktualisiert' }),
      });
    },
    onError: () => {
      toast({
        title: t('common.error'),
        variant: 'destructive',
      });
    },
  });

  const updateUserViews = useMutation({
    mutationFn: async ({
      userId,
      views,
    }: {
      userId: string;
      views: ClinicalView[];
    }) => {
      // Delete existing views
      await supabase.from('user_views').delete().eq('user_id', userId);

      // Insert new views
      if (views.length > 0) {
        const { error } = await supabase.from('user_views').insert(
          views.map((view) => ({
            user_id: userId,
            view,
          }))
        );
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast({
        title: t('common.success'),
        description: t('admin.users.viewsUpdated', { defaultValue: 'Sichten aktualisiert' }),
      });
    },
    onError: () => {
      toast({
        title: t('common.error'),
        variant: 'destructive',
      });
    },
  });

  return {
    users,
    isLoading,
    updateUserRole,
    updateUserViews,
  };
}
