import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface ICD10Code {
  code: string;
  title: string;
  title_short: string | null;
  chapter: string | null;
  block: string | null;
  category: string | null;
  is_terminal: boolean | null;
  parent_code: string | null;
  year: number | null;
  exclusions: string[] | null;
  inclusions: string[] | null;
  notes: string | null;
}

export interface SyncStatus {
  last_sync: string | null;
  total_codes: number;
  year: number | null;
  is_syncing: boolean;
}

export interface SyncResult {
  success: boolean;
  result: {
    inserted: number;
    updated: number;
    errors: string[];
  };
  message: string;
}

export type DataSource = 'local' | 'api' | 'unknown';

export function useIcd10Gm() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [searchResults, setSearchResults] = useState<ICD10Code[]>([]);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  // ICD-10-GM is always local - no external API calls for lookups
  const lastDataSource: DataSource = 'local';

  // Search ICD-10-GM codes locally
  const searchCodes = useCallback(async (query: string, limit = 20): Promise<ICD10Code[]> => {
    if (!query || query.length < 2) {
      setSearchResults([]);
      return [];
    }

    setIsLoading(true);
    try {
      const searchTerm = query.trim().toUpperCase();
      
      // Search by code prefix or title
      const { data, error } = await supabase
        .from('icd10gm_codes')
        .select('*')
        .or(`code.ilike.${searchTerm}%,title.ilike.%${query}%`)
        .order('code')
        .limit(limit);

      if (error) throw error;

      setSearchResults(data || []);
      return data || [];
    } catch (error) {
      console.error('ICD-10-GM search error:', error);
      toast({
        title: 'Suchfehler',
        description: 'ICD-10-GM Suche fehlgeschlagen',
        variant: 'destructive',
      });
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  // Get code details
  const getCode = useCallback(async (code: string): Promise<ICD10Code | null> => {
    try {
      const { data, error } = await supabase
        .from('icd10gm_codes')
        .select('*')
        .eq('code', code)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('ICD-10-GM lookup error:', error);
      return null;
    }
  }, []);

  // Get child codes
  const getChildren = useCallback(async (parentCode: string): Promise<ICD10Code[]> => {
    try {
      const { data, error } = await supabase
        .from('icd10gm_codes')
        .select('*')
        .eq('parent_code', parentCode)
        .order('code');

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('ICD-10-GM children error:', error);
      return [];
    }
  }, []);

  // Map chapter IDs to code prefixes
  const chapterRanges: Record<string, string[]> = {
    'I': ['A', 'B'],
    'II': ['C', 'D0', 'D1', 'D2', 'D3', 'D4'],
    'III': ['D5', 'D6', 'D7', 'D8', 'D9'],
    'IV': ['E'],
    'V': ['F'],
    'VI': ['G'],
    'VII': ['H0', 'H1', 'H2', 'H3', 'H4', 'H5'],
    'VIII': ['H6', 'H7', 'H8', 'H9'],
    'IX': ['I'],
    'X': ['J'],
    'XI': ['K'],
    'XII': ['L'],
    'XIII': ['M'],
    'XIV': ['N'],
    'XV': ['O'],
    'XVI': ['P'],
    'XVII': ['Q'],
    'XVIII': ['R'],
    'XIX': ['S', 'T'],
    'XX': ['V', 'W', 'X', 'Y'],
    'XXI': ['Z'],
    'XXII': ['U'],
  };

  // Get codes by chapter - uses chapter field directly
  const getByChapter = useCallback(async (chapter: string): Promise<ICD10Code[]> => {
    try {
      // Query by chapter field
      const { data, error } = await supabase
        .from('icd10gm_codes')
        .select('*')
        .eq('chapter', chapter)
        .order('code');

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('ICD-10-GM chapter error:', error);
      return [];
    }
  }, []);

  // Get codes by code range (e.g., "A00-B99" for chapter I)
  // Returns top-level groups (blocks) for the chapter, whose parent_code is the chapter ID itself
  const getByCodeRange = useCallback(async (chapterId: string): Promise<ICD10Code[]> => {
    try {
      // Query for codes whose parent_code is the chapter ID (e.g., "I", "II", etc.)
      // These are the block-level groups like "A00-A09"
      const { data, error } = await supabase
        .from('icd10gm_codes')
        .select('*')
        .eq('parent_code', chapterId)
        .order('code')
        .limit(200);

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('ICD-10-GM code range error:', error);
      return [];
    }
  }, []);

  // Fetch sync status
  const fetchSyncStatus = useCallback(async (): Promise<SyncStatus | null> => {
    try {
      const { data, error } = await supabase.functions.invoke('icd10gm-sync', {
        body: { action: 'status' },
      });

      if (error) throw error;
      
      const status = data.status as SyncStatus;
      setSyncStatus(status);
      return status;
    } catch (error) {
      console.error('Sync status error:', error);
      return null;
    }
  }, []);

  // Trigger manual sync
  const triggerSync = useCallback(async (year?: number, force = false): Promise<SyncResult | null> => {
    setIsSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('icd10gm-sync', {
        body: { 
          action: 'sync',
          year: year || new Date().getFullYear(),
          force,
        },
      });

      if (error) throw error;

      const result = data as SyncResult;
      
      if (result.success) {
        toast({
          title: 'Synchronisation erfolgreich',
          description: result.message,
        });
      } else {
        const errors = result.result?.errors || [];
        const isAlreadySynced = errors.length > 0 && errors.every(e => e.toLowerCase().includes('already synced'));

        toast({
          title: isAlreadySynced ? 'Bereits synchronisiert' : 'Synchronisation mit Warnungen',
          description: isAlreadySynced
            ? 'Der ICD-10-GM Katalog ist bereits aktuell. (Zum Neuimport: Force-Sync ausführen.)'
            : errors.join(', '),
          variant: isAlreadySynced ? undefined : 'destructive',
        });
      }

      // Refresh status
      await fetchSyncStatus();
      
      return result;
    } catch (error) {
      console.error('Sync error:', error);
      toast({
        title: 'Synchronisation fehlgeschlagen',
        description: error.message || 'Unbekannter Fehler',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsSyncing(false);
    }
  }, [toast, fetchSyncStatus]);

  // Clear codes for a year
  const clearCodes = useCallback(async (year: number): Promise<boolean> => {
    try {
      const { data, error } = await supabase.functions.invoke('icd10gm-sync', {
        body: { action: 'clear', year },
      });

      if (error) throw error;

      toast({
        title: 'Codes gelöscht',
        description: `ICD-10-GM Codes für ${year} wurden gelöscht`,
      });

      await fetchSyncStatus();
      return true;
    } catch (error) {
      console.error('Clear error:', error);
      toast({
        title: 'Löschen fehlgeschlagen',
        description: error.message || 'Unbekannter Fehler',
        variant: 'destructive',
      });
      return false;
    }
  }, [toast, fetchSyncStatus]);

  return {
    // State
    isLoading,
    isSyncing,
    searchResults,
    syncStatus,
    lastDataSource,
    
    // Search & lookup
    searchCodes,
    getCode,
    getChildren,
    getByChapter,
    
    // Sync management
    fetchSyncStatus,
    triggerSync,
    clearCodes,
  };
}
