import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Json } from '@/integrations/supabase/types';

// Types
export interface PipelineDomain {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  is_active: boolean;
  classification_keywords: string[];
  created_at: string;
  updated_at: string;
}

export interface Pipeline {
  id: string;
  domain_id: string;
  slug: string;
  name: string;
  description: string | null;
  is_active: boolean;
  phase_order: string[];
  fallback_pipeline_id: string | null;
  created_at: string;
  updated_at: string;
  domain?: PipelineDomain;
}

export interface PromptTemplate {
  id: string;
  pipeline_id: string | null;
  domain_id: string | null;
  phase: string;
  name: string;
  description: string | null;
  system_prompt: string;
  user_prompt_template: string | null;
  parameter_schema: Json;
  model_config: {
    model: string;
    temperature: number;
    max_tokens: number;
  };
  version: number;
  is_active: boolean;
  parent_template_id: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  pipeline?: Pipeline;
  domain?: PipelineDomain;
}

// Domains
export function useDomains() {
  return useQuery({
    queryKey: ['pipeline-domains'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('pipeline_domains')
        .select('*')
        .order('slug');
      
      if (error) throw error;
      return data as PipelineDomain[];
    },
  });
}

export function useUpdateDomain() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<PipelineDomain> & { id: string }) => {
      const { data, error } = await supabase
        .from('pipeline_domains')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pipeline-domains'] });
    },
  });
}

// Pipelines
export function usePipelines(domainId?: string) {
  return useQuery({
    queryKey: ['pipelines', domainId],
    queryFn: async () => {
      let query = supabase
        .from('pipelines')
        .select('*, domain:pipeline_domains(*)');
      
      if (domainId) {
        query = query.eq('domain_id', domainId);
      }
      
      const { data, error } = await query.order('name');
      
      if (error) throw error;
      return data as Pipeline[];
    },
  });
}

export function useUpdatePipeline() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Pipeline> & { id: string }) => {
      const { data, error } = await supabase
        .from('pipelines')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pipelines'] });
    },
  });
}

export function useCreatePipeline() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (pipeline: Omit<Pipeline, 'id' | 'created_at' | 'updated_at' | 'domain'>) => {
      const { data, error } = await supabase
        .from('pipelines')
        .insert(pipeline)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pipelines'] });
    },
  });
}

// Prompt Templates
export function usePromptTemplates(pipelineId?: string, domainId?: string) {
  return useQuery({
    queryKey: ['prompt-templates', pipelineId, domainId],
    queryFn: async () => {
      let query = supabase
        .from('prompt_templates')
        .select('*, pipeline:pipelines(*), domain:pipeline_domains(*)');
      
      if (pipelineId) {
        query = query.eq('pipeline_id', pipelineId);
      }
      if (domainId) {
        query = query.eq('domain_id', domainId);
      }
      
      const { data, error } = await query.order('phase').order('version', { ascending: false });
      
      if (error) throw error;
      return data as PromptTemplate[];
    },
  });
}

export function usePromptTemplate(id: string) {
  return useQuery({
    queryKey: ['prompt-template', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('prompt_templates')
        .select('*, pipeline:pipelines(*), domain:pipeline_domains(*)')
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return data as PromptTemplate;
    },
    enabled: !!id,
  });
}

export function useCreateTemplate() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (template: Omit<PromptTemplate, 'id' | 'created_at' | 'updated_at' | 'pipeline' | 'domain'>) => {
      const insertData = {
        pipeline_id: template.pipeline_id,
        domain_id: template.domain_id,
        phase: template.phase,
        name: template.name,
        description: template.description,
        system_prompt: template.system_prompt,
        user_prompt_template: template.user_prompt_template,
        parameter_schema: template.parameter_schema,
        model_config: template.model_config as Json,
        version: template.version,
        is_active: template.is_active,
        parent_template_id: template.parent_template_id,
        created_by: template.created_by,
      };
      
      const { data, error } = await supabase
        .from('prompt_templates')
        .insert(insertData)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompt-templates'] });
    },
  });
}

export function useUpdateTemplate() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<PromptTemplate> & { id: string }) => {
      const { pipeline, domain, ...rest } = updates;
      const updateData: Record<string, unknown> = {};
      
      if (rest.pipeline_id !== undefined) updateData.pipeline_id = rest.pipeline_id;
      if (rest.domain_id !== undefined) updateData.domain_id = rest.domain_id;
      if (rest.phase !== undefined) updateData.phase = rest.phase;
      if (rest.name !== undefined) updateData.name = rest.name;
      if (rest.description !== undefined) updateData.description = rest.description;
      if (rest.system_prompt !== undefined) updateData.system_prompt = rest.system_prompt;
      if (rest.user_prompt_template !== undefined) updateData.user_prompt_template = rest.user_prompt_template;
      if (rest.parameter_schema !== undefined) updateData.parameter_schema = rest.parameter_schema;
      if (rest.model_config !== undefined) updateData.model_config = rest.model_config as Json;
      if (rest.version !== undefined) updateData.version = rest.version;
      if (rest.is_active !== undefined) updateData.is_active = rest.is_active;
      if (rest.parent_template_id !== undefined) updateData.parent_template_id = rest.parent_template_id;
      
      const { data, error } = await supabase
        .from('prompt_templates')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['prompt-templates'] });
      queryClient.invalidateQueries({ queryKey: ['prompt-template', variables.id] });
    },
  });
}

export function useDeleteTemplate() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('prompt_templates')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompt-templates'] });
    },
  });
}

// Template Versions
export function useTemplateVersions(parentTemplateId: string) {
  return useQuery({
    queryKey: ['template-versions', parentTemplateId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('prompt_templates')
        .select('*')
        .or(`id.eq.${parentTemplateId},parent_template_id.eq.${parentTemplateId}`)
        .order('version', { ascending: false });
      
      if (error) throw error;
      return data as PromptTemplate[];
    },
    enabled: !!parentTemplateId,
  });
}

// Create new version of template
export function useCreateTemplateVersion() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ parentId, updates }: { parentId: string; updates: Partial<PromptTemplate> }) => {
      // First get the current template to copy data
      const { data: current, error: fetchError } = await supabase
        .from('prompt_templates')
        .select('*')
        .eq('id', parentId)
        .single();
      
      if (fetchError) throw fetchError;
      
      // Get max version
      const { data: versions, error: versionError } = await supabase
        .from('prompt_templates')
        .select('version')
        .or(`id.eq.${parentId},parent_template_id.eq.${parentId}`)
        .order('version', { ascending: false })
        .limit(1);
      
      if (versionError) throw versionError;
      
      const newVersion = (versions?.[0]?.version || 1) + 1;
      
      // Create new version
      const insertData = {
        pipeline_id: current.pipeline_id,
        domain_id: current.domain_id,
        phase: current.phase,
        name: current.name,
        description: current.description,
        system_prompt: updates.system_prompt || current.system_prompt,
        user_prompt_template: updates.user_prompt_template || current.user_prompt_template,
        parameter_schema: updates.parameter_schema || current.parameter_schema,
        model_config: (updates.model_config || current.model_config) as Json,
        version: newVersion,
        is_active: true,
        parent_template_id: current.parent_template_id || parentId,
        created_by: current.created_by,
      };
      
      const { data, error } = await supabase
        .from('prompt_templates')
        .insert(insertData)
        .select()
        .single();
      
      if (error) throw error;
      
      // Deactivate old version
      await supabase
        .from('prompt_templates')
        .update({ is_active: false })
        .eq('id', parentId);
      
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompt-templates'] });
      queryClient.invalidateQueries({ queryKey: ['template-versions'] });
    },
  });
}
