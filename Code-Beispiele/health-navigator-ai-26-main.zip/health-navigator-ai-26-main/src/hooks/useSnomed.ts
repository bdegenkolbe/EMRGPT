import { useState, useCallback, useRef, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface SnomedConcept {
  conceptId: string;
  fsn: { term: string; lang: string };
  pt: { term: string; lang: string };
  active: boolean;
  definitionStatus: string;
  moduleId: string;
}

interface SearchResult {
  concepts: SnomedConcept[];
  total: number;
}

interface ValidationResult {
  valid: boolean;
  concept: SnomedConcept | null;
}

interface UseSnomedOptions {
  language?: string;
  debounceMs?: number;
  cacheEnabled?: boolean;
}

// Simple in-memory cache
const searchCache = new Map<string, { data: SearchResult; timestamp: number }>();
const conceptCache = new Map<string, { data: SnomedConcept; timestamp: number }>();
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

function getCacheKey(action: string, params: Record<string, string>): string {
  return `${action}:${JSON.stringify(params)}`;
}

export type DataSource = 'local' | 'api' | 'unknown';

export function useSnomed(options: UseSnomedOptions = {}) {
  const { language = 'de', debounceMs = 300, cacheEnabled = true } = options;
  
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SnomedConcept[]>([]);
  const [searchTotal, setSearchTotal] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [lastDataSource, setLastDataSource] = useState<DataSource>('unknown');
  
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  // Search with debouncing
  const searchConcepts = useCallback(
    async (query: string, limit: number = 20): Promise<SearchResult | null> => {
      // Cancel previous request
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      
      if (!query || query.length < 2) {
        setSearchResults([]);
        setSearchTotal(0);
        return null;
      }

      const cacheKey = getCacheKey('search', { q: query, limit: String(limit), lang: language });
      
      // Check cache
      if (cacheEnabled) {
        const cached = searchCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
          setSearchResults(cached.data.concepts);
          setSearchTotal(cached.data.total);
          return cached.data;
        }
      }

      return new Promise((resolve) => {
        // Clear previous timer
        if (debounceTimerRef.current) {
          clearTimeout(debounceTimerRef.current);
        }

        debounceTimerRef.current = setTimeout(async () => {
          setIsSearching(true);
          setError(null);
          abortControllerRef.current = new AbortController();

          try {
            const { data, error: fnError } = await supabase.functions.invoke('snomed-lookup', {
              body: null,
              headers: {
                'Content-Type': 'application/json',
              },
            });

            // Use query params approach
            const response = await fetch(
              `https://vzmpqhmletvylcggcjjl.supabase.co/functions/v1/snomed-lookup?action=search&q=${encodeURIComponent(query)}&limit=${limit}&lang=${language}`,
              {
                headers: {
                  Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token || ''}`,
                  apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6bXBxaG1sZXR2eWxjZ2djampsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAyMjQ0NjcsImV4cCI6MjA4NTgwMDQ2N30.ki0O8T9FCxlqI5Xzcy-ZmC-hrZXvxJ1TrnQbXS6wdMs',
                },
                signal: abortControllerRef.current?.signal,
              }
            );

            if (!response.ok) {
              throw new Error(`Search failed: ${response.status}`);
            }

            const result: SearchResult = await response.json();

            // Update cache
            if (cacheEnabled) {
              searchCache.set(cacheKey, { data: result, timestamp: Date.now() });
            }

            setSearchResults(result.concepts);
            setSearchTotal(result.total);
            setLastDataSource('api'); // SNOMED always from Snowstorm API
            resolve(result);
          } catch (err) {
            if (err instanceof Error && err.name === 'AbortError') {
              resolve(null);
              return;
            }
            const errorMsg = err instanceof Error ? err.message : 'Search failed';
            setError(errorMsg);
            console.error('[useSnomed] Search error:', errorMsg);
            resolve(null);
          } finally {
            setIsSearching(false);
          }
        }, debounceMs);
      });
    },
    [language, debounceMs, cacheEnabled]
  );

  // Get single concept
  const getConcept = useCallback(
    async (conceptId: string): Promise<SnomedConcept | null> => {
      const cacheKey = `concept:${conceptId}:${language}`;
      
      // Check cache
      if (cacheEnabled) {
        const cached = conceptCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
          return cached.data;
        }
      }

      try {
        const response = await fetch(
          `https://vzmpqhmletvylcggcjjl.supabase.co/functions/v1/snomed-lookup?action=lookup&id=${conceptId}&lang=${language}`,
          {
            headers: {
              Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token || ''}`,
              apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6bXBxaG1sZXR2eWxjZ2djampsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAyMjQ0NjcsImV4cCI6MjA4NTgwMDQ2N30.ki0O8T9FCxlqI5Xzcy-ZmC-hrZXvxJ1TrnQbXS6wdMs',
            },
          }
        );

        if (!response.ok) {
          return null;
        }

        const data = await response.json();
        const concept = data.concept as SnomedConcept;

        // Update cache
        if (cacheEnabled && concept) {
          conceptCache.set(cacheKey, { data: concept, timestamp: Date.now() });
        }

        return concept;
      } catch (err) {
        console.error('[useSnomed] Lookup error:', err);
        return null;
      }
    },
    [language, cacheEnabled]
  );

  // Validate SNOMED code
  const validateCode = useCallback(
    async (sctid: string): Promise<ValidationResult> => {
      try {
        const response = await fetch(
          `https://vzmpqhmletvylcggcjjl.supabase.co/functions/v1/snomed-lookup?action=validate&code=${sctid}&lang=${language}`,
          {
            headers: {
              Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token || ''}`,
              apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6bXBxaG1sZXR2eWxjZ2djampsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAyMjQ0NjcsImV4cCI6MjA4NTgwMDQ2N30.ki0O8T9FCxlqI5Xzcy-ZmC-hrZXvxJ1TrnQbXS6wdMs',
            },
          }
        );

        if (!response.ok) {
          return { valid: false, concept: null };
        }

        return await response.json();
      } catch (err) {
        console.error('[useSnomed] Validation error:', err);
        return { valid: false, concept: null };
      }
    },
    [language]
  );

  // Execute ECL query
  const executeECL = useCallback(
    async (expression: string, limit: number = 50): Promise<SearchResult | null> => {
      try {
        const response = await fetch(
          `https://vzmpqhmletvylcggcjjl.supabase.co/functions/v1/snomed-lookup?action=ecl&expression=${encodeURIComponent(expression)}&limit=${limit}&lang=${language}`,
          {
            headers: {
              Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token || ''}`,
              apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6bXBxaG1sZXR2eWxjZ2djampsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAyMjQ0NjcsImV4cCI6MjA4NTgwMDQ2N30.ki0O8T9FCxlqI5Xzcy-ZmC-hrZXvxJ1TrnQbXS6wdMs',
            },
          }
        );

        if (!response.ok) {
          return null;
        }

        return await response.json();
      } catch (err) {
        console.error('[useSnomed] ECL error:', err);
        return null;
      }
    },
    [language]
  );

  // Clear cache
  const clearCache = useCallback(() => {
    searchCache.clear();
    conceptCache.clear();
  }, []);

  // Clear search results
  const clearSearch = useCallback(() => {
    setSearchResults([]);
    setSearchTotal(0);
    setError(null);
  }, []);

  return {
    // Search
    searchConcepts,
    isSearching,
    searchResults,
    searchTotal,
    error,
    lastDataSource,
    clearSearch,
    
    // Single concept
    getConcept,
    
    // Validation
    validateCode,
    
    // ECL
    executeECL,
    
    // Cache
    clearCache,
  };
}
