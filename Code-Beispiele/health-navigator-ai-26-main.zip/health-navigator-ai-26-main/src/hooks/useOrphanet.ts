import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface OrphanetConcept {
  orphaCode: string;
  name: string;
  nameEn?: string;
  definition?: string;
  classification?: string;
  synonyms?: string[];
  prevalence?: string;
  inheritance?: string[];
  ageOfOnset?: string[];
  orphaUrl?: string;
  icd10Codes?: string[];
  omimCodes?: string[];
  hpoCodes?: string[];
  isTerminal?: boolean;
  labels?: Record<string, string>;
}

export interface OrphanetTranslation {
  orpha_code: string;
  name_en: string;
  name_de: string;
  explanation_de?: string;
  source: 'official' | 'ai_translated';
  confidence: number;
}

interface UseOrphanetOptions {
  language?: string;
}

export function useOrphanet(options: UseOrphanetOptions = {}) {
  const { language = 'de' } = options;
  
  const [searchResults, setSearchResults] = useState<OrphanetConcept[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchConcepts = useCallback(async (query: string, limit: number = 20) => {
    if (!query.trim()) {
      setSearchResults([]);
      return [];
    }

    setIsSearching(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('orphanet-lookup', {
        body: {
          action: 'search',
          q: query,
          lang: language,
          limit,
        },
      });

      if (fnError) throw fnError;

      const results = Array.isArray(data) ? data : [];
      setSearchResults(results);
      return results;
    } catch (err) {
      console.error('Orphanet search error:', err);
      setError('Suche fehlgeschlagen');
      setSearchResults([]);
      return [];
    } finally {
      setIsSearching(false);
    }
  }, [language]);

  const getConcept = useCallback(async (orphaCode: string): Promise<OrphanetConcept | null> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('orphanet-lookup', {
        body: {
          action: 'details',
          orphaCode,
          lang: language,
        },
      });

      if (fnError) throw fnError;
      return data;
    } catch (err) {
      console.error('Orphanet get concept error:', err);
      return null;
    }
  }, [language]);

  const getChildren = useCallback(async (parentCode: string): Promise<OrphanetConcept[]> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('orphanet-lookup', {
        body: {
          action: 'children',
          orphaCode: parentCode,
          lang: language,
        },
      });

      if (fnError) throw fnError;
      return data?.children || [];
    } catch (err) {
      console.error('Orphanet get children error:', err);
      return [];
    }
  }, [language]);

  const getClassifications = useCallback(async (): Promise<OrphanetConcept[]> => {
    try {
      // First: Try to load root classifications from local database
      const { data: localCodes, error: dbError } = await supabase
        .from('orphanet_codes')
        .select('*')
        .is('parent_code', null)
        .order('orpha_code');
      
      if (!dbError && localCodes && localCodes.length > 0) {
        console.log(`[Orphanet] Loaded ${localCodes.length} root classifications from database`);
        
        return localCodes.map(code => {
          const labels = code.labels as Record<string, string> | null;
          
          return {
            orphaCode: code.orpha_code,
            name: labels?.de || code.name,
            nameEn: code.name,
            definition: code.definition || undefined,
            classification: code.classification || 'Disorder',
            prevalence: code.prevalence || undefined,
            inheritance: code.inheritance || undefined,
            ageOfOnset: code.age_of_onset || undefined,
            orphaUrl: code.orpha_url || undefined,
            icd10Codes: code.icd10_codes || undefined,
            omimCodes: code.omim_codes || undefined,
            hpoCodes: code.hpo_codes || undefined,
            isTerminal: code.is_terminal ?? false,
            labels: code.labels as Record<string, string> | undefined,
          };
        });
      }
      
      // Fallback: Load from API
      console.log(`[Orphanet] No root classifications in DB, fetching from API...`);
      
      const { data, error: fnError } = await supabase.functions.invoke('orphanet-lookup', {
        body: {
          action: 'classifications',
          lang: language,
        },
      });

      if (fnError) throw fnError;
      return data?.classifications || [];
    } catch (err) {
      console.error('Orphanet get classifications error:', err);
      return [];
    }
  }, [language]);

  const translateTerms = useCallback(async (
    terms: { orphaCode: string; name: string; definition?: string }[]
  ): Promise<Map<string, OrphanetTranslation>> => {
    const resultMap = new Map<string, OrphanetTranslation>();
    if (terms.length === 0) return resultMap;

    try {
      const { data, error: fnError } = await supabase.functions.invoke('orphanet-lookup', {
        body: {
          action: 'translate',
          terms,
        },
      });

      if (fnError) throw fnError;

      const translations = data?.translations || [];
      for (const t of translations) {
        resultMap.set(t.orpha_code, t);
      }
    } catch (err) {
      console.error('Orphanet translation error:', err);
    }

    return resultMap;
  }, []);

  const clearSearch = useCallback(() => {
    setSearchResults([]);
    setError(null);
  }, []);

  return {
    searchConcepts,
    getConcept,
    getChildren,
    getClassifications,
    translateTerms,
    clearSearch,
    searchResults,
    isSearching,
    error,
  };
}
