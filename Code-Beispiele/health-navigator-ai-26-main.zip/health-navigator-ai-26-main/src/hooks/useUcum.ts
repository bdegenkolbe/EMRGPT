import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface UcumValidationResult {
  valid: boolean;
  unit?: string;
  ucumCode?: string;
  message?: string;
}

export interface UcumConversionResult {
  success: boolean;
  fromValue?: number;
  fromUnit?: string;
  toValue?: number;
  toUnit?: string;
  message?: string;
}

export interface UcumSuggestion {
  unit: string;
  display: string;
  category: string;
}

interface UseUcumOptions {
  debounceMs?: number;
}

// Simple in-memory cache
const validationCache = new Map<string, { result: UcumValidationResult; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

export function useUcum(options: UseUcumOptions = {}) {
  const { debounceMs = 300 } = options;
  
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<UcumValidationResult | null>(null);
  const [suggestions, setSuggestions] = useState<UcumSuggestion[]>([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const debounceRef = useRef<NodeJS.Timeout | null>(null);
  const suggestDebounceRef = useRef<NodeJS.Timeout | null>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
      if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    };
  }, []);

  const validateUnit = useCallback(async (unit: string): Promise<UcumValidationResult> => {
    if (!unit.trim()) {
      const result = { valid: false, message: 'Keine Einheit angegeben' };
      setValidationResult(result);
      return result;
    }

    // Check cache first
    const cacheKey = unit.trim().toLowerCase();
    const cached = validationCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      setValidationResult(cached.result);
      return cached.result;
    }

    setIsValidating(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('ucum-validate', {
        body: { action: 'validate', unit: unit.trim() },
      });

      if (fnError) throw fnError;

      const result: UcumValidationResult = data;
      
      // Cache the result
      validationCache.set(cacheKey, { result, timestamp: Date.now() });
      
      setValidationResult(result);
      return result;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Validierungsfehler';
      setError(errorMsg);
      const result = { valid: false, message: errorMsg };
      setValidationResult(result);
      return result;
    } finally {
      setIsValidating(false);
    }
  }, []);

  const validateUnitDebounced = useCallback((unit: string) => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    debounceRef.current = setTimeout(() => {
      validateUnit(unit);
    }, debounceMs);
  }, [validateUnit, debounceMs]);

  const convertUnits = useCallback(async (
    value: number,
    fromUnit: string,
    toUnit: string
  ): Promise<UcumConversionResult> => {
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('ucum-validate', {
        body: { action: 'convert', value, fromUnit, toUnit },
      });

      if (fnError) throw fnError;

      return data as UcumConversionResult;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Konvertierungsfehler';
      setError(errorMsg);
      return { success: false, message: errorMsg };
    }
  }, []);

  const getSuggestions = useCallback(async (query?: string): Promise<UcumSuggestion[]> => {
    setIsLoadingSuggestions(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('ucum-validate', {
        body: { action: 'suggest', query: query || '' },
      });

      if (fnError) throw fnError;

      const results = data.suggestions || [];
      setSuggestions(results);
      return results;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Fehler beim Laden der Vorschläge';
      setError(errorMsg);
      setSuggestions([]);
      return [];
    } finally {
      setIsLoadingSuggestions(false);
    }
  }, []);

  const getSuggestionsDebounced = useCallback((query: string) => {
    if (suggestDebounceRef.current) {
      clearTimeout(suggestDebounceRef.current);
    }

    suggestDebounceRef.current = setTimeout(() => {
      getSuggestions(query);
    }, debounceMs);
  }, [getSuggestions, debounceMs]);

  const getBaseUnits = useCallback(async (unit: string): Promise<string | null> => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('ucum-validate', {
        body: { action: 'base', unit },
      });

      if (fnError) throw fnError;

      return data.baseUnits || null;
    } catch (err) {
      console.error('Base units error:', err);
      return null;
    }
  }, []);

  const clearValidation = useCallback(() => {
    setValidationResult(null);
    setError(null);
  }, []);

  return {
    // Validation
    validateUnit,
    validateUnitDebounced,
    isValidating,
    validationResult,
    
    // Conversion
    convertUnits,
    
    // Suggestions
    getSuggestions,
    getSuggestionsDebounced,
    suggestions,
    isLoadingSuggestions,
    
    // Utilities
    getBaseUnits,
    clearValidation,
    error,
  };
}
