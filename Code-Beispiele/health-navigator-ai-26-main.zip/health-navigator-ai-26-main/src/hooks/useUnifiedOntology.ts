import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

/**
 * Unified interface for all ontology codes
 * Following pattern: xxx_codes with JSONB labels, definitions, explanations
 */
export interface OntologyCode {
  code: string;
  system: 'HPO' | 'SNOMED' | 'ICD10GM' | 'ORPHANET';
  label: string;
  labelEn?: string;
  definition?: string;
  isTerminal?: boolean;
  parentCodes?: string[];
  source?: string;
}

export interface OntologyAnalysis {
  code: string;
  system: 'HPO' | 'SNOMED' | 'ICD10GM' | 'ORPHANET';
  content: {
    explanation?: string;
    symptoms?: string[];
    diagnosis?: string;
    therapy?: string;
    notes?: string;
  };
  mappings: {
    hpo: Array<{ code: string; label: string; confidence: number }>;
    snomed: Array<{ code: string; label: string; confidence: number }>;
    icd10: Array<{ code: string; label: string; confidence: number }>;
    orphanet?: Array<{ code: string; label: string; confidence: number }>;
  };
  generatedAt?: string;
  sourceLanguage: string;
}

export interface OntologyTranslation {
  code: string;
  system: 'HPO' | 'SNOMED' | 'ICD10GM' | 'ORPHANET';
  labelDe: string;
  labelEn: string;
  explanationDe?: string;
  explanationEn?: string;
  source: 'official' | 'ai_translated';
  confidence: number;
}

/**
 * Check if a code exists in the local database
 */
export async function checkCodeExists(
  system: OntologyCode['system'],
  code: string
): Promise<boolean> {
  const tableMap = {
    HPO: { table: 'hpo_codes', column: 'hpo_code' },
    SNOMED: { table: 'snomed_codes', column: 'sctid' },
    ICD10GM: { table: 'icd10gm_codes', column: 'code' },
    ORPHANET: { table: 'orphanet_codes', column: 'orpha_code' },
  };

  const { table, column } = tableMap[system];
  
  const { data, error } = await supabase
    .from(table as any)
    .select('*')
    .eq(column, code)
    .maybeSingle();

  return !error && data !== null;
}

/**
 * Get analysis for a code, checking cache first
 */
export async function getAnalysis(
  system: OntologyCode['system'],
  code: string
): Promise<OntologyAnalysis | null> {
  let data: Record<string, unknown> | null = null;
  
  if (system === 'HPO') {
    const { data: result } = await supabase
      .from('hpo_analyses')
      .select('*')
      .eq('hpo_code', code)
      .maybeSingle();
    data = result;
  } else if (system === 'SNOMED') {
    const { data: result } = await supabase
      .from('snomed_analyses')
      .select('*')
      .eq('sctid', code)
      .maybeSingle();
    data = result;
  } else if (system === 'ICD10GM') {
    const { data: result } = await supabase
      .from('icd10gm_analyses')
      .select('*')
      .eq('icd_code', code)
      .maybeSingle();
    data = result;
  } else if (system === 'ORPHANET') {
    const { data: result } = await supabase
      .from('orphanet_analyses')
      .select('*')
      .eq('orpha_code', code)
      .maybeSingle();
    data = result;
  }

  if (!data) return null;

  return {
    code,
    system,
    content: (data.content as OntologyAnalysis['content']) || {},
    mappings: {
      hpo: (data.hpo_mappings as OntologyAnalysis['mappings']['hpo']) || [],
      snomed: (data.snomed_mappings as OntologyAnalysis['mappings']['snomed']) || [],
      icd10: (data.icd10_mappings as OntologyAnalysis['mappings']['icd10']) || [],
      orphanet: [],
    },
    generatedAt: data.generated_at as string | undefined,
    sourceLanguage: (data.source_language as string) || 'de',
  };
}

/**
 * Get translation for a code from JSONB labels in main tables
 */
export async function getTranslation(
  system: OntologyCode['system'],
  code: string
): Promise<OntologyTranslation | null> {
  if (system === 'HPO') {
    const { data } = await supabase
      .from('hpo_codes')
      .select('hpo_code, label, labels, definitions, explanations')
      .eq('hpo_code', code)
      .maybeSingle();
    
    if (data) {
      const labels = data.labels as Record<string, unknown> | null;
      const definitions = data.definitions as Record<string, string> | null;
      const explanations = data.explanations as Record<string, string> | null;
      return {
        code,
        system,
        labelDe: (labels?.de as string) || data.label,
        labelEn: (labels?.en as string) || data.label,
        explanationDe: definitions?.de || explanations?.de,
        explanationEn: definitions?.en || explanations?.en,
        source: labels?._source === 'ai_translated' ? 'ai_translated' : 'official',
        confidence: 1.0,
      };
    }
  } else if (system === 'SNOMED') {
    const { data } = await supabase
      .from('snomed_codes')
      .select('sctid, fsn, pt, labels, definitions, explanations')
      .eq('sctid', code)
      .maybeSingle();
    
    if (data) {
      const labels = data.labels as Record<string, string> | null;
      const definitions = data.definitions as Record<string, string> | null;
      const explanations = data.explanations as Record<string, string> | null;
      return {
        code,
        system,
        labelDe: labels?.de || data.pt,
        labelEn: labels?.en || data.pt,
        explanationDe: definitions?.de || explanations?.de,
        explanationEn: definitions?.en || explanations?.en,
        source: 'official',
        confidence: 1.0,
      };
    }
  } else if (system === 'ORPHANET') {
    const { data } = await supabase
      .from('orphanet_codes')
      .select('orpha_code, name, labels, definitions, explanations')
      .eq('orpha_code', code)
      .maybeSingle();
    
    if (data) {
      const labels = data.labels as Record<string, string> | null;
      const definitions = data.definitions as Record<string, string> | null;
      const explanations = data.explanations as Record<string, string> | null;
      return {
        code,
        system,
        labelDe: labels?.de || data.name,
        labelEn: labels?.en || data.name,
        explanationDe: definitions?.de || explanations?.de,
        explanationEn: definitions?.en || explanations?.en,
        source: 'official',
        confidence: 1.0,
      };
    }
  } else if (system === 'ICD10GM') {
    const { data } = await supabase
      .from('icd10gm_codes')
      .select('code, title, labels, definitions, explanations')
      .eq('code', code)
      .maybeSingle();
    
    if (data) {
      const labels = data.labels as Record<string, string> | null;
      const definitions = data.definitions as Record<string, string> | null;
      const explanations = data.explanations as Record<string, string> | null;
      return {
        code,
        system,
        labelDe: labels?.de || data.title,
        labelEn: labels?.en || data.title,
        explanationDe: definitions?.de || explanations?.de,
        explanationEn: definitions?.en || explanations?.en,
        source: 'official',
        confidence: 1.0,
      };
    }
  }

  return null;
}

/**
 * Hook for unified ontology operations
 */
export function useUnifiedOntology() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCode = useCallback(async (
    system: OntologyCode['system'],
    code: string,
    forceRefresh = false
  ): Promise<OntologyCode | null> => {
    setIsLoading(true);
    setError(null);

    try {
      // For forceRefresh, call the API directly
      if (forceRefresh) {
        const edgeFunctionMap: Record<OntologyCode['system'], string> = {
          HPO: 'hpo-lookup',
          SNOMED: 'snomed-lookup',
          ICD10GM: 'icd10gm-sync',
          ORPHANET: 'orphanet-lookup',
        };

        const { data, error: fnError } = await supabase.functions.invoke(
          edgeFunctionMap[system],
          {
            body: {
              action: system === 'ICD10GM' ? 'sync' : 'validate',
              code,
            },
          }
        );

        if (fnError) throw fnError;
        return data;
      }

      // Check local DB first using JSONB labels
      if (system === 'HPO') {
        const { data } = await supabase
          .from('hpo_codes')
          .select('hpo_code, label, labels, definitions, explanations, is_terminal, parent_codes, source')
          .eq('hpo_code', code)
          .maybeSingle();
        if (data) {
          const labels = data.labels as Record<string, string> | null;
          return {
            code,
            system,
            label: labels?.de || data.label || '',
            labelEn: labels?.en || data.label || '',
            isTerminal: data.is_terminal || false,
            parentCodes: data.parent_codes || [],
            source: data.source || 'local_db',
          };
        }
      } else if (system === 'SNOMED') {
        const { data } = await supabase
          .from('snomed_codes')
          .select('sctid, fsn, pt, labels, definitions, explanations, is_terminal, parent_codes, source')
          .eq('sctid', code)
          .maybeSingle();
        if (data) {
          const labels = data.labels as Record<string, string> | null;
          return {
            code,
            system,
            label: labels?.de || data.pt || '',
            labelEn: labels?.en || data.pt || '',
            isTerminal: data.is_terminal || false,
            parentCodes: data.parent_codes || [],
            source: data.source || 'local_db',
          };
        }
      } else if (system === 'ICD10GM') {
        const { data } = await supabase
          .from('icd10gm_codes')
          .select('code, title, labels, definitions, explanations, is_terminal, parent_code, notes')
          .eq('code', code)
          .maybeSingle();
        if (data) {
          const labels = data.labels as Record<string, string> | null;
          return {
            code,
            system,
            label: labels?.de || data.title || '',
            labelEn: labels?.en || data.title || '',
            definition: data.notes || undefined,
            isTerminal: data.is_terminal || false,
            parentCodes: data.parent_code ? [data.parent_code] : [],
            source: 'local_db',
          };
        }
      } else if (system === 'ORPHANET') {
        const { data } = await supabase
          .from('orphanet_codes')
          .select('orpha_code, name, labels, definitions, explanations, is_terminal, parent_code, definition, source')
          .eq('orpha_code', code)
          .maybeSingle();
        if (data) {
          const labels = data.labels as Record<string, string> | null;
          return {
            code,
            system,
            label: labels?.de || data.name || '',
            labelEn: labels?.en || data.name || '',
            definition: data.definition || undefined,
            isTerminal: data.is_terminal || false,
            parentCodes: data.parent_code ? [data.parent_code] : [],
            source: data.source || 'local_db',
          };
        }
      }

      return null;
    } catch (err) {
      console.error('Fetch code error:', err);
      setError('Code nicht gefunden');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchAnalysis = useCallback(async (
    system: OntologyCode['system'],
    code: string,
    forceGenerate = false
  ): Promise<OntologyAnalysis | null> => {
    setIsLoading(true);
    setError(null);

    try {
      // Check existing analysis first
      if (!forceGenerate) {
        const existing = await getAnalysis(system, code);
        if (existing) return existing;
      }

      // Call edge function to generate
      const edgeFunctionMap = {
        HPO: 'hpo-analyze',
        SNOMED: 'snomed-analyze',
        ICD10GM: 'icd10-analyze',
        ORPHANET: 'orphanet-analyze',
      };

      const { data, error: fnError } = await supabase.functions.invoke(
        edgeFunctionMap[system],
        {
          body: {
            action: forceGenerate ? 'generate' : 'get',
            code,
            [system === 'HPO' ? 'hpoCode' : system === 'SNOMED' ? 'sctid' : system === 'ICD10GM' ? 'icdCode' : 'orphaCode']: code,
            forceRegenerate: forceGenerate,
          },
        }
      );

      if (fnError) throw fnError;

      if (data?.analysis) {
        return {
          code,
          system,
          content: data.analysis.content || {},
          mappings: {
            hpo: data.analysis.hpo_mappings || [],
            snomed: data.analysis.snomed_mappings || [],
            icd10: data.analysis.icd10_mappings || [],
          },
          generatedAt: data.analysis.generated_at,
          sourceLanguage: data.analysis.source_language || 'de',
        };
      }

      return null;
    } catch (err) {
      console.error('Fetch analysis error:', err);
      setError('Analyse nicht gefunden');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchTranslation = useCallback(async (
    system: OntologyCode['system'],
    code: string
  ): Promise<OntologyTranslation | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const translation = await getTranslation(system, code);
      return translation;
    } catch (err) {
      console.error('Fetch translation error:', err);
      setError('Übersetzung nicht gefunden');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    fetchCode,
    fetchAnalysis,
    fetchTranslation,
    isLoading,
    error,
  };
}

export default useUnifiedOntology;
