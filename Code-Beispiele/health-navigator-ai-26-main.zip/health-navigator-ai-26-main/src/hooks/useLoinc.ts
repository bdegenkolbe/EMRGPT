import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface LoincCode {
  loinc_num: string;
  component: string;
  long_common_name: string | null;
  short_name: string | null;
  class: string | null;
  example_ucum_units: string | null;
  property: string | null;
  time_aspect: string | null;
  system: string | null;
  scale_type: string | null;
}

interface UseLoincOptions {
  debounceMs?: number;
}

// Simple in-memory cache
const searchCache = new Map<string, { codes: LoincCode[]; total: number; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

export type DataSource = 'local' | 'api' | 'unknown';

export function useLoinc(options: UseLoincOptions = {}) {
  const { debounceMs = 300 } = options;
  
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<LoincCode[]>([]);
  const [totalResults, setTotalResults] = useState(0);
  const [classes, setClasses] = useState<string[]>([]);
  const [isLoadingClasses, setIsLoadingClasses] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // LOINC is always local - no external API
  const lastDataSource: DataSource = 'local';
  
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  const searchLoinc = useCallback(async (
    query: string,
    classFilter?: string,
    limit = 20
  ): Promise<{ codes: LoincCode[]; total: number }> => {
    if (!query || query.trim().length < 2) {
      setSearchResults([]);
      setTotalResults(0);
      return { codes: [], total: 0 };
    }

    // Check cache
    const cacheKey = `${query.trim().toLowerCase()}:${classFilter || ''}:${limit}`;
    const cached = searchCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      setSearchResults(cached.codes);
      setTotalResults(cached.total);
      return { codes: cached.codes, total: cached.total };
    }

    setIsSearching(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('loinc-lookup', {
        body: { action: 'search', query: query.trim(), classFilter, limit },
      });

      if (fnError) throw fnError;

      const result = {
        codes: data.codes as LoincCode[],
        total: data.total as number,
      };

      // Cache result
      searchCache.set(cacheKey, { ...result, timestamp: Date.now() });

      setSearchResults(result.codes);
      setTotalResults(result.total);
      return result;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Suchfehler';
      setError(errorMsg);
      setSearchResults([]);
      setTotalResults(0);
      return { codes: [], total: 0 };
    } finally {
      setIsSearching(false);
    }
  }, []);

  const searchLoincDebounced = useCallback((
    query: string,
    classFilter?: string,
    limit = 20
  ) => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    debounceRef.current = setTimeout(() => {
      searchLoinc(query, classFilter, limit);
    }, debounceMs);
  }, [searchLoinc, debounceMs]);

  const lookupLoinc = useCallback(async (loincNum: string): Promise<LoincCode | null> => {
    if (!loincNum) return null;

    try {
      const { data, error: fnError } = await supabase.functions.invoke('loinc-lookup', {
        body: { action: 'lookup', loincNum },
      });

      if (fnError) throw fnError;

      return data.found ? (data.code as LoincCode) : null;
    } catch (err) {
      console.error('LOINC lookup error:', err);
      return null;
    }
  }, []);

  const validateLoinc = useCallback(async (loincNum: string): Promise<{
    valid: boolean;
    component?: string;
    name?: string;
  }> => {
    if (!loincNum) return { valid: false };

    try {
      const { data, error: fnError } = await supabase.functions.invoke('loinc-lookup', {
        body: { action: 'validate', loincNum },
      });

      if (fnError) throw fnError;

      return {
        valid: data.valid,
        component: data.component,
        name: data.name,
      };
    } catch (err) {
      console.error('LOINC validation error:', err);
      return { valid: false };
    }
  }, []);

  const loadClasses = useCallback(async () => {
    if (classes.length > 0) return classes;

    setIsLoadingClasses(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('loinc-lookup', {
        body: { action: 'classes' },
      });

      if (fnError) throw fnError;

      const classNames = data.classes as string[];
      setClasses(classNames);
      return classNames;
    } catch (err) {
      console.error('Load classes error:', err);
      return [];
    } finally {
      setIsLoadingClasses(false);
    }
  }, [classes]);

  const clearSearch = useCallback(() => {
    setSearchResults([]);
    setTotalResults(0);
    setError(null);
  }, []);

  return {
    // Search
    searchLoinc,
    searchLoincDebounced,
    isSearching,
    searchResults,
    totalResults,
    lastDataSource,
    
    // Lookup & Validate
    lookupLoinc,
    validateLoinc,
    
    // Classes
    loadClasses,
    classes,
    isLoadingClasses,
    
    // Utilities
    clearSearch,
    error,
  };
}
