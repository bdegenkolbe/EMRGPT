import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type SyncSource = 'hpo' | 'snomed' | 'icd11' | 'orphanet';
export type SyncStatus = 'pending' | 'running' | 'completed' | 'error' | 'paused';

export interface SyncProgress {
  source_name: SyncSource;
  status: SyncStatus;
  total_synced: number;
  total_available: number | null;
  last_cursor: string | null;
  error_message: string | null;
  started_at: string | null;
  completed_at: string | null;
  remote_version?: string | null;
  local_version?: string | null;
}

export interface VersionCheckResult {
  remoteVersion: string | null;
  localVersion: string | null;
  needsSync: boolean;
  message: string;
}

interface UseBulkSyncOptions {
  onComplete?: (source: SyncSource) => void;
  onError?: (source: SyncSource, error: string) => void;
  onProgress?: (source: SyncSource, synced: number, total: number | null) => void;
}

export function useBulkSync(options: UseBulkSyncOptions = {}) {
  const [syncProgress, setSyncProgress] = useState<Map<SyncSource, SyncProgress>>(new Map());
  const [isRunning, setIsRunning] = useState<Map<SyncSource, boolean>>(new Map());

  // Load current sync status from database
  const loadSyncStatus = useCallback(async (source?: SyncSource) => {
    try {
      let query = supabase.from('sync_status').select('*');
      
      if (source) {
        query = query.eq('source_name', source);
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('[useBulkSync] Error loading sync status:', error);
        return;
      }
      
      if (data) {
        setSyncProgress(prev => {
          const newMap = new Map(prev);
          for (const row of data) {
            newMap.set(row.source_name as SyncSource, {
              source_name: row.source_name as SyncSource,
              status: row.status as SyncStatus,
              total_synced: row.total_synced || 0,
              total_available: row.total_available,
              last_cursor: row.last_cursor,
              error_message: row.error_message,
              started_at: row.started_at,
              completed_at: row.completed_at,
              remote_version: row.remote_version,
              local_version: row.local_version,
            });
          }
          return newMap;
        });
      }
    } catch (err) {
      console.error('[useBulkSync] Exception loading sync status:', err);
    }
  }, []);

  // Initialize sync status on mount
  useEffect(() => {
    loadSyncStatus();
  }, [loadSyncStatus]);

  // Run a single sync page
  const runSyncPage = useCallback(
    async (
      source: SyncSource,
    ): Promise<{ hasMore: boolean; synced: number; paused?: boolean; error?: string }> => {
      const functionName = `${source}-sync`;

      const { data, error } = await supabase.functions.invoke(functionName, {
        body: { action: 'sync_page' },
      });

      if (error) {
        throw new Error(error.message || 'Sync page failed');
      }

      return {
        hasMore: data?.hasMore ?? false,
        synced: data?.syncedCount ?? 0,
        paused: data?.paused ?? false,
        error: data?.error ?? undefined,
      };
    },
    [],
  );

  // Start bulk sync for a source
  const startSync = useCallback(
    async (source: SyncSource) => {
      if (isRunning.get(source)) {
        console.log(`[useBulkSync] Sync already running for ${source}`);
        return;
      }

      setIsRunning(prev => new Map(prev).set(source, true));

      try {
        // Initialize or reset sync status
        const { error: initError } = await supabase.functions.invoke(`${source}-sync`, {
          body: { action: 'init' },
        });

        if (initError) {
          throw new Error(initError.message || 'Failed to initialize sync');
        }

        // Reload status after init
        await loadSyncStatus(source);

        // Run pages until complete
        let hasMore = true;
        let totalSynced = 0;

        while (hasMore) {
          const result = await runSyncPage(source);

          if (result.paused) {
            // Edge function intentionally paused (e.g., provider outage/rate limit)
            setSyncProgress(prev => {
              const newMap = new Map(prev);
              const current = newMap.get(source);
              if (current) {
                newMap.set(source, {
                  ...current,
                  status: 'paused',
                  error_message: result.error || current.error_message,
                });
              }
              return newMap;
            });

            if (result.error) {
              options.onError?.(source, result.error);
            }

            break;
          }

          hasMore = result.hasMore;
          totalSynced += result.synced;

          // Update local progress
          setSyncProgress(prev => {
            const newMap = new Map(prev);
            const current = newMap.get(source) || {
              source_name: source,
              status: 'running',
              total_synced: 0,
              total_available: null,
              last_cursor: null,
              error_message: null,
              started_at: new Date().toISOString(),
              completed_at: null,
            };
            newMap.set(source, {
              ...current,
              total_synced: totalSynced,
              status: hasMore ? 'running' : 'completed',
            });
            return newMap;
          });

          options.onProgress?.(source, totalSynced, null);

          // Longer delay between pages to avoid rate limiting (especially for OLS API)
          if (hasMore) {
            await new Promise(resolve => setTimeout(resolve, 1500));
          }
        }

        // Reload final status
        await loadSyncStatus(source);

        const { data: finalRow } = await supabase
          .from('sync_status')
          .select('status, error_message')
          .eq('source_name', source)
          .maybeSingle();

        if (finalRow?.status === 'completed') {
          options.onComplete?.(source);
        }

      } catch (err: any) {
        console.error(`[useBulkSync] Error syncing ${source}:`, err);

        setSyncProgress(prev => {
          const newMap = new Map(prev);
          const current = newMap.get(source);
          if (current) {
            newMap.set(source, {
              ...current,
              status: 'error',
              error_message: err.message,
            });
          }
          return newMap;
        });

        options.onError?.(source, err.message);
      } finally {
        setIsRunning(prev => new Map(prev).set(source, false));
      }
    },
    [isRunning, loadSyncStatus, runSyncPage, options],
  );

  // Pause sync
  const pauseSync = useCallback(
    async (source: SyncSource) => {
      setIsRunning(prev => new Map(prev).set(source, false));

      // Update status in database
      await supabase.functions.invoke(`${source}-sync`, {
        body: { action: 'pause' },
      });

      await loadSyncStatus(source);
    },
    [loadSyncStatus],
  );

  // Resume sync (continue from last cursor)
  const resumeSync = useCallback(
    async (source: SyncSource) => {
      if (isRunning.get(source)) return;

      setIsRunning(prev => new Map(prev).set(source, true));

      try {
        let hasMore = true;
        const current = syncProgress.get(source);
        let totalSynced = current?.total_synced || 0;

        while (hasMore) {
          const result = await runSyncPage(source);

          if (result.paused) {
            setSyncProgress(prev => {
              const newMap = new Map(prev);
              const curr = newMap.get(source);
              if (curr) {
                newMap.set(source, {
                  ...curr,
                  status: 'paused',
                  error_message: result.error || curr.error_message,
                });
              }
              return newMap;
            });

            if (result.error) {
              options.onError?.(source, result.error);
            }

            break;
          }

          hasMore = result.hasMore;
          totalSynced += result.synced;

          setSyncProgress(prev => {
            const newMap = new Map(prev);
            const curr = newMap.get(source);
            if (curr) {
              newMap.set(source, {
                ...curr,
                total_synced: totalSynced,
                status: hasMore ? 'running' : 'completed',
              });
            }
            return newMap;
          });

          options.onProgress?.(source, totalSynced, null);

          if (hasMore) {
            await new Promise(resolve => setTimeout(resolve, 1500));
          }
        }

        await loadSyncStatus(source);

        const { data: finalRow } = await supabase
          .from('sync_status')
          .select('status, error_message')
          .eq('source_name', source)
          .maybeSingle();

        if (finalRow?.status === 'completed') {
          options.onComplete?.(source);
        }

      } catch (err: any) {
        console.error(`[useBulkSync] Error resuming ${source}:`, err);
        setSyncProgress(prev => {
          const newMap = new Map(prev);
          const curr = newMap.get(source);
          if (curr) {
            newMap.set(source, { ...curr, status: 'error', error_message: err.message });
          }
          return newMap;
        });
        options.onError?.(source, err.message);
      } finally {
        setIsRunning(prev => new Map(prev).set(source, false));
      }
    },
    [isRunning, syncProgress, runSyncPage, loadSyncStatus, options],
  );

  // Reset sync status
  const resetSync = useCallback(async (source: SyncSource) => {
    await supabase.functions.invoke(`${source}-sync`, {
      body: { action: 'reset' },
    });
    await loadSyncStatus(source);
  }, [loadSyncStatus]);

  // Get progress for a specific source
  const getProgress = useCallback((source: SyncSource): SyncProgress | undefined => {
    return syncProgress.get(source);
  }, [syncProgress]);

  // Check if a source is currently syncing
  const isSyncing = useCallback((source: SyncSource): boolean => {
    return isRunning.get(source) || false;
  }, [isRunning]);

  // Check version for a source (only implemented for HPO currently)
  const checkVersion = useCallback(async (source: SyncSource): Promise<VersionCheckResult> => {
    try {
      const { data, error } = await supabase.functions.invoke(`${source}-sync`, {
        body: { action: 'check_version' },
      });

      if (error) {
        console.error(`[useBulkSync] Version check error for ${source}:`, error);
        return {
          remoteVersion: null,
          localVersion: null,
          needsSync: true, // Default to needing sync on error
          message: error.message || 'Versionsabfrage fehlgeschlagen',
        };
      }

      // Reload status to get updated remote_version
      await loadSyncStatus(source);

      return {
        remoteVersion: data?.remoteVersion ?? null,
        localVersion: data?.localVersion ?? null,
        needsSync: data?.needsSync ?? true,
        message: data?.message ?? 'Unbekannter Status',
      };
    } catch (err: any) {
      console.error(`[useBulkSync] Exception checking version for ${source}:`, err);
      return {
        remoteVersion: null,
        localVersion: null,
        needsSync: true,
        message: err.message || 'Versionsabfrage fehlgeschlagen',
      };
    }
  }, [loadSyncStatus]);

  return {
    syncProgress,
    startSync,
    pauseSync,
    resumeSync,
    resetSync,
    getProgress,
    isSyncing,
    loadSyncStatus,
    checkVersion,
  };
}
