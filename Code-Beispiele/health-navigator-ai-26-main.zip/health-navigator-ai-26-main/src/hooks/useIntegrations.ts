import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

interface Integration {
  id: string;
  name: string;
  provider: string;
  is_active: boolean;
  vault_secret_id: string | null;
  created_at: string;
  updated_at: string;
}

interface CreateIntegrationData {
  name: string;
  provider: string;
  apiKey?: string;
}

export function useIntegrations() {
  const { t } = useTranslation();
  const queryClient = useQueryClient();

  const { data: integrations, isLoading } = useQuery({
    queryKey: ['integrations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('integrations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Integration[];
    },
  });

  const createIntegration = useMutation({
    mutationFn: async (data: CreateIntegrationData) => {
      const { data: result, error } = await supabase
        .from('integrations')
        .insert({
          name: data.name,
          provider: data.provider,
          is_active: false,
        })
        .select()
        .single();

      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['integrations'] });
      toast({
        title: t('common.success'),
        description: t('admin.integrations.created', { defaultValue: 'Integration erstellt' }),
      });
    },
    onError: () => {
      toast({
        title: t('common.error'),
        variant: 'destructive',
      });
    },
  });

  const toggleIntegration = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const { error } = await supabase
        .from('integrations')
        .update({ 
          is_active: isActive,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['integrations'] });
      toast({
        title: t('common.success'),
      });
    },
    onError: () => {
      toast({
        title: t('common.error'),
        variant: 'destructive',
      });
    },
  });

  const deleteIntegration = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('integrations')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['integrations'] });
      toast({
        title: t('common.success'),
        description: t('admin.integrations.deleted', { defaultValue: 'Integration gelöscht' }),
      });
    },
    onError: () => {
      toast({
        title: t('common.error'),
        variant: 'destructive',
      });
    },
  });

  return {
    integrations,
    isLoading,
    createIntegration,
    toggleIntegration,
    deleteIntegration,
  };
}
