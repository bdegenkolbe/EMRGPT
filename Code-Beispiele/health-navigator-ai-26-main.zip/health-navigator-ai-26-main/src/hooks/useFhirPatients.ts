import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface FhirPatient {
  id: string;
  fhir_id: string;
  active: boolean;
  given_name: string;
  family_name: string;
  birth_date: string | null;
  gender: string | null;
  identifier_mrn: string | null;
  telecom: any;
  address: any;
  fhir_resource: any;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface FhirEncounter {
  id: string;
  fhir_id: string;
  patient_id: string;
  status: string;
  class: string | null;
  type_code: string | null;
  type_display: string | null;
  period_start: string | null;
  period_end: string | null;
  reason_codes: any;
  diagnosis_codes: any;
  service_provider: string | null;
  fhir_resource: any;
  created_at: string;
}

export interface FhirCondition {
  id: string;
  fhir_id: string;
  patient_id: string;
  clinical_status: string | null;
  verification_status: string | null;
  category: string | null;
  code_system: string | null;
  code: string | null;
  code_display: string | null;
  severity: string | null;
  onset_datetime: string | null;
  abatement_datetime: string | null;
  hpo_codes: string[];
  snomed_codes: string[];
  fhir_resource: any;
}

export interface FhirObservation {
  id: string;
  fhir_id: string;
  patient_id: string;
  status: string;
  category: string | null;
  loinc_code: string | null;
  code_display: string | null;
  value_quantity: number | null;
  value_unit: string | null;
  value_string: string | null;
  reference_range_low: number | null;
  reference_range_high: number | null;
  interpretation: string | null;
  effective_datetime: string | null;
  fhir_resource: any;
}

export interface FhirMedicationRequest {
  id: string;
  fhir_id: string;
  patient_id: string;
  status: string;
  intent: string;
  medication_code: string | null;
  medication_display: string | null;
  dosage_text: string | null;
  dosage_route: string | null;
  authored_on: string | null;
  requester_display: string | null;
  reason_codes: any;
  fhir_resource: any;
}

export interface FhirAllergy {
  id: string;
  fhir_id: string;
  patient_id: string;
  clinical_status: string | null;
  verification_status: string | null;
  type: string | null;
  category: string | null;
  criticality: string | null;
  code: string | null;
  code_display: string | null;
  onset_datetime: string | null;
  reactions: any;
  fhir_resource: any;
}

export function useFhirPatients() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const patientsQuery = useQuery({
    queryKey: ['fhir-patients'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_patients')
        .select('*')
        .order('family_name');
      if (error) throw error;
      return data as FhirPatient[];
    },
    enabled: !!user,
  });

  const importBundle = useMutation({
    mutationFn: async (bundle: any) => {
      const { data, error } = await supabase.functions.invoke('fhir-import', {
        body: { bundle },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['fhir-patients'] });
      toast.success(`Import erfolgreich: ${data.stats?.patients || 0} Patienten, ${data.stats?.conditions || 0} Diagnosen, ${data.stats?.observations || 0} Laborwerte`);
    },
    onError: (error: Error) => {
      toast.error(`Import fehlgeschlagen: ${error.message}`);
    },
  });

  return { ...patientsQuery, importBundle };
}

export function useFhirPatientData(patientId: string | null) {
  const { user } = useAuth();

  const conditions = useQuery({
    queryKey: ['fhir-conditions', patientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_conditions')
        .select('*')
        .eq('patient_id', patientId!)
        .order('onset_datetime', { ascending: false });
      if (error) throw error;
      return data as FhirCondition[];
    },
    enabled: !!user && !!patientId,
  });

  const observations = useQuery({
    queryKey: ['fhir-observations', patientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_observations')
        .select('*')
        .eq('patient_id', patientId!)
        .order('effective_datetime', { ascending: false });
      if (error) throw error;
      return data as FhirObservation[];
    },
    enabled: !!user && !!patientId,
  });

  const medications = useQuery({
    queryKey: ['fhir-medications', patientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_medication_requests')
        .select('*')
        .eq('patient_id', patientId!);
      if (error) throw error;
      return data as FhirMedicationRequest[];
    },
    enabled: !!user && !!patientId,
  });

  const allergies = useQuery({
    queryKey: ['fhir-allergies', patientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_allergies')
        .select('*')
        .eq('patient_id', patientId!);
      if (error) throw error;
      return data as FhirAllergy[];
    },
    enabled: !!user && !!patientId,
  });

  const encounters = useQuery({
    queryKey: ['fhir-encounters', patientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_encounters')
        .select('*')
        .eq('patient_id', patientId!)
        .order('period_start', { ascending: false });
      if (error) throw error;
      return data as FhirEncounter[];
    },
    enabled: !!user && !!patientId,
  });

  return { conditions, observations, medications, allergies, encounters };
}
