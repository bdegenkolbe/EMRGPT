import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface ICD11Code {
  code: string;
  title: string;
  title_short: string | null;
  definition: string | null;
  chapter: string | null;
  block: string | null;
  category: string | null;
  is_terminal: boolean | null;
  parent_code: string | null;
  foundation_uri: string | null;
  linearization_uri: string | null;
  class_kind: string | null;
  // Multilingual JSONB fields - use Record for compatibility with Json type
  labels?: Record<string, string> | null;
  definitions?: Record<string, string> | null;
}

export interface ICD11Analysis {
  id: string;
  icd_code: string;
  content: {
    explanation?: string;
    symptoms?: string[];
    diagnosis?: string;
    therapy?: string;
    notes?: string;
  };
  hpo_mappings: Array<{ code: string; label: string; confidence: number }>;
  snomed_mappings: Array<{ code: string; label: string; confidence: number }>;
  symptom_mappings: Array<{ symptom: string; hpo?: string; snomed?: string }>;
  generated_at: string | null;
  source_language: string;
}

export interface SyncStatus {
  total_codes: number;
  last_sync: string | null;
  is_configured: boolean;
}

export type DataSource = 'local' | 'api' | 'unknown';

interface TranslationResult {
  code: string;
  title_de: string;
  definition_de?: string;
}

export function useIcd11() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<ICD11Code[]>([]);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [lastDataSource, setLastDataSource] = useState<DataSource>('unknown');

  // Search ICD-11 codes (local DB first, then API)
  const searchCodes = useCallback(async (query: string, limit = 20): Promise<ICD11Code[]> => {
    if (!query || query.length < 2) {
      setSearchResults([]);
      return [];
    }

    setIsLoading(true);
    try {
      // First try local database
      const { data: localResults, error: localError } = await supabase
        .from('icd11_codes')
        .select('*')
        .or(`code.ilike.${query}%,title.ilike.%${query}%`)
        .order('code')
        .limit(limit);

      if (!localError && localResults && localResults.length > 0) {
        const mappedResults = localResults as unknown as ICD11Code[];
        setSearchResults(mappedResults);
        setLastDataSource('local');
        return mappedResults;
      }

      // Fallback to API search
      setLastDataSource('api');
      const { data, error } = await supabase.functions.invoke('icd11-lookup', {
        body: { action: 'search', q: query, limit },
      });

      if (error) throw error;

      const results = data?.data || [];
      setSearchResults(results);
      return results;
    } catch (error: unknown) {
      console.error('ICD-11 search error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // Check if it's a configuration error
      if (errorMessage.includes('not configured')) {
        toast({
          title: 'ICD-11 API nicht konfiguriert',
          description: 'Bitte fügen Sie die API-Credentials hinzu (ICD11_CLIENT_ID, ICD11_CLIENT_SECRET)',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Suchfehler',
          description: 'ICD-11 Suche fehlgeschlagen',
          variant: 'destructive',
        });
      }
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  // Get code details
  const getCode = useCallback(async (code: string): Promise<ICD11Code | null> => {
    try {
      // Check local first
      const { data: localData } = await supabase
        .from('icd11_codes')
        .select('*')
        .eq('code', code)
        .maybeSingle();

      if (localData) return localData as unknown as ICD11Code;

      // Fetch from API
      const { data, error } = await supabase.functions.invoke('icd11-lookup', {
        body: { action: 'lookup', code },
      });

      if (error) throw error;
      return data?.data || null;
    } catch (error) {
      console.error('ICD-11 lookup error:', error);
      return null;
    }
  }, []);

  // Get child codes - uses linearization_uri if available, otherwise code
  const getChildren = useCallback(async (codeOrUri: string): Promise<ICD11Code[]> => {
    try {
      // First check local database for children
      const { data: localData, error: localError } = await supabase
        .from('icd11_codes')
        .select('*')
        .eq('parent_code', codeOrUri)
        .order('code');

      if (!localError && localData && localData.length > 0) {
        setLastDataSource('local');
        return localData as unknown as ICD11Code[];
      }

      // Fetch from API - pass code or URI
      setLastDataSource('api');
      const { data, error } = await supabase.functions.invoke('icd11-lookup', {
        body: { action: 'children', parent: codeOrUri },
      });

      if (error) throw error;
      return data?.data || [];
    } catch (error) {
      console.error('ICD-11 children error:', error);
      return [];
    }
  }, []);

  // Get chapters (top level)
  const getChapters = useCallback(async (): Promise<ICD11Code[]> => {
    setIsLoading(true);
    try {
      // Check if we have chapters locally
      const { data: localChapters, error } = await supabase
        .from('icd11_codes')
        .select('*')
        .is('parent_code', null)
        .order('code');

      if (!error && localChapters && localChapters.length > 0) {
        return localChapters as unknown as ICD11Code[];
      }

      // Fetch from API - but gracefully handle configuration errors
      try {
        const { data, error: apiError } = await supabase.functions.invoke('icd11-lookup', {
          body: { action: 'chapters' },
        });

        if (apiError) {
          console.warn('ICD-11 API not available:', apiError.message);
          return [];
        }
        return data?.data || [];
      } catch (apiErr) {
        // API may not be configured - return empty gracefully
        console.warn('ICD-11 API call failed:', apiErr);
        return [];
      }
    } catch (error) {
      console.error('ICD-11 chapters error:', error);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Get or generate analysis
  const getAnalysis = useCallback(async (
    code: string, 
    title?: string,
    forceRegenerate = false
  ): Promise<ICD11Analysis | null> => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('icd11-analyze', {
        body: {
          action: forceRegenerate ? 'generate' : 'get',
          code,
          title,
          forceRegenerate,
        },
      });

      if (error) throw error;

      if (!data?.analysis && !forceRegenerate) {
        // No cached analysis, generate one
        const { data: genData, error: genError } = await supabase.functions.invoke('icd11-analyze', {
          body: { action: 'generate', code, title },
        });

        if (genError) throw genError;
        return genData?.analysis || null;
      }

      return data?.analysis || null;
    } catch (error) {
      console.error('ICD-11 analysis error:', error);
      toast({
        title: 'Analysefehler',
        description: 'ICD-11 Analyse konnte nicht geladen werden',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  // Fetch sync status
  const fetchSyncStatus = useCallback(async (): Promise<SyncStatus | null> => {
    try {
      const { data, count } = await supabase
        .from('icd11_codes')
        .select('created_at', { count: 'exact' })
        .order('created_at', { ascending: false })
        .limit(1);

      const status: SyncStatus = {
        total_codes: count || 0,
        last_sync: data?.[0]?.created_at || null,
        is_configured: true, // Will be updated if API call fails
      };

      setSyncStatus(status);
      return status;
    } catch (error) {
      console.error('Sync status error:', error);
      return null;
    }
  }, []);

  // Translate codes to German
  const translateCodes = useCallback(async (codes: ICD11Code[]): Promise<TranslationResult[]> => {
    if (codes.length === 0) return [];
    
    try {
      const terms = codes.map(c => ({
        code: c.code,
        title: c.title,
        definition: c.definition || undefined,
      }));
      
      const { data, error } = await supabase.functions.invoke('icd11-translate', {
        body: { terms },
      });
      
      if (error) {
        console.error('ICD-11 translation error:', error);
        return [];
      }
      
      return data?.translations || [];
    } catch (error) {
      console.error('ICD-11 translation error:', error);
      return [];
    }
  }, []);

  return {
    // State
    isLoading,
    searchResults,
    syncStatus,
    lastDataSource,

    // Search & lookup
    searchCodes,
    getCode,
    getChildren,
    getChapters,

    // Analysis
    getAnalysis,

    // Translation
    translateCodes,

    // Status
    fetchSyncStatus,
  };
}
