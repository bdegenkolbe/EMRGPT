import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

interface Profile {
  id: string;
  user_id: string;
  email: string;
  display_name: string | null;
  language: string;
  dark_mode: boolean;
  show_english_details: boolean;
  sidebar_collapsed: boolean;
  sidebar_tab_order: string[] | null;
  created_at: string;
  updated_at: string;
}

interface UpdateProfileData {
  display_name?: string;
  language?: string;
  dark_mode?: boolean;
  show_english_details?: boolean;
  sidebar_collapsed?: boolean;
  sidebar_tab_order?: string[];
}

export function useProfile() {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const queryClient = useQueryClient();

  const { data: profile, isLoading } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (error) throw error;
      return data as Profile;
    },
    enabled: !!user?.id,
  });

  const updateProfile = useMutation({
    mutationFn: async (updates: UpdateProfileData) => {
      if (!user?.id) throw new Error('No user');
      
      const { data, error } = await supabase
        .from('profiles')
        .update({
          ...updates,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user.id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['profile', user?.id] });
      
      // Sync language with i18n
      if (data.language && data.language !== i18n.language) {
        i18n.changeLanguage(data.language);
      }
      
      toast({
        title: t('common.success'),
        description: t('profile.updateSuccess'),
      });
    },
    onError: () => {
      toast({
        title: t('common.error'),
        description: t('profile.updateError'),
        variant: 'destructive',
      });
    },
  });

  const updatePassword = useMutation({
    mutationFn: async (newPassword: string) => {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: t('common.success'),
        description: t('profile.passwordUpdated'),
      });
    },
    onError: () => {
      toast({
        title: t('common.error'),
        description: t('profile.passwordError'),
        variant: 'destructive',
      });
    },
  });

  return {
    profile,
    isLoading,
    updateProfile,
    updatePassword,
  };
}
