 import { useMutation, useQueryClient } from '@tanstack/react-query';
 import { supabase } from '@/integrations/supabase/client';
 import { useToast } from '@/hooks/use-toast';
 
 interface HpoLabel {
   code: string;
   label_de: string;
   label_en: string;
 }
 
 interface Observation {
   raw_input: string;
   hpo_codes: string[];
   onset?: string;
   severity?: string;
 }
 
 interface GeneratePathParams {
   sessionId: string;
   hpoCodes: string[];
   hpoLabels: HpoLabel[];
   existingPathId?: string;
   observations?: Observation[];
  combineMode?: 'single' | 'combined' | 'auto';
  forceNew?: boolean;
 }
 
 export function useAnamnesisPath() {
   const { toast } = useToast();
   const queryClient = useQueryClient();
 
   const generatePath = useMutation({
    mutationFn: async ({ sessionId, hpoCodes, hpoLabels, existingPathId, observations, combineMode = 'auto', forceNew = false }: GeneratePathParams) => {
       const { data, error } = await supabase.functions.invoke('generate-anamnesis-path', {
         body: {
           session_id: sessionId,
           hpo_codes: hpoCodes,
           hpo_labels: hpoLabels,
           existing_path_id: existingPathId,
           observations,
          combine_mode: combineMode,
          force_new: forceNew,
         },
       });
 
       if (error) {
         if (error.message?.includes('429')) {
           throw new Error('Rate limit exceeded. Please wait a moment.');
         }
         if (error.message?.includes('402')) {
           throw new Error('Payment required. Please add credits.');
         }
         throw error;
       }
 
       return data;
     },
    onSuccess: (data) => {
       queryClient.invalidateQueries({ queryKey: ['anamnesis-paths'] });
      
      // Log if path was reused
      if (data?.reused) {
        console.log(`♻️ Reused existing path ${data.id} (originally from session ${data.reused_from_session || data.session_id})`);
      }
     },
     onError: (error: Error) => {
       console.error('Path generation error:', error);
       // Silent fail - don't disrupt the anamnesis flow
     },
   });
 
   return {
     generatePath: generatePath.mutate,
     isGenerating: generatePath.isPending,
   };
 }