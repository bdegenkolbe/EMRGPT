import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface PhaseResult {
  phase: string;
  output: unknown;
  latency_ms: number;
  prompt_tokens?: number;
  completion_tokens?: number;
}

export interface PipelineResult {
  domain: string;
  pipeline: string;
  phases_executed: number;
  results: PhaseResult[];
  total_latency_ms: number;
  total_tokens: number;
}

interface UsePipelineOrchestrationOptions {
  sessionId?: string;
  clinicalView?: string;
  enabled?: boolean;
}

export function usePipelineOrchestration(options: UsePipelineOrchestrationOptions = {}) {
  const { sessionId, clinicalView = 'hausarztpraxis', enabled = true } = options;
  
  const [isRunning, setIsRunning] = useState(false);
  const [lastResult, setLastResult] = useState<PipelineResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runPipeline = useCallback(async (
    userInput: string,
    conversationHistory: string = ''
  ): Promise<PipelineResult | null> => {
    if (!enabled) return null;
    
    setIsRunning(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('pipeline-orchestrate', {
        body: {
          user_input: userInput,
          session_id: sessionId,
          clinical_view: clinicalView,
          conversation_history: conversationHistory,
        },
      });

      if (fnError) {
        throw new Error(fnError.message);
      }

      const result = data as PipelineResult;
      setLastResult(result);
      return result;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Pipeline orchestration failed';
      setError(errorMsg);
      console.error('[Pipeline] Error:', errorMsg);
      return null;
    } finally {
      setIsRunning(false);
    }
  }, [sessionId, clinicalView, enabled]);

  const clearResult = useCallback(() => {
    setLastResult(null);
    setError(null);
  }, []);

  return {
    runPipeline,
    isRunning,
    lastResult,
    error,
    clearResult,
  };
}
