 import { useState } from 'react';
 import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
 import { useTranslation } from 'react-i18next';
 import { 
   GitBranch, 
   Search, 
   Loader2, 
   RefreshCw, 
   ChevronDown, 
   ChevronRight,
   Activity,
   Layers,
   Clock,
   Stethoscope,
   AlertTriangle,
   ExternalLink,
   Sparkles,
   Calendar,
   Filter,
  X,
  AlertCircle,
  Heart,
  Pill,
  Users,
  ClipboardCheck,
  CheckCircle2,
  FileDown,
  BookOpen,
  Recycle,
  HelpCircle,
  History
 } from 'lucide-react';
 import { AppLayout } from '@/components/layout/AppLayout';
 import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
 import { Input } from '@/components/ui/input';
 import { Button } from '@/components/ui/button';
 import { Badge } from '@/components/ui/badge';
 import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
 import { ScrollArea } from '@/components/ui/scroll-area';
 import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
 import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
 } from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
 import { MermaidDiagram } from '@/components/anamnesis/MermaidDiagram';
 import { supabase } from '@/integrations/supabase/client';
 import { useToast } from '@/hooks/use-toast';
import { format, isWithinInterval, startOfDay, endOfDay, subDays } from 'date-fns';
 import { de } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import type { DateRange } from 'react-day-picker';
import { downloadAnamnesisPathPDF } from '@/lib/export/pdfGenerator';
import { useNavigate } from 'react-router-dom';
import { useAnamnesisPath } from '@/hooks/useAnamnesisPath';
import { PathVersionCompare } from '@/components/anamnesis/PathVersionCompare';
import { QuestionTreeView } from '@/components/anamnesis/QuestionTreeView';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

// Category definitions for filtering
type AnamnesisCategory = 
  | 'chief_complaint' 
  | 'hpi' 
  | 'ros' 
  | 'pmh' 
  | 'medications'
  | 'social' 
  | 'family';

interface CategoryInfo {
  id: AnamnesisCategory;
  labelDe: string;
  labelEn: string;
  icon: React.ElementType;
  hpoPatterns: string[]; // HPO code patterns associated with this category
}

const ANAMNESIS_CATEGORIES: CategoryInfo[] = [
  { 
    id: 'chief_complaint', 
    labelDe: 'Hauptbeschwerde', 
    labelEn: 'Chief Complaint', 
    icon: AlertCircle,
    hpoPatterns: ['HP:0012531', 'HP:0000739', 'HP:0002315'] // Pain, anxiety, headache
  },
  { 
    id: 'hpi', 
    labelDe: 'Aktuelle Beschwerden', 
    labelEn: 'History of Present Illness', 
    icon: Activity,
    hpoPatterns: ['HP:0025142', 'HP:0012378', 'HP:0012384'] // Constitutional symptoms
  },
  { 
    id: 'ros', 
    labelDe: 'Systemübersicht', 
    labelEn: 'Review of Systems', 
    icon: Stethoscope,
    hpoPatterns: ['HP:0002094', 'HP:0001945', 'HP:0002014'] // Respiratory, fever, nausea
  },
  { 
    id: 'pmh', 
    labelDe: 'Vorerkrankungen', 
    labelEn: 'Past Medical History', 
    icon: ClipboardCheck,
    hpoPatterns: ['HP:0001627', 'HP:0000819', 'HP:0002099'] // Cardiac, diabetes, respiratory
  },
  { 
    id: 'medications', 
    labelDe: 'Medikamente', 
    labelEn: 'Medications', 
    icon: Pill,
    hpoPatterns: [] // Usually RxNorm, not HPO
  },
  { 
    id: 'social', 
    labelDe: 'Sozialanamnese', 
    labelEn: 'Social History', 
    icon: Users,
    hpoPatterns: ['HP:0001513', 'HP:0001254'] // Obesity, lethargy
  },
  { 
    id: 'family', 
    labelDe: 'Familienanamnese', 
    labelEn: 'Family History', 
    icon: Heart,
    hpoPatterns: ['HP:0001627', 'HP:0002664', 'HP:0000819'] // Cardiac, neoplasm, diabetes
  },
];
 
 interface AnamnesisPath {
   id: string;
   session_id: string;
   hpo_codes: string[];
   symptom_hierarchy: Record<string, unknown>;
   temporal_sequence: unknown[];
   differential_diagnoses: DifferentialDiagnosis[];
   question_tree: Record<string, unknown>;
   mermaid_diagram: string | null;
   ai_reasoning: string | null;
   version: number;
   is_combined: boolean;
   source_observation_ids: string[];
   created_at: string;
   updated_at: string;
 }
 
 interface DifferentialDiagnosis {
   name: string;
   probability: number;
   icd10?: string;
   reasoning: string;
 }
 
 interface HpoLabel {
   hpo_code: string;
   label_de: string;
   label_en: string;
 }
 
 export default function AnamnesisPathways() {
   const { i18n } = useTranslation();
   const { toast } = useToast();
   const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { generatePath, isGenerating } = useAnamnesisPath();
   
   const [searchTerm, setSearchTerm] = useState('');
   const [typeFilter, setTypeFilter] = useState<string>('all');
   const [selectedPath, setSelectedPath] = useState<AnamnesisPath | null>(null);
   const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set());
  const [sessionFilter, setSessionFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const [datePreset, setDatePreset] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<AnamnesisCategory | 'all'>('all');
  const [showCombineDialog, setShowCombineDialog] = useState(false);
  const [selectedHpoCodes, setSelectedHpoCodes] = useState<Set<string>>(new Set());
  const [regeneratingPathId, setRegeneratingPathId] = useState<string | null>(null);
  const [showVersionCompare, setShowVersionCompare] = useState(false);
  const [comparePathHpoCodes, setComparePathHpoCodes] = useState<string[]>([]);
 
   // Fetch all paths
   const { data: paths, isLoading } = useQuery({
     queryKey: ['anamnesis-paths'],
     queryFn: async () => {
       const { data, error } = await supabase
         .from('anamnesis_paths')
         .select('*')
         .order('created_at', { ascending: false });
       
       if (error) throw error;
       return (data || []).map(d => ({
         ...d,
         differential_diagnoses: (d.differential_diagnoses as unknown as DifferentialDiagnosis[]) || [],
         symptom_hierarchy: d.symptom_hierarchy as Record<string, unknown>,
         temporal_sequence: d.temporal_sequence as unknown[],
         question_tree: d.question_tree as Record<string, unknown>,
       })) as AnamnesisPath[];
     },
   });
 
  // Fetch sessions for the filter
  const { data: sessions } = useQuery({
    queryKey: ['anamnesis-sessions-for-filter'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('anamnesis_sessions')
        .select('id, clinical_view, created_at, patient_identifier')
        .order('created_at', { ascending: false })
        .limit(50);
      
      if (error) throw error;
      return data || [];
    },
  });

   // Fetch HPO labels for display
  const { data: hpoLabels } = useQuery({
    queryKey: ['hpo-labels', paths?.flatMap(p => p.hpo_codes)],
    queryFn: async () => {
      if (!paths?.length) return {};
      const allCodes = [...new Set(paths.flatMap(p => p.hpo_codes))];
      if (!allCodes.length) return {};
      
      const { data, error } = await supabase
        .from('hpo_codes')
        .select('hpo_code, label, labels')
        .in('hpo_code', allCodes);
      
      if (error) throw error;
      
      const labelsMap: Record<string, HpoLabel> = {};
      data?.forEach(h => {
        const labels = h.labels as Record<string, string> | null;
        labelsMap[h.hpo_code] = {
          hpo_code: h.hpo_code,
          label_de: labels?.de || h.label,
          label_en: labels?.en || h.label,
        };
      });
      return labelsMap;
    },
    enabled: !!paths?.length,
  });
 
  // Handle date preset changes
  const handleDatePreset = (preset: string) => {
    setDatePreset(preset);
    const now = new Date();
    
    switch (preset) {
      case 'today':
        setDateRange({ from: startOfDay(now), to: endOfDay(now) });
        break;
      case 'week':
        setDateRange({ from: startOfDay(subDays(now, 7)), to: endOfDay(now) });
        break;
      case 'month':
        setDateRange({ from: startOfDay(subDays(now, 30)), to: endOfDay(now) });
        break;
      case 'all':
      default:
        setDateRange(undefined);
        break;
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setTypeFilter('all');
    setSessionFilter('all');
    setDateRange(undefined);
    setDatePreset('all');
    setCategoryFilter('all');
  };

  const hasActiveFilters = searchTerm || typeFilter !== 'all' || sessionFilter !== 'all' || dateRange || categoryFilter !== 'all';

  // Helper to check if a path matches a category based on HPO codes
  const pathMatchesCategory = (path: AnamnesisPath, category: AnamnesisCategory): boolean => {
    const categoryInfo = ANAMNESIS_CATEGORIES.find(c => c.id === category);
    if (!categoryInfo || categoryInfo.hpoPatterns.length === 0) return false;
    
    // Check if any HPO code in the path starts with any of the category patterns
    // or if the HPO label contains keywords related to the category
    return path.hpo_codes.some(code => {
      // Direct pattern match
      if (categoryInfo.hpoPatterns.some(pattern => code.startsWith(pattern.split(':')[0]))) {
        return true;
      }
      // Check labels for category-related keywords
      const label = hpoLabels?.[code];
      if (label) {
        const labelText = (label.label_de + ' ' + label.label_en).toLowerCase();
        switch (category) {
          case 'chief_complaint':
            return labelText.includes('schmerz') || labelText.includes('pain') || labelText.includes('beschwerde');
          case 'hpi':
            return labelText.includes('akut') || labelText.includes('acute') || labelText.includes('symptom');
          case 'ros':
            return labelText.includes('atem') || labelText.includes('breath') || labelText.includes('herz') || labelText.includes('cardiac');
          case 'pmh':
            return labelText.includes('chronisch') || labelText.includes('chronic') || labelText.includes('vorgeschichte');
          case 'social':
            return labelText.includes('alkohol') || labelText.includes('alcohol') || labelText.includes('rauchen') || labelText.includes('smoking');
          case 'family':
            return labelText.includes('famili') || labelText.includes('heredit') || labelText.includes('genetisch');
          default:
            return false;
        }
      }
      return false;
    });
  };

   // Filter paths
   const filteredPaths = paths?.filter(p => {
     const matchesSearch = !searchTerm || 
       p.hpo_codes.some(code => code.toLowerCase().includes(searchTerm.toLowerCase())) ||
       p.ai_reasoning?.toLowerCase().includes(searchTerm.toLowerCase()) ||
       p.hpo_codes.some(code => {
         const label = hpoLabels?.[code];
         return label?.label_de.toLowerCase().includes(searchTerm.toLowerCase()) ||
                label?.label_en.toLowerCase().includes(searchTerm.toLowerCase());
       });
     
     const matchesType = typeFilter === 'all' || 
       (typeFilter === 'single' && !p.is_combined) ||
       (typeFilter === 'combined' && p.is_combined);
    
    const matchesSession = sessionFilter === 'all' || p.session_id === sessionFilter;
    
    const matchesDate = !dateRange?.from || !dateRange?.to || 
      isWithinInterval(new Date(p.created_at), { 
        start: startOfDay(dateRange.from), 
        end: endOfDay(dateRange.to) 
      });
    
    const matchesCategory = categoryFilter === 'all' || pathMatchesCategory(p, categoryFilter);
     
    return matchesSearch && matchesType && matchesSession && matchesDate && matchesCategory;
   });
 
   // Group paths by HPO codes for the "By HPO" view
   const pathsByHpo = paths?.reduce((acc, path) => {
     path.hpo_codes.forEach(code => {
       if (!acc[code]) acc[code] = [];
       acc[code].push(path);
     });
     return acc;
   }, {} as Record<string, AnamnesisPath[]>) || {};
 
   const togglePath = (id: string) => {
     setExpandedPaths(prev => {
       const next = new Set(prev);
       if (next.has(id)) next.delete(id);
       else next.add(id);
       return next;
     });
   };
 
   const getHpoLabel = (code: string): string => {
     return hpoLabels?.[code]?.label_de || hpoLabels?.[code]?.label_en || code;
   };

  const handleExportPDF = (path: AnamnesisPath) => {
    const pathData = {
      id: path.id,
      hpoCodes: path.hpo_codes,
      hpoLabels: hpoLabels || {},
      differentialDiagnoses: path.differential_diagnoses || [],
      aiReasoning: path.ai_reasoning || undefined,
      mermaidDiagram: path.mermaid_diagram || undefined,
      version: path.version,
      isCombined: path.is_combined,
      createdAt: format(new Date(path.created_at), 'dd.MM.yyyy HH:mm', { locale: de }),
      updatedAt: format(new Date(path.updated_at), 'dd.MM.yyyy HH:mm', { locale: de }),
    };
    
    downloadAnamnesisPathPDF(pathData);
    
    toast({
      title: 'PDF exportiert',
      description: 'Der Anamnesepfad wurde als PDF heruntergeladen.',
    });
  };

  const handleEvidenceSearch = (diagnosisName: string, icd10?: string) => {
    const searchQuery = icd10 ? `${diagnosisName} ${icd10}` : diagnosisName;
    sessionStorage.setItem('evidence_search_query', searchQuery);
    navigate('/evidence-search');
  };

  // Regenerate entire path
  const handleRegeneratePath = async (path: AnamnesisPath) => {
    setRegeneratingPathId(path.id);
    
    const labels = path.hpo_codes.map(code => ({
      code,
      label_de: hpoLabels?.[code]?.label_de || code,
      label_en: hpoLabels?.[code]?.label_en || code,
    }));

    generatePath({
      sessionId: path.session_id || 'regenerated-' + Date.now(),
      hpoCodes: path.hpo_codes,
      hpoLabels: labels,
      existingPathId: path.id,
      combineMode: path.is_combined ? 'combined' : 'single',
      forceNew: true,
    }, {
      onSuccess: () => {
        toast({
          title: 'Pfad neu generiert',
          description: `Der Anamnesepfad wurde erfolgreich mit KI neu erstellt (v${path.version + 1}).`,
        });
        setRegeneratingPathId(null);
        queryClient.invalidateQueries({ queryKey: ['anamnesis-paths'] });
      },
      onError: (error: Error) => {
        toast({
          title: 'Fehler bei der Neugenerierung',
          description: error.message || 'Der Pfad konnte nicht neu generiert werden.',
          variant: 'destructive',
        });
        setRegeneratingPathId(null);
      },
    });
  };

  // Regenerate specific category/step
  // Get all versions for a specific HPO code set
  const getPathVersions = (hpoCodes: string[]): AnamnesisPath[] => {
    if (!paths) return [];
    const sortedCodes = [...hpoCodes].sort().join(',');
    return paths.filter(p => {
      const pCodes = [...p.hpo_codes].sort().join(',');
      return pCodes === sortedCodes;
    }).sort((a, b) => b.version - a.version);
  };

  const handleShowVersionCompare = (hpoCodes: string[]) => {
    setComparePathHpoCodes(hpoCodes);
    setShowVersionCompare(true);
  };

  // Regenerate specific category/step
  const handleRegenerateStep = async (path: AnamnesisPath, categoryKey: string, categoryLabel: string) => {
    setRegeneratingPathId(path.id + '-' + categoryKey);
    
    try {
      const { data, error } = await supabase.functions.invoke('generate-anamnesis-path', {
        body: {
          session_id: path.session_id || 'regenerated-step-' + Date.now(),
          hpo_codes: path.hpo_codes,
          hpo_labels: path.hpo_codes.map(code => ({
            code,
            label_de: hpoLabels?.[code]?.label_de || code,
            label_en: hpoLabels?.[code]?.label_en || code,
          })),
          existing_path_id: path.id,
          regenerate_step: categoryKey,
          force_new: true,
        },
      });

      if (error) throw error;

      toast({
        title: 'Schritt neu generiert',
        description: `Der Schritt "${categoryLabel}" wurde erfolgreich aktualisiert.`,
      });
      queryClient.invalidateQueries({ queryKey: ['anamnesis-paths'] });
    } catch (error: any) {
      toast({
        title: 'Fehler',
        description: error.message || 'Der Schritt konnte nicht neu generiert werden.',
        variant: 'destructive',
      });
    } finally {
      setRegeneratingPathId(null);
    }
  };

  // Save question tree changes
  const handleSaveQuestionTree = async (pathId: string, updatedTree: Record<string, unknown>) => {
    const { error } = await supabase
      .from('anamnesis_paths')
      .update({ question_tree: updatedTree as unknown as import('@/integrations/supabase/types').Json })
      .eq('id', pathId);
    
    if (error) {
      toast({
        title: 'Fehler beim Speichern',
        description: error.message,
        variant: 'destructive',
      });
      throw error;
    }
    
    toast({
      title: 'Gespeichert',
      description: 'Der Fragenbaum wurde erfolgreich aktualisiert.',
    });
    
    queryClient.invalidateQueries({ queryKey: ['anamnesis-paths'] });
  };

  // Get all unique HPO codes from paths
  const allHpoCodes = [...new Set(paths?.flatMap(p => p.hpo_codes) || [])];

  const toggleHpoCode = (code: string) => {
    setSelectedHpoCodes(prev => {
      const next = new Set(prev);
      if (next.has(code)) next.delete(code);
      else next.add(code);
      return next;
    });
  };

  const handleCombinePaths = async () => {
    if (selectedHpoCodes.size < 2) {
      toast({
        title: 'Mindestens 2 Symptome auswählen',
        description: 'Für einen kombinierten Pfad werden mindestens 2 HPO-Codes benötigt.',
        variant: 'destructive',
      });
      return;
    }

    const codes = Array.from(selectedHpoCodes);
    const labels = codes.map(code => ({
      code,
      label_de: hpoLabels?.[code]?.label_de || code,
      label_en: hpoLabels?.[code]?.label_en || code,
    }));

    // Find any session that has these codes
    const relevantPath = paths?.find(p => p.hpo_codes.some(c => codes.includes(c)));
    const sessionId = relevantPath?.session_id || 'combined-' + Date.now();

    generatePath({
      sessionId,
      hpoCodes: codes,
      hpoLabels: labels,
      combineMode: 'combined',
      forceNew: true,
    }, {
      onSuccess: (result) => {
        // Check if path was reused
        if ((result as any)?.reused) {
          toast({
            title: '♻️ Bestehender Pfad wiederverwendet',
            description: 'Ein bereits existierender Pfad mit denselben HPO-Codes wurde gefunden und wiederverwendet.',
          });
        } else {
          toast({
            title: 'Kombinierter Pfad erstellt',
            description: `${codes.length} Symptome wurden zu einem gemeinsamen Anamnesepfad kombiniert.`,
          });
        }
        setShowCombineDialog(false);
        setSelectedHpoCodes(new Set());
        queryClient.invalidateQueries({ queryKey: ['anamnesis-paths'] });
      },
      onError: (error: Error) => {
        toast({
          title: 'Fehler',
          description: error.message || 'Der kombinierte Pfad konnte nicht erstellt werden.',
          variant: 'destructive',
        });
      },
    });
  };
 
   // Stats
   const stats = {
     total: paths?.length || 0,
     single: paths?.filter(p => !p.is_combined).length || 0,
     combined: paths?.filter(p => p.is_combined).length || 0,
     uniqueHpos: Object.keys(pathsByHpo).length,
   };
 
   return (
     <AppLayout>
       <div className="container mx-auto py-6 space-y-6">
         {/* Header */}
         <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
           <div>
             <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
               <GitBranch className="h-6 w-6" />
               Anamnesepfade
             </h1>
             <p className="text-muted-foreground">
               Klinische Entscheidungspfade basierend auf erkannten Symptomen
             </p>
           </div>
          
          {/* Combine Button */}
          <Dialog open={showCombineDialog} onOpenChange={setShowCombineDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Layers className="h-4 w-4" />
                Symptome kombinieren
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Symptome kombinieren</DialogTitle>
                <DialogDescription>
                  Wählen Sie mindestens 2 HPO-Codes aus, um einen kombinierten Anamnesepfad zu erstellen.
                </DialogDescription>
              </DialogHeader>
              
              <div className="max-h-[400px] overflow-y-auto space-y-2 py-4">
                {allHpoCodes.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    Keine HPO-Codes verfügbar
                  </p>
                ) : (
                  allHpoCodes.map(code => (
                    <div
                      key={code}
                      className="flex items-center space-x-3 p-2 rounded-md hover:bg-muted/50 cursor-pointer"
                      onClick={() => toggleHpoCode(code)}
                    >
                      <Checkbox
                        checked={selectedHpoCodes.has(code)}
                        onCheckedChange={() => toggleHpoCode(code)}
                      />
                      <div className="flex-1">
                        <span className="font-medium">{getHpoLabel(code)}</span>
                        <span className="ml-2 text-xs font-mono text-muted-foreground">{code}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowCombineDialog(false)}>
                  Abbrechen
                </Button>
                <Button 
                  onClick={handleCombinePaths} 
                  disabled={selectedHpoCodes.size < 2 || isGenerating}
                  className="gap-2"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Generiere...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      {selectedHpoCodes.size} Symptome kombinieren
                    </>
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
         </div>
 
         {/* Stats */}
         <div className="grid gap-4 md:grid-cols-4">
           <Card>
             <CardHeader className="pb-2">
               <CardDescription className="flex items-center gap-1">
                 <Activity className="h-3 w-3" />
                 Gesamt
               </CardDescription>
               <CardTitle className="text-3xl">{stats.total}</CardTitle>
             </CardHeader>
           </Card>
           <Card>
             <CardHeader className="pb-2">
               <CardDescription className="flex items-center gap-1">
                 <Stethoscope className="h-3 w-3" />
                 Einzelsymptome
               </CardDescription>
               <CardTitle className="text-3xl">{stats.single}</CardTitle>
             </CardHeader>
           </Card>
           <Card>
             <CardHeader className="pb-2">
               <CardDescription className="flex items-center gap-1">
                 <Layers className="h-3 w-3" />
                 Kombiniert
               </CardDescription>
               <CardTitle className="text-3xl">{stats.combined}</CardTitle>
             </CardHeader>
           </Card>
           <Card>
             <CardHeader className="pb-2">
               <CardDescription className="flex items-center gap-1">
                 <GitBranch className="h-3 w-3" />
                 HPO-Codes
               </CardDescription>
               <CardTitle className="text-3xl">{stats.uniqueHpos}</CardTitle>
             </CardHeader>
           </Card>
         </div>
 
         {/* Filters */}
         <Card>
           <CardContent className="pt-6">
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-4 md:flex-row md:items-center">
               <div className="relative flex-1">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                 <Input
                   placeholder="HPO-Code oder Symptom suchen..."
                   value={searchTerm}
                   onChange={(e) => setSearchTerm(e.target.value)}
                   className="pl-9"
                 />
               </div>
               <Select value={typeFilter} onValueChange={setTypeFilter}>
                 <SelectTrigger className="w-[180px]">
                   <Layers className="h-4 w-4 mr-2" />
                   <SelectValue placeholder="Typ" />
                 </SelectTrigger>
                 <SelectContent>
                   <SelectItem value="all">Alle Pfade</SelectItem>
                   <SelectItem value="single">Einzelsymptome</SelectItem>
                   <SelectItem value="combined">Kombiniert</SelectItem>
                 </SelectContent>
               </Select>
              
              {/* Session Filter */}
              <Select value={sessionFilter} onValueChange={setSessionFilter}>
                <SelectTrigger className="w-[200px]">
                  <Stethoscope className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Sitzung" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle Sitzungen</SelectItem>
                  {sessions?.map((session) => (
                    <SelectItem key={session.id} value={session.id}>
                      <span className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(session.created_at), 'dd.MM.yy HH:mm', { locale: de })}
                        </span>
                        {session.patient_identifier && (
                          <span className="text-xs">({session.patient_identifier})</span>
                        )}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              </div>
              
              {/* Date Range Filter */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1 mr-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Zeitraum:</span>
                </div>
                
                <div className="flex gap-1">
                  <Button 
                    variant={datePreset === 'all' ? 'secondary' : 'ghost'} 
                    size="sm"
                    onClick={() => handleDatePreset('all')}
                  >
                    Alle
                  </Button>
                  <Button 
                    variant={datePreset === 'today' ? 'secondary' : 'ghost'} 
                    size="sm"
                    onClick={() => handleDatePreset('today')}
                  >
                    Heute
                  </Button>
                  <Button 
                    variant={datePreset === 'week' ? 'secondary' : 'ghost'} 
                    size="sm"
                    onClick={() => handleDatePreset('week')}
                  >
                    7 Tage
                  </Button>
                  <Button 
                    variant={datePreset === 'month' ? 'secondary' : 'ghost'} 
                    size="sm"
                    onClick={() => handleDatePreset('month')}
                  >
                    30 Tage
                  </Button>
                </div>
                
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={dateRange && datePreset === 'custom' ? 'secondary' : 'outline'}
                      size="sm"
                      className="gap-1"
                    >
                      <Calendar className="h-3 w-3" />
                      {dateRange?.from && dateRange?.to ? (
                        <span className="text-xs">
                          {format(dateRange.from, 'dd.MM.yy')} - {format(dateRange.to, 'dd.MM.yy')}
                        </span>
                      ) : (
                        'Benutzerdefiniert'
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarComponent
                      mode="range"
                      defaultMonth={dateRange?.from}
                      selected={dateRange}
                      onSelect={(range) => {
                        setDateRange(range);
                        if (range?.from && range?.to) {
                          setDatePreset('custom');
                        }
                      }}
                      numberOfMonths={2}
                      className={cn("p-3 pointer-events-auto")}
                      locale={de}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              {/* Category Filter */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1 mr-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Kategorie:</span>
                </div>
                
                <div className="flex flex-wrap gap-1">
                  <Button 
                    variant={categoryFilter === 'all' ? 'secondary' : 'ghost'} 
                    size="sm"
                    onClick={() => setCategoryFilter('all')}
                    className="gap-1"
                  >
                    Alle
                  </Button>
                  {ANAMNESIS_CATEGORIES.map((category) => {
                    const Icon = category.icon;
                    const isActive = categoryFilter === category.id;
                    
                    return (
                      <Button
                        key={category.id}
                        variant={isActive ? 'secondary' : 'ghost'}
                        size="sm"
                        onClick={() => setCategoryFilter(category.id)}
                        className="gap-1"
                      >
                        <Icon className="h-3 w-3" />
                        <span className="hidden md:inline">{category.labelDe}</span>
                      </Button>
                    );
                  })}
                </div>
              </div>
                
              {/* Clear filters */}
              <div className="flex items-center">
                {hasActiveFilters && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={clearFilters}
                    className="gap-1 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-3 w-3" />
                    Filter zurücksetzen
                  </Button>
                )}
              </div>
             </div>
           </CardContent>
         </Card>
 
         {/* Tabs */}
         <Tabs defaultValue="list">
           <TabsList>
             <TabsTrigger value="list" className="gap-2">
               <Activity className="h-4 w-4" />
               Alle Pfade
             </TabsTrigger>
             <TabsTrigger value="by-hpo" className="gap-2">
               <GitBranch className="h-4 w-4" />
               Nach HPO
             </TabsTrigger>
           </TabsList>
 
           {/* All Paths Tab */}
           <TabsContent value="list" className="mt-6">
             {isLoading ? (
               <Card>
                 <CardContent className="flex items-center justify-center py-12">
                   <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                 </CardContent>
               </Card>
             ) : filteredPaths?.length === 0 ? (
               <Card>
                 <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                   <GitBranch className="h-12 w-12 text-muted-foreground mb-4" />
                   <h3 className="font-medium text-lg">Keine Anamnesepfade gefunden</h3>
                   <p className="text-muted-foreground mt-1">
                     Anamnesepfade werden automatisch erstellt, wenn Symptome erkannt werden.
                   </p>
                 </CardContent>
               </Card>
             ) : (
               <div className="space-y-4">
                 {filteredPaths?.map((path) => (
                   <Collapsible key={path.id} open={expandedPaths.has(path.id)}>
                     <Card>
                       <CardHeader className="pb-3">
                         <div className="flex items-start justify-between">
                           <div className="flex-1">
                             <div className="flex items-center gap-2 mb-2">
                               <CollapsibleTrigger asChild>
                                 <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => togglePath(path.id)}>
                                   {expandedPaths.has(path.id) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                 </Button>
                               </CollapsibleTrigger>
                               <CardTitle className="text-base">
                                 {path.hpo_codes.map(code => getHpoLabel(code)).join(' + ')}
                               </CardTitle>
                               {path.is_combined && (
                                 <Badge variant="outline" className="gap-1">
                                   <Layers className="h-3 w-3" />
                                   Kombiniert
                                 </Badge>
                               )}
                               <Badge variant="secondary" className="gap-1">
                                 v{path.version}
                               </Badge>
                             </div>
                              {/* Action Buttons */}
                              <div className="flex items-center gap-1 ml-auto">
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      className="h-8 w-8"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleExportPDF(path);
                                      }}
                                    >
                                      <FileDown className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Als PDF exportieren</TooltipContent>
                                </Tooltip>
                                
                                <AlertDialog>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <AlertDialogTrigger asChild>
                                        <Button 
                                          variant="ghost" 
                                          size="icon" 
                                          className="h-8 w-8"
                                          disabled={regeneratingPathId === path.id || isGenerating}
                                          onClick={(e) => e.stopPropagation()}
                                        >
                                          {regeneratingPathId === path.id ? (
                                            <Loader2 className="h-4 w-4 animate-spin" />
                                          ) : (
                                            <RefreshCw className="h-4 w-4" />
                                          )}
                                        </Button>
                                      </AlertDialogTrigger>
                                    </TooltipTrigger>
                                    <TooltipContent>Gesamten Pfad neu generieren</TooltipContent>
                                  </Tooltip>
                                  <AlertDialogContent onClick={(e) => e.stopPropagation()}>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Pfad neu generieren?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Der gesamte Anamnesepfad wird mit KI neu erstellt. 
                                        Dies erstellt eine neue Version (v{path.version + 1}) des Pfads.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Abbrechen</AlertDialogCancel>
                                      <AlertDialogAction 
                                        onClick={() => handleRegeneratePath(path)}
                                        className="gap-2"
                                      >
                                        <Sparkles className="h-4 w-4" />
                                        Neu generieren
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                             {/* Version History Button */}
                             {getPathVersions(path.hpo_codes).length >= 2 && (
                               <Tooltip>
                                 <TooltipTrigger asChild>
                                   <Button
                                     variant="ghost"
                                     size="icon"
                                     className="h-8 w-8"
                                     onClick={(e) => {
                                       e.stopPropagation();
                                       handleShowVersionCompare(path.hpo_codes);
                                     }}
                                   >
                                     <History className="h-4 w-4" />
                                   </Button>
                                 </TooltipTrigger>
                                 <TooltipContent>
                                   Versionsvergleich ({getPathVersions(path.hpo_codes).length} Versionen)
                                 </TooltipContent>
                               </Tooltip>
                             )}
                             <div className="flex items-center gap-4 text-xs text-muted-foreground pl-8">
                               <span className="flex items-center gap-1">
                                 <Clock className="h-3 w-3" />
                                 {format(new Date(path.created_at), 'dd.MM.yyyy HH:mm', { locale: de })}
                               </span>
                               <div className="flex gap-1">
                                 {path.hpo_codes.map(code => (
                                   <Badge key={code} variant="outline" className="font-mono text-xs">{code}</Badge>
                                 ))}
                               </div>
                             </div>
                           </div>
                         </div>
                       </CardHeader>
                       <CollapsibleContent>
                         <CardContent className="pt-0 space-y-6">
                           {/* Mermaid Diagram */}
                           {path.mermaid_diagram && (
                             <div className="space-y-2">
                               <div className="flex items-center justify-between">
                                 <h4 className="font-medium text-sm flex items-center gap-2">
                                   <GitBranch className="h-4 w-4" />
                                   Entscheidungspfad
                                 </h4>
                                 <Tooltip>
                                   <TooltipTrigger asChild>
                                     <Button
                                       variant="ghost"
                                       size="sm"
                                       className="gap-1 h-7"
                                       disabled={regeneratingPathId?.startsWith(path.id) || isGenerating}
                                       onClick={() => handleRegenerateStep(path, 'mermaid_diagram', 'Entscheidungspfad')}
                                     >
                                       {regeneratingPathId === path.id + '-mermaid_diagram' ? (
                                         <Loader2 className="h-3 w-3 animate-spin" />
                                       ) : (
                                         <RefreshCw className="h-3 w-3" />
                                       )}
                                       <span className="text-xs">Neu</span>
                                     </Button>
                                   </TooltipTrigger>
                                   <TooltipContent>Diagramm neu generieren</TooltipContent>
                                 </Tooltip>
                               </div>
                               <Card className="bg-muted/30">
                                 <CardContent className="p-4">
                                   <MermaidDiagram diagram={path.mermaid_diagram} className="max-h-[600px]" />
                                 </CardContent>
                               </Card>
                             </div>
                           )}
 
                           {/* Differential Diagnoses */}
                           {path.differential_diagnoses?.length > 0 && (
                             <div className="space-y-2">
                               <div className="flex items-center justify-between">
                                 <h4 className="font-medium text-sm flex items-center gap-2">
                                   <Stethoscope className="h-4 w-4" />
                                   Differentialdiagnosen
                                 </h4>
                                 <Tooltip>
                                   <TooltipTrigger asChild>
                                     <Button
                                       variant="ghost"
                                       size="sm"
                                       className="gap-1 h-7"
                                       disabled={regeneratingPathId?.startsWith(path.id) || isGenerating}
                                       onClick={() => handleRegenerateStep(path, 'differential_diagnoses', 'Differentialdiagnosen')}
                                     >
                                       {regeneratingPathId === path.id + '-differential_diagnoses' ? (
                                         <Loader2 className="h-3 w-3 animate-spin" />
                                       ) : (
                                         <RefreshCw className="h-3 w-3" />
                                       )}
                                       <span className="text-xs">Neu</span>
                                     </Button>
                                   </TooltipTrigger>
                                   <TooltipContent>Differentialdiagnosen neu generieren</TooltipContent>
                                 </Tooltip>
                               </div>
                               <div className="grid gap-2 md:grid-cols-2">
                                 {path.differential_diagnoses.map((dd, idx) => (
                                   <Card key={idx} className="bg-muted/30">
                                     <CardContent className="p-3">
                                       <div className="flex items-start justify-between mb-1">
                                          <div className="flex items-center gap-2">
                                            <span className="font-medium">{dd.name}</span>
                                            <Tooltip>
                                              <TooltipTrigger asChild>
                                                <Button
                                                  variant="ghost"
                                                  size="icon"
                                                  className="h-6 w-6"
                                                  onClick={() => handleEvidenceSearch(dd.name, dd.icd10)}
                                                >
                                                  <BookOpen className="h-3.5 w-3.5" />
                                                </Button>
                                              </TooltipTrigger>
                                              <TooltipContent>
                                                <p>Evidenz suchen</p>
                                              </TooltipContent>
                                            </Tooltip>
                                          </div>
                                         <Badge variant={dd.probability > 0.5 ? 'default' : 'secondary'}>
                                           {Math.round(dd.probability * 100)}%
                                         </Badge>
                                       </div>
                                       {dd.icd10 && (
                                         <span className="text-xs font-mono text-muted-foreground">ICD-10: {dd.icd10}</span>
                                       )}
                                       <p className="text-xs text-muted-foreground mt-1">{dd.reasoning}</p>
                                     </CardContent>
                                   </Card>
                                 ))}
                               </div>
                             </div>
                           )}
 
                           {/* AI Reasoning */}
                            {path.question_tree && Object.keys(path.question_tree).length > 0 && (
                             <div className="space-y-2">
                               <div className="flex items-center justify-between">
                                 <h4 className="font-medium text-sm flex items-center gap-2">
                                   <HelpCircle className="h-4 w-4" />
                                   Fragenbaum
                                 </h4>
                                 <Tooltip>
                                   <TooltipTrigger asChild>
                                     <Button
                                       variant="ghost"
                                       size="sm"
                                       className="gap-1 h-7"
                                       disabled={regeneratingPathId?.startsWith(path.id) || isGenerating}
                                       onClick={() => handleRegenerateStep(path, 'question_tree', 'Fragenbaum')}
                                     >
                                       {regeneratingPathId === path.id + '-question_tree' ? (
                                         <Loader2 className="h-3 w-3 animate-spin" />
                                       ) : (
                                         <RefreshCw className="h-3 w-3" />
                                       )}
                                       <span className="text-xs">Neu</span>
                                     </Button>
                                   </TooltipTrigger>
                                   <TooltipContent>Fragenbaum neu generieren</TooltipContent>
                                 </Tooltip>
                               </div>
                                <QuestionTreeView 
                                  questionTree={path.question_tree} 
                                  language={i18n.language}
                                  editable={true}
                                  onSave={(updatedTree) => handleSaveQuestionTree(path.id, updatedTree)}
                                />
                             </div>
                           )}

                           {/* AI Reasoning - After Question Tree */}
                           {path.ai_reasoning && (
                             <div className="space-y-2">
                               <div className="flex items-center justify-between">
                                 <h4 className="font-medium text-sm flex items-center gap-2">
                                   <Sparkles className="h-4 w-4" />
                                   KI-Begründung
                                 </h4>
                                 <Tooltip>
                                   <TooltipTrigger asChild>
                                     <Button
                                       variant="ghost"
                                       size="sm"
                                       className="gap-1 h-7"
                                       disabled={regeneratingPathId?.startsWith(path.id) || isGenerating}
                                       onClick={() => handleRegenerateStep(path, 'ai_reasoning', 'KI-Begründung')}
                                     >
                                       {regeneratingPathId === path.id + '-ai_reasoning' ? (
                                         <Loader2 className="h-3 w-3 animate-spin" />
                                       ) : (
                                         <RefreshCw className="h-3 w-3" />
                                       )}
                                       <span className="text-xs">Neu</span>
                                     </Button>
                                   </TooltipTrigger>
                                   <TooltipContent>Begründung neu generieren</TooltipContent>
                                 </Tooltip>
                               </div>
                               <Card className="bg-muted/30">
                                 <CardContent className="p-3">
                                   <p className="text-sm">{path.ai_reasoning}</p>
                                 </CardContent>
                               </Card>
                             </div>
                           )}
                         </CardContent>
                       </CollapsibleContent>
                     </Card>
                   </Collapsible>
                 ))}
               </div>
             )}
           </TabsContent>
 
           {/* By HPO Tab */}
           <TabsContent value="by-hpo" className="mt-6">
             {isLoading ? (
               <Card>
                 <CardContent className="flex items-center justify-center py-12">
                   <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                 </CardContent>
               </Card>
             ) : Object.keys(pathsByHpo).length === 0 ? (
               <Card>
                 <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                   <GitBranch className="h-12 w-12 text-muted-foreground mb-4" />
                   <h3 className="font-medium text-lg">Keine HPO-Pfade verfügbar</h3>
                 </CardContent>
               </Card>
             ) : (
               <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                 {Object.entries(pathsByHpo).map(([hpoCode, hpoPaths]) => (
                   <Card key={hpoCode} className="hover:shadow-md transition-shadow">
                     <CardHeader className="pb-2">
                       <div className="flex items-start justify-between">
                         <div>
                           <Badge variant="outline" className="font-mono text-xs mb-2">{hpoCode}</Badge>
                           <CardTitle className="text-base">{getHpoLabel(hpoCode)}</CardTitle>
                         </div>
                         <Badge>{hpoPaths.length}</Badge>
                       </div>
                     </CardHeader>
                     <CardContent>
                       <div className="space-y-2">
                         {hpoPaths.slice(0, 3).map((path) => (
                           <div 
                             key={path.id}
                             className="flex items-center justify-between text-sm p-2 rounded-md bg-muted/50 cursor-pointer hover:bg-muted"
                             onClick={() => {
                               setExpandedPaths(prev => new Set(prev).add(path.id));
                               setSelectedPath(path);
                             }}
                           >
                             <span className="flex items-center gap-2">
                               {path.is_combined && <Layers className="h-3 w-3" />}
                               v{path.version}
                             </span>
                             <span className="text-xs text-muted-foreground">
                               {format(new Date(path.created_at), 'dd.MM.yy', { locale: de })}
                             </span>
                           </div>
                         ))}
                         {hpoPaths.length > 3 && (
                           <p className="text-xs text-muted-foreground text-center pt-1">
                             +{hpoPaths.length - 3} weitere Pfade
                           </p>
                         )}
                       </div>
                     </CardContent>
                   </Card>
                 ))}
               </div>
             )}
           </TabsContent>
         </Tabs>

         {/* Version Compare Dialog */}
         <PathVersionCompare
           open={showVersionCompare}
           onOpenChange={setShowVersionCompare}
           versions={getPathVersions(comparePathHpoCodes)}
           hpoLabels={hpoLabels || {}}
         />
       </div>
     </AppLayout>
   );
 }