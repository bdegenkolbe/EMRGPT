import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { 
  Stethoscope, 
  FileText, 
  Users, 
  Activity,
  ArrowRight,
  Clock,
  GitBranch,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { SessionProgressBadges, type AnamnesisCategory } from '@/components/anamnesis/SessionProgressBadges';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

export default function Dashboard() {
  const { t } = useTranslation();
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();

  // Fetch recent sessions with their paths
  const { data: recentSessions, isLoading: isLoadingSessions } = useQuery({
    queryKey: ['dashboard-recent-sessions'],
    queryFn: async () => {
      const { data: sessions, error } = await supabase
        .from('anamnesis_sessions')
        .select('id, clinical_view, status, created_at, completed_at, patient_identifier')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      if (!sessions?.length) return [];

      const sessionIds = sessions.map(s => s.id);
      const { data: paths } = await supabase
        .from('anamnesis_paths')
        .select('session_id, differential_diagnoses, hpo_codes')
        .in('session_id', sessionIds);

      const { data: obsCount } = await supabase
        .from('observations')
        .select('session_id')
        .in('session_id', sessionIds);

      return sessions.map(session => {
        const sessionPaths = paths?.filter(p => p.session_id === session.id) || [];
        const sessionObs = obsCount?.filter(o => o.session_id === session.id) || [];
        
        const allDiagnoses = sessionPaths.flatMap(p => 
          (p.differential_diagnoses as { name: string; probability: number }[]) || []
        );
        const uniqueDiagnoses = [...new Set(allDiagnoses.map(d => d.name))];
        
        const completedCategories: AnamnesisCategory[] = [];
        if (sessionObs.length > 0) completedCategories.push('chief_complaint');
        if (sessionObs.length >= 2) completedCategories.push('hpi');
        if (sessionObs.length >= 3) completedCategories.push('ros');
        if (sessionObs.length >= 4) completedCategories.push('pmh');
        if (sessionObs.length >= 5) completedCategories.push('medications');
        if (sessionObs.length >= 6) completedCategories.push('social');
        if (sessionObs.length >= 7) completedCategories.push('family');
        if (session.status === 'completed') completedCategories.push('summary');

        return {
          ...session,
          pathCount: sessionPaths.length,
          diagnosesCount: uniqueDiagnoses.length,
          observationsCount: sessionObs.length,
          hpoCodes: [...new Set(sessionPaths.flatMap(p => p.hpo_codes || []))],
          completedCategories,
        };
      });
    },
  });

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Welcome Section */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            {t('dashboard.welcome', { name: user?.email?.split('@')[0] || t('common.user') })}
          </h1>
          <p className="text-muted-foreground">
            {t('dashboard.subtitle')}
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card className="cursor-pointer transition-shadow hover:shadow-md" onClick={() => navigate('/anamnesis')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('dashboard.newAnamnesis')}</CardTitle>
              <Stethoscope className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <CardDescription>{t('dashboard.newAnamnesisDesc')}</CardDescription>
              <Button variant="link" className="mt-2 p-0">
                {t('common.start')} <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          <Card className="cursor-pointer transition-shadow hover:shadow-md" onClick={() => navigate('/sessions')}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('dashboard.mySessions')}</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <CardDescription>{t('dashboard.mySessionsDesc')}</CardDescription>
              <Button variant="link" className="mt-2 p-0">
                {t('common.view')} <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          {isAdmin && (
            <Card className="cursor-pointer transition-shadow hover:shadow-md" onClick={() => navigate('/admin/users')}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t('dashboard.manageUsers')}</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{t('dashboard.manageUsersDesc')}</CardDescription>
                <Button variant="link" className="mt-2 p-0">
                  {t('common.manage')} <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('dashboard.totalSessions')}</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {recentSessions !== undefined ? recentSessions.length : '—'}
              </div>
              <p className="text-xs text-muted-foreground">
                {recentSessions?.length ? 'Letzte 5 Sitzungen' : t('dashboard.noData')}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('dashboard.completedToday')}</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {recentSessions?.filter(s => s.status === 'completed').length ?? '—'}
              </div>
              <p className="text-xs text-muted-foreground">
                {recentSessions?.filter(s => s.status === 'completed').length 
                  ? 'Abgeschlossen' 
                  : t('dashboard.noData')}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Sessions with Progress */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="flex items-center gap-2">
              <Stethoscope className="h-5 w-5" />
              <div>
                <CardTitle className="text-lg">Letzte Anamnesesitzungen</CardTitle>
                <CardDescription>
                  Kategorien-Fortschritt und Differentialdiagnosen
                </CardDescription>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/sessions')}>
              Alle anzeigen
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            {isLoadingSessions ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Skeleton className="h-10 w-full" />
                  </div>
                ))}
              </div>
            ) : !recentSessions || recentSessions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Stethoscope className="h-10 w-10 mx-auto mb-2 opacity-50" />
                <p>Noch keine Anamnesesitzungen vorhanden</p>
                <Button 
                  variant="link" 
                  className="mt-2"
                  onClick={() => navigate('/anamnesis')}
                >
                  Erste Anamnese starten <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {recentSessions.map((session) => (
                  <div
                    key={session.id}
                    className="p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => navigate(
                      session.status === 'completed' 
                        ? `/sessions/${session.id}` 
                        : `/anamnesis?session=${session.id}`
                    )}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Badge variant={session.status === 'completed' ? 'default' : 'secondary'}>
                          {session.status === 'completed' ? 'Abgeschlossen' : 'In Bearbeitung'}
                        </Badge>
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {format(new Date(session.created_at), 'dd.MM.yy HH:mm', { locale: de })}
                        </span>
                        {session.patient_identifier && (
                          <Badge variant="outline" className="text-xs">
                            {session.patient_identifier}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {session.pathCount > 0 && (
                          <Badge variant="outline" className="gap-1 text-xs">
                            <GitBranch className="h-3 w-3" />
                            {session.pathCount} Pfade
                          </Badge>
                        )}
                        {session.diagnosesCount > 0 && (
                          <Badge variant="outline" className="gap-1 text-xs text-primary border-primary/30">
                            <Stethoscope className="h-3 w-3" />
                            {session.diagnosesCount} DD
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <SessionProgressBadges
                      completedCategories={session.completedCategories}
                      currentCategory={session.status === 'in_progress' ? 'hpi' : undefined}
                      compact={false}
                      language="de"
                    />
                    
                    {session.hpoCodes.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {session.hpoCodes.slice(0, 3).map((code) => (
                          <Badge key={code} variant="secondary" className="text-[10px] font-mono">
                            {code}
                          </Badge>
                        ))}
                        {session.hpoCodes.length > 3 && (
                          <Badge variant="secondary" className="text-[10px]">
                            +{session.hpoCodes.length - 3}
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
