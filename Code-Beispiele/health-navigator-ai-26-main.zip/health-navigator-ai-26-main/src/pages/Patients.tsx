import { useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PatientList } from '@/components/patients/PatientList';
import { PatientOverview } from '@/components/patients/PatientOverview';
import { PatientConditions } from '@/components/patients/PatientConditions';
import { PatientLabValues } from '@/components/patients/PatientLabValues';
import { PatientMedications } from '@/components/patients/PatientMedications';
import { PatientEncounters } from '@/components/patients/PatientEncounters';
import { PatientAllergies } from '@/components/patients/PatientAllergies';
import { PatientChat } from '@/components/patients/PatientChat';
import { PatientEvidenceSidebar } from '@/components/patients/PatientEvidenceSidebar';
import { FhirPatient } from '@/hooks/useFhirPatients';
import { Stethoscope } from 'lucide-react';

export default function Patients() {
  const [selectedPatient, setSelectedPatient] = useState<FhirPatient | null>(null);

  return (
    <AppLayout>
      <div className="h-[calc(100vh-4rem)] -m-6 flex flex-col">
        <ResizablePanelGroup direction="horizontal" className="flex-1">
          {/* Patient List */}
          <ResizablePanel defaultSize={18} minSize={14} maxSize={28}>
            <PatientList 
              selectedId={selectedPatient?.id || null} 
              onSelect={setSelectedPatient} 
            />
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Main Content */}
          <ResizablePanel defaultSize={58} minSize={40}>
            {selectedPatient ? (
              <ResizablePanelGroup direction="vertical">
                {/* Patient Record Tabs */}
                <ResizablePanel defaultSize={65} minSize={30}>
                  <Tabs defaultValue="overview" className="h-full flex flex-col">
                    <div className="border-b px-3">
                      <TabsList className="h-9 bg-transparent gap-1">
                        <TabsTrigger value="overview" className="text-xs h-7 data-[state=active]:bg-primary/10">Übersicht</TabsTrigger>
                        <TabsTrigger value="encounters" className="text-xs h-7 data-[state=active]:bg-primary/10">Aufenthalte</TabsTrigger>
                        <TabsTrigger value="conditions" className="text-xs h-7 data-[state=active]:bg-primary/10">Diagnosen</TabsTrigger>
                        <TabsTrigger value="lab" className="text-xs h-7 data-[state=active]:bg-primary/10">Labor</TabsTrigger>
                        <TabsTrigger value="medications" className="text-xs h-7 data-[state=active]:bg-primary/10">Medikation</TabsTrigger>
                        <TabsTrigger value="allergies" className="text-xs h-7 data-[state=active]:bg-primary/10">Allergien</TabsTrigger>
                      </TabsList>
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <TabsContent value="overview" className="h-full m-0 overflow-auto">
                        <PatientOverview patient={selectedPatient} />
                      </TabsContent>
                      <TabsContent value="encounters" className="h-full m-0">
                        <PatientEncounters patientId={selectedPatient.id} />
                      </TabsContent>
                      <TabsContent value="conditions" className="h-full m-0">
                        <PatientConditions patientId={selectedPatient.id} />
                      </TabsContent>
                      <TabsContent value="lab" className="h-full m-0">
                        <PatientLabValues patientId={selectedPatient.id} />
                      </TabsContent>
                      <TabsContent value="medications" className="h-full m-0">
                        <PatientMedications patientId={selectedPatient.id} />
                      </TabsContent>
                      <TabsContent value="allergies" className="h-full m-0">
                        <PatientAllergies patientId={selectedPatient.id} />
                      </TabsContent>
                    </div>
                  </Tabs>
                </ResizablePanel>

                <ResizableHandle withHandle />

                {/* Chat */}
                <ResizablePanel defaultSize={35} minSize={20}>
                  <PatientChat 
                    patientId={selectedPatient.id} 
                    patientName={`${selectedPatient.given_name} ${selectedPatient.family_name}`}
                  />
                </ResizablePanel>
              </ResizablePanelGroup>
            ) : (
              <div className="flex h-full items-center justify-center">
                <div className="text-center space-y-3">
                  <Stethoscope className="h-12 w-12 mx-auto text-muted-foreground/30" />
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Kein Patient ausgewählt</p>
                    <p className="text-xs text-muted-foreground/70 mt-1">Wählen Sie einen Patienten aus der Liste oder importieren Sie ein FHIR Bundle.</p>
                  </div>
                </div>
              </div>
            )}
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Evidence Sidebar */}
          <ResizablePanel defaultSize={24} minSize={16} maxSize={35}>
            {selectedPatient ? (
              <PatientEvidenceSidebar patientId={selectedPatient.id} />
            ) : (
              <div className="flex h-full items-center justify-center border-l bg-card">
                <p className="text-xs text-muted-foreground text-center px-4">
                  Evidenz wird automatisch angezeigt, wenn ein Patient mit aktiven Diagnosen ausgewählt ist.
                </p>
              </div>
            )}
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </AppLayout>
  );
}
