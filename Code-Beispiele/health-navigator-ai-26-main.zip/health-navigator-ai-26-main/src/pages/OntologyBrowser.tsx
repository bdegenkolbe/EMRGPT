import { useState, useRef, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TreeDeciduous, Stethoscope, ArrowLeftRight, Layers, FileCode, ArrowLeft, Heart, GitBranch, Globe } from 'lucide-react';
import { HpoBrowser } from '@/components/ontology/HpoBrowser';
import { SnomedBrowser } from '@/components/ontology/SnomedBrowser';
import { OntologyMappingView } from '@/components/ontology/OntologyMappingView';
import { MappingHubView } from '@/components/ontology/MappingHubView';
import { UnifiedSearchView } from '@/components/ontology/UnifiedSearchView';
import { Icd10GmBrowser } from '@/components/ontology/Icd10GmBrowser';
import { Icd11Browser } from '@/components/ontology/Icd11Browser';
import { OrphanetBrowser } from '@/components/ontology/OrphanetBrowser';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';

const TABS = ['unified', 'hpo', 'snomed', 'icd10', 'icd11', 'orphanet', 'mapping', 'hub'] as const;
type TabType = typeof TABS[number];

export default function OntologyBrowser() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const initialTab = (searchParams.get('tab') as TabType) || 'unified';
  const [activeTab, setActiveTab] = useState<TabType>(initialTab);
  const [previousTab, setPreviousTab] = useState<TabType | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const isMobile = useIsMobile();

  // Back navigation params
  const backTab = searchParams.get('backTab');
  const backCode = searchParams.get('backCode');
  const searchQuery = searchParams.get('search');

  const handleTabChange = (value: string) => {
    if (value === activeTab) return;
    
    setPreviousTab(activeTab);
    setIsAnimating(true);
    setActiveTab(value as TabType);
    // Clear back params when manually changing tabs
    setSearchParams({ tab: value });
  };

  const handleBackNavigation = () => {
    if (backTab && backCode) {
      navigate(`/ontology?tab=${backTab}&search=${encodeURIComponent(backCode)}`);
    }
  };

  // Reset animation state after transition
  useEffect(() => {
    if (isAnimating) {
      const timer = setTimeout(() => {
        setIsAnimating(false);
        setPreviousTab(null);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isAnimating]);

  // Determine slide direction based on tab order
  const getSlideDirection = () => {
    if (!previousTab) return 'none';
    const prevIndex = TABS.indexOf(previousTab);
    const currIndex = TABS.indexOf(activeTab);
    return currIndex > prevIndex ? 'left' : 'right';
  };

  const slideDirection = getSlideDirection();

  const getDescription = () => {
    switch (activeTab) {
      case 'unified':
        return 'Durchsuche HPO und SNOMED CT gleichzeitig';
      case 'hpo':
        return 'Human Phenotype Ontology - Medizinische Phänotypen strukturiert durchsuchen';
      case 'snomed':
        return 'SNOMED CT - Systematisierte Nomenklatur der Medizin';
      case 'icd10':
        return 'ICD-10-GM - Internationale Klassifikation der Krankheiten (German Modification)';
      case 'icd11':
        return 'ICD-11 - WHO Internationale Klassifikation der Krankheiten (2024)';
      case 'orphanet':
        return 'Orphanet - Seltene Erkrankungen (ORPHAcodes) mit KI-Übersetzung';
      case 'mapping':
        return 'Finde Zuordnungen zwischen HPO und SNOMED CT Konzepten';
      case 'hub':
        return 'Cross-Ontology Mappings verwalten und validieren';
      default:
        return '';
    }
  };

  const getIcon = () => {
    switch (activeTab) {
      case 'unified':
        return <Layers className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      case 'hpo':
        return <TreeDeciduous className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      case 'snomed':
        return <Stethoscope className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      case 'icd10':
        return <FileCode className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      case 'icd11':
        return <Globe className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      case 'orphanet':
        return <Heart className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      case 'mapping':
        return <ArrowLeftRight className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      case 'hub':
        return <GitBranch className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
      default:
        return <Layers className="h-6 w-6 md:h-8 md:w-8 text-primary" />;
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'unified':
        return <UnifiedSearchView />;
      case 'hpo':
        return <HpoBrowser />;
      case 'snomed':
        return <SnomedBrowser />;
      case 'icd10':
        return <Icd10GmBrowser />;
      case 'icd11':
        return <Icd11Browser />;
      case 'orphanet':
        return <OrphanetBrowser />;
      case 'mapping':
        return <OntologyMappingView />;
      case 'hub':
        return <MappingHubView />;
      default:
        return null;
    }
  };

  return (
    <AppLayout>
      <div className="h-[calc(100vh-4rem)] flex flex-col">
        {/* Header with Tabs */}
        <div className="border-b">
          <div className="p-3 md:p-4 pb-0">
            <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
              {/* Back button when coming from another tab */}
              {backTab && backCode && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 px-2 shrink-0"
                  onClick={handleBackNavigation}
                >
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Zurück zu</span>
                  <Badge variant="outline" className="ml-1 text-xs font-mono">
                    {backCode}
                  </Badge>
                </Button>
              )}
              <div className={cn(
                'transition-all duration-300',
                isAnimating && 'animate-pulse'
              )}>
                {getIcon()}
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="text-lg md:text-2xl font-bold truncate">Ontologie Browser</h1>
                <p className={cn(
                  'text-muted-foreground text-xs md:text-sm line-clamp-1',
                  'transition-opacity duration-200',
                  isAnimating ? 'opacity-0' : 'opacity-100'
                )}>
                  {getDescription()}
                </p>
              </div>
            </div>
            
            <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
              <TabsList className="w-full grid grid-cols-8 h-auto">
                <TabsTrigger value="unified" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <Layers className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'unified' && 'scale-110')} />
                  <span className="hidden lg:inline">Suche</span>
                </TabsTrigger>
                <TabsTrigger value="hpo" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <TreeDeciduous className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'hpo' && 'scale-110')} />
                  <span className="hidden lg:inline">HPO</span>
                </TabsTrigger>
                <TabsTrigger value="snomed" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <Stethoscope className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'snomed' && 'scale-110')} />
                  <span className="hidden lg:inline">SNOMED</span>
                </TabsTrigger>
                <TabsTrigger value="icd10" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <FileCode className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'icd10' && 'scale-110')} />
                  <span className="hidden lg:inline">ICD-10</span>
                </TabsTrigger>
                <TabsTrigger value="icd11" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <Globe className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'icd11' && 'scale-110')} />
                  <span className="hidden lg:inline">ICD-11</span>
                </TabsTrigger>
                <TabsTrigger value="orphanet" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <Heart className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'orphanet' && 'scale-110')} />
                  <span className="hidden lg:inline">Orphanet</span>
                </TabsTrigger>
                <TabsTrigger value="mapping" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <ArrowLeftRight className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'mapping' && 'scale-110')} />
                  <span className="hidden lg:inline">Mapping</span>
                </TabsTrigger>
                <TabsTrigger value="hub" className="flex items-center gap-1 md:gap-2 px-1.5 py-1.5 md:px-2 md:py-2 text-xs md:text-sm">
                  <GitBranch className={cn('h-3.5 w-3.5 md:h-4 md:w-4', activeTab === 'hub' && 'scale-110')} />
                  <span className="hidden lg:inline">Hub</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Tab Content with Animation */}
        <div className="flex-1 min-h-0 overflow-hidden relative">
          <div
            className={cn(
              'absolute inset-0 transition-all duration-300 ease-out',
              isAnimating && slideDirection === 'left' && 'animate-slide-in-from-right',
              isAnimating && slideDirection === 'right' && 'animate-slide-in-from-left',
              !isAnimating && 'opacity-100'
            )}
            style={{
              animation: isAnimating 
                ? slideDirection === 'left' 
                  ? 'slideInFromRight 0.3s ease-out forwards'
                  : 'slideInFromLeft 0.3s ease-out forwards'
                : undefined
            }}
          >
            {renderTabContent()}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideInFromRight {
          from {
            opacity: 0;
            transform: translateX(20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        @keyframes slideInFromLeft {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
      `}</style>
    </AppLayout>
  );
}
