import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { AppLayout } from '@/components/layout/AppLayout';
import { useIntegrations } from '@/hooks/useIntegrations';
import { useIcd10Gm } from '@/hooks/useIcd10Gm';
import { OntologyStatistics } from '@/components/admin/OntologyStatistics';
import { ScheduledSyncConfig } from '@/components/admin/ScheduledSyncConfig';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Loader2, Plus, Trash2, Activity, Sparkles, Brain, BookOpen, RefreshCw, Database, Calendar, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

const PROVIDERS = [
  { id: 'gemini', name: 'Google Gemini', icon: Sparkles },
  { id: 'chatgpt', name: 'OpenAI ChatGPT', icon: Brain },
  { id: 'ncbi', name: 'NCBI/PubMed', icon: BookOpen },
];

export default function Integrations() {
  const { t } = useTranslation();
  const { integrations, isLoading, createIntegration, toggleIntegration, deleteIntegration } =
    useIntegrations();
  const { syncStatus, isSyncing, fetchSyncStatus, triggerSync } = useIcd10Gm();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newProvider, setNewProvider] = useState('');
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  // Fetch sync status on mount
  useEffect(() => {
    fetchSyncStatus();
  }, [fetchSyncStatus]);

  const handleCreate = () => {
    if (newName && newProvider) {
      createIntegration.mutate(
        { name: newName, provider: newProvider },
        {
          onSuccess: () => {
            setIsDialogOpen(false);
            setNewName('');
            setNewProvider('');
          },
        }
      );
    }
  };

  const getProviderIcon = (provider: string) => {
    const p = PROVIDERS.find((pr) => pr.id === provider);
    return p ? <p.icon className="h-5 w-5" /> : <Activity className="h-5 w-5" />;
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              {t('admin.integrations.title')}
            </h1>
            <p className="text-muted-foreground">
              {t('admin.integrations.description', { defaultValue: 'AI und Evidenz-APIs verwalten' })}
            </p>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                {t('admin.integrations.addIntegration')}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t('admin.integrations.addIntegration')}</DialogTitle>
                <DialogDescription>
                  {t('admin.integrations.addDescription', { defaultValue: 'Neue Integration konfigurieren' })}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">{t('admin.integrations.name', { defaultValue: 'Name' })}</Label>
                  <Input
                    id="name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="z.B. Gemini Pro"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="provider">{t('admin.integrations.provider')}</Label>
                  <Select value={newProvider} onValueChange={setNewProvider}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('admin.integrations.selectProvider', { defaultValue: 'Provider wählen' })} />
                    </SelectTrigger>
                    <SelectContent>
                      {PROVIDERS.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={handleCreate}
                disabled={createIntegration.isPending || !newName || !newProvider}
                className="w-full"
              >
                {createIntegration.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                {t('common.create')}
              </Button>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {integrations?.map((integration) => (
            <Card key={integration.id}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="flex items-center gap-2">
                  {getProviderIcon(integration.provider)}
                  <CardTitle className="text-base font-medium">
                    {integration.name}
                  </CardTitle>
                </div>
                <Badge variant={integration.is_active ? 'default' : 'secondary'}>
                  {integration.is_active
                    ? t('admin.integrations.active')
                    : t('admin.integrations.inactive')}
                </Badge>
              </CardHeader>
              <CardContent>
                <CardDescription className="mb-4">
                  {t(`admin.integrations.providers.${integration.provider}`, { defaultValue: integration.provider })}
                </CardDescription>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={integration.is_active}
                      onCheckedChange={(checked) =>
                        toggleIntegration.mutate({
                          id: integration.id,
                          isActive: checked,
                        })
                      }
                    />
                    <Label className="text-sm text-muted-foreground">
                      {t('admin.integrations.status')}
                    </Label>
                  </div>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          {t('admin.integrations.deleteConfirm', { defaultValue: 'Integration löschen?' })}
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          {t('admin.integrations.deleteWarning', { defaultValue: 'Diese Aktion kann nicht rückgängig gemacht werden.' })}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deleteIntegration.mutate(integration.id)}
                          className="bg-destructive text-destructive-foreground"
                        >
                          {t('common.delete')}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}

          {(!integrations || integrations.length === 0) && (
            <Card className="col-span-full">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Activity className="mb-4 h-12 w-12 text-muted-foreground" />
                <p className="text-muted-foreground">
                  {t('admin.integrations.noIntegrations', { defaultValue: 'Keine Integrationen konfiguriert' })}
                </p>
                <Button
                  variant="link"
                  onClick={() => setIsDialogOpen(true)}
                  className="mt-2"
                >
                  {t('admin.integrations.addFirst', { defaultValue: 'Erste Integration hinzufügen' })}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* ICD-10-GM Sync Section */}
        <div className="mt-8 pt-6 border-t">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Database className="h-5 w-5" />
            Terminologie-Datenbanken
          </h2>
          
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">ICD-10-GM Katalog</CardTitle>
                  <CardDescription>
                    Internationale statistische Klassifikation der Krankheiten (Deutsche Modifikation)
                  </CardDescription>
                </div>
                {syncStatus && syncStatus.total_codes > 0 && (
                  <Badge variant="outline" className="gap-1">
                    <CheckCircle2 className="h-3 w-3" />
                    {syncStatus.total_codes.toLocaleString()} Codes
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Sync Status */}
                {syncStatus && syncStatus.last_sync && (
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Letzte Sync: {format(new Date(syncStatus.last_sync), 'dd.MM.yyyy HH:mm', { locale: de })}
                    </span>
                    {syncStatus.year && (
                      <span>Jahr: {syncStatus.year}</span>
                    )}
                  </div>
                )}
                
                {/* Sync Controls */}
                <div className="flex items-center gap-3">
                  <Select 
                    value={selectedYear.toString()} 
                    onValueChange={(v) => setSelectedYear(parseInt(v))}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[2025, 2024, 2023, 2022].map((year) => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Button 
                    onClick={() => triggerSync(selectedYear, false)}
                    disabled={isSyncing}
                  >
                    {isSyncing ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <RefreshCw className="mr-2 h-4 w-4" />
                    )}
                    Synchronisieren
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={() => triggerSync(selectedYear, true)}
                    disabled={isSyncing}
                  >
                    Neu laden (Force)
                  </Button>
                </div>
                
                {isSyncing && (
                  <div className="space-y-2">
                    <Progress value={undefined} className="h-2" />
                    <p className="text-sm text-muted-foreground">
                      Importiere ICD-10-GM Codes...
                    </p>
                  </div>
                )}
                
                <p className="text-xs text-muted-foreground">
                  Die Daten basieren auf dem offiziellen BfArM ICD-10-GM Katalog. 
                  Bei aktiviertem Cron-Job wird wöchentlich automatisch synchronisiert.
                </p>
              </div>
            </CardContent>
        </Card>
        </div>

        {/* Scheduled Sync Config Section */}
        <div className="mt-8 pt-6 border-t">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Geplante Synchronisation
          </h2>
          <ScheduledSyncConfig />
        </div>

        {/* Ontology Statistics Section */}
        <div className="mt-8 pt-6 border-t">
          <OntologyStatistics />
        </div>
      </div>
    </AppLayout>
  );
}
