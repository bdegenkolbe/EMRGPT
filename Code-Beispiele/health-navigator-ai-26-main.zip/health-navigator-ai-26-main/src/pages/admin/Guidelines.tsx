import { useState, useCallback, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient, keepPreviousData } from '@tanstack/react-query';
import { useDropzone } from 'react-dropzone';
import { 
  FileText, 
  Upload, 
  Trash2, 
  Search, 
  Loader2,
  CheckCircle,
  XCircle,
  Clock,
  RefreshCw,
  AlertCircle,
  BookOpen,
  Calendar,
  Building2,
  Sparkles,
  Edit2,
  Save,
  X,
  Library,
  Globe
} from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { UnifiedKnowledgeSearch } from '@/components/knowledge';

// Helper to strip HTML tags for plain text display
const stripHtmlTags = (html: string): string => {
  if (!html) return '';
  // Decode HTML entities and strip tags
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return doc.body.textContent || '';
};

interface Guideline {
  id: string;
  title: string;
  description: string | null;
  source: string | null;
  version: string | null;
  valid_from: string | null;
  valid_until: string | null;
  file_name: string | null;
  file_size: number | null;
  total_chunks: number;
  embedding_status: 'pending' | 'processing' | 'completed' | 'failed';
  embedding_error: string | null;
  embedding_progress: number;
  created_at: string;
  detected_icd10_codes: string[] | null;
  detected_hpo_codes: string[] | null;
  detected_snomed_codes: string[] | null;
}

interface PendingUpload {
  id: string;
  file: File;
  status: 'extracting' | 'ready' | 'uploading' | 'error';
  progress: number;
  error?: string;
  metadata: {
    title: string;
    description: string;
    source: string;
    version: string;
    validFrom: string;
    validUntil: string;
  };
  textContent: string;
  detectedCodes: {
    icd10: string[];
    hpo: string[];
    snomed: string[];
  };
}

const PAGE_SIZE = 50;

export default function GuidelinesAdmin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [page, setPage] = useState(0);
  const [pendingUploads, setPendingUploads] = useState<PendingUpload[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Guideline>>({});
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  // Generate unique ID for uploads
  const generateId = () => Math.random().toString(36).substring(2, 11);

  // Debounce search
  useEffect(() => {
    debounceRef.current = setTimeout(() => {
      setDebouncedSearch(searchTerm);
      setPage(0); // Reset to first page on search
    }, 300);
    return () => clearTimeout(debounceRef.current);
  }, [searchTerm]);

  // Fetch total count
  const { data: totalCount } = useQuery({
    queryKey: ['guidelines-count', debouncedSearch],
    queryFn: async () => {
      let query = supabase
        .from('guidelines')
        .select('id', { count: 'exact', head: true });
      
      if (debouncedSearch) {
        query = query.or(`title.ilike.%${debouncedSearch}%,source.ilike.%${debouncedSearch}%,description.ilike.%${debouncedSearch}%`);
      }
      
      const { count, error } = await query;
      if (error) throw error;
      return count ?? 0;
    },
  });

  // Fetch guidelines with server-side pagination + search
  const { data: guidelines, isLoading } = useQuery({
    queryKey: ['guidelines', debouncedSearch, page],
    queryFn: async () => {
      const from = page * PAGE_SIZE;
      const to = from + PAGE_SIZE - 1;

      let query = supabase
        .from('guidelines')
        .select('*')
        .order('created_at', { ascending: false })
        .range(from, to);
      
      if (debouncedSearch) {
        query = query.or(`title.ilike.%${debouncedSearch}%,source.ilike.%${debouncedSearch}%,description.ilike.%${debouncedSearch}%`);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as Guideline[];
    },
    placeholderData: keepPreviousData,
    refetchInterval: (query) => {
      const data = query.state.data;
      const hasProcessing = data?.some(g => g.embedding_status === 'processing');
      return hasProcessing ? 3000 : false;
    },
  });

  const totalPages = Math.ceil((totalCount ?? 0) / PAGE_SIZE);

  // Update guideline metadata mutation
  const updateMutation = useMutation({
    mutationFn: async (data: { id: string; updates: Partial<Guideline> }) => {
      const { error } = await supabase
        .from('guidelines')
        .update({
          title: data.updates.title,
          description: data.updates.description,
          source: data.updates.source,
          version: data.updates.version,
          valid_from: data.updates.valid_from || null,
          valid_until: data.updates.valid_until || null,
        })
        .eq('id', data.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['guidelines'] });
      toast({ title: 'Metadaten aktualisiert' });
      setEditingId(null);
    },
    onError: (error: Error) => {
      toast({ 
        variant: 'destructive', 
        title: 'Fehler beim Speichern', 
        description: error.message 
      });
    },
  });

  // Reset stuck processing mutation
  const resetStuckMutation = useMutation({
    mutationFn: async (guidelineId: string) => {
      const { error } = await supabase
        .from('guidelines')
        .update({ 
          embedding_status: 'pending', 
          embedding_progress: 0,
          embedding_error: null 
        })
        .eq('id', guidelineId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['guidelines'] });
      toast({ title: 'Status zurückgesetzt' });
    },
  });

  // Re-embed mutation - fetch chunks and re-embed them
  const reEmbedMutation = useMutation({
    mutationFn: async (guidelineId: string) => {
      // First, get existing chunks to reconstruct content
      const { data: chunks, error: chunksError } = await supabase
        .from('guideline_chunks')
        .select('content, chunk_index')
        .eq('guideline_id', guidelineId)
        .order('chunk_index', { ascending: true });

      let textContent = '';
      
      if (!chunksError && chunks && chunks.length > 0) {
        // Reconstruct content from chunks
        textContent = chunks.map(c => c.content).join(' ');
        console.log(`Reconstructed ${textContent.length} chars from ${chunks.length} chunks`);
      } else {
        // No chunks available - update status with error message
        await supabase
          .from('guidelines')
          .update({ 
            embedding_status: 'failed', 
            embedding_progress: 0,
            embedding_error: 'Kein Text-Inhalt vorhanden. Bitte Leitlinie löschen und erneut hochladen.'
          })
          .eq('id', guidelineId);
        throw new Error('Kein Text-Inhalt vorhanden. Bitte Leitlinie löschen und erneut hochladen.');
      }

      // Delete existing chunks (they will be recreated with embeddings)
      await supabase
        .from('guideline_chunks')
        .delete()
        .eq('guideline_id', guidelineId);

      // Set status to processing
      await supabase
        .from('guidelines')
        .update({ 
          embedding_status: 'processing', 
          embedding_progress: 0,
          embedding_error: null 
        })
        .eq('id', guidelineId);

      // Call embed function with sync mode for reliable processing
      const { data, error } = await supabase.functions.invoke('guidelines-embed', {
        body: {
          guideline_id: guidelineId,
          content: textContent,
          sync: true,
        },
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['guidelines'] });
      toast({ title: 'Vektorisierung gestartet' });
    },
    onError: (error: Error) => {
      toast({ 
        variant: 'destructive', 
        title: 'Fehler', 
        description: error.message 
      });
      queryClient.invalidateQueries({ queryKey: ['guidelines'] });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (guidelineId: string) => {
      const { error } = await supabase
        .from('guidelines')
        .delete()
        .eq('id', guidelineId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['guidelines'] });
      queryClient.invalidateQueries({ queryKey: ['guidelines-count'] });
      toast({ title: 'Leitlinie gelöscht' });
    },
    onError: (error: Error) => {
      toast({ 
        variant: 'destructive', 
        title: 'Fehler beim Löschen', 
        description: error.message 
      });
    },
  });

  // Helper to parse dates
  const parseDate = (dateStr: string | undefined): string | null => {
    if (!dateStr || dateStr === 'Unbekannt' || dateStr.trim() === '') return null;
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return dateStr;
    if (/^\d{4}-\d{2}$/.test(dateStr)) return `${dateStr}-01`;
    if (/^\d{4}$/.test(dateStr)) return `${dateStr}-01-01`;
    const date = new Date(dateStr);
    if (!isNaN(date.getTime())) return date.toISOString().split('T')[0];
    return null;
  };

  // Process dropped files
  const processFile = async (file: File, uploadId: string) => {
    try {
      // Check if it's a text file
      if (file.type === 'text/plain' || file.name.endsWith('.txt') || file.name.endsWith('.md')) {
        setPendingUploads(prev => prev.map(u => 
          u.id === uploadId ? { ...u, progress: 50 } : u
        ));
        
        const text = await file.text();
        setPendingUploads(prev => prev.map(u => 
          u.id === uploadId ? { 
            ...u, 
            status: 'ready', 
            progress: 100,
            metadata: {
              ...u.metadata,
              title: file.name.replace(/\.[^/.]+$/, ''),
            },
            textContent: text,
          } : u
        ));
        return;
      }

      // PDF - call parsing function
      setPendingUploads(prev => prev.map(u => 
        u.id === uploadId ? { ...u, progress: 20 } : u
      ));
      
      const arrayBuffer = await file.arrayBuffer();
      const base64 = btoa(
        new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
      );
      
      setPendingUploads(prev => prev.map(u => 
        u.id === uploadId ? { ...u, progress: 40 } : u
      ));

      const { data, error } = await supabase.functions.invoke('guidelines-parse', {
        body: {
          file_base64: base64,
          file_name: file.name,
          file_size: file.size,
        },
      });

      if (error) throw error;

      setPendingUploads(prev => prev.map(u => 
        u.id === uploadId ? { 
          ...u, 
          status: 'ready', 
          progress: 100,
          metadata: {
            title: stripHtmlTags(data?.title || file.name.replace(/\.[^/.]+$/, '')),
            description: stripHtmlTags(data?.description || ''),
            source: stripHtmlTags(data?.source || ''),
            version: data?.version || '',
            validFrom: data?.validFrom || '',
            validUntil: data?.validUntil || '',
          },
          textContent: data?.textContent || '',
          detectedCodes: {
            icd10: data?.icd10Codes || [],
            hpo: data?.hpoCodes || [],
            snomed: data?.snomedCodes || [],
          },
        } : u
      ));
    } catch (err) {
      console.error('Extraction error:', err);
      setPendingUploads(prev => prev.map(u => 
        u.id === uploadId ? { 
          ...u, 
          status: 'error', 
          error: 'Extraktionsfehler',
          metadata: {
            ...u.metadata,
            title: file.name.replace(/\.[^/.]+$/, ''),
          },
        } : u
      ));
    }
  };

  // Handle file drop
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const newUploads: PendingUpload[] = acceptedFiles.map(file => ({
      id: generateId(),
      file,
      status: 'extracting' as const,
      progress: 10,
      metadata: {
        title: '',
        description: '',
        source: '',
        version: '',
        validFrom: '',
        validUntil: '',
      },
      textContent: '',
      detectedCodes: { icd10: [], hpo: [], snomed: [] },
    }));

    setPendingUploads(prev => [...prev, ...newUploads]);

    // Process each file
    for (const upload of newUploads) {
      await processFile(upload.file, upload.id);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
    },
    maxSize: 50 * 1024 * 1024,
    noClick: pendingUploads.length > 0 || (totalCount ?? 0) > 0,
  });

  // Upload a pending guideline
  const uploadGuideline = async (upload: PendingUpload) => {
    if (!upload.metadata.title || !upload.textContent) {
      toast({
        variant: 'destructive',
        title: 'Titel und Inhalt erforderlich',
      });
      return;
    }

    setPendingUploads(prev => prev.map(u => 
      u.id === upload.id ? { ...u, status: 'uploading' } : u
    ));

    try {
      const { data: guideline, error: insertError } = await supabase
        .from('guidelines')
        .insert({
          title: upload.metadata.title,
          description: upload.metadata.description || null,
          source: upload.metadata.source || null,
          version: upload.metadata.version || null,
          valid_from: parseDate(upload.metadata.validFrom),
          valid_until: parseDate(upload.metadata.validUntil),
          file_name: upload.file.name,
          file_size: upload.file.size,
          mime_type: upload.file.type || 'application/pdf',
          detected_icd10_codes: upload.detectedCodes.icd10.length > 0 ? upload.detectedCodes.icd10 : null,
          detected_hpo_codes: upload.detectedCodes.hpo.length > 0 ? upload.detectedCodes.hpo : null,
          detected_snomed_codes: upload.detectedCodes.snomed.length > 0 ? upload.detectedCodes.snomed : null,
        })
        .select()
        .single();

      if (insertError) throw insertError;

      // Trigger embedding
      await supabase.functions.invoke('guidelines-embed', {
        body: {
          guideline_id: guideline.id,
          content: upload.textContent,
        },
      });

      // Remove from pending
      setPendingUploads(prev => prev.filter(u => u.id !== upload.id));
      queryClient.invalidateQueries({ queryKey: ['guidelines'] });
      queryClient.invalidateQueries({ queryKey: ['guidelines-count'] });
      toast({ title: 'Leitlinie gespeichert', description: 'Vektorisierung läuft im Hintergrund.' });
    } catch (err: any) {
      setPendingUploads(prev => prev.map(u => 
        u.id === upload.id ? { ...u, status: 'error', error: err.message } : u
      ));
      toast({
        variant: 'destructive',
        title: 'Fehler beim Speichern',
        description: err.message,
      });
    }
  };

  // Remove pending upload
  const removePendingUpload = (id: string) => {
    setPendingUploads(prev => prev.filter(u => u.id !== id));
  };

  // Update pending upload metadata
  const updatePendingMetadata = (id: string, field: string, value: string) => {
    setPendingUploads(prev => prev.map(u => 
      u.id === id ? { ...u, metadata: { ...u.metadata, [field]: value } } : u
    ));
  };

  const startEditing = (guideline: Guideline) => {
    setEditingId(guideline.id);
    setEditForm({
      title: guideline.title,
      description: guideline.description || '',
      source: guideline.source || '',
      version: guideline.version || '',
      valid_from: guideline.valid_from || '',
      valid_until: guideline.valid_until || '',
    });
  };

  const getStatusBadge = (guideline: Guideline) => {
    switch (guideline.embedding_status) {
      case 'completed':
        return <Badge className="gap-1 bg-primary text-primary-foreground"><CheckCircle className="h-3 w-3" /> Bereit</Badge>;
      case 'processing':
        return (
          <Badge variant="secondary" className="gap-1">
            <Loader2 className="h-3 w-3 animate-spin" /> 
            {guideline.embedding_progress}%
          </Badge>
        );
      case 'failed':
        return <Badge variant="destructive" className="gap-1"><XCircle className="h-3 w-3" /> Fehler</Badge>;
      default:
        return <Badge variant="outline" className="gap-1"><Clock className="h-3 w-3" /> Ausstehend</Badge>;
    }
  };

  const hasContent = (totalCount ?? 0) > 0 || pendingUploads.length > 0;

  return (
    <AppLayout>
      <div className="container mx-auto py-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <BookOpen className="h-6 w-6" />
              Leitlinien-Verwaltung
            </h1>
            <p className="text-muted-foreground">
              Wissensdatenbank verwalten
            </p>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="knowledge" className="w-full">
          <TabsList>
            <TabsTrigger value="knowledge" className="gap-2">
              <Sparkles className="h-4 w-4" />
              Wissenssuche
            </TabsTrigger>
            <TabsTrigger value="manage" className="gap-2">
              <Library className="h-4 w-4" />
              Verwaltung
            </TabsTrigger>
          </TabsList>

          <TabsContent value="knowledge" className="mt-6">
            <UnifiedKnowledgeSearch />
          </TabsContent>

          <TabsContent value="manage" className="mt-6 space-y-6">
            {/* Search */}
            {hasContent && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Leitlinien durchsuchen (Titel, Quelle, ICD-10, HPO...)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            )}

        {/* Dropzone + Content Area */}
        <div
          {...getRootProps()}
          className={cn(
            "min-h-[400px] rounded-lg border-2 border-dashed transition-all",
            isDragActive
              ? "border-primary bg-primary/5 scale-[1.01]"
              : "border-muted-foreground/25",
            !hasContent && "cursor-pointer hover:border-primary/50 hover:bg-muted/30"
          )}
        >
          <input {...getInputProps()} />

          {isDragActive && (
            <div className="absolute inset-0 flex items-center justify-center bg-primary/10 rounded-lg z-10 pointer-events-none">
              <div className="text-center">
                <Upload className="h-12 w-12 text-primary mx-auto mb-2" />
                <p className="text-lg font-medium">PDFs hier ablegen</p>
              </div>
            </div>
          )}

          <div className="p-4 space-y-4">
            {/* Pending Uploads */}
            {pendingUploads.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-medium flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  Neue Leitlinien ({pendingUploads.length})
                </h3>
                {pendingUploads.map((upload) => (
                  <Card key={upload.id} className="border-primary/30">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          <span className="font-medium">{upload.file.name}</span>
                          {upload.status === 'extracting' && (
                            <Badge variant="secondary" className="gap-1">
                              <Loader2 className="h-3 w-3 animate-spin" />
                              {upload.progress}%
                            </Badge>
                          )}
                          {upload.status === 'ready' && (
                            <Badge className="bg-primary/10 text-primary">Bereit</Badge>
                          )}
                          {upload.status === 'uploading' && (
                            <Badge variant="secondary" className="gap-1">
                              <Loader2 className="h-3 w-3 animate-spin" />
                              Speichern...
                            </Badge>
                          )}
                          {upload.status === 'error' && (
                            <Badge variant="destructive">{upload.error}</Badge>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removePendingUpload(upload.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    
                    {upload.status === 'extracting' && (
                      <CardContent>
                        <Progress value={upload.progress} className="h-2" />
                      </CardContent>
                    )}

                    {(upload.status === 'ready' || upload.status === 'error' || upload.status === 'uploading') && (
                      <CardContent className="space-y-4">
                        {/* Detected codes */}
                        {(upload.detectedCodes.icd10.length > 0 || 
                          upload.detectedCodes.hpo.length > 0 || 
                          upload.detectedCodes.snomed.length > 0) && (
                          <div className="flex flex-wrap gap-1.5">
                            {upload.detectedCodes.icd10.slice(0, 5).map(code => (
                              <Badge key={code} variant="outline" className="text-xs bg-primary/10 text-primary">
                                ICD-10: {code}
                              </Badge>
                            ))}
                            {upload.detectedCodes.icd10.length > 5 && (
                              <Badge variant="outline" className="text-xs">
                                +{upload.detectedCodes.icd10.length - 5}
                              </Badge>
                            )}
                            {upload.detectedCodes.hpo.length > 0 && (
                              <Badge variant="secondary" className="text-xs">
                                HPO: {upload.detectedCodes.hpo.length}
                              </Badge>
                            )}
                            {upload.detectedCodes.snomed.length > 0 && (
                              <Badge variant="outline" className="text-xs bg-accent">
                                SNOMED: {upload.detectedCodes.snomed.length}
                              </Badge>
                            )}
                          </div>
                        )}

                        {/* Metadata form */}
                        <div className="grid gap-3">
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Titel *</Label>
                            <Input
                              value={upload.metadata.title}
                              onChange={(e) => updatePendingMetadata(upload.id, 'title', e.target.value)}
                              className="h-8"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Quelle</Label>
                              <Input
                                value={upload.metadata.source}
                                onChange={(e) => updatePendingMetadata(upload.id, 'source', e.target.value)}
                                placeholder="AWMF, DEGAM..."
                                className="h-8"
                              />
                            </div>
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Version</Label>
                              <Input
                                value={upload.metadata.version}
                                onChange={(e) => updatePendingMetadata(upload.id, 'version', e.target.value)}
                                placeholder="S3, 2023"
                                className="h-8"
                              />
                            </div>
                          </div>
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Beschreibung</Label>
                            <Textarea
                              value={upload.metadata.description}
                              onChange={(e) => updatePendingMetadata(upload.id, 'description', e.target.value)}
                              rows={2}
                              className="text-sm"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Gültig ab</Label>
                              <Input
                                type="date"
                                value={upload.metadata.validFrom}
                                onChange={(e) => updatePendingMetadata(upload.id, 'validFrom', e.target.value)}
                                className="h-8"
                              />
                            </div>
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Gültig bis</Label>
                              <Input
                                type="date"
                                value={upload.metadata.validUntil}
                                onChange={(e) => updatePendingMetadata(upload.id, 'validUntil', e.target.value)}
                                className="h-8"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Word count and save button */}
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-xs text-muted-foreground">
                            {upload.textContent.split(/\s+/).length} Wörter extrahiert
                          </span>
                          <Button
                            size="sm"
                            onClick={() => uploadGuideline(upload)}
                            disabled={!upload.metadata.title || !upload.textContent || upload.status === 'uploading'}
                          >
                            {upload.status === 'uploading' ? (
                              <Loader2 className="h-4 w-4 animate-spin mr-2" />
                            ) : (
                              <Save className="h-4 w-4 mr-2" />
                            )}
                            Speichern
                          </Button>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                ))}
              </div>
            )}

            {/* Guidelines List */}
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : !hasContent ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="p-4 rounded-full bg-muted mb-4">
                  <Upload className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="font-medium text-lg">Leitlinien hierher ziehen</h3>
                <p className="text-muted-foreground mt-1 max-w-md">
                  PDF-Dateien direkt in diesen Bereich ziehen. Metadaten werden automatisch extrahiert.
                </p>
                <p className="text-xs text-muted-foreground mt-4">
                  oder klicken zum Auswählen
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {guidelines?.map((guideline) => (
                  <Card key={guideline.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            {editingId === guideline.id ? (
                              <Input
                                value={editForm.title || ''}
                                onChange={(e) => setEditForm(f => ({ ...f, title: e.target.value }))}
                                className="h-8 font-semibold"
                              />
                            ) : (
                              <CardTitle className="text-lg truncate">{stripHtmlTags(guideline.title)}</CardTitle>
                            )}
                            {getStatusBadge(guideline)}
                          </div>
                          {!editingId && guideline.description && (
                            <CardDescription className="line-clamp-1">{stripHtmlTags(guideline.description)}</CardDescription>
                          )}
                        </div>
                        
                        <div className="flex gap-1">
                          {editingId === guideline.id ? (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setEditingId(null)}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => updateMutation.mutate({ id: guideline.id, updates: editForm })}
                                disabled={updateMutation.isPending}
                              >
                                {updateMutation.isPending ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Save className="h-4 w-4" />
                                )}
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => startEditing(guideline)}
                                title="Bearbeiten"
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              {(guideline.embedding_status === 'pending' || guideline.embedding_status === 'failed') && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => reEmbedMutation.mutate(guideline.id)}
                                  disabled={reEmbedMutation.isPending}
                                  title="Vektorisierung starten"
                                >
                                  {reEmbedMutation.isPending ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <RefreshCw className="h-4 w-4" />
                                  )}
                                </Button>
                              )}
                              {guideline.embedding_status === 'processing' && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => resetStuckMutation.mutate(guideline.id)}
                                  title="Status zurücksetzen"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              )}
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Leitlinie löschen?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Diese Aktion kann nicht rückgängig gemacht werden.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Abbrechen</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteMutation.mutate(guideline.id)}
                                      className="bg-destructive text-destructive-foreground"
                                    >
                                      Löschen
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-3">
                      {/* Edit form */}
                      {editingId === guideline.id && (
                        <div className="grid gap-3 p-3 bg-muted/50 rounded-lg">
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Beschreibung</Label>
                            <Textarea
                              value={editForm.description || ''}
                              onChange={(e) => setEditForm(f => ({ ...f, description: e.target.value }))}
                              rows={2}
                              className="text-sm"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Quelle</Label>
                              <Input
                                value={editForm.source || ''}
                                onChange={(e) => setEditForm(f => ({ ...f, source: e.target.value }))}
                                className="h-8"
                              />
                            </div>
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Version</Label>
                              <Input
                                value={editForm.version || ''}
                                onChange={(e) => setEditForm(f => ({ ...f, version: e.target.value }))}
                                className="h-8"
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Gültig ab</Label>
                              <Input
                                type="date"
                                value={editForm.valid_from || ''}
                                onChange={(e) => setEditForm(f => ({ ...f, valid_from: e.target.value }))}
                                className="h-8"
                              />
                            </div>
                            <div className="grid gap-1.5">
                              <Label className="text-xs">Gültig bis</Label>
                              <Input
                                type="date"
                                value={editForm.valid_until || ''}
                                onChange={(e) => setEditForm(f => ({ ...f, valid_until: e.target.value }))}
                                className="h-8"
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Progress bar */}
                      {guideline.embedding_status === 'processing' && (
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Vektorisierung...</span>
                            <span>{guideline.embedding_progress}%</span>
                          </div>
                          <Progress value={guideline.embedding_progress} className="h-2" />
                        </div>
                      )}
                      
                      {/* Metadata */}
                      {editingId !== guideline.id && (
                        <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                          {guideline.source && (
                            <span className="flex items-center gap-1">
                              <Building2 className="h-3 w-3" />
                              {guideline.source}
                            </span>
                          )}
                          {guideline.version && <span>v{guideline.version}</span>}
                          {guideline.valid_from && (
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {format(new Date(guideline.valid_from), 'dd.MM.yyyy', { locale: de })}
                            </span>
                          )}
                          {guideline.embedding_status === 'completed' && (
                            <Badge variant="outline">{guideline.total_chunks} Chunks</Badge>
                          )}
                          {guideline.embedding_error && (
                            <span className="text-destructive flex items-center gap-1">
                              <AlertCircle className="h-3 w-3" />
                              {guideline.embedding_error}
                            </span>
                          )}
                        </div>
                      )}
                      
                      {/* Detected codes */}
                      {editingId !== guideline.id && ((guideline.detected_icd10_codes?.length || 0) > 0 || 
                        (guideline.detected_hpo_codes?.length || 0) > 0 || 
                        (guideline.detected_snomed_codes?.length || 0) > 0) && (
                        <div className="flex flex-wrap gap-1.5 pt-2 border-t">
                          {guideline.detected_icd10_codes?.slice(0, 4).map(code => (
                            <Badge key={code} variant="outline" className="text-xs bg-primary/10 text-primary">
                              {code}
                            </Badge>
                          ))}
                          {(guideline.detected_icd10_codes?.length || 0) > 4 && (
                            <Badge variant="outline" className="text-xs">
                              +{(guideline.detected_icd10_codes?.length || 0) - 4} ICD-10
                            </Badge>
                          )}
                          {(guideline.detected_hpo_codes?.length || 0) > 0 && (
                            <Badge variant="secondary" className="text-xs">
                              HPO: {guideline.detected_hpo_codes?.length}
                            </Badge>
                          )}
                          {(guideline.detected_snomed_codes?.length || 0) > 0 && (
                            <Badge variant="outline" className="text-xs">
                              SNOMED: {guideline.detected_snomed_codes?.length}
                            </Badge>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between pt-4">
                    <p className="text-sm text-muted-foreground">
                      {(page * PAGE_SIZE + 1).toLocaleString('de-DE')}–{Math.min((page + 1) * PAGE_SIZE, totalCount ?? 0).toLocaleString('de-DE')} von {(totalCount ?? 0).toLocaleString('de-DE')} Dokumenten
                    </p>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPage(p => Math.max(0, p - 1))}
                        disabled={page === 0}
                      >
                        Zurück
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPage(p => p + 1)}
                        disabled={page >= totalPages - 1}
                      >
                        Weiter
                      </Button>
                    </div>
                  </div>
                )}
                {totalPages <= 1 && (totalCount ?? 0) > 0 && (
                  <p className="text-sm text-muted-foreground pt-2">
                    {(totalCount ?? 0).toLocaleString('de-DE')} Dokument{(totalCount ?? 0) !== 1 ? 'e' : ''}
                  </p>
                )}
              </div>
              )}
            </div>
          </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
