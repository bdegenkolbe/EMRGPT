import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AppLayout } from '@/components/layout/AppLayout';
import { useUsers } from '@/hooks/useUsers';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Loader2, Settings, Users as UsersIcon } from 'lucide-react';
import { Constants } from '@/integrations/supabase/types';
import type { Database } from '@/integrations/supabase/types';

type ClinicalView = Database['public']['Enums']['clinical_view'];

const CLINICAL_VIEWS = Constants.public.Enums.clinical_view as readonly ClinicalView[];

export default function Users() {
  const { t } = useTranslation();
  const { users, isLoading, updateUserRole, updateUserViews } = useUsers();
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [selectedViews, setSelectedViews] = useState<ClinicalView[]>([]);

  const handleViewsChange = (view: ClinicalView, checked: boolean) => {
    if (checked) {
      setSelectedViews((prev) => [...prev, view]);
    } else {
      setSelectedViews((prev) => prev.filter((v) => v !== view));
    }
  };

  const handleSaveViews = () => {
    if (selectedUser) {
      updateUserViews.mutate({ userId: selectedUser, views: selectedViews });
    }
  };

  const openViewsDialog = (userId: string, currentViews: ClinicalView[]) => {
    setSelectedUser(userId);
    setSelectedViews(currentViews);
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              {t('admin.users.title')}
            </h1>
            <p className="text-muted-foreground">
              {t('admin.users.description', { defaultValue: 'Benutzer und Berechtigungen verwalten' })}
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UsersIcon className="h-5 w-5" />
              {t('admin.users.title')}
            </CardTitle>
            <CardDescription>
              {users?.length || 0} {t('admin.users.registered', { defaultValue: 'registrierte Benutzer' })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('admin.users.email')}</TableHead>
                  <TableHead>{t('admin.users.role')}</TableHead>
                  <TableHead>{t('admin.users.views')}</TableHead>
                  <TableHead>{t('admin.users.createdAt')}</TableHead>
                  <TableHead className="text-right">{t('common.actions', { defaultValue: 'Aktionen' })}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users?.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{user.email}</p>
                        {user.display_name && (
                          <p className="text-sm text-muted-foreground">
                            {user.display_name}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Select
                        value={user.role}
                        onValueChange={(value) =>
                          updateUserRole.mutate({
                            userId: user.id,
                            role: value as 'admin' | 'user',
                          })
                        }
                      >
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="user">{t('common.user')}</SelectItem>
                          <SelectItem value="admin">{t('common.admin')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {user.views.length > 0 ? (
                          user.views.map((view) => (
                            <Badge key={view} variant="secondary" className="text-xs">
                              {t(`medical.views.${view}`)}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-sm text-muted-foreground">
                            {t('admin.users.noViews', { defaultValue: 'Keine Sichten' })}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {new Date(user.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openViewsDialog(user.id, user.views)}
                          >
                            <Settings className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>{t('admin.users.assignViews')}</DialogTitle>
                            <DialogDescription>
                              {user.email}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            {CLINICAL_VIEWS.map((view) => (
                              <div key={view} className="flex items-center space-x-2">
                                <Checkbox
                                  id={view}
                                  checked={selectedViews.includes(view)}
                                  onCheckedChange={(checked) =>
                                    handleViewsChange(view, checked as boolean)
                                  }
                                />
                                <Label htmlFor={view}>
                                  {t(`medical.views.${view}`)}
                                </Label>
                              </div>
                            ))}
                          </div>
                          <Button
                            onClick={handleSaveViews}
                            disabled={updateUserViews.isPending}
                            className="w-full"
                          >
                            {updateUserViews.isPending && (
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            )}
                            {t('common.save')}
                          </Button>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
