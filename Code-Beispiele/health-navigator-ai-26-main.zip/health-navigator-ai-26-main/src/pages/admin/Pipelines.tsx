import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AppLayout } from '@/components/layout/AppLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DomainList } from '@/components/pipelines/DomainList';
import { PipelineConfigurator } from '@/components/pipelines/PipelineConfigurator';
import { PromptTemplateList } from '@/components/pipelines/PromptTemplateList';
import { ExecutionHistory } from '@/components/pipelines/ExecutionHistory';
import { TokenStatistics } from '@/components/pipelines/TokenStatistics';
import { Workflow, Settings, FileText, History, BarChart3 } from 'lucide-react';

export default function Pipelines() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('domains');

  return (
    <AppLayout>
      <div className="container mx-auto py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            {t('admin.pipelines.title', { defaultValue: 'Pipeline-Verwaltung' })}
          </h1>
          <p className="text-muted-foreground">
            {t('admin.pipelines.description', { defaultValue: 'Domänen, Pipelines und Prompt-Templates konfigurieren' })}
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid">
            <TabsTrigger value="domains" className="flex items-center gap-2">
              <Workflow className="h-4 w-4" />
              <span className="hidden sm:inline">
                {t('admin.pipelines.tabs.domains', { defaultValue: 'Domänen' })}
              </span>
            </TabsTrigger>
            <TabsTrigger value="pipelines" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">
                {t('admin.pipelines.tabs.pipelines', { defaultValue: 'Pipelines' })}
              </span>
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">
                {t('admin.pipelines.tabs.templates', { defaultValue: 'Templates' })}
              </span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              <span className="hidden sm:inline">
                {t('admin.pipelines.tabs.history', { defaultValue: 'Ausführungen' })}
              </span>
            </TabsTrigger>
            <TabsTrigger value="statistics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">
                {t('admin.pipelines.tabs.statistics', { defaultValue: 'Statistiken' })}
              </span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="domains" className="space-y-4">
            <DomainList />
          </TabsContent>

          <TabsContent value="pipelines" className="space-y-4">
            <PipelineConfigurator />
          </TabsContent>

          <TabsContent value="templates" className="space-y-4">
            <PromptTemplateList />
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <ExecutionHistory />
          </TabsContent>

          <TabsContent value="statistics" className="space-y-4">
            <TokenStatistics />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
