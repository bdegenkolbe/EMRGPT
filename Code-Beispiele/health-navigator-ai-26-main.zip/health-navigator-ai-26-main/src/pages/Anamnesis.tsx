import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { ChatInterface } from '@/components/anamnesis/ChatInterface';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Database } from '@/integrations/supabase/types';

type ClinicalView = Database['public']['Enums']['clinical_view'];

const clinicalViews: ClinicalView[] = [
  'hausarztpraxis',
  'notaufnahme',
  'telemedizin',
  'fachambulanz',
  'klinik',
];

export default function Anamnesis() {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [selectedView, setSelectedView] = useState<ClinicalView>('hausarztpraxis');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [sessionClinicalView, setSessionClinicalView] = useState<ClinicalView>('hausarztpraxis');
  const [isStarting, setIsStarting] = useState(false);
  const [isLoadingSession, setIsLoadingSession] = useState(false);

  // Check for existing session from URL query parameter
  useEffect(() => {
    const existingSessionId = searchParams.get('session');
    if (existingSessionId && !sessionId) {
      loadExistingSession(existingSessionId);
    }
  }, [searchParams]);

  const loadExistingSession = async (id: string) => {
    setIsLoadingSession(true);
    try {
      const { data, error } = await supabase
        .from('anamnesis_sessions')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;

      if (data && data.status === 'in_progress') {
        setSessionId(data.id);
        setSessionClinicalView(data.clinical_view);
      } else if (data && data.status === 'completed') {
        // Redirect to documentation if session is already completed
        navigate(`/sessions/${id}`);
      }
    } catch (error) {
      console.error('Error loading session:', error);
      toast({
        variant: 'destructive',
        title: t('common.error'),
        description: i18n.language === 'de' 
          ? 'Sitzung konnte nicht geladen werden'
          : 'Could not load session',
      });
    } finally {
      setIsLoadingSession(false);
    }
  };

  const startSession = async () => {
    if (!user) return;
    
    setIsStarting(true);
    try {
      const { data, error } = await supabase
        .from('anamnesis_sessions')
        .insert({
          user_id: user.id,
          clinical_view: selectedView,
          language: i18n.language,
          status: 'in_progress',
        })
        .select('id')
        .single();

      if (error) throw error;

      setSessionId(data.id);
      setSessionClinicalView(selectedView);
      toast({
        title: t('common.success'),
        description: t('anamnesis.startSession'),
      });
    } catch (error) {
      console.error('Error starting session:', error);
      toast({
        variant: 'destructive',
        title: t('common.error'),
        description: String(error),
      });
    } finally {
      setIsStarting(false);
    }
  };

  const handleSessionComplete = () => {
    if (sessionId) {
      navigate(`/anamnesis/${sessionId}/evidence`);
    }
  };

  if (isLoadingSession) {
    return (
      <AppLayout>
        <div className="container max-w-2xl py-8 flex items-center justify-center">
          <Card className="w-full">
            <CardContent className="pt-6">
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">
                  {i18n.language === 'de' ? 'Sitzung wird geladen...' : 'Loading session...'}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  if (!sessionId) {
    return (
      <AppLayout>
        <div className="container max-w-2xl py-8">
          <Card>
            <CardHeader>
              <CardTitle>{t('anamnesis.selectView')}</CardTitle>
              <CardDescription>
                {t('dashboard.newAnamnesisDesc')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <RadioGroup
                value={selectedView}
                onValueChange={(value) => setSelectedView(value as ClinicalView)}
                className="grid gap-3"
              >
                {clinicalViews.map((view) => (
                  <div key={view} className="flex items-center space-x-3">
                    <RadioGroupItem value={view} id={view} />
                    <Label htmlFor={view} className="cursor-pointer">
                      {t(`medical.views.${view}`)}
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <Button
                onClick={startSession}
                disabled={isStarting}
                className="w-full"
              >
                {isStarting ? t('common.loading') : t('anamnesis.startSession')}
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-4rem)]">
        <ChatInterface
          sessionId={sessionId}
          clinicalView={sessionClinicalView}
          language={i18n.language}
          onComplete={handleSessionComplete}
        />
      </div>
    </AppLayout>
  );
}
