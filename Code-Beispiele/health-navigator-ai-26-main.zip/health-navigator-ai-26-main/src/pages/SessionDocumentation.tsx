import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, FileText, BookOpen } from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SOAPNote } from '@/components/documentation/SOAPNote';
import { ExportButtons } from '@/components/documentation/ExportButtons';
import { EvidencePanel } from '@/components/evidence/EvidencePanel';
import { supabase } from '@/integrations/supabase/client';
import { Loader2 } from 'lucide-react';

interface SessionData {
  id: string;
  user_id: string;
  patient_identifier: string | null;
  clinical_view: string;
  language: string;
  status: string;
  started_at: string | null;
  completed_at: string | null;
  created_at: string | null;
}

interface ObservationData {
  id: string;
  raw_input: string;
  normalized_value: string | null;
  language: string;
  hpo_codes: string[] | null;
  rxnorm_codes: string[] | null;
  mesh_terms: string[] | null;
  negated: boolean | null;
  onset: string | null;
  duration: string | null;
  severity: string | null;
  confidence: number | null;
  provenance: string | null;
  created_at: string | null;
}

export default function SessionDocumentation() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [session, setSession] = useState<SessionData | null>(null);
  const [observations, setObservations] = useState<ObservationData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!sessionId) return;

    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [sessionResult, observationsResult] = await Promise.all([
          supabase
            .from('anamnesis_sessions')
            .select('*')
            .eq('id', sessionId)
            .single(),
          supabase
            .from('observations')
            .select('*')
            .eq('session_id', sessionId)
            .order('created_at', { ascending: true }),
        ]);

        if (sessionResult.data) {
          setSession(sessionResult.data);
        }
        if (observationsResult.data) {
          setObservations(observationsResult.data);
        }
      } catch (error) {
        console.error('Error fetching session data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [sessionId]);

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!session) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-full">
          <p className="text-muted-foreground mb-4">{t('common.error')}</p>
          <Button onClick={() => navigate('/dashboard')}>
            {t('common.back')}
          </Button>
        </div>
      </AppLayout>
    );
  }

  // Extract SOAP data from observations
  const chiefComplaint = observations.length > 0 
    ? observations[0].raw_input 
    : '';
  
  const hpi = observations
    .slice(1)
    .filter(o => !o.negated)
    .map(o => o.raw_input)
    .join('\n');

  const hpoCodes = observations
    .flatMap(o => o.hpo_codes || [])
    .filter((code, i, arr) => arr.indexOf(code) === i);
  
  const meshTerms = observations
    .flatMap(o => o.mesh_terms || [])
    .filter((term, i, arr) => arr.indexOf(term) === i);

  const soapData = {
    chiefComplaint,
    historyOfPresentIllness: hpi,
    reviewOfSystems: [],
    redFlags: [], // Would come from AI analysis
    summary: '',
  };

  return (
    <AppLayout>
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate(-1)}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('common.back')}
            </Button>
            <h1 className="text-2xl font-bold">{t('documentation.soapNote')}</h1>
          </div>
          
          <ExportButtons
            session={session}
            observations={observations}
            soapData={soapData}
          />
        </div>

        {/* Content */}
        <Tabs defaultValue="documentation" className="flex-1">
          <TabsList>
            <TabsTrigger value="documentation" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              {t('documentation.soapNote')}
            </TabsTrigger>
            <TabsTrigger value="evidence" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              {t('evidence.title')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="documentation" className="flex-1 mt-4">
            <SOAPNote
              chiefComplaint={chiefComplaint}
              historyOfPresentIllness={hpi}
              observations={observations}
              hpoCodes={hpoCodes}
              meshTerms={meshTerms}
              redFlags={[]}
              patientIdentifier={session.patient_identifier ?? undefined}
              sessionDate={new Date(session.created_at || Date.now()).toLocaleDateString('de-DE')}
              clinicalView={session.clinical_view}
            />
          </TabsContent>

          <TabsContent value="evidence" className="flex-1 mt-4">
            <div className="rounded-lg border bg-card h-[600px]">
              <EvidencePanel sessionId={session.id} />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
