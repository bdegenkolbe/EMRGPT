 import { useState, useEffect } from 'react';
 import { useTranslation } from 'react-i18next';
 import { useNavigate } from 'react-router-dom';
 import { ArrowLeft, Search, Loader2, BookOpen, FlaskConical, AlertTriangle, Globe, ExternalLink } from 'lucide-react';
 import { AppLayout } from '@/components/layout/AppLayout';
 import { Button } from '@/components/ui/button';
 import { Input } from '@/components/ui/input';
 import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
 import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
 import { Badge } from '@/components/ui/badge';
 import { ScrollArea } from '@/components/ui/scroll-area';
 import { supabase } from '@/integrations/supabase/client';
 import { useToast } from '@/hooks/use-toast';
 
 interface SearchResult {
   id: string;
   source: string;
   title: string;
   year?: number;
   venue?: string;
   url?: string;
   snippet?: string;
   study_type?: string;
 }
 
 interface EuropePMCArticle {
   id: string;
   title: string;
   authors?: string;
   journal?: string;
   year?: number;
   pmid?: string;
   doi?: string;
   abstract?: string;
   isOpenAccess?: boolean;
   citedByCount?: number;
 }
 
 export default function EvidenceSearch() {
   const { t } = useTranslation();
   const navigate = useNavigate();
   const { toast } = useToast();
   
   const [searchQuery, setSearchQuery] = useState('');
   const [isLoading, setIsLoading] = useState(false);
   const [pubmedResults, setPubmedResults] = useState<SearchResult[]>([]);
   const [trialsResults, setTrialsResults] = useState<SearchResult[]>([]);
   const [europePMCResults, setEuropePMCResults] = useState<EuropePMCArticle[]>([]);
   const [hasSearched, setHasSearched] = useState(false);
 
   // Load initial query from sessionStorage
   useEffect(() => {
     const storedQuery = sessionStorage.getItem('evidence_search_query');
     if (storedQuery) {
       setSearchQuery(storedQuery);
       sessionStorage.removeItem('evidence_search_query');
       // Auto-search with the stored query
       performSearch(storedQuery);
     }
   }, []);
 
   const performSearch = async (query: string) => {
     if (!query.trim()) return;
     
     setIsLoading(true);
     setHasSearched(true);
     
     try {
       // Search PubMed via Europe PMC
       const europePMCPromise = supabase.functions.invoke('evidence-europepmc', {
         body: { query, limit: 15 }
       });
       
       // Search Clinical Trials
       const trialsPromise = supabase.functions.invoke('evidence-trials', {
         body: { query, limit: 10 }
       });
       
       const [europePMCResult, trialsResult] = await Promise.all([
         europePMCPromise,
         trialsPromise
       ]);
       
       if (europePMCResult.data?.articles) {
         setEuropePMCResults(europePMCResult.data.articles);
       }
       
       if (trialsResult.data?.trials) {
         setTrialsResults(trialsResult.data.trials.map((trial: any) => ({
           id: trial.nctId,
           source: 'clinicaltrials',
           title: trial.title,
           study_type: trial.studyType,
           url: `https://clinicaltrials.gov/study/${trial.nctId}`,
           snippet: trial.conditions?.join(', ')
         })));
       }
     } catch (error) {
       console.error('Search error:', error);
       toast({
         variant: 'destructive',
         title: 'Suchfehler',
         description: 'Die Evidenzsuche konnte nicht durchgeführt werden.'
       });
     } finally {
       setIsLoading(false);
     }
   };
 
   const handleSearch = (e: React.FormEvent) => {
     e.preventDefault();
     performSearch(searchQuery);
   };
 
   return (
     <AppLayout>
       <div className="container mx-auto py-6 space-y-6">
         {/* Header */}
         <div className="flex items-center gap-4">
           <Button
             variant="ghost"
             size="sm"
             onClick={() => navigate(-1)}
           >
             <ArrowLeft className="mr-2 h-4 w-4" />
             Zurück
           </Button>
           <div>
             <h1 className="text-2xl font-bold flex items-center gap-2">
               <BookOpen className="h-6 w-6" />
               Evidenz-Suche
             </h1>
             <p className="text-muted-foreground">
               Durchsuchen Sie medizinische Literatur und klinische Studien
             </p>
           </div>
         </div>
 
         {/* Search Form */}
         <Card>
           <CardContent className="pt-6">
             <form onSubmit={handleSearch} className="flex gap-2">
               <div className="relative flex-1">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                 <Input
                   placeholder="Diagnose, Symptom oder Medikament suchen..."
                   value={searchQuery}
                   onChange={(e) => setSearchQuery(e.target.value)}
                   className="pl-9"
                 />
               </div>
               <Button type="submit" disabled={isLoading || !searchQuery.trim()}>
                 {isLoading ? (
                   <Loader2 className="h-4 w-4 animate-spin" />
                 ) : (
                   'Suchen'
                 )}
               </Button>
             </form>
           </CardContent>
         </Card>
 
         {/* Results */}
         {isLoading ? (
           <Card>
             <CardContent className="flex items-center justify-center py-12">
               <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
             </CardContent>
           </Card>
         ) : hasSearched ? (
           <Tabs defaultValue="articles">
             <TabsList>
               <TabsTrigger value="articles" className="gap-2">
                 <Globe className="h-4 w-4" />
                 Artikel ({europePMCResults.length})
               </TabsTrigger>
               <TabsTrigger value="trials" className="gap-2">
                 <FlaskConical className="h-4 w-4" />
                 Studien ({trialsResults.length})
               </TabsTrigger>
             </TabsList>
 
             <TabsContent value="articles" className="mt-4">
               <ScrollArea className="h-[600px]">
                 <div className="space-y-3 pr-4">
                   {europePMCResults.length === 0 ? (
                     <Card>
                       <CardContent className="py-8 text-center text-muted-foreground">
                         Keine Artikel gefunden
                       </CardContent>
                     </Card>
                   ) : (
                     europePMCResults.map((article) => (
                       <Card key={article.id} className="hover:bg-muted/50 transition-colors">
                         <CardContent className="p-4">
                           <div className="flex items-start justify-between gap-4">
                             <div className="flex-1">
                               <h3 className="font-medium leading-tight mb-1">
                                 {article.title}
                               </h3>
                               <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground mb-2">
                                 {article.authors && <span>{article.authors}</span>}
                                 {article.journal && <span>• {article.journal}</span>}
                                 {article.year && <span>• {article.year}</span>}
                               </div>
                               {article.abstract && (
                                 <p className="text-sm text-muted-foreground line-clamp-2">
                                   {article.abstract}
                                 </p>
                               )}
                               <div className="flex items-center gap-2 mt-2">
                                 {article.isOpenAccess && (
                                   <Badge variant="secondary" className="text-xs">Open Access</Badge>
                                 )}
                                 {article.citedByCount && article.citedByCount > 0 && (
                                   <Badge variant="outline" className="text-xs">
                                     {article.citedByCount} Zitierungen
                                   </Badge>
                                 )}
                                 {article.pmid && (
                                   <Badge variant="outline" className="font-mono text-xs">
                                     PMID: {article.pmid}
                                   </Badge>
                                 )}
                               </div>
                             </div>
                             {article.pmid && (
                               <Button
                                 variant="ghost"
                                 size="icon"
                                 className="flex-shrink-0"
                                 onClick={() => window.open(`https://pubmed.ncbi.nlm.nih.gov/${article.pmid}`, '_blank')}
                               >
                                 <ExternalLink className="h-4 w-4" />
                               </Button>
                             )}
                           </div>
                         </CardContent>
                       </Card>
                     ))
                   )}
                 </div>
               </ScrollArea>
             </TabsContent>
 
             <TabsContent value="trials" className="mt-4">
               <ScrollArea className="h-[600px]">
                 <div className="space-y-3 pr-4">
                   {trialsResults.length === 0 ? (
                     <Card>
                       <CardContent className="py-8 text-center text-muted-foreground">
                         Keine klinischen Studien gefunden
                       </CardContent>
                     </Card>
                   ) : (
                     trialsResults.map((trial) => (
                       <Card key={trial.id} className="hover:bg-muted/50 transition-colors">
                         <CardContent className="p-4">
                           <div className="flex items-start justify-between gap-4">
                             <div className="flex-1">
                               <h3 className="font-medium leading-tight mb-1">
                                 {trial.title}
                               </h3>
                               <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground mb-2">
                                 <Badge variant="outline" className="font-mono">{trial.id}</Badge>
                                 {trial.study_type && <span>• {trial.study_type}</span>}
                               </div>
                               {trial.snippet && (
                                 <p className="text-sm text-muted-foreground">
                                   {trial.snippet}
                                 </p>
                               )}
                             </div>
                             <Button
                               variant="ghost"
                               size="icon"
                               className="flex-shrink-0"
                               onClick={() => window.open(trial.url, '_blank')}
                             >
                               <ExternalLink className="h-4 w-4" />
                             </Button>
                           </div>
                         </CardContent>
                       </Card>
                     ))
                   )}
                 </div>
               </ScrollArea>
             </TabsContent>
           </Tabs>
         ) : (
           <Card>
             <CardContent className="py-12 text-center">
               <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
               <h3 className="font-medium text-lg mb-1">Evidenzbasierte Recherche</h3>
               <p className="text-muted-foreground">
                 Geben Sie einen Suchbegriff ein, um medizinische Literatur und klinische Studien zu durchsuchen.
               </p>
             </CardContent>
           </Card>
         )}
       </div>
     </AppLayout>
   );
 }