import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { de, enUS } from 'date-fns/locale';
import { 
  FileText, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Search,
  Filter,
  ChevronRight,
  Stethoscope,
  Building2,
  Phone,
  Hospital,
  Activity,
  Trash2,
   Loader2,
   Square,
   CheckSquare,
    X,
    CalendarIcon
} from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
 import { Checkbox } from '@/components/ui/checkbox';
 import { Calendar } from '@/components/ui/calendar';
 import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
 import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';

type Session = Tables<'anamnesis_sessions'>;

 interface SessionWithCounts extends Session {
   messageCount: number;
   observationCount: number;
 }
 
const viewIcons: Record<string, React.ReactNode> = {
  hausarztpraxis: <Stethoscope className="h-4 w-4" />,
  notaufnahme: <AlertCircle className="h-4 w-4" />,
  telemedizin: <Phone className="h-4 w-4" />,
  fachambulanz: <Building2 className="h-4 w-4" />,
  klinik: <Hospital className="h-4 w-4" />,
};

const viewLabels: Record<string, { de: string; en: string }> = {
  hausarztpraxis: { de: 'Hausarztpraxis', en: 'General Practice' },
  notaufnahme: { de: 'Notaufnahme', en: 'Emergency Room' },
  telemedizin: { de: 'Telemedizin', en: 'Telemedicine' },
  fachambulanz: { de: 'Fachambulanz', en: 'Specialist Clinic' },
  klinik: { de: 'Klinik', en: 'Hospital' },
};

export default function Sessions() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [viewFilter, setViewFilter] = useState<string>('all');
  const [deleteConfirmSession, setDeleteConfirmSession] = useState<Session | null>(null);
   const [selectedSessions, setSelectedSessions] = useState<Set<string>>(new Set());
   const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);
   const [deleteMultipleConfirm, setDeleteMultipleConfirm] = useState(false);
   const [dateFilter, setDateFilter] = useState<Date | undefined>(undefined);

  const locale = i18n.language === 'de' ? de : enUS;

   const { data: sessions, isLoading, error } = useQuery<SessionWithCounts[]>({
    queryKey: ['anamnesis-sessions'],
    queryFn: async () => {
       // Fetch sessions with counts of messages and observations
       const { data: sessionsData, error: sessionsError } = await supabase
        .from('anamnesis_sessions')
        .select('*')
        .order('created_at', { ascending: false });
      
       if (sessionsError) throw sessionsError;
       if (!sessionsData) return [];
 
       // Fetch message counts
       const { data: messageCounts } = await supabase
         .from('conversation_messages')
         .select('session_id');
       
       // Fetch observation counts
       const { data: observationCounts } = await supabase
         .from('observations')
         .select('session_id');
       
       // Count per session
       const messageCountMap = new Map<string, number>();
       const observationCountMap = new Map<string, number>();
       
       messageCounts?.forEach(m => {
         messageCountMap.set(m.session_id, (messageCountMap.get(m.session_id) || 0) + 1);
       });
       
       observationCounts?.forEach(o => {
         observationCountMap.set(o.session_id, (observationCountMap.get(o.session_id) || 0) + 1);
       });
       
       // Combine data
       return sessionsData.map(session => ({
         ...session,
         messageCount: messageCountMap.get(session.id) || 0,
         observationCount: observationCountMap.get(session.id) || 0,
       }));
    },
  });

   // Helper function to delete a single session
   const deleteSessionData = async (sessionId: string) => {
     // Delete evidence items via evidence requests
     const { data: requests } = await supabase
       .from('evidence_requests')
       .select('id')
       .eq('session_id', sessionId);
     
     if (requests && requests.length > 0) {
       const requestIds = requests.map(r => r.id);
       await supabase
         .from('evidence_items')
         .delete()
         .in('request_id', requestIds);
     }
     
     // Delete evidence requests
     await supabase
       .from('evidence_requests')
       .delete()
       .eq('session_id', sessionId);
     
     // Delete observations
     await supabase
       .from('observations')
       .delete()
       .eq('session_id', sessionId);
     
     // Delete conversation messages
     await supabase
       .from('conversation_messages')
       .delete()
       .eq('session_id', sessionId);
     
     // Finally delete the session
     const { error } = await supabase
       .from('anamnesis_sessions')
       .delete()
       .eq('id', sessionId);
     
     if (error) throw error;
   };
 
   const deleteMutation = useMutation({
     mutationFn: deleteSessionData,
     onSuccess: () => {
       queryClient.invalidateQueries({ queryKey: ['anamnesis-sessions'] });
       setDeleteConfirmSession(null);
       toast({
         title: i18n.language === 'de' ? 'Sitzung gelöscht' : 'Session deleted',
         description: i18n.language === 'de'
           ? 'Die Sitzung und alle zugehörigen Daten wurden entfernt.'
           : 'The session and all related data have been removed.',
       });
     },
     onError: (error) => {
       toast({
         variant: 'destructive',
         title: i18n.language === 'de' ? 'Fehler' : 'Error',
         description: String(error),
       });
     },
   });
 
   const deleteMultipleMutation = useMutation({
     mutationFn: async (sessionIds: string[]) => {
       // Delete all sessions sequentially to avoid race conditions
       for (const sessionId of sessionIds) {
         await deleteSessionData(sessionId);
       }
     },
     onSuccess: () => {
       queryClient.invalidateQueries({ queryKey: ['anamnesis-sessions'] });
       setDeleteMultipleConfirm(false);
       setSelectedSessions(new Set());
       setIsMultiSelectMode(false);
       toast({
         title: i18n.language === 'de' ? 'Sitzungen gelöscht' : 'Sessions deleted',
         description: i18n.language === 'de'
           ? 'Alle ausgewählten Sitzungen wurden entfernt.'
           : 'All selected sessions have been removed.',
       });
     },
     onError: (error) => {
       toast({
         variant: 'destructive',
         title: i18n.language === 'de' ? 'Fehler' : 'Error',
         description: String(error),
       });
     },
   });

  const filteredSessions = sessions?.filter(session => {
    const matchesSearch = !searchTerm || 
      session.patient_identifier?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      session.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || session.status === statusFilter;
    const matchesView = viewFilter === 'all' || session.clinical_view === viewFilter;

     // Date filter
     let matchesDate = true;
     if (dateFilter) {
       const sessionDate = new Date(session.created_at || '');
       matchesDate = 
         sessionDate.getFullYear() === dateFilter.getFullYear() &&
         sessionDate.getMonth() === dateFilter.getMonth() &&
         sessionDate.getDate() === dateFilter.getDate();
     }

     return matchesSearch && matchesStatus && matchesView && matchesDate;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge variant="default" className="bg-primary/10 text-primary hover:bg-primary/20">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            {i18n.language === 'de' ? 'Abgeschlossen' : 'Completed'}
          </Badge>
        );
      case 'in_progress':
        return (
          <Badge variant="secondary">
            <Clock className="h-3 w-3 mr-1" />
            {i18n.language === 'de' ? 'In Bearbeitung' : 'In Progress'}
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            <Activity className="h-3 w-3 mr-1" />
            {status}
          </Badge>
        );
    }
  };

  const handleSessionClick = (session: Session) => {
    if (session.status === 'completed') {
      navigate(`/sessions/${session.id}`);
    } else {
      navigate(`/anamnesis?session=${session.id}`);
    }
  };

  const handleDeleteClick = (e: React.MouseEvent, session: Session) => {
    e.stopPropagation();
    setDeleteConfirmSession(session);
  };

   const toggleSessionSelection = (sessionId: string, e?: React.MouseEvent) => {
     e?.stopPropagation();
     setSelectedSessions(prev => {
       const next = new Set(prev);
       if (next.has(sessionId)) {
         next.delete(sessionId);
       } else {
         next.add(sessionId);
       }
       return next;
     });
   };
 
   const toggleSelectAll = () => {
     if (!filteredSessions) return;
     if (selectedSessions.size === filteredSessions.length) {
       setSelectedSessions(new Set());
     } else {
       setSelectedSessions(new Set(filteredSessions.map(s => s.id)));
     }
   };
 
   const cancelMultiSelect = () => {
     setIsMultiSelectMode(false);
     setSelectedSessions(new Set());
   };
 
  return (
    <AppLayout>
      <div className="container mx-auto py-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              {i18n.language === 'de' ? 'Anamnese-Sitzungen' : 'Anamnesis Sessions'}
            </h1>
            <p className="text-muted-foreground">
              {i18n.language === 'de' 
                ? 'Übersicht aller durchgeführten Anamnese-Gespräche'
                : 'Overview of all conducted anamnesis interviews'}
            </p>
          </div>
         <div className="flex gap-2">
           {!isMultiSelectMode ? (
             <>
               {filteredSessions && filteredSessions.length > 0 && (
                 <Button variant="outline" onClick={() => setIsMultiSelectMode(true)}>
                   <CheckSquare className="h-4 w-4 mr-2" />
                   {i18n.language === 'de' ? 'Auswählen' : 'Select'}
                 </Button>
               )}
               <Button onClick={() => navigate('/anamnesis')}>
                 <FileText className="h-4 w-4 mr-2" />
                 {i18n.language === 'de' ? 'Neue Anamnese' : 'New Anamnesis'}
               </Button>
             </>
           ) : (
             <>
               <Button variant="ghost" onClick={cancelMultiSelect}>
                 <X className="h-4 w-4 mr-2" />
                 {i18n.language === 'de' ? 'Abbrechen' : 'Cancel'}
               </Button>
               <Button 
                 variant="outline" 
                 onClick={toggleSelectAll}
               >
                 {selectedSessions.size === filteredSessions?.length ? (
                   <>
                     <Square className="h-4 w-4 mr-2" />
                     {i18n.language === 'de' ? 'Keine auswählen' : 'Deselect all'}
                   </>
                 ) : (
                   <>
                     <CheckSquare className="h-4 w-4 mr-2" />
                     {i18n.language === 'de' ? 'Alle auswählen' : 'Select all'}
                   </>
                 )}
               </Button>
               <Button 
                 variant="destructive" 
                 disabled={selectedSessions.size === 0}
                 onClick={() => setDeleteMultipleConfirm(true)}
               >
                 <Trash2 className="h-4 w-4 mr-2" />
                 {i18n.language === 'de' ? `${selectedSessions.size} löschen` : `Delete ${selectedSessions.size}`}
               </Button>
             </>
           )}
         </div>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder={i18n.language === 'de' ? 'Suchen...' : 'Search...'}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[160px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">
                      {i18n.language === 'de' ? 'Alle Status' : 'All Status'}
                    </SelectItem>
                    <SelectItem value="in_progress">
                      {i18n.language === 'de' ? 'In Bearbeitung' : 'In Progress'}
                    </SelectItem>
                    <SelectItem value="completed">
                      {i18n.language === 'de' ? 'Abgeschlossen' : 'Completed'}
                    </SelectItem>
                  </SelectContent>
                </Select>
                <Select value={viewFilter} onValueChange={setViewFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder={i18n.language === 'de' ? 'Klinische Sicht' : 'Clinical View'} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">
                      {i18n.language === 'de' ? 'Alle Sichten' : 'All Views'}
                    </SelectItem>
                    {Object.entries(viewLabels).map(([key, labels]) => (
                      <SelectItem key={key} value={key}>
                        {i18n.language === 'de' ? labels.de : labels.en}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                 
                 {/* Date Filter */}
                 <Popover>
                   <PopoverTrigger asChild>
                     <Button
                       variant="outline"
                       className={cn(
                         "w-[180px] justify-start text-left font-normal",
                         !dateFilter && "text-muted-foreground"
                       )}
                     >
                       <CalendarIcon className="mr-2 h-4 w-4" />
                       {dateFilter 
                         ? format(dateFilter, 'P', { locale })
                         : (i18n.language === 'de' ? 'Datum wählen' : 'Pick a date')}
                     </Button>
                   </PopoverTrigger>
                   <PopoverContent className="w-auto p-0" align="start">
                     <Calendar
                       mode="single"
                       selected={dateFilter}
                       onSelect={setDateFilter}
                       initialFocus
                       locale={locale}
                       className={cn("p-3 pointer-events-auto")}
                     />
                     {dateFilter && (
                       <div className="p-2 border-t">
                         <Button 
                           variant="ghost" 
                           size="sm" 
                           className="w-full"
                           onClick={() => setDateFilter(undefined)}
                         >
                           <X className="h-4 w-4 mr-2" />
                           {i18n.language === 'de' ? 'Datum löschen' : 'Clear date'}
                         </Button>
                       </div>
                     )}
                   </PopoverContent>
                 </Popover>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sessions List */}
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i}>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                    <Skeleton className="h-6 w-24" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center text-destructive">
                {i18n.language === 'de' 
                  ? 'Fehler beim Laden der Sitzungen'
                  : 'Error loading sessions'}
              </div>
            </CardContent>
          </Card>
        ) : filteredSessions?.length === 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">
                  {i18n.language === 'de' 
                    ? 'Keine Sitzungen gefunden'
                    : 'No sessions found'}
                </h3>
                <p className="text-muted-foreground mb-4">
                   {searchTerm || statusFilter !== 'all' || viewFilter !== 'all' || dateFilter
                    ? (i18n.language === 'de' 
                        ? 'Versuche die Filter anzupassen'
                        : 'Try adjusting your filters')
                    : (i18n.language === 'de'
                        ? 'Starte deine erste Anamnese-Sitzung'
                        : 'Start your first anamnesis session')}
                </p>
                 {!searchTerm && statusFilter === 'all' && viewFilter === 'all' && !dateFilter && (
                  <Button onClick={() => navigate('/anamnesis')}>
                    {i18n.language === 'de' ? 'Anamnese starten' : 'Start Anamnesis'}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredSessions?.map((session) => (
              <Card 
                key={session.id} 
               className={`cursor-pointer transition-colors hover:bg-muted/50 group ${
                 selectedSessions.has(session.id) ? 'ring-2 ring-primary bg-primary/5' : ''
               }`}
               onClick={() => isMultiSelectMode ? toggleSessionSelection(session.id) : handleSessionClick(session)}
              >
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4">
                   {isMultiSelectMode && (
                     <Checkbox
                       checked={selectedSessions.has(session.id)}
                       onCheckedChange={() => toggleSessionSelection(session.id)}
                       onClick={(e) => e.stopPropagation()}
                       className="h-5 w-5"
                     />
                   )}
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                      {viewIcons[session.clinical_view] || <Stethoscope className="h-5 w-5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium truncate">
                          {viewLabels[session.clinical_view]?.[i18n.language === 'de' ? 'de' : 'en'] || session.clinical_view}
                        </span>
                        {session.patient_identifier && (
                          <span className="text-sm text-muted-foreground">
                            • {session.patient_identifier}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span>
                          {session.started_at 
                            ? format(new Date(session.started_at), 'PPp', { locale })
                            : format(new Date(session.created_at!), 'PPp', { locale })}
                        </span>
                        {session.completed_at && (
                          <>
                            <span>→</span>
                            <span>{format(new Date(session.completed_at), 'p', { locale })}</span>
                          </>
                        )}
                       <span className="text-muted-foreground/50">•</span>
                       <Tooltip>
                         <TooltipTrigger asChild>
                           <span className="flex items-center gap-1 cursor-help">
                             <FileText className="h-3 w-3" />
                             {session.messageCount}
                           </span>
                         </TooltipTrigger>
                         <TooltipContent>
                           {i18n.language === 'de' 
                             ? `${session.messageCount} Nachrichten` 
                             : `${session.messageCount} messages`}
                         </TooltipContent>
                       </Tooltip>
                       <Tooltip>
                         <TooltipTrigger asChild>
                           <span className="flex items-center gap-1 cursor-help">
                             <Activity className="h-3 w-3" />
                             {session.observationCount}
                           </span>
                         </TooltipTrigger>
                         <TooltipContent>
                           {i18n.language === 'de' 
                             ? `${session.observationCount} Beobachtungen` 
                             : `${session.observationCount} observations`}
                         </TooltipContent>
                       </Tooltip>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(session.status)}
                     {!isMultiSelectMode && (
                       <>
                         <Tooltip>
                           <TooltipTrigger asChild>
                             <Button
                               variant="ghost"
                               size="icon"
                               className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                               onClick={(e) => handleDeleteClick(e, session)}
                             >
                               <Trash2 className="h-4 w-4" />
                             </Button>
                           </TooltipTrigger>
                           <TooltipContent>
                             {i18n.language === 'de' ? 'Sitzung löschen' : 'Delete session'}
                           </TooltipContent>
                         </Tooltip>
                         <ChevronRight className="h-5 w-5 text-muted-foreground" />
                       </>
                     )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Summary Stats */}
        {sessions && sessions.length > 0 && (
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>
                  {i18n.language === 'de' ? 'Gesamt' : 'Total'}
                </CardDescription>
                <CardTitle className="text-3xl">{sessions.length}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>
                  {i18n.language === 'de' ? 'Abgeschlossen' : 'Completed'}
                </CardDescription>
                <CardTitle className="text-3xl text-primary">
                  {sessions.filter(s => s.status === 'completed').length}
                </CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>
                  {i18n.language === 'de' ? 'In Bearbeitung' : 'In Progress'}
                </CardDescription>
                <CardTitle className="text-3xl text-muted-foreground">
                  {sessions.filter(s => s.status === 'in_progress').length}
                </CardTitle>
              </CardHeader>
            </Card>
          </div>
        )}

        {/* Delete Confirmation Dialog */}
        <AlertDialog
          open={!!deleteConfirmSession}
          onOpenChange={(open) => !open && setDeleteConfirmSession(null)}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {i18n.language === 'de' ? 'Sitzung löschen?' : 'Delete Session?'}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {i18n.language === 'de'
                  ? 'Diese Aktion kann nicht rückgängig gemacht werden. Die Sitzung und alle zugehörigen Daten (Nachrichten, Beobachtungen, Evidenz) werden dauerhaft gelöscht.'
                  : 'This action cannot be undone. The session and all related data (messages, observations, evidence) will be permanently deleted.'}
              </AlertDialogDescription>
              {deleteConfirmSession && (
                <div className="mt-4 p-3 bg-muted rounded-lg text-sm">
                  <p className="font-medium">
                    {viewLabels[deleteConfirmSession.clinical_view]?.[i18n.language === 'de' ? 'de' : 'en']}
                  </p>
                  <p className="text-muted-foreground">
                    {deleteConfirmSession.started_at
                      ? format(new Date(deleteConfirmSession.started_at), 'PPp', { locale })
                      : format(new Date(deleteConfirmSession.created_at!), 'PPp', { locale })}
                  </p>
                </div>
              )}
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>
                {i18n.language === 'de' ? 'Abbrechen' : 'Cancel'}
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteConfirmSession && deleteMutation.mutate(deleteConfirmSession.id)}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {deleteMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="h-4 w-4 mr-2" />
                )}
                {i18n.language === 'de' ? 'Löschen' : 'Delete'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
 
       {/* Delete Multiple Confirmation Dialog */}
       <AlertDialog
         open={deleteMultipleConfirm}
         onOpenChange={(open) => !open && setDeleteMultipleConfirm(false)}
       >
         <AlertDialogContent>
           <AlertDialogHeader>
             <AlertDialogTitle>
               {i18n.language === 'de' 
                 ? `${selectedSessions.size} Sitzungen löschen?` 
                 : `Delete ${selectedSessions.size} Sessions?`}
             </AlertDialogTitle>
             <AlertDialogDescription>
               {i18n.language === 'de'
                 ? 'Diese Aktion kann nicht rückgängig gemacht werden. Alle ausgewählten Sitzungen und deren zugehörige Daten werden dauerhaft gelöscht.'
                 : 'This action cannot be undone. All selected sessions and their related data will be permanently deleted.'}
             </AlertDialogDescription>
           </AlertDialogHeader>
           <AlertDialogFooter>
             <AlertDialogCancel>
               {i18n.language === 'de' ? 'Abbrechen' : 'Cancel'}
             </AlertDialogCancel>
             <AlertDialogAction
               onClick={() => deleteMultipleMutation.mutate(Array.from(selectedSessions))}
               className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
             >
               {deleteMultipleMutation.isPending ? (
                 <Loader2 className="h-4 w-4 mr-2 animate-spin" />
               ) : (
                 <Trash2 className="h-4 w-4 mr-2" />
               )}
               {i18n.language === 'de' ? `${selectedSessions.size} löschen` : `Delete ${selectedSessions.size}`}
             </AlertDialogAction>
           </AlertDialogFooter>
         </AlertDialogContent>
       </AlertDialog>
      </div>
    </AppLayout>
  );
}
