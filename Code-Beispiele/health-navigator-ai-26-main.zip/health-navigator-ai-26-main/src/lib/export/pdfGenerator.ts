import { jsPDF } from 'jspdf';

interface SOAPNoteData {
  patientIdentifier?: string;
  sessionDate: string;
  clinicalView: string;
  language: string;
  subjective: {
    chiefComplaint: string;
    historyOfPresentIllness: string;
    reviewOfSystems?: string[];
  };
  objective: {
    observations: Array<{
      raw_input: string;
      normalized_value?: string;
      hpo_codes?: string[];
      severity?: string;
      onset?: string;
      duration?: string;
      negated?: boolean;
    }>;
  };
  assessment: {
    hpoCodes: string[];
    meshTerms: string[];
    redFlags: string[];
    summary?: string;
  };
  plan: {
    notes?: string;
  };
  metadata: {
    sessionId: string;
    userId: string;
    createdAt: string;
    completedAt?: string;
    aiProvider?: string;
  };
}

export function generateSOAPNotePDF(data: SOAPNoteData): jsPDF {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - 2 * margin;
  let y = margin;

  const addText = (text: string, fontSize: number = 10, isBold: boolean = false) => {
    doc.setFontSize(fontSize);
    doc.setFont('helvetica', isBold ? 'bold' : 'normal');
    const lines = doc.splitTextToSize(text, contentWidth);
    
    lines.forEach((line: string) => {
      if (y > 270) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += fontSize * 0.5;
    });
    y += 2;
  };

  const addSection = (title: string, content: string | string[]) => {
    addText(title, 12, true);
    y += 2;
    
    if (Array.isArray(content)) {
      content.forEach(item => addText(`• ${item}`));
    } else if (content) {
      addText(content);
    } else {
      addText('—');
    }
    y += 5;
  };

  // Header
  doc.setFillColor(59, 130, 246);
  doc.rect(0, 0, pageWidth, 35, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('SOAP Note - KI-Anamnese', margin, 20);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Datum: ${data.sessionDate}`, margin, 28);
  doc.text(`Sicht: ${data.clinicalView}`, pageWidth / 2, 28);
  
  y = 45;
  doc.setTextColor(0, 0, 0);

  // Patient Info
  if (data.patientIdentifier) {
    addText(`Patient-ID: ${data.patientIdentifier}`, 10);
    y += 3;
  }

  // Subjective
  doc.setDrawColor(59, 130, 246);
  doc.setLineWidth(0.5);
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  
  addSection('SUBJECTIVE (S)', '');
  addText('Hauptbeschwerde:', 10, true);
  addText(data.subjective.chiefComplaint || '—');
  y += 3;
  
  addText('Anamnese:', 10, true);
  addText(data.subjective.historyOfPresentIllness || '—');
  
  if (data.subjective.reviewOfSystems?.length) {
    y += 3;
    addText('Systemübersicht:', 10, true);
    data.subjective.reviewOfSystems.forEach(item => addText(`• ${item}`));
  }

  // Objective
  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  
  addSection('OBJECTIVE (O)', '');
  addText('Erfasste Beobachtungen:', 10, true);
  
  if (data.objective.observations.length > 0) {
    data.objective.observations.forEach(obs => {
      let obsText = obs.negated ? `[NEGIERT] ${obs.raw_input}` : obs.raw_input;
      if (obs.severity) obsText += ` (Schweregrad: ${obs.severity})`;
      if (obs.onset) obsText += ` | Beginn: ${obs.onset}`;
      if (obs.duration) obsText += ` | Dauer: ${obs.duration}`;
      addText(`• ${obsText}`);
      
      if (obs.hpo_codes?.length) {
        addText(`  HPO: ${obs.hpo_codes.join(', ')}`, 8);
      }
    });
  } else {
    addText('Keine Beobachtungen erfasst.');
  }

  // Assessment
  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  
  addSection('ASSESSMENT (A)', '');
  
  if (data.assessment.redFlags.length > 0) {
    doc.setTextColor(220, 38, 38);
    addText('⚠ Red Flags:', 10, true);
    data.assessment.redFlags.forEach(flag => addText(`• ${flag}`));
    doc.setTextColor(0, 0, 0);
    y += 3;
  }
  
  if (data.assessment.summary) {
    addText('Zusammenfassung:', 10, true);
    addText(data.assessment.summary);
  }
  
  if (data.assessment.hpoCodes.length > 0) {
    y += 3;
    addText('HPO-Codes:', 10, true);
    addText(data.assessment.hpoCodes.join(', '), 8);
  }
  
  if (data.assessment.meshTerms.length > 0) {
    y += 3;
    addText('MeSH-Terme:', 10, true);
    addText(data.assessment.meshTerms.join(', '), 8);
  }

  // Plan
  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  
  addSection('PLAN (P)', '');
  addText(data.plan.notes || '(Vom Behandler auszufüllen)', 10);

  // Footer with metadata
  y += 10;
  doc.setDrawColor(200, 200, 200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  
  doc.setFontSize(8);
  doc.setTextColor(128, 128, 128);
  doc.text(`Session-ID: ${data.metadata.sessionId}`, margin, y);
  y += 4;
  doc.text(`Erstellt: ${data.metadata.createdAt}`, margin, y);
  if (data.metadata.completedAt) {
    doc.text(`Abgeschlossen: ${data.metadata.completedAt}`, pageWidth / 2, y);
  }
  y += 6;
  
  // Disclaimer
  doc.setFontSize(7);
  doc.text(
    'Dieses Dokument wurde durch KI-gestützte Anamnese erstellt und ersetzt keine ärztliche Beurteilung.',
    margin,
    y
  );

  return doc;
}

export function downloadSOAPNotePDF(data: SOAPNoteData, filename?: string) {
  const doc = generateSOAPNotePDF(data);
  const defaultFilename = `soap-note-${data.metadata.sessionId.slice(0, 8)}-${data.sessionDate.replace(/\./g, '-')}.pdf`;
  doc.save(filename || defaultFilename);
}

// Anamnesis Path PDF Export
interface AnamnesisPathData {
  id: string;
  hpoCodes: string[];
  hpoLabels: Record<string, { label_de: string; label_en: string }>;
  differentialDiagnoses: Array<{
    name: string;
    probability: number;
    icd10?: string;
    reasoning: string;
  }>;
  aiReasoning?: string;
  mermaidDiagram?: string;
  version: number;
  isCombined: boolean;
  createdAt: string;
  updatedAt: string;
}

export function generateAnamnesisPathPDF(data: AnamnesisPathData): jsPDF {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - 2 * margin;
  let y = margin;

  const addText = (text: string, fontSize: number = 10, isBold: boolean = false) => {
    doc.setFontSize(fontSize);
    doc.setFont('helvetica', isBold ? 'bold' : 'normal');
    const lines = doc.splitTextToSize(text, contentWidth);
    
    lines.forEach((line: string) => {
      if (y > 270) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += fontSize * 0.5;
    });
    y += 2;
  };

  const addSection = (title: string) => {
    y += 5;
    doc.setDrawColor(59, 130, 246);
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);
    y += 8;
    addText(title, 12, true);
    y += 2;
  };

  // Header
  doc.setFillColor(59, 130, 246);
  doc.rect(0, 0, pageWidth, 35, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Anamnesepfad', margin, 20);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Version: ${data.version}`, margin, 28);
  doc.text(data.isCombined ? 'Kombinierter Pfad' : 'Einzelpfad', pageWidth / 2, 28);
  
  y = 45;
  doc.setTextColor(0, 0, 0);

  // HPO Codes Section
  addSection('HPO-Codes & Symptome');
  
  data.hpoCodes.forEach(code => {
    const label = data.hpoLabels[code];
    const displayLabel = label?.label_de || label?.label_en || 'Unbekannt';
    addText(`• ${code}: ${displayLabel}`);
  });

  // Differential Diagnoses
  if (data.differentialDiagnoses.length > 0) {
    addSection('Differentialdiagnosen');
    
    data.differentialDiagnoses.forEach((dd, idx) => {
      y += 2;
      addText(`${idx + 1}. ${dd.name} (${Math.round(dd.probability * 100)}%)`, 10, true);
      if (dd.icd10) {
        addText(`   ICD-10: ${dd.icd10}`, 9);
      }
      if (dd.reasoning) {
        addText(`   ${dd.reasoning}`, 9);
      }
      y += 2;
    });
  }

  // AI Reasoning
  if (data.aiReasoning) {
    addSection('KI-Begründung');
    addText(data.aiReasoning);
  }

  // Mermaid Diagram Note
  if (data.mermaidDiagram) {
    addSection('Entscheidungspfad');
    addText('Ein visuelles Mermaid-Diagramm ist in der Web-Anwendung verfügbar.', 9);
    y += 5;
    doc.setFontSize(8);
    doc.setTextColor(128, 128, 128);
    // Show first 500 chars of mermaid code
    const preview = data.mermaidDiagram.slice(0, 500) + (data.mermaidDiagram.length > 500 ? '...' : '');
    doc.setFont('courier', 'normal');
    const lines = doc.splitTextToSize(preview, contentWidth);
    lines.slice(0, 15).forEach((line: string) => {
      if (y > 270) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += 4;
    });
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(0, 0, 0);
  }

  // Footer
  y += 10;
  doc.setDrawColor(200, 200, 200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  
  doc.setFontSize(8);
  doc.setTextColor(128, 128, 128);
  doc.text(`Pfad-ID: ${data.id}`, margin, y);
  y += 4;
  doc.text(`Erstellt: ${data.createdAt}`, margin, y);
  doc.text(`Aktualisiert: ${data.updatedAt}`, pageWidth / 2, y);
  y += 8;
  
  // Disclaimer
  doc.setFontSize(7);
  doc.text(
    'Dieses Dokument wurde durch KI-gestützte Analyse erstellt und ersetzt keine ärztliche Beurteilung.',
    margin,
    y
  );

  return doc;
}

export function downloadAnamnesisPathPDF(data: AnamnesisPathData, filename?: string) {
  const doc = generateAnamnesisPathPDF(data);
  const hpoSummary = data.hpoCodes.slice(0, 2).join('-').replace(/:/g, '');
  const defaultFilename = `anamnesepfad-${hpoSummary}-v${data.version}.pdf`;
  doc.save(filename || defaultFilename);
}

// Question Tree Checklist PDF Export
interface ChecklistCategory {
  key: string;
  labelDe: string;
  labelEn: string;
  questions: Array<{
    question?: string;
    text?: string;
    followUp?: string[];
    options?: string[];
  }>;
}

interface ChecklistData {
  categories: ChecklistCategory[];
  patientIdentifier?: string;
  sessionDate?: string;
  language: string;
}

const CATEGORY_LABELS: Record<string, { labelDe: string; labelEn: string }> = {
  chief_complaint: { labelDe: 'Hauptbeschwerde', labelEn: 'Chief Complaint' },
  hpi: { labelDe: 'Aktuelle Beschwerden', labelEn: 'History of Present Illness' },
  ros: { labelDe: 'Systemübersicht', labelEn: 'Review of Systems' },
  pmh: { labelDe: 'Vorerkrankungen', labelEn: 'Past Medical History' },
  medications: { labelDe: 'Medikamente', labelEn: 'Medications' },
  social: { labelDe: 'Sozialanamnese', labelEn: 'Social History' },
  family: { labelDe: 'Familienanamnese', labelEn: 'Family History' },
};

export function generateChecklistPDF(data: ChecklistData): jsPDF {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin;
  const checkboxSize = 4;
  const lineHeight = 6;
  let y = margin;
  const isGerman = data.language === 'de';

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > 280) {
      doc.addPage();
      y = margin;
      return true;
    }
    return false;
  };

  const drawCheckbox = (x: number, yPos: number) => {
    doc.setDrawColor(100, 100, 100);
    doc.setLineWidth(0.3);
    doc.rect(x, yPos - checkboxSize + 1, checkboxSize, checkboxSize);
  };

  // Header
  doc.setFillColor(59, 130, 246);
  doc.rect(0, 0, pageWidth, 25, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(isGerman ? 'Anamnese-Checkliste' : 'Anamnesis Checklist', margin, 15);
  
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  const dateStr = data.sessionDate || new Date().toLocaleDateString(isGerman ? 'de-DE' : 'en-US');
  doc.text(`${isGerman ? 'Datum' : 'Date'}: ${dateStr}`, pageWidth - margin - 40, 15);
  
  y = 35;
  doc.setTextColor(0, 0, 0);

  // Patient identifier line
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(isGerman ? 'Patient:' : 'Patient:', margin, y);
  doc.setFont('helvetica', 'normal');
  if (data.patientIdentifier) {
    doc.text(data.patientIdentifier, margin + 25, y);
  } else {
    doc.setDrawColor(150, 150, 150);
    doc.line(margin + 25, y, pageWidth - margin, y);
  }
  y += 10;

  // Categories with questions
  data.categories.forEach(category => {
    if (category.questions.length === 0) return;

    const labels = CATEGORY_LABELS[category.key] || { labelDe: category.key, labelEn: category.key };
    const categoryLabel = isGerman ? labels.labelDe : labels.labelEn;
    
    // Check if we need a new page for category header + at least one question
    checkPageBreak(20);

    // Category header
    doc.setFillColor(240, 240, 245);
    doc.rect(margin, y - 4, contentWidth, 8, 'F');
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(59, 130, 246);
    doc.text(categoryLabel, margin + 3, y + 1);
    doc.setTextColor(0, 0, 0);
    y += 10;

    // Questions
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    
    category.questions.forEach(q => {
      const questionText = q.question || q.text || '';
      if (!questionText) return;

      const lines = doc.splitTextToSize(questionText, contentWidth - 15);
      const questionHeight = lines.length * lineHeight + 2;
      
      // Check for follow-ups and options
      const hasFollowUp = q.followUp && q.followUp.length > 0;
      const hasOptions = q.options && q.options.length > 0;
      const extraHeight = (hasFollowUp ? q.followUp!.length * lineHeight : 0) + 
                          (hasOptions ? q.options!.length * lineHeight : 0);
      
      checkPageBreak(questionHeight + extraHeight + 5);

      // Draw checkbox and question
      drawCheckbox(margin, y);
      
      lines.forEach((line: string, lineIdx: number) => {
        doc.text(line, margin + checkboxSize + 4, y + (lineIdx * lineHeight));
      });
      y += lines.length * lineHeight + 1;

      // Follow-up questions (indented, smaller)
      if (hasFollowUp) {
        doc.setFontSize(8);
        doc.setTextColor(100, 100, 100);
        q.followUp!.forEach(fu => {
          checkPageBreak(lineHeight + 2);
          drawCheckbox(margin + 8, y);
          const fuLines = doc.splitTextToSize(`→ ${fu}`, contentWidth - 25);
          fuLines.forEach((line: string, lineIdx: number) => {
            doc.text(line, margin + 16, y + (lineIdx * lineHeight));
          });
          y += fuLines.length * lineHeight;
        });
        doc.setFontSize(9);
        doc.setTextColor(0, 0, 0);
      }

      // Options (as bullet points)
      if (hasOptions) {
        doc.setFontSize(8);
        doc.setTextColor(80, 80, 80);
        q.options!.forEach(opt => {
          checkPageBreak(lineHeight + 2);
          doc.text(`○ ${opt}`, margin + 12, y);
          y += lineHeight - 1;
        });
        doc.setFontSize(9);
        doc.setTextColor(0, 0, 0);
      }

      y += 2;
    });

    y += 5;
  });

  // Notes section at bottom
  checkPageBreak(40);
  y += 5;
  doc.setDrawColor(200, 200, 200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(isGerman ? 'Notizen:' : 'Notes:', margin, y);
  y += 5;
  
  // Draw lines for notes
  doc.setDrawColor(220, 220, 220);
  for (let i = 0; i < 5; i++) {
    y += 8;
    if (y > 275) break;
    doc.line(margin, y, pageWidth - margin, y);
  }

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text(
      `${isGerman ? 'Seite' : 'Page'} ${i}/${pageCount}`,
      pageWidth / 2,
      290,
      { align: 'center' }
    );
    doc.text(
      isGerman ? 'KI-Anamnese Checkliste' : 'AI Anamnesis Checklist',
      margin,
      290
    );
  }

  return doc;
}

export function downloadChecklistPDF(data: ChecklistData, filename?: string) {
  const doc = generateChecklistPDF(data);
  const dateStr = new Date().toISOString().slice(0, 10);
  const defaultFilename = `anamnese-checkliste-${dateStr}.pdf`;
  doc.save(filename || defaultFilename);
}
