interface SessionExportData {
  session: {
    id: string;
    userId: string;
    patientIdentifier?: string;
    clinicalView: string;
    language: string;
    status: string;
    startedAt: string;
    completedAt?: string;
    createdAt: string;
  };
  observations: Array<{
    id: string;
    rawInput: string;
    normalizedValue?: string;
    language: string;
    hpoCodes?: string[];
    rxnormCodes?: string[];
    meshTerms?: string[];
    negated?: boolean;
    onset?: string;
    duration?: string;
    severity?: string;
    confidence?: number;
    provenance?: string;
    createdAt: string;
  }>;
  evidenceRequests?: Array<{
    id: string;
    queryContext: Record<string, unknown>;
    queryStrings: Record<string, unknown>;
    sources: string[];
    createdAt: string;
  }>;
  evidenceItems?: Array<{
    id: string;
    source: string;
    externalId: string;
    title: string;
    year?: number;
    venue?: string;
    url?: string;
    snippet?: string;
    studyType?: string;
    relevanceScore?: number;
    createdAt: string;
  }>;
  metadata: {
    exportedAt: string;
    exportVersion: string;
    schemaVersion: string;
  };
}

export function formatSessionForExport(
  session: {
    id: string;
    user_id: string;
    patient_identifier?: string | null;
    clinical_view: string;
    language: string;
    status: string;
    started_at?: string | null;
    completed_at?: string | null;
    created_at?: string | null;
  },
  observations: Array<{
    id: string;
    raw_input: string;
    normalized_value?: string | null;
    language: string;
    hpo_codes?: string[] | null;
    rxnorm_codes?: string[] | null;
    mesh_terms?: string[] | null;
    negated?: boolean | null;
    onset?: string | null;
    duration?: string | null;
    severity?: string | null;
    confidence?: number | null;
    provenance?: string | null;
    created_at?: string | null;
  }>,
  evidenceRequests?: Array<{
    id: string;
    query_context: Record<string, unknown>;
    query_strings: Record<string, unknown>;
    sources: string[];
    created_at?: string | null;
  }>,
  evidenceItems?: Array<{
    id: string;
    source: string;
    external_id: string;
    title: string;
    year?: number | null;
    venue?: string | null;
    url?: string | null;
    snippet?: string | null;
    study_type?: string | null;
    relevance_score?: number | null;
    created_at?: string | null;
  }>
): SessionExportData {
  return {
    session: {
      id: session.id,
      userId: session.user_id,
      patientIdentifier: session.patient_identifier ?? undefined,
      clinicalView: session.clinical_view,
      language: session.language,
      status: session.status,
      startedAt: session.started_at ?? '',
      completedAt: session.completed_at ?? undefined,
      createdAt: session.created_at ?? '',
    },
    observations: observations.map(obs => ({
      id: obs.id,
      rawInput: obs.raw_input,
      normalizedValue: obs.normalized_value ?? undefined,
      language: obs.language,
      hpoCodes: obs.hpo_codes ?? undefined,
      rxnormCodes: obs.rxnorm_codes ?? undefined,
      meshTerms: obs.mesh_terms ?? undefined,
      negated: obs.negated ?? undefined,
      onset: obs.onset ?? undefined,
      duration: obs.duration ?? undefined,
      severity: obs.severity ?? undefined,
      confidence: obs.confidence ?? undefined,
      provenance: obs.provenance ?? undefined,
      createdAt: obs.created_at ?? '',
    })),
    evidenceRequests: evidenceRequests?.map(req => ({
      id: req.id,
      queryContext: req.query_context,
      queryStrings: req.query_strings,
      sources: req.sources,
      createdAt: req.created_at ?? '',
    })),
    evidenceItems: evidenceItems?.map(item => ({
      id: item.id,
      source: item.source,
      externalId: item.external_id,
      title: item.title,
      year: item.year ?? undefined,
      venue: item.venue ?? undefined,
      url: item.url ?? undefined,
      snippet: item.snippet ?? undefined,
      studyType: item.study_type ?? undefined,
      relevanceScore: item.relevance_score ?? undefined,
      createdAt: item.created_at ?? '',
    })),
    metadata: {
      exportedAt: new Date().toISOString(),
      exportVersion: '1.0.0',
      schemaVersion: '1.0.0',
    },
  };
}

export function downloadSessionJSON(data: SessionExportData, filename?: string) {
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = filename || `anamnesis-session-${data.session.id.slice(0, 8)}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function generateFHIRBundle(data: SessionExportData): Record<string, unknown> {
  // Basic FHIR R4 Bundle structure for interoperability
  return {
    resourceType: 'Bundle',
    type: 'document',
    timestamp: data.metadata.exportedAt,
    entry: [
      {
        resource: {
          resourceType: 'Composition',
          status: 'final',
          type: {
            coding: [{
              system: 'http://loinc.org',
              code: '11506-3',
              display: 'Progress note',
            }],
          },
          date: data.session.createdAt,
          title: 'KI-gestützte Anamnese',
          section: [
            {
              title: 'Subjective',
              code: {
                coding: [{
                  system: 'http://loinc.org',
                  code: '61150-9',
                  display: 'Subjective',
                }],
              },
            },
            {
              title: 'Objective',
              code: {
                coding: [{
                  system: 'http://loinc.org',
                  code: '61149-1',
                  display: 'Objective',
                }],
              },
            },
          ],
        },
      },
      // Observations with HPO coding
      ...data.observations.map(obs => ({
        resource: {
          resourceType: 'Observation',
          status: 'final',
          code: {
            coding: obs.hpoCodes?.map(code => ({
              system: 'http://purl.obolibrary.org/obo/hp.owl',
              code: code,
            })) || [],
            text: obs.rawInput,
          },
          valueString: obs.normalizedValue || obs.rawInput,
          effectiveDateTime: obs.createdAt,
          interpretation: obs.negated ? [{
            coding: [{
              system: 'http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation',
              code: 'NEG',
              display: 'Negative',
            }],
          }] : undefined,
        },
      })),
    ],
  };
}
