import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Users from "./pages/admin/Users";
import Integrations from "./pages/admin/Integrations";
import GuidelinesAdmin from "./pages/admin/Guidelines";
import PipelinesAdmin from "./pages/admin/Pipelines";
import Anamnesis from "./pages/Anamnesis";
import AnamnesisEvidence from "./pages/AnamnesisEvidence";
import SessionDocumentation from "./pages/SessionDocumentation";
import Sessions from "./pages/Sessions";
import OntologyBrowser from "./pages/OntologyBrowser";
import AnamnesisPathways from "./pages/AnamnesisPathways";
import EvidenceSearch from "./pages/EvidenceSearch";
import Patients from "./pages/Patients";
import Chatbot from "./pages/Chatbot";
import NotFound from "./pages/NotFound";
import "@/i18n";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/login" element={<Login />} />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <Profile />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/users"
                element={
                  <ProtectedRoute requireAdmin>
                    <Users />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/integrations"
                element={
                  <ProtectedRoute requireAdmin>
                    <Integrations />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/guidelines"
                element={
                  <ProtectedRoute requireAdmin>
                    <GuidelinesAdmin />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/pipelines"
                element={
                  <ProtectedRoute requireAdmin>
                    <PipelinesAdmin />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/anamnesis"
                element={
                  <ProtectedRoute>
                    <Anamnesis />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/anamnesis/:sessionId/evidence"
                element={
                  <ProtectedRoute>
                    <AnamnesisEvidence />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/sessions"
                element={
                  <ProtectedRoute>
                    <Sessions />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/sessions/:sessionId"
                element={
                  <ProtectedRoute>
                    <SessionDocumentation />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/ontology"
                element={
                  <ProtectedRoute>
                    <OntologyBrowser />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/pathways"
                element={
                  <ProtectedRoute>
                    <AnamnesisPathways />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/evidence-search"
                element={
                  <ProtectedRoute>
                    <EvidenceSearch />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/patients"
                element={
                  <ProtectedRoute>
                    <Patients />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/chatbot"
                element={
                  <ProtectedRoute>
                    <Chatbot />
                  </ProtectedRoute>
                }
              />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
