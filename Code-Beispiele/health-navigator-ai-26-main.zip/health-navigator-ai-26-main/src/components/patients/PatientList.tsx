import { useState } from 'react';
import { Search, Upload, Database } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { FhirPatient, useFhirPatients } from '@/hooks/useFhirPatients';
import { FhirImportDialog } from './FhirImportDialog';
import { FhirDemoDataDialog } from './FhirDemoDataDialog';

interface PatientListProps {
  selectedId: string | null;
  onSelect: (patient: FhirPatient) => void;
}

export function PatientList({ selectedId, onSelect }: PatientListProps) {
  const [search, setSearch] = useState('');
  const [importOpen, setImportOpen] = useState(false);
  const [demoOpen, setDemoOpen] = useState(false);
  const { data: patients, isLoading, importBundle } = useFhirPatients();

  const handleImport = async (bundle: any) => {
    const result = await importBundle.mutateAsync(bundle);
    return result;
  };

  const filtered = (patients || []).filter(p => {
    const q = search.toLowerCase();
    return !q || 
      p.given_name.toLowerCase().includes(q) || 
      p.family_name.toLowerCase().includes(q) ||
      p.identifier_mrn?.toLowerCase().includes(q);
  });

  const getAge = (birthDate: string | null) => {
    if (!birthDate) return null;
    return Math.floor((Date.now() - new Date(birthDate).getTime()) / 31557600000);
  };

  const genderIcon = (g: string | null) => {
    switch (g) {
      case 'male': return '♂';
      case 'female': return '♀';
      default: return '⚧';
    }
  };

  return (
    <div className="flex h-full flex-col border-r bg-card">
      <div className="border-b p-3 space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground">Patienten</h2>
          <div className="flex gap-1">
            <Button 
              size="sm" 
              variant="outline" 
              className="h-7 text-xs gap-1"
              onClick={() => setDemoOpen(true)}
            >
              <Database className="h-3 w-3" />
              Demo
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              className="h-7 text-xs gap-1"
              onClick={() => setImportOpen(true)}
            >
              <Upload className="h-3 w-3" />
              Import
            </Button>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input 
            placeholder="Name oder MRN..." 
            value={search} 
            onChange={e => setSearch(e.target.value)}
            className="h-8 pl-7 text-xs"
          />
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {isLoading ? (
            <p className="text-xs text-muted-foreground p-3 text-center">Laden...</p>
          ) : filtered.length === 0 ? (
            <p className="text-xs text-muted-foreground p-3 text-center">
              {patients?.length ? 'Keine Treffer' : 'Noch keine Patienten. Importieren Sie ein FHIR Bundle.'}
            </p>
          ) : (
            filtered.map(p => {
              const age = getAge(p.birth_date);
              return (
                <button
                  key={p.id}
                  onClick={() => onSelect(p)}
                  className={cn(
                    'w-full text-left rounded-lg p-2.5 transition-all duration-200',
                    'hover:bg-accent/50 group',
                    selectedId === p.id 
                      ? 'bg-primary/10 border border-primary/30 shadow-sm' 
                      : 'border border-transparent'
                  )}
                >
                  <div className="flex items-start gap-2.5">
                    <div className={cn(
                      'flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold flex-shrink-0',
                      selectedId === p.id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                    )}>
                      {p.given_name[0]}{p.family_name[0]}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate text-foreground">
                        {p.family_name}, {p.given_name}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-muted-foreground">
                          {genderIcon(p.gender)} {age !== null ? `${age}J` : ''}
                        </span>
                        {p.identifier_mrn && (
                          <span className="text-xs text-muted-foreground font-mono">
                            #{p.identifier_mrn}
                          </span>
                        )}
                      </div>
                    </div>
                    {p.active && (
                      <Badge variant="outline" className="text-[10px] h-4 px-1 bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                        aktiv
                      </Badge>
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>
      </ScrollArea>

      <div className="border-t p-2 text-center">
        <p className="text-[10px] text-muted-foreground">
          {filtered.length} von {patients?.length || 0} Patienten
        </p>
      </div>

      <FhirImportDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        onImport={handleImport}
        isPending={importBundle.isPending}
      />

      <FhirDemoDataDialog
        open={demoOpen}
        onOpenChange={setDemoOpen}
        onImport={handleImport}
      />
    </div>
  );
}
