import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import JSZip from 'jszip';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Upload, FileJson, Archive, CheckCircle2, AlertCircle, Loader2, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ParsedBundle {
  id: string;
  fileName: string;
  bundle: any;
  patientCount: number;
  resourceCount: number;
  status: 'pending' | 'importing' | 'done' | 'error';
  error?: string;
  stats?: Record<string, number>;
}

interface FhirImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (bundle: any) => Promise<any>;
  isPending: boolean;
}

export function FhirImportDialog({ open, onOpenChange, onImport, isPending }: FhirImportDialogProps) {
  const [bundles, setBundles] = useState<ParsedBundle[]>([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);

  const parseFhirJson = (json: any, fileName: string): ParsedBundle | null => {
    if (json.resourceType === 'Bundle' && json.entry) {
      const patientCount = json.entry.filter((e: any) => e.resource?.resourceType === 'Patient').length;
      return {
        id: crypto.randomUUID(),
        fileName,
        bundle: json,
        patientCount,
        resourceCount: json.entry.length,
        status: 'pending',
      };
    }
    return null;
  };

  const processFile = async (file: File): Promise<ParsedBundle[]> => {
    const results: ParsedBundle[] = [];

    if (file.name.endsWith('.zip')) {
      const zip = await JSZip.loadAsync(file);
      const jsonFiles = Object.entries(zip.files).filter(
        ([name]) => name.endsWith('.json') && !name.startsWith('__MACOSX')
      );

      for (const [name, zipEntry] of jsonFiles) {
        try {
          const text = await zipEntry.async('text');
          const json = JSON.parse(text);
          const parsed = parseFhirJson(json, name.split('/').pop() || name);
          if (parsed) results.push(parsed);
        } catch {
          // skip invalid files
        }
      }
    } else if (file.name.endsWith('.json')) {
      try {
        const text = await file.text();
        const json = JSON.parse(text);
        const parsed = parseFhirJson(json, file.name);
        if (parsed) results.push(parsed);
      } catch {
        // skip
      }
    }

    return results;
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const allBundles: ParsedBundle[] = [];
    for (const file of acceptedFiles) {
      const parsed = await processFile(file);
      allBundles.push(...parsed);
    }
    setBundles(prev => [...prev, ...allBundles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/json': ['.json'],
      'application/zip': ['.zip'],
      'application/x-zip-compressed': ['.zip'],
    },
    multiple: true,
  });

  const removeBundle = (id: string) => {
    setBundles(prev => prev.filter(b => b.id !== id));
  };

  const importAll = async () => {
    setImporting(true);
    setProgress(0);

    for (let i = 0; i < bundles.length; i++) {
      const bundle = bundles[i];
      if (bundle.status === 'done') continue;

      setBundles(prev => prev.map(b => b.id === bundle.id ? { ...b, status: 'importing' } : b));

      try {
        const result = await onImport(bundle.bundle);
        setBundles(prev => prev.map(b => b.id === bundle.id
          ? { ...b, status: 'done', stats: result?.stats }
          : b
        ));
      } catch (err: any) {
        setBundles(prev => prev.map(b => b.id === bundle.id
          ? { ...b, status: 'error', error: err.message }
          : b
        ));
      }

      setProgress(((i + 1) / bundles.length) * 100);
    }

    setImporting(false);
  };

  const handleClose = (open: boolean) => {
    if (!importing) {
      if (!open) setBundles([]);
      onOpenChange(open);
    }
  };

  const pendingCount = bundles.filter(b => b.status === 'pending').length;
  const doneCount = bundles.filter(b => b.status === 'done').length;
  const totalPatients = bundles.reduce((s, b) => s + b.patientCount, 0);
  const totalResources = bundles.reduce((s, b) => s + b.resourceCount, 0);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            FHIR-Import
          </DialogTitle>
          <DialogDescription>
            FHIR Bundles als JSON oder ZIP mit mehreren JSON-Dateien importieren.
          </DialogDescription>
        </DialogHeader>

        {/* Dropzone */}
        <div
          {...getRootProps()}
          className={cn(
            'border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors',
            isDragActive
              ? 'border-primary bg-primary/5'
              : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-accent/30'
          )}
        >
          <input {...getInputProps()} />
          <div className="flex flex-col items-center gap-2">
            <div className="flex gap-2">
              <FileJson className="h-8 w-8 text-muted-foreground" />
              <Archive className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">
              {isDragActive ? 'Dateien hier ablegen...' : 'JSON oder ZIP-Dateien hierher ziehen'}
            </p>
            <p className="text-xs text-muted-foreground">
              Unterstützt: .json (FHIR Bundle), .zip (mehrere Bundles)
            </p>
          </div>
        </div>

        {/* Bundle List */}
        {bundles.length > 0 && (
          <>
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>{bundles.length} Bundle(s) · {totalPatients} Patienten · {totalResources} Ressourcen</span>
              <span>{doneCount}/{bundles.length} importiert</span>
            </div>

            {importing && <Progress value={progress} className="h-1.5" />}

            <ScrollArea className="max-h-52">
              <div className="space-y-1.5">
                {bundles.map(b => (
                  <div
                    key={b.id}
                    className={cn(
                      'flex items-center gap-2 rounded-md border px-3 py-2 text-sm',
                      b.status === 'done' && 'bg-emerald-500/5 border-emerald-500/20',
                      b.status === 'error' && 'bg-destructive/5 border-destructive/20',
                      b.status === 'importing' && 'bg-primary/5 border-primary/20',
                    )}
                  >
                    {b.status === 'pending' && <FileJson className="h-4 w-4 text-muted-foreground flex-shrink-0" />}
                    {b.status === 'importing' && <Loader2 className="h-4 w-4 text-primary animate-spin flex-shrink-0" />}
                    {b.status === 'done' && <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0" />}
                    {b.status === 'error' && <AlertCircle className="h-4 w-4 text-destructive flex-shrink-0" />}

                    <div className="min-w-0 flex-1">
                      <p className="truncate font-mono text-xs">{b.fileName}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {b.patientCount} Pat. · {b.resourceCount} Res.
                        {b.stats && ` · ${b.stats.conditions || 0} Diag. · ${b.stats.observations || 0} Labor`}
                        {b.error && <span className="text-destructive ml-1">{b.error}</span>}
                      </p>
                    </div>

                    {b.status === 'pending' && !importing && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0"
                        onClick={(e) => { e.stopPropagation(); removeBundle(b.id); }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => handleClose(false)} disabled={importing}>
                Abbrechen
              </Button>
              <Button
                size="sm"
                onClick={importAll}
                disabled={importing || pendingCount === 0}
                className="gap-1.5"
              >
                {importing ? (
                  <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Importiere...</>
                ) : (
                  <><Upload className="h-3.5 w-3.5" /> {pendingCount} Bundle(s) importieren</>
                )}
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
