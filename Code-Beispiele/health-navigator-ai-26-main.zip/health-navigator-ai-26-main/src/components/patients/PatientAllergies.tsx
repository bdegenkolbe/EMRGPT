import { useFhirPatientData } from '@/hooks/useFhirPatients';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertTriangle } from 'lucide-react';

interface Props { patientId: string; }

const critColors: Record<string, string> = {
  high: 'bg-destructive/10 text-destructive border-destructive/20',
  low: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  'unable-to-assess': 'bg-muted text-muted-foreground',
};

export function PatientAllergies({ patientId }: Props) {
  const { allergies } = useFhirPatientData(patientId);

  if (allergies.isLoading) return <p className="p-4 text-sm text-muted-foreground">Laden...</p>;
  const data = allergies.data || [];

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-2">
        <h3 className="text-sm font-semibold text-foreground mb-3">Allergien & Unverträglichkeiten ({data.length})</h3>
        {data.length === 0 ? (
          <p className="text-sm text-muted-foreground">Keine Allergien dokumentiert.</p>
        ) : data.map(a => (
          <Card key={a.id} className={a.criticality === 'high' ? 'border-destructive/30' : ''}>
            <CardContent className="p-3">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className={`h-4 w-4 mt-0.5 flex-shrink-0 ${a.criticality === 'high' ? 'text-destructive' : 'text-amber-500'}`} />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground">{a.code_display || a.code || 'Unbekannt'}</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {a.type && <Badge variant="outline" className="text-[10px]">{a.type}</Badge>}
                    {a.category && <Badge variant="secondary" className="text-[10px]">{a.category}</Badge>}
                    {a.criticality && (
                      <Badge variant="outline" className={`text-[10px] ${critColors[a.criticality] || ''}`}>
                        {a.criticality === 'high' ? 'Hoch' : a.criticality === 'low' ? 'Niedrig' : a.criticality}
                      </Badge>
                    )}
                  </div>
                  {Array.isArray(a.reactions) && a.reactions.length > 0 && (
                    <div className="mt-1.5">
                      <p className="text-xs text-muted-foreground">
                        Reaktionen: {a.reactions.map((r: any) => r.manifestation?.[0]?.coding?.[0]?.display || r.description || '?').join(', ')}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </ScrollArea>
  );
}
