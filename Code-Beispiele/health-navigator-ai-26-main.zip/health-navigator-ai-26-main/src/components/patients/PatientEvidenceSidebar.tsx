import { useState, useEffect, useRef, useCallback } from 'react';
import { useFhirPatientData } from '@/hooks/useFhirPatients';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent } from '@/components/ui/tabs';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Progress } from '@/components/ui/progress';
import {
  BookOpen, ExternalLink, Loader2, RefreshCw, FileText,
  ChevronDown, ChevronRight, FileDown, FlaskConical, Users, Calendar,
  CheckCircle, Languages, Copy, Check, Info, Globe, FolderOpen,
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { PatientDocumentsTab } from './PatientDocumentsTab';
import { DocumentDetailPanel } from './DocumentDetailPanel';
import { DraggableTabsList } from './DraggableTabsList';
import { useProfile } from '@/hooks/useProfile';

/* ── Types ── */
interface GuidelineChunk {
  chunk_id: string;
  section_title: string | null;
  content: string;
  page_number: number | null;
  similarity: number;
}

interface GuidelineGroup {
  guideline_id: string;
  guideline_title: string;
  file_path?: string | null;
  file_name?: string | null;
  source?: string | null;
  description?: string | null;
  chunks: GuidelineChunk[];
}

interface Article {
  id: string;
  title: string;
  authors: string[];
  authorDetails?: { given: string; family: string; fullName: string; orcid?: string; affiliations?: string[] }[];
  journal: string;
  year: number | null;
  publicationDate: string | null;
  doi: string | null;
  pmid: string | null;
  pmcid: string | null;
  isOpenAccess: boolean;
  oaStatus: string | null;
  citedByCount: number;
  abstract: string;
  pdfUrl: string | null;
  fullTextUrl: string | null;
  europePmcUrl: string;
  keywords: string[];
  meshTerms: string[];
}

interface PersistedSource {
  id: string;
  external_id: string | null;
  title: string;
  translated_title: string | null;
  original_content: string | null;
  translated_content: string | null;
  content_status: string;
  translation_status: string;
  content_type: string;
  original_language: string | null;
  pdf_path: string | null;
  year: number | null;
  authors: string | null;
  url: string | null;
  metadata: Record<string, unknown> | null;
  relevance_score: number | null;
}

interface ClinicalTrial {
  nctId: string;
  title: string;
  status: string;
  phase: string;
  conditions: string[];
  interventions: string[];
  sponsor: string;
  startDate: string | null;
  completionDate: string | null;
  enrollment: number | null;
  studyType: string;
  briefSummary: string;
  url: string;
}

interface Props {
  patientId: string;
}

export function PatientEvidenceSidebar({ patientId }: Props) {
  const { conditions } = useFhirPatientData(patientId);
  const { profile, updateProfile } = useProfile();

  const DEFAULT_TAB_ORDER = ['guidelines', 'literature', 'trials', 'documents'];
  const tabOrder = profile?.sidebar_tab_order ?? DEFAULT_TAB_ORDER;

  const TAB_DEFS = [
    { value: 'guidelines', label: 'Leitlinien', icon: <FileText className="h-3 w-3" /> },
    { value: 'literature', label: 'Literatur', icon: <BookOpen className="h-3 w-3" /> },
    { value: 'trials', label: 'Studien', icon: <FlaskConical className="h-3 w-3" /> },
    { value: 'documents', label: 'Doku', icon: <FolderOpen className="h-3 w-3" /> },
  ];

  const handleTabOrderChange = useCallback((newOrder: string[]) => {
    updateProfile.mutate({ sidebar_tab_order: newOrder });
  }, [updateProfile]);

  const [guidelines, setGuidelines] = useState<GuidelineGroup[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [persistedSources, setPersistedSources] = useState<PersistedSource[]>([]);
  const [trials, setTrials] = useState<ClinicalTrial[]>([]);
  const [expandedArticles, setExpandedArticles] = useState<Set<string>>(new Set());
  const [loadingGL, setLoadingGL] = useState(false);
  const [loadingLit, setLoadingLit] = useState(false);
  const [loadingTrials, setLoadingTrials] = useState(false);
  const [showOriginal, setShowOriginal] = useState<Set<string>>(new Set());
  const [searchId, setSearchId] = useState<string | null>(null);
  const [pmcQuery, setPmcQuery] = useState<string | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<any | null>(null);

  const prevKeyRef = useRef('');

  const activeConditions = (conditions.data || []).filter(
    (c) => c.clinical_status === 'active' || !c.abatement_datetime,
  );

  const conditionKey = activeConditions.map((c) => c.id).join(',');

  /* ── Build search params from conditions ── */
  const buildSearchParams = useCallback(() => {
    const slice = activeConditions.slice(0, 5);
    const terms = slice.map((c) => c.code_display || c.code || '').filter(Boolean);
    const icd10: string[] = [];
    const hpo: string[] = [];
    const snomed: string[] = [];

    for (const c of slice) {
      if (c.code) icd10.push(c.code);
      if (c.hpo_codes?.length) hpo.push(...c.hpo_codes);
      if (c.snomed_codes?.length) snomed.push(...c.snomed_codes);
    }

    return { terms, icd10, hpo, snomed };
  }, [conditionKey]);

  /* ── Persist articles to knowledge_sources and trigger translation ── */
  const persistAndTranslate = useCallback(async (articlesData: Article[], query: string) => {
    try {
      // Get user id
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Check for existing sources by external_id to reuse translations
      const externalIds = articlesData.map(a => a.pmid || a.id).filter(Boolean);
      const { data: existingSources } = await supabase
        .from('knowledge_sources')
        .select('external_id, translated_title, translated_content, translation_status, content_status, content_type, original_content, pdf_path')
        .in('external_id', externalIds)
        .eq('translation_status', 'completed');

      const existingMap = new Map(
        (existingSources || []).map(s => [s.external_id, s])
      );

      // Create knowledge_searches record
      const { data: searchData, error: searchError } = await supabase
        .from('knowledge_searches')
        .insert({
          query,
          user_id: user.id,
          language: 'de',
          query_analysis: { pmcQuery: query, source: 'patient_evidence' },
        })
        .select('id')
        .single();

      if (searchError || !searchData) {
        console.error('Failed to create search record:', searchError);
        return;
      }

      const newSearchId = searchData.id;
      setSearchId(newSearchId);

      // Build source records
      const sourceRecords = articlesData.map((a) => {
        const externalId = a.pmid || a.id;
        const existing = existingMap.get(externalId);

        return {
          search_id: newSearchId,
          source_type: 'europepmc',
          external_id: externalId,
          title: a.title,
          authors: a.authors?.join(', ') || null,
          year: a.year,
          url: a.europePmcUrl,
          original_language: 'en',
          original_content: existing?.original_content || a.abstract || null,
          translated_title: existing?.translated_title || null,
          translated_content: existing?.translated_content || null,
          content_status: existing?.content_status === 'loaded' ? 'loaded' : (a.abstract ? 'loaded' : 'pending'),
          content_type: existing?.content_type || 'abstract',
          translation_status: existing?.translation_status === 'completed' ? 'completed' : 'pending',
          target_language: 'de',
          pdf_path: existing?.pdf_path || null,
          metadata: {
            pmcid: a.pmcid,
            doi: a.doi,
            isOpenAccess: a.isOpenAccess,
            pdfUrl: a.pdfUrl,
            journal: a.journal,
            citedByCount: a.citedByCount,
          },
        };
      });

      const { data: insertedSources, error: insertError } = await supabase
        .from('knowledge_sources')
        .insert(sourceRecords)
        .select('*');

      if (insertError) {
        console.error('Failed to insert sources:', insertError);
        return;
      }

      setPersistedSources((insertedSources || []) as PersistedSource[]);

      // Trigger knowledge-load-content for sources needing translation
      const sourcesNeedingWork = (insertedSources || []).filter(
        s => s.translation_status === 'pending' || s.content_status === 'pending'
      );

      if (sourcesNeedingWork.length > 0) {
        supabase.functions.invoke('knowledge-load-content', {
          body: {
            searchId: newSearchId,
            sourceIds: sourcesNeedingWork.map(s => s.id),
            targetLanguage: 'de',
          },
        }).then(({ error }) => {
          if (error) console.error('knowledge-load-content error:', error);
        });
      }
    } catch (err) {
      console.error('Persist error:', err);
    }
  }, []);

  /* ── Poll for translation/content updates ── */
  useEffect(() => {
    if (!searchId || persistedSources.length === 0) return;

    const pending = persistedSources.filter(
      s => s.content_status === 'pending' || s.content_status === 'loading' ||
           s.translation_status === 'pending' || s.translation_status === 'loading'
    );

    if (pending.length === 0) return;

    const interval = setInterval(async () => {
      const { data } = await supabase
        .from('knowledge_sources')
        .select('*')
        .eq('search_id', searchId);

      if (data) {
        setPersistedSources(data as PersistedSource[]);

        const stillPending = data.filter(
          s => s.content_status === 'pending' || s.content_status === 'loading' ||
               s.translation_status === 'pending' || s.translation_status === 'loading'
        );
        if (stillPending.length === 0) {
          clearInterval(interval);
        }
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [searchId, persistedSources]);

  /* ── Parallel search ── */
  const runSearch = useCallback(async () => {
    const { terms, icd10, hpo, snomed } = buildSearchParams();
    if (terms.length === 0) {
      setGuidelines([]);
      setArticles([]);
      setPersistedSources([]);
      setTrials([]);
      setSearchId(null);
      setPmcQuery(null);
      return;
    }

    const queryText = terms.join(' ');

    // Guidelines search
    setLoadingGL(true);
    supabase.functions
      .invoke('guidelines-search', {
        body: {
          query: queryText,
          icd10_codes: icd10.length ? icd10 : undefined,
          hpo_codes: hpo.length ? hpo : undefined,
          snomed_codes: snomed.length ? snomed : undefined,
          match_count: 10,
          match_threshold: 0.2,
        },
      })
      .then(({ data, error }) => {
        if (!error && data?.grouped) {
          setGuidelines(data.grouped as GuidelineGroup[]);
        } else {
          console.error('Guidelines search error:', error || data?.error);
          setGuidelines([]);
        }
      })
      .finally(() => setLoadingGL(false));

    // Europe PMC search
    setLoadingLit(true);
    const builtPmcQuery = terms.map((t) => `(${t})`).join(' OR ') + ' AND (HAS_FT:Y)';
    setPmcQuery(builtPmcQuery);
    supabase.functions
      .invoke('evidence-europepmc', {
        body: {
          action: 'search',
          query: builtPmcQuery,
          resultType: 'core',
          limit: 15,
        },
      })
      .then(({ data, error }) => {
        if (!error && data?.articles) {
          const loadedArticles = data.articles as Article[];
          setArticles(loadedArticles);
          // Persist and trigger translation pipeline
          persistAndTranslate(loadedArticles, builtPmcQuery);
        } else {
          console.error('Europe PMC search error:', error || data?.error);
          setArticles([]);
        }
      })
      .finally(() => setLoadingLit(false));

    // Clinical trials search
    setLoadingTrials(true);
    supabase.functions
      .invoke('evidence-trials', {
        body: {
          query: queryText,
          conditions: terms,
          limit: 10,
        },
      })
      .then(({ data, error }) => {
        if (!error && data?.trials) {
          setTrials(data.trials as ClinicalTrial[]);
        } else {
          console.error('Trials search error:', error || data?.error);
          setTrials([]);
        }
      })
      .finally(() => setLoadingTrials(false));
  }, [buildSearchParams, persistAndTranslate]);

  useEffect(() => {
    if (conditionKey === prevKeyRef.current) return;
    prevKeyRef.current = conditionKey;
    runSearch();
  }, [conditionKey, runSearch]);

  /* ── Search terms for display ── */
  const displayTerms = activeConditions
    .slice(0, 5)
    .map((c) => c.code_display || c.code || '')
    .filter(Boolean);

  const similarityColor = (s: number) => {
    if (s >= 0.75) return 'bg-emerald-500';
    if (s >= 0.6) return 'bg-amber-500';
    return 'bg-muted-foreground/40';
  };

  /* ── Helper: get persisted source for an article ── */
  const getPersistedSource = useCallback((article: Article): PersistedSource | undefined => {
    const externalId = article.pmid || article.id;
    return persistedSources.find(s => s.external_id === externalId);
  }, [persistedSources]);

  const toggleTranslation = useCallback((id: string) => {
    setShowOriginal(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  /* ── Render ── */
  return (
    <div className="flex h-full flex-col border-l bg-card">
      {/* Header */}
      <div className="border-b p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <BookOpen className="h-3.5 w-3.5 text-primary" />
            <h3 className="text-xs font-semibold text-foreground">Evidenz</h3>
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6"
            onClick={runSearch}
            disabled={loadingGL || loadingLit || loadingTrials}
          >
            <RefreshCw className={`h-3 w-3 ${loadingGL || loadingLit || loadingTrials ? 'animate-spin' : ''}`} />
          </Button>
        </div>
        {displayTerms.length > 0 && (
          <div className="mt-1.5 flex flex-wrap gap-1">
            {displayTerms.map((t, i) => (
              <Badge key={i} variant="secondary" className="text-[10px]">
                {t.length > 25 ? t.slice(0, 25) + '...' : t}
              </Badge>
            ))}
          </div>
        )}
      </div>

      {/* Tabs */}
      <Tabs defaultValue={tabOrder[0] || 'guidelines'} className="flex flex-1 flex-col overflow-hidden">
        <DraggableTabsList
          tabs={TAB_DEFS}
          order={tabOrder}
          onOrderChange={handleTabOrderChange}
          className="mx-2 mt-2"
        />

        {/* Guidelines Tab */}
        <TabsContent value="guidelines" className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="space-y-2 p-2">
              {loadingGL ? (
                <div className="flex items-center justify-center p-6">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : guidelines.length === 0 ? (
                <p className="p-3 text-center text-xs text-muted-foreground">
                  {displayTerms.length ? 'Keine passenden Leitlinien gefunden.' : 'Wählen Sie einen Patienten mit aktiven Diagnosen.'}
                </p>
              ) : (
                guidelines.map((g) => {
                  // Collect unique page numbers from chunks
                  const pages = [...new Set(g.chunks.map(c => c.page_number).filter((p): p is number => p != null))].sort((a, b) => a - b);
                  const bestSimilarity = Math.max(...g.chunks.map(c => c.similarity));

                  const openPdf = async (page?: number) => {
                    if (!g.file_path) return;
                    const { data } = await supabase.storage.from('guidelines').createSignedUrl(g.file_path, 300);
                    if (data?.signedUrl) {
                      const url = page ? `${data.signedUrl}#page=${page}` : data.signedUrl;
                      window.open(url, '_blank');
                    }
                  };

                  return (
                    <Card key={g.guideline_id} className="overflow-hidden">
                      <div className="p-2.5 space-y-1.5">
                        {/* Title row */}
                        <div className="flex items-start gap-2">
                          <FileText className="h-3.5 w-3.5 mt-0.5 shrink-0 text-primary" />
                          <div className="flex-1 min-w-0">
                            <button
                              onClick={() => openPdf()}
                              disabled={!g.file_path}
                              className="text-xs font-semibold leading-snug text-foreground hover:text-primary transition-colors text-left line-clamp-2 disabled:opacity-50 disabled:cursor-default"
                            >
                              {g.guideline_title}
                            </button>
                            {g.source && (
                              <span className="text-[10px] text-muted-foreground block">{g.source}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <Progress
                              value={bestSimilarity * 100}
                              className={`h-1 w-10 ${similarityColor(bestSimilarity)}`}
                            />
                            <span className="text-[9px] text-muted-foreground">{Math.round(bestSimilarity * 100)}%</span>
                          </div>
                        </div>

                        {/* Page anchors */}
                        {pages.length > 0 && (
                          <div className="flex flex-wrap gap-1 pl-5">
                            {pages.map((p) => (
                              <Button
                                key={p}
                                variant="outline"
                                size="sm"
                                className="h-5 px-1.5 text-[10px] gap-0.5"
                                onClick={() => openPdf(p)}
                                disabled={!g.file_path}
                              >
                                <ExternalLink className="h-2.5 w-2.5" />
                                S.{p}
                              </Button>
                            ))}
                          </div>
                        )}

                        {/* Best matching section hint */}
                        {g.chunks[0]?.section_title && (
                          <p className="text-[10px] text-muted-foreground pl-5 line-clamp-1">
                            ↳ {g.chunks[0].section_title}
                          </p>
                        )}
                      </div>
                    </Card>
                  );
                })
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* Literature Tab */}
        <TabsContent value="literature" className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="space-y-1.5 p-2">
              {/* Query info */}
              {pmcQuery && (
                <div className="flex items-center gap-1 pb-1">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-5 w-5">
                        <Info className="h-3 w-3 text-muted-foreground" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent side="bottom" align="start" className="w-64">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-1.5">
                          <Globe className="h-3 w-3 text-muted-foreground" />
                          <span className="text-xs font-medium">Europe PMC Query</span>
                        </div>
                        <code className="block break-all text-[10px] text-foreground/80">{pmcQuery}</code>
                      </div>
                    </PopoverContent>
                  </Popover>
                  <span className="text-[10px] text-muted-foreground">
                    {articles.length} Ergebnisse
                  </span>
                  {/* Translation progress */}
                  {persistedSources.some(s => s.translation_status === 'loading' || s.translation_status === 'pending') && (
                    <span className="ml-auto flex items-center gap-1 text-[10px] text-muted-foreground">
                      <Languages className="h-3 w-3 animate-pulse text-primary" />
                      Übersetze...
                    </span>
                  )}
                </div>
              )}

              {loadingLit ? (
                <div className="flex items-center justify-center p-6">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : articles.length === 0 ? (
                <p className="p-3 text-center text-xs text-muted-foreground">
                  {displayTerms.length ? 'Keine Artikel gefunden.' : 'Wählen Sie einen Patienten mit aktiven Diagnosen.'}
                </p>
              ) : (
                articles.map((a, idx) => (
                  <ArticleItem
                    key={a.id || a.pmid || idx}
                    article={a}
                    index={idx + 1}
                    isExpanded={expandedArticles.has(a.id)}
                    onToggle={() => {
                      setExpandedArticles((prev) => {
                        const next = new Set(prev);
                        if (next.has(a.id)) next.delete(a.id);
                        else next.add(a.id);
                        return next;
                      });
                    }}
                    persistedSource={getPersistedSource(a)}
                    showTranslated={!showOriginal.has(a.id)}
                    onToggleTranslation={() => toggleTranslation(a.id)}
                  />
                ))
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* Trials Tab */}
        <TabsContent value="trials" className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="space-y-2 p-2">
              {loadingTrials ? (
                <div className="flex items-center justify-center p-6">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : trials.length === 0 ? (
                <p className="p-3 text-center text-xs text-muted-foreground">
                  {displayTerms.length ? 'Keine klinischen Studien gefunden.' : 'Wählen Sie einen Patienten mit aktiven Diagnosen.'}
                </p>
              ) : (
                trials.map((t) => (
                  <Card key={t.nctId} className="transition-colors hover:bg-accent/30">
                    <CardContent className="p-2.5">
                      <p className="text-xs font-medium leading-snug text-foreground line-clamp-3">
                        {t.title}
                      </p>
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                        <Badge
                          variant="outline"
                          className={`text-[9px] ${
                            t.status === 'RECRUITING'
                              ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-600'
                              : t.status === 'COMPLETED'
                                ? 'border-blue-500/20 bg-blue-500/10 text-blue-600'
                                : ''
                          }`}
                        >
                          {t.status}
                        </Badge>
                        {t.phase !== 'N/A' && (
                          <Badge variant="secondary" className="text-[9px]">{t.phase}</Badge>
                        )}
                        {t.studyType && (
                          <Badge variant="outline" className="text-[9px]">{t.studyType}</Badge>
                        )}
                      </div>

                      {t.sponsor && (
                        <p className="mt-1 truncate text-[10px] text-muted-foreground">
                          <Users className="mr-0.5 inline h-2.5 w-2.5" />
                          {t.sponsor}
                        </p>
                      )}

                      {(t.enrollment != null || t.startDate) && (
                        <div className="mt-1 flex items-center gap-2 text-[10px] text-muted-foreground">
                          {t.enrollment != null && (
                            <span>{t.enrollment} Teilnehmer</span>
                          )}
                          {t.startDate && (
                            <span className="flex items-center gap-0.5">
                              <Calendar className="h-2.5 w-2.5" /> {t.startDate}
                            </span>
                          )}
                        </div>
                      )}

                      {t.briefSummary && (
                        <p className="mt-1 text-[10px] leading-snug text-muted-foreground line-clamp-2">
                          {t.briefSummary}
                        </p>
                      )}

                      <a
                        href={t.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-1.5 flex items-center gap-1 text-[10px] text-primary hover:underline"
                      >
                        <ExternalLink className="h-2.5 w-2.5" /> {t.nctId}
                      </a>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="flex-1 overflow-hidden">
          {selectedDocument ? (
            <DocumentDetailPanel
              document={selectedDocument}
              patientId={patientId}
              onBack={() => setSelectedDocument(null)}
            />
          ) : (
            <PatientDocumentsTab
              patientId={patientId}
              onSelectDocument={(doc) => setSelectedDocument(doc)}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ── Article Item with Translation Support ── */
function ArticleItem({
  article: a,
  index,
  isExpanded,
  onToggle,
  persistedSource,
  showTranslated,
  onToggleTranslation,
}: {
  article: Article;
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
  persistedSource?: PersistedSource;
  showTranslated: boolean;
  onToggleTranslation: () => void;
}) {
  const [linkCopied, setLinkCopied] = useState(false);

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = a.doi ? `https://doi.org/${a.doi}` : a.europePmcUrl;
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 1500);
    } catch { /* ignore */ }
  };

  const cleanText = (t: string) => {
    // Strip HTML tags, then decode HTML entities via DOM
    const stripped = t.replace(/<[^>]*>/g, ' ').replace(/\s{2,}/g, ' ').trim();
    const textarea = document.createElement('textarea');
    textarea.innerHTML = stripped;
    return textarea.value;
  };

  const translationReady = persistedSource?.translation_status === 'completed';
  const translationLoading = persistedSource?.translation_status === 'loading' || persistedSource?.translation_status === 'pending';
  const contentType = persistedSource?.content_type || 'abstract';

  // Determine displayed title and content
  const displayTitle = (showTranslated && translationReady && persistedSource?.translated_title)
    ? cleanText(persistedSource.translated_title)
    : cleanText(a.title);

  const displayAbstract = (showTranslated && translationReady && persistedSource?.translated_content)
    ? cleanText(persistedSource.translated_content)
    : (a.abstract ? cleanText(a.abstract) : null);

  const displayLang = showTranslated && translationReady ? 'DE' : 'EN';

  return (
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <div className="rounded-lg border bg-card transition-colors hover:bg-muted/50">
        <div className="flex items-start">
          <CollapsibleTrigger asChild>
            <button className="flex-1 p-2 text-left">
              <div className="flex items-start gap-1.5">
                <span className="mt-0.5 font-mono text-[10px] text-muted-foreground">[{index}]</span>
                {isExpanded ? (
                  <ChevronDown className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                ) : (
                  <ChevronRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                )}
                <div className="min-w-0 flex-1">
                  <h5 className="text-xs font-medium leading-snug line-clamp-2">
                    {displayTitle}
                  </h5>
                  {a.authors?.length > 0 && (
                    <p className="mt-0.5 truncate text-[10px] text-muted-foreground">
                      {a.authors.slice(0, 3).join(', ')}
                      {a.authors.length > 3 && ' et al.'}
                    </p>
                  )}
                  <div className="mt-1 flex flex-wrap items-center gap-1">
                    {a.year && <span className="text-[10px] text-muted-foreground">{a.year}</span>}
                    {/* Content type badge */}
                    <Badge variant="outline" className="h-4 gap-0.5 border-emerald-500/40 px-1 text-[9px] text-emerald-700 dark:text-emerald-400">
                      <CheckCircle className="h-2.5 w-2.5" />
                      {contentType === 'fulltext' ? 'Volltext' : 'Abstract'}
                    </Badge>
                    {/* OA badge */}
                    {a.isOpenAccess && (
                      <Badge variant="outline" className="h-4 gap-0.5 border-emerald-500/40 px-1 text-[9px] text-emerald-700 dark:text-emerald-400">
                        OA
                      </Badge>
                    )}
                    {/* PDF badge */}
                    {(a.pdfUrl || persistedSource?.pdf_path) && (
                      <Badge variant="outline" className="h-4 gap-0.5 border-violet-500/40 px-1 text-[9px] text-violet-700 dark:text-violet-400">
                        <FileText className="h-2.5 w-2.5" />
                        PDF
                      </Badge>
                    )}
                    {/* Language badge */}
                    <Badge
                      variant="secondary"
                      className={`h-4 px-1 text-[9px] cursor-pointer ${showTranslated && translationReady ? 'bg-primary/10 text-primary' : ''}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (translationReady) onToggleTranslation();
                      }}
                    >
                      {translationLoading ? (
                        <Loader2 className="h-2.5 w-2.5 animate-spin" />
                      ) : (
                        displayLang
                      )}
                    </Badge>
                    {a.citedByCount > 0 && (
                      <span className="text-[9px] text-muted-foreground">{a.citedByCount} Zit.</span>
                    )}
                  </div>
                </div>
              </div>
            </button>
          </CollapsibleTrigger>

          {/* Action buttons */}
          <div className="mr-1.5 mt-2 flex gap-0.5">
            {/* Translation toggle */}
            {translationReady && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); onToggleTranslation(); }}
                      className={`inline-flex h-6 w-6 items-center justify-center rounded-md transition-colors hover:bg-muted ${showTranslated ? 'text-primary' : ''}`}
                    >
                      <Languages className="h-3 w-3" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="left" className="text-xs">
                    {showTranslated ? 'Original anzeigen' : 'Übersetzung anzeigen'}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            {a.europePmcUrl && (
              <a
                href={a.europePmcUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex h-6 w-6 items-center justify-center rounded-md transition-colors hover:bg-muted"
                onClick={(e) => e.stopPropagation()}
              >
                <ExternalLink className="h-3 w-3" />
              </a>
            )}
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex h-6 w-6 items-center justify-center rounded-md transition-colors hover:bg-muted"
            >
              {linkCopied ? <Check className="h-3 w-3 text-primary" /> : <Copy className="h-3 w-3" />}
            </button>
          </div>
        </div>

        {/* Expanded content */}
        <CollapsibleContent>
          <div className="space-y-2 rounded-b-lg bg-muted/30 px-2.5 pb-2.5 pt-1">
            {/* Metadata row */}
            {(a.journal || a.publicationDate || a.doi) && (
              <div className="space-y-1 border-b border-border/50 pb-2">
                {a.journal && (
                  <div className="flex items-center gap-1 text-[11px]">
                    <BookOpen className="h-3 w-3 shrink-0 text-muted-foreground" />
                    <span className="font-medium">{a.journal}</span>
                  </div>
                )}
                <div className="flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground">
                  {a.publicationDate && <span>Veröffentlicht: {a.publicationDate}</span>}
                  {a.citedByCount > 0 && <span>{a.citedByCount} Zitierungen</span>}
                  {a.isOpenAccess && (
                    <Badge variant="secondary" className="h-4 text-[9px]">Open Access</Badge>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
                  {a.pmid && <Badge variant="outline" className="h-4 text-[9px]">PMID: {a.pmid}</Badge>}
                  {a.pmcid && <Badge variant="outline" className="h-4 text-[9px]">{a.pmcid}</Badge>}
                  {a.doi && (
                    <a
                      href={`https://doi.org/${a.doi}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-0.5 text-primary hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      DOI: {a.doi}
                    </a>
                  )}
                  {a.pdfUrl && (
                    <a
                      href={a.pdfUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-0.5 text-primary hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <FileDown className="h-3 w-3" /> PDF
                    </a>
                  )}
                </div>
              </div>
            )}

            {/* Authors */}
            {a.authorDetails && a.authorDetails.length > 0 && (
              <div className="space-y-0.5">
                <p className="text-[10px] font-medium text-muted-foreground">Autoren</p>
                <div className="flex flex-wrap gap-1">
                  {a.authorDetails.slice(0, 6).map((author, i) => (
                    <TooltipProvider key={i}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Badge variant="outline" className="h-4 cursor-default px-1 text-[9px]">
                            {author.fullName}
                            {author.orcid && <span className="ml-0.5 text-emerald-600">●</span>}
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent side="bottom" className="max-w-[200px] text-xs">
                          <p className="font-medium">{author.fullName}</p>
                          {author.orcid && <p className="text-muted-foreground">ORCID: {author.orcid}</p>}
                          {author.affiliations?.[0] && (
                            <p className="text-muted-foreground line-clamp-2">{author.affiliations[0]}</p>
                          )}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  ))}
                  {a.authorDetails.length > 6 && (
                    <Badge variant="secondary" className="h-4 px-1 text-[9px]">
                      +{a.authorDetails.length - 6}
                    </Badge>
                  )}
                </div>
              </div>
            )}

            {/* Abstract / Translated Content */}
            {displayAbstract && (
              <div>
                <div className="mb-0.5 flex items-center gap-1.5">
                  <p className="text-[10px] font-medium text-muted-foreground">
                    {showTranslated && translationReady ? 'Übersetzung' : 'Abstract'}
                  </p>
                  {translationReady && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onToggleTranslation(); }}
                      className="text-[9px] text-primary hover:underline"
                    >
                      {showTranslated ? '→ Original' : '→ Deutsch'}
                    </button>
                  )}
                  {translationLoading && (
                    <span className="flex items-center gap-0.5 text-[9px] text-muted-foreground">
                      <Loader2 className="h-2.5 w-2.5 animate-spin" /> Wird übersetzt...
                    </span>
                  )}
                </div>
                <p className="text-[11px] leading-relaxed text-foreground">
                  {displayAbstract}
                </p>
              </div>
            )}

            {/* Keywords / MeSH */}
            {(a.keywords?.length > 0 || a.meshTerms?.length > 0) && (
              <div className="flex flex-wrap gap-1">
                {(a.meshTerms || a.keywords || []).slice(0, 8).map((kw, i) => (
                  <Badge key={i} variant="secondary" className="h-4 px-1 text-[9px]">
                    {kw}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}
