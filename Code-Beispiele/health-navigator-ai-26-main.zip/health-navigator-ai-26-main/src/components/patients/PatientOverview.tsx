import { FhirPatient } from '@/hooks/useFhirPatients';
import { useFhirPatientData } from '@/hooks/useFhirPatients';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, AlertTriangle, Pill, Stethoscope, Activity } from 'lucide-react';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

interface PatientOverviewProps {
  patient: FhirPatient;
}

export function PatientOverview({ patient }: PatientOverviewProps) {
  const { conditions, observations, medications, allergies, encounters } = useFhirPatientData(patient.id);

  const age = patient.birth_date 
    ? Math.floor((Date.now() - new Date(patient.birth_date).getTime()) / 31557600000) 
    : null;

  const activeConditions = (conditions.data || []).filter(c => c.clinical_status === 'active' || !c.abatement_datetime);
  const activeMeds = (medications.data || []).filter(m => m.status === 'active');
  const criticalAllergies = (allergies.data || []).filter(a => a.criticality === 'high');
  
  const recentLabs = (observations.data || [])
    .filter(o => o.category === 'laboratory' || o.loinc_code)
    .slice(0, 5);

  const recentVitals = (observations.data || [])
    .filter(o => o.category === 'vital-signs')
    .slice(0, 5);

  return (
    <div className="space-y-4 p-4">
      {/* Patient Header */}
      <div className="flex items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-2xl font-bold text-primary">
          {patient.given_name[0]}{patient.family_name[0]}
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground">
            {patient.given_name} {patient.family_name}
          </h2>
          <div className="flex items-center gap-3 text-sm text-muted-foreground mt-0.5">
            {patient.birth_date && (
              <span className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                {format(new Date(patient.birth_date), 'dd.MM.yyyy', { locale: de })} ({age}J)
              </span>
            )}
            <span>{patient.gender === 'male' ? '♂ Männlich' : patient.gender === 'female' ? '♀ Weiblich' : '⚧ Divers'}</span>
            {patient.identifier_mrn && <span className="font-mono">MRN: {patient.identifier_mrn}</span>}
          </div>
        </div>
      </div>

      {/* Allergy Warning */}
      {criticalAllergies.length > 0 && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="p-3 flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-destructive mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-destructive">Kritische Allergien</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {criticalAllergies.map(a => (
                  <Badge key={a.id} variant="destructive" className="text-xs">{a.code_display || a.code}</Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-3 text-center">
            <Stethoscope className="h-5 w-5 mx-auto text-primary mb-1" />
            <p className="text-2xl font-bold text-foreground">{activeConditions.length}</p>
            <p className="text-xs text-muted-foreground">Aktive Diagnosen</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <Pill className="h-5 w-5 mx-auto text-blue-500 mb-1" />
            <p className="text-2xl font-bold text-foreground">{activeMeds.length}</p>
            <p className="text-xs text-muted-foreground">Medikamente</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <AlertTriangle className="h-5 w-5 mx-auto text-amber-500 mb-1" />
            <p className="text-2xl font-bold text-foreground">{(allergies.data || []).length}</p>
            <p className="text-xs text-muted-foreground">Allergien</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <Activity className="h-5 w-5 mx-auto text-emerald-500 mb-1" />
            <p className="text-2xl font-bold text-foreground">{(encounters.data || []).length}</p>
            <p className="text-xs text-muted-foreground">Aufenthalte</p>
          </CardContent>
        </Card>
      </div>

      {/* Active Diagnoses */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Aktive Diagnosen</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1.5">
          {activeConditions.length === 0 ? (
            <p className="text-xs text-muted-foreground">Keine aktiven Diagnosen</p>
          ) : activeConditions.slice(0, 8).map(c => (
            <div key={c.id} className="flex items-center justify-between text-sm">
              <span className="text-foreground">{c.code_display || 'Unbekannt'}</span>
              <div className="flex items-center gap-1.5">
                {c.code && <Badge variant="outline" className="text-[10px] font-mono">{c.code}</Badge>}
                {c.severity && <Badge variant="secondary" className="text-[10px]">{c.severity}</Badge>}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recent Lab Values */}
      {recentLabs.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Letzte Laborwerte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1.5">
              {recentLabs.map(o => {
                const isAbnormal = o.interpretation === 'H' || o.interpretation === 'L' || o.interpretation === 'abnormal';
                return (
                  <div key={o.id} className="flex items-center justify-between text-sm">
                    <span className="text-foreground">{o.code_display}</span>
                    <div className="flex items-center gap-2">
                      <span className={isAbnormal ? 'font-semibold text-destructive' : 'text-muted-foreground'}>
                        {o.value_quantity != null ? `${o.value_quantity} ${o.value_unit || ''}` : o.value_string || '-'}
                      </span>
                      {o.loinc_code && <Badge variant="outline" className="text-[10px] font-mono">{o.loinc_code}</Badge>}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
