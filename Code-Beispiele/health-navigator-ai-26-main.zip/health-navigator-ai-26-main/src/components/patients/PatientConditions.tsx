import { useFhirPatientData } from '@/hooks/useFhirPatients';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

interface Props { patientId: string; }

const statusColors: Record<string, string> = {
  active: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  resolved: 'bg-muted text-muted-foreground',
  inactive: 'bg-muted text-muted-foreground',
  recurrence: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
};

export function PatientConditions({ patientId }: Props) {
  const { conditions } = useFhirPatientData(patientId);

  if (conditions.isLoading) return <p className="p-4 text-sm text-muted-foreground">Laden...</p>;
  
  const data = conditions.data || [];

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-2">
        <h3 className="text-sm font-semibold text-foreground mb-3">Diagnosen & Conditions ({data.length})</h3>
        {data.length === 0 ? (
          <p className="text-sm text-muted-foreground">Keine Diagnosen dokumentiert.</p>
        ) : data.map(c => (
          <Card key={c.id} className="overflow-hidden">
            <CardContent className="p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground">{c.code_display || 'Unbekannt'}</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {c.code && (
                      <Badge variant="outline" className="text-[10px] font-mono">
                        {c.code_system?.includes('icd') ? 'ICD' : c.code_system?.includes('snomed') ? 'SCT' : ''} {c.code}
                      </Badge>
                    )}
                    {c.severity && <Badge variant="secondary" className="text-[10px]">{c.severity}</Badge>}
                    {c.category && <Badge variant="secondary" className="text-[10px]">{c.category}</Badge>}
                  </div>
                </div>
                <Badge variant="outline" className={`text-[10px] flex-shrink-0 ${statusColors[c.clinical_status || ''] || ''}`}>
                  {c.clinical_status || 'unbekannt'}
                </Badge>
              </div>
              {(c.onset_datetime || c.abatement_datetime) && (
                <p className="text-xs text-muted-foreground mt-1.5">
                  {c.onset_datetime && `Seit: ${format(new Date(c.onset_datetime), 'dd.MM.yyyy', { locale: de })}`}
                  {c.abatement_datetime && ` · Bis: ${format(new Date(c.abatement_datetime), 'dd.MM.yyyy', { locale: de })}`}
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </ScrollArea>
  );
}
