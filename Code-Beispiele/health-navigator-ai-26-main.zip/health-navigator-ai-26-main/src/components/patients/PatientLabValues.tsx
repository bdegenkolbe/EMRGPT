import { useMemo } from 'react';
import { useFhirPatientData, FhirObservation } from '@/hooks/useFhirPatients';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface Props { patientId: string; }

export function PatientLabValues({ patientId }: Props) {
  const { observations } = useFhirPatientData(patientId);
  
  const labs = useMemo(() => 
    (observations.data || []).filter(o => o.category === 'laboratory' || o.loinc_code),
    [observations.data]
  );

  // Group by code_display for charts
  const grouped = useMemo(() => {
    const map = new Map<string, FhirObservation[]>();
    for (const o of labs) {
      const key = o.code_display || o.loinc_code || 'Unbekannt';
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(o);
    }
    // Sort each group by date and only show groups with numeric values
    const result: [string, FhirObservation[]][] = [];
    for (const [key, obs] of map) {
      const withValues = obs.filter(o => o.value_quantity != null).sort((a, b) => 
        new Date(a.effective_datetime || 0).getTime() - new Date(b.effective_datetime || 0).getTime()
      );
      if (withValues.length > 0) result.push([key, withValues]);
    }
    return result;
  }, [labs]);

  if (observations.isLoading) return <p className="p-4 text-sm text-muted-foreground">Laden...</p>;

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-4">
        <h3 className="text-sm font-semibold text-foreground">Laborwerte ({labs.length})</h3>

        {/* Summary table */}
        <Card>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-2 text-xs font-medium text-muted-foreground">Parameter</th>
                  <th className="text-right p-2 text-xs font-medium text-muted-foreground">Wert</th>
                  <th className="text-right p-2 text-xs font-medium text-muted-foreground">Referenz</th>
                  <th className="text-right p-2 text-xs font-medium text-muted-foreground">Datum</th>
                </tr>
              </thead>
              <tbody>
                {labs.slice(0, 30).map(o => {
                  const isAbnormal = o.interpretation === 'H' || o.interpretation === 'L' || 
                    o.interpretation === 'abnormal' || o.interpretation === 'critical';
                  return (
                    <tr key={o.id} className="border-b last:border-0">
                      <td className="p-2">
                        <span className="text-foreground">{o.code_display}</span>
                        {o.loinc_code && <span className="text-[10px] text-muted-foreground ml-1">({o.loinc_code})</span>}
                      </td>
                      <td className={cn('p-2 text-right font-mono', isAbnormal ? 'text-destructive font-semibold' : 'text-foreground')}>
                        {o.value_quantity != null ? `${o.value_quantity} ${o.value_unit || ''}` : o.value_string || '-'}
                        {isAbnormal && <span className="ml-1 text-[10px]">{o.interpretation === 'H' ? '↑' : o.interpretation === 'L' ? '↓' : '!'}</span>}
                      </td>
                      <td className="p-2 text-right text-xs text-muted-foreground">
                        {o.reference_range_low != null && o.reference_range_high != null 
                          ? `${o.reference_range_low} - ${o.reference_range_high}` : '-'}
                      </td>
                      <td className="p-2 text-right text-xs text-muted-foreground">
                        {o.effective_datetime ? format(new Date(o.effective_datetime), 'dd.MM.yy', { locale: de }) : '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>

        {/* Trend charts for params with multiple values */}
        {grouped.filter(([, obs]) => obs.length >= 2).slice(0, 6).map(([name, obs]) => {
          const refLow = obs[0].reference_range_low;
          const refHigh = obs[0].reference_range_high;
          const chartData = obs.map(o => ({
            date: o.effective_datetime ? format(new Date(o.effective_datetime), 'dd.MM', { locale: de }) : '',
            value: o.value_quantity,
          }));
          
          return (
            <Card key={name}>
              <CardHeader className="pb-1 pt-3 px-3">
                <CardTitle className="text-xs">{name} <span className="text-muted-foreground font-normal">{obs[0].value_unit || ''}</span></CardTitle>
              </CardHeader>
              <CardContent className="px-3 pb-3">
                <ResponsiveContainer width="100%" height={120}>
                  <LineChart data={chartData}>
                    <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} width={40} />
                    <Tooltip />
                    {refLow != null && <ReferenceLine y={refLow} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" />}
                    {refHigh != null && <ReferenceLine y={refHigh} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" />}
                    <Line type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </ScrollArea>
  );
}
