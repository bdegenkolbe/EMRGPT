import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { Database, Loader2, CheckCircle2, AlertCircle, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface DemoSource {
  name: string;
  label: string;
  description: string;
}

const AVAILABLE_SOURCES: DemoSource[] = [
  { name: 'smart', label: 'SMART Health IT', description: 'Testdaten vom SMART on FHIR R4 Server (hochwertig)' },
  { name: 'hapi', label: 'HAPI FHIR (Synthea)', description: 'Öffentlicher FHIR-Server mit synthetischen Daten' },
];

interface FetchResult {
  source: string;
  label: string;
  bundle: any;
  patientCount: number;
  resourceCount: number;
}

type ImportStatus = 'idle' | 'fetching' | 'importing' | 'done' | 'error';

interface FhirDemoDataDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (bundle: any) => Promise<any>;
}

export function FhirDemoDataDialog({ open, onOpenChange, onImport }: FhirDemoDataDialogProps) {
  const [selectedSources, setSelectedSources] = useState<string[]>(['smart', 'hapi']);
  const [count, setCount] = useState(5);
  const [status, setStatus] = useState<ImportStatus>('idle');
  const [results, setResults] = useState<FetchResult[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [importProgress, setImportProgress] = useState(0);
  const [importedCount, setImportedCount] = useState(0);

  const toggleSource = (name: string) => {
    setSelectedSources(prev =>
      prev.includes(name) ? prev.filter(s => s !== name) : [...prev, name]
    );
  };

  const fetchAndImport = async () => {
    if (selectedSources.length === 0) return;
    
    setStatus('fetching');
    setResults([]);
    setErrors([]);
    setImportProgress(0);
    setImportedCount(0);

    try {
      // Step 1: Fetch from public servers
      const { data, error } = await supabase.functions.invoke('fhir-demo-data', {
        body: { sources: selectedSources, count },
      });

      if (error) throw error;
      if (data.errors?.length) setErrors(data.errors);
      
      const fetchedResults: FetchResult[] = data.results || [];
      setResults(fetchedResults);

      if (fetchedResults.length === 0) {
        setStatus('error');
        toast.error('Keine Daten von den Servern erhalten');
        return;
      }

      // Step 2: Import each bundle
      setStatus('importing');
      let imported = 0;

      for (let i = 0; i < fetchedResults.length; i++) {
        try {
          await onImport(fetchedResults[i].bundle);
          imported++;
        } catch (err: any) {
          console.error(`Import error for ${fetchedResults[i].source}:`, err);
          setErrors(prev => [...prev, `Import ${fetchedResults[i].label}: ${err.message}`]);
        }
        setImportProgress(((i + 1) / fetchedResults.length) * 100);
      }

      setImportedCount(imported);
      setStatus('done');
      toast.success(`${imported} Quelle(n) erfolgreich importiert`);
    } catch (err: any) {
      console.error('Demo data error:', err);
      setStatus('error');
      toast.error(`Fehler: ${err.message}`);
    }
  };

  const handleClose = (open: boolean) => {
    if (status === 'fetching' || status === 'importing') return;
    if (!open) {
      setStatus('idle');
      setResults([]);
      setErrors([]);
    }
    onOpenChange(open);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Demo-Patienten laden
          </DialogTitle>
          <DialogDescription>
            Beispieldaten von öffentlichen FHIR-Testservern laden und importieren.
          </DialogDescription>
        </DialogHeader>

        {/* Source selection */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Quellen auswählen:</p>
          {AVAILABLE_SOURCES.map(s => (
            <label
              key={s.name}
              className={cn(
                'flex items-start gap-3 rounded-lg border p-3 cursor-pointer transition-colors',
                selectedSources.includes(s.name)
                  ? 'border-primary/30 bg-primary/5'
                  : 'border-border hover:bg-accent/30'
              )}
            >
              <Checkbox
                checked={selectedSources.includes(s.name)}
                onCheckedChange={() => toggleSource(s.name)}
                disabled={status === 'fetching' || status === 'importing'}
              />
              <div>
                <p className="text-sm font-medium">{s.label}</p>
                <p className="text-xs text-muted-foreground">{s.description}</p>
              </div>
            </label>
          ))}
        </div>

        {/* Count selector */}
        <div className="flex items-center gap-3">
          <label className="text-xs text-muted-foreground">Patienten pro Quelle:</label>
          <div className="flex gap-1">
            {[3, 5, 10].map(n => (
              <Button
                key={n}
                size="sm"
                variant={count === n ? 'default' : 'outline'}
                className="h-7 w-10 text-xs"
                onClick={() => setCount(n)}
                disabled={status === 'fetching' || status === 'importing'}
              >
                {n}
              </Button>
            ))}
          </div>
        </div>

        {/* Progress */}
        {(status === 'fetching' || status === 'importing') && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
              <span>
                {status === 'fetching'
                  ? 'Lade Daten von FHIR-Servern...'
                  : 'Importiere in Datenbank...'}
              </span>
            </div>
            {status === 'importing' && <Progress value={importProgress} className="h-1.5" />}
          </div>
        )}

        {/* Results */}
        {results.length > 0 && status !== 'fetching' && (
          <div className="space-y-1.5">
            {results.map(r => (
              <div key={r.source} className="flex items-center gap-2 rounded-md border px-3 py-2 text-sm bg-emerald-500/5 border-emerald-500/20">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium">{r.label}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {r.patientCount} Patienten · {r.resourceCount} Ressourcen
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Errors */}
        {errors.length > 0 && (
          <div className="space-y-1">
            {errors.map((e, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-destructive">
                <AlertCircle className="h-3 w-3 flex-shrink-0" />
                <span>{e}</span>
              </div>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-end gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleClose(false)}
            disabled={status === 'fetching' || status === 'importing'}
          >
            {status === 'done' ? 'Schließen' : 'Abbrechen'}
          </Button>
          {status !== 'done' && (
            <Button
              size="sm"
              onClick={fetchAndImport}
              disabled={selectedSources.length === 0 || status === 'fetching' || status === 'importing'}
              className="gap-1.5"
            >
              {status === 'fetching' || status === 'importing' ? (
                <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Laden...</>
              ) : (
                <><Download className="h-3.5 w-3.5" /> Laden & Importieren</>
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
