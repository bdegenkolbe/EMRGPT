import { useState, useCallback, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import {
  ArrowLeft, FileText, Brain, Tags, Database, Loader2, CheckCircle,
  AlertTriangle, Stethoscope, Pill, FlaskConical, Scissors, HeartPulse,
  RefreshCw, ChevronDown,
} from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { toast } from 'sonner';

interface AnalysisResult {
  abstract?: string;
  structured_summary?: {
    anamnese?: string;
    befund?: string;
    diagnosen?: string;
    therapie?: string;
    procedere?: string;
  };
  ontology_codes?: {
    icd10?: { code: string; display: string; confidence: number }[];
    snomed?: { code: string; display: string; confidence: number }[];
    hpo?: { code: string; display: string; confidence: number }[];
    loinc?: { code: string; display: string; confidence: number }[];
    ops?: { code: string; display: string; confidence: number }[];
  };
  extracted_fhir?: {
    conditions?: { code: string; code_system: string; display: string; clinical_status: string; onset_datetime: string | null }[];
    medications?: { code: string | null; display: string; dosage_text: string; status: string }[];
    allergies?: { code: string | null; display: string; category: string; criticality: string; clinical_status: string }[];
    observations?: { loinc_code: string; display: string; value: number; unit: string; effective_datetime: string | null }[];
    procedures?: { code: string; code_system: string; display: string; performed_datetime: string | null }[];
  };
}

interface DocumentRef {
  id: string;
  fhir_id: string;
  patient_id: string;
  description: string | null;
  content_type: string | null;
  storage_path: string | null;
  analysis_status: string | null;
  analysis_result: AnalysisResult | null;
  transferred_resources: Record<string, string[]> | null;
  date: string | null;
}

interface Props {
  document: DocumentRef;
  patientId: string;
  onBack: () => void;
}

export function DocumentDetailPanel({ document, patientId, onBack }: Props) {
  const queryClient = useQueryClient();
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);

  // Get signed URL for PDF preview
  useEffect(() => {
    if (!document.storage_path) return;
    supabase.storage
      .from('patient-documents')
      .createSignedUrl(document.storage_path, 600)
      .then(({ data }) => {
        if (data?.signedUrl) setPdfUrl(data.signedUrl);
      });
  }, [document.storage_path]);

  // Poll for analysis status
  const { data: currentDoc } = useQuery({
    queryKey: ['document-detail', document.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_document_references')
        .select('*')
        .eq('id', document.id)
        .single();
      if (error) throw error;
      return data as unknown as DocumentRef;
    },
    refetchInterval: (query) => {
      const status = query.state.data?.analysis_status;
      return status === 'analyzing' || status === 'pending' ? 3000 : false;
    },
  });

  const doc = currentDoc || document;
  const analysis = (doc.analysis_result || {}) as AnalysisResult;
  const transferred = (doc.transferred_resources || {}) as Record<string, string[]>;

  // Re-analyze mutation
  const reanalyze = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.functions.invoke('document-analyze', {
        body: { documentId: doc.id },
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['document-detail', doc.id] });
      toast.success('Analyse gestartet');
    },
    onError: (err: Error) => toast.error(`Analyse fehlgeschlagen: ${err.message}`),
  });

  // Transfer to FHIR
  const transferMutation = useMutation({
    mutationFn: async ({ type, index, data }: { type: string; index: number; data: Record<string, unknown> }) => {
      const fhirId = `extracted-${doc.fhir_id}-${type}-${index}`;
      let tableName = '';
      let insertData: Record<string, unknown> = {};

      switch (type) {
        case 'conditions':
          tableName = 'fhir_conditions';
          insertData = {
            fhir_id: fhirId,
            patient_id: patientId,
            code: data.code,
            code_display: data.display,
            code_system: data.code_system || 'http://fhir.de/CodeSystem/bfarm/icd-10-gm',
            clinical_status: data.clinical_status || 'active',
            onset_datetime: data.onset_datetime || null,
            fhir_resource: { resourceType: 'Condition', id: fhirId, code: { coding: [{ system: data.code_system, code: data.code, display: data.display }] }, clinicalStatus: { coding: [{ code: data.clinical_status || 'active' }] }, subject: { reference: `Patient/${patientId}` } },
          };
          break;
        case 'medications':
          tableName = 'fhir_medication_requests';
          insertData = {
            fhir_id: fhirId,
            patient_id: patientId,
            medication_display: data.display,
            medication_code: data.code || null,
            dosage_text: data.dosage_text || null,
            status: data.status || 'active',
            intent: 'order',
            fhir_resource: { resourceType: 'MedicationRequest', id: fhirId, medicationCodeableConcept: { text: data.display as string }, dosageInstruction: [{ text: data.dosage_text as string }], subject: { reference: `Patient/${patientId}` }, status: data.status || 'active', intent: 'order' },
          };
          break;
        case 'allergies':
          tableName = 'fhir_allergies';
          insertData = {
            fhir_id: fhirId,
            patient_id: patientId,
            code_display: data.display,
            code: data.code || null,
            category: data.category || 'medication',
            criticality: data.criticality || 'low',
            clinical_status: data.clinical_status || 'active',
            fhir_resource: { resourceType: 'AllergyIntolerance', id: fhirId, code: { text: data.display as string }, category: [data.category || 'medication'], criticality: data.criticality || 'low', patient: { reference: `Patient/${patientId}` } },
          };
          break;
        case 'observations':
          tableName = 'fhir_observations';
          insertData = {
            fhir_id: fhirId,
            patient_id: patientId,
            loinc_code: data.loinc_code || null,
            code_display: data.display,
            value_quantity: data.value || null,
            value_unit: data.unit || null,
            status: 'final',
            effective_datetime: data.effective_datetime || null,
            category: 'laboratory',
            fhir_resource: { resourceType: 'Observation', id: fhirId, code: { coding: [{ system: 'http://loinc.org', code: data.loinc_code, display: data.display }] }, valueQuantity: { value: data.value, unit: data.unit }, subject: { reference: `Patient/${patientId}` }, status: 'final' },
          };
          break;
        case 'procedures':
          tableName = 'fhir_procedures';
          insertData = {
            fhir_id: fhirId,
            patient_id: patientId,
            code: data.code,
            code_display: data.display,
            code_system: data.code_system || 'http://fhir.de/CodeSystem/bfarm/ops',
            performed_datetime: data.performed_datetime || null,
            source_document_id: doc.id,
            fhir_resource: { resourceType: 'Procedure', id: fhirId, code: { coding: [{ system: data.code_system || 'http://fhir.de/CodeSystem/bfarm/ops', code: data.code, display: data.display }] }, subject: { reference: `Patient/${patientId}` }, status: 'completed' },
          };
          break;
      }

      const { error } = await supabase.from(tableName as any).insert(insertData as any);
      if (error) throw error;

      // Track transferred resource
      const newTransferred = { ...transferred };
      if (!newTransferred[type]) newTransferred[type] = [];
      newTransferred[type].push(String(index));

      await supabase
        .from('fhir_document_references')
        .update({ transferred_resources: newTransferred })
        .eq('id', doc.id);

      return { type, index };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['document-detail', doc.id] });
      queryClient.invalidateQueries({ queryKey: ['patient-'] });
      toast.success('In FHIR-Ressource übernommen');
    },
    onError: (err: Error) => toast.error(`Übertrag fehlgeschlagen: ${err.message}`),
  });

  const isTransferred = (type: string, index: number) => {
    return transferred[type]?.includes(String(index)) || false;
  };

  const confidenceColor = (c: number) => {
    if (c >= 0.9) return 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950';
    if (c >= 0.7) return 'text-amber-600 bg-amber-50 dark:bg-amber-950';
    return 'text-muted-foreground bg-muted';
  };

  const systemLabel = (system: string) => {
    const map: Record<string, { label: string; color: string }> = {
      icd10: { label: 'ICD-10', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300' },
      snomed: { label: 'SNOMED', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' },
      hpo: { label: 'HPO', color: 'bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300' },
      loinc: { label: 'LOINC', color: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300' },
      ops: { label: 'OPS', color: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300' },
    };
    return map[system] || { label: system, color: 'bg-muted text-muted-foreground' };
  };

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="border-b p-3">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="min-w-0 flex-1">
            <h3 className="truncate text-sm font-semibold">{doc.description || 'Dokument'}</h3>
            <div className="flex items-center gap-2">
              {doc.analysis_status === 'completed' && (
                <Badge variant="outline" className="h-4 px-1.5 text-[9px] text-emerald-600">
                  <CheckCircle className="mr-0.5 h-2.5 w-2.5" /> Analysiert
                </Badge>
              )}
              {doc.analysis_status === 'analyzing' && (
                <Badge variant="outline" className="h-4 px-1.5 text-[9px] text-primary">
                  <Loader2 className="mr-0.5 h-2.5 w-2.5 animate-spin" /> Wird analysiert...
                </Badge>
              )}
              {doc.analysis_status === 'error' && (
                <Badge variant="destructive" className="h-4 px-1.5 text-[9px]">
                  <AlertTriangle className="mr-0.5 h-2.5 w-2.5" /> Fehler
                </Badge>
              )}
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => reanalyze.mutate()}
            disabled={reanalyze.isPending || doc.analysis_status === 'analyzing'}
          >
            <RefreshCw className={`h-3.5 w-3.5 ${reanalyze.isPending ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Content Tabs */}
      <Tabs defaultValue="summary" className="flex flex-1 flex-col overflow-hidden">
        <TabsList className="mx-2 mt-2 h-8">
          <TabsTrigger value="preview" className="gap-1 text-[11px]">
            <FileText className="h-3 w-3" /> PDF
          </TabsTrigger>
          <TabsTrigger value="summary" className="gap-1 text-[11px]">
            <Brain className="h-3 w-3" /> Abstrakt
          </TabsTrigger>
          <TabsTrigger value="codes" className="gap-1 text-[11px]">
            <Tags className="h-3 w-3" /> Codes
          </TabsTrigger>
          <TabsTrigger value="fhir" className="gap-1 text-[11px]">
            <Database className="h-3 w-3" /> FHIR
          </TabsTrigger>
        </TabsList>

        {/* PDF Preview */}
        <TabsContent value="preview" className="flex-1 overflow-hidden p-2">
          {pdfUrl ? (
            <iframe
              src={pdfUrl}
              className="h-full w-full rounded-lg border"
              title="PDF Preview"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
              Vorschau nicht verfügbar
            </div>
          )}
        </TabsContent>

        {/* AI Summary */}
        <TabsContent value="summary" className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="space-y-3 p-3">
              {doc.analysis_status === 'analyzing' ? (
                <div className="flex flex-col items-center justify-center gap-2 py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  <p className="text-xs text-muted-foreground">KI analysiert den Arztbrief...</p>
                </div>
              ) : doc.analysis_status === 'completed' && analysis ? (
                <>
                  {/* Abstract */}
                  {analysis.abstract && (
                    <Card>
                      <CardHeader className="pb-2 pt-3 px-3">
                        <CardTitle className="text-xs font-semibold">Zusammenfassung</CardTitle>
                      </CardHeader>
                      <CardContent className="px-3 pb-3">
                        <p className="text-xs leading-relaxed text-foreground">{analysis.abstract}</p>
                      </CardContent>
                    </Card>
                  )}

                  {/* Structured Summary */}
                  {analysis.structured_summary && (
                    <div className="space-y-2">
                      {Object.entries(analysis.structured_summary).map(([key, value]) => {
                        if (!value) return null;
                        const labels: Record<string, { label: string; icon: typeof Stethoscope }> = {
                          anamnese: { label: 'Anamnese', icon: Stethoscope },
                          befund: { label: 'Befund', icon: FlaskConical },
                          diagnosen: { label: 'Diagnosen', icon: HeartPulse },
                          therapie: { label: 'Therapie', icon: Pill },
                          procedere: { label: 'Procedere', icon: ArrowLeft },
                        };
                        const config = labels[key] || { label: key, icon: FileText };
                        const Icon = config.icon;
                        return (
                          <Collapsible key={key} defaultOpen>
                            <CollapsibleTrigger className="flex w-full items-center gap-1.5 rounded-md bg-muted/50 px-2.5 py-1.5 text-left">
                              <Icon className="h-3 w-3 text-primary" />
                              <span className="flex-1 text-[11px] font-semibold">{config.label}</span>
                              <ChevronDown className="h-3 w-3 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                            </CollapsibleTrigger>
                            <CollapsibleContent>
                              <p className="px-2.5 py-1.5 text-[11px] leading-relaxed text-foreground">{value}</p>
                            </CollapsibleContent>
                          </Collapsible>
                        );
                      })}
                    </div>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center justify-center gap-2 py-8">
                  <Brain className="h-6 w-6 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Noch keine Analyse verfügbar</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs"
                    onClick={() => reanalyze.mutate()}
                    disabled={reanalyze.isPending}
                  >
                    {reanalyze.isPending && <Loader2 className="mr-1.5 h-3 w-3 animate-spin" />}
                    Jetzt analysieren
                  </Button>
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* Ontology Codes */}
        <TabsContent value="codes" className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="space-y-3 p-3">
              {doc.analysis_status === 'completed' && analysis.ontology_codes ? (
                Object.entries(analysis.ontology_codes).map(([system, codes]) => {
                  if (!codes || codes.length === 0) return null;
                  const { label, color } = systemLabel(system);
                  return (
                    <div key={system}>
                      <h4 className="mb-1.5 text-[11px] font-semibold text-foreground">{label}</h4>
                      <div className="flex flex-wrap gap-1">
                        {codes.map((c, i) => (
                          <Tooltip key={i}>
                            <TooltipTrigger asChild>
                              <Badge
                                variant="outline"
                                className={`cursor-default text-[10px] ${color}`}
                              >
                                {c.code} · {Math.round(c.confidence * 100)}%
                              </Badge>
                            </TooltipTrigger>
                            <TooltipContent side="bottom" className="max-w-[200px]">
                              <p className="text-xs font-medium">{c.display}</p>
                              <p className="text-[10px] text-muted-foreground">
                                Konfidenz: {Math.round(c.confidence * 100)}%
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        ))}
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="flex flex-col items-center justify-center gap-2 py-8">
                  <Tags className="h-6 w-6 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Keine Codes erkannt</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* FHIR Transfer */}
        <TabsContent value="fhir" className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="space-y-3 p-3">
              {doc.analysis_status === 'completed' && analysis.extracted_fhir ? (
                <>
                  <FhirSection
                    title="Diagnosen"
                    icon={<HeartPulse className="h-3.5 w-3.5 text-red-500" />}
                    items={analysis.extracted_fhir.conditions || []}
                    type="conditions"
                    renderItem={(item) => (
                      <div>
                        <p className="text-xs font-medium">{item.display}</p>
                        <p className="text-[10px] text-muted-foreground">{item.code} · {item.clinical_status}</p>
                      </div>
                    )}
                    isTransferred={isTransferred}
                    onTransfer={(index, data) => transferMutation.mutate({ type: 'conditions', index, data })}
                    isPending={transferMutation.isPending}
                  />

                  <FhirSection
                    title="Medikamente"
                    icon={<Pill className="h-3.5 w-3.5 text-blue-500" />}
                    items={analysis.extracted_fhir.medications || []}
                    type="medications"
                    renderItem={(item) => (
                      <div>
                        <p className="text-xs font-medium">{item.display}</p>
                        {item.dosage_text && <p className="text-[10px] text-muted-foreground">{item.dosage_text}</p>}
                      </div>
                    )}
                    isTransferred={isTransferred}
                    onTransfer={(index, data) => transferMutation.mutate({ type: 'medications', index, data })}
                    isPending={transferMutation.isPending}
                  />

                  <FhirSection
                    title="Allergien"
                    icon={<AlertTriangle className="h-3.5 w-3.5 text-amber-500" />}
                    items={analysis.extracted_fhir.allergies || []}
                    type="allergies"
                    renderItem={(item) => (
                      <div>
                        <p className="text-xs font-medium">{item.display}</p>
                        <p className="text-[10px] text-muted-foreground">{item.category} · {item.criticality}</p>
                      </div>
                    )}
                    isTransferred={isTransferred}
                    onTransfer={(index, data) => transferMutation.mutate({ type: 'allergies', index, data })}
                    isPending={transferMutation.isPending}
                  />

                  <FhirSection
                    title="Laborwerte"
                    icon={<FlaskConical className="h-3.5 w-3.5 text-teal-500" />}
                    items={analysis.extracted_fhir.observations || []}
                    type="observations"
                    renderItem={(item) => (
                      <div>
                        <p className="text-xs font-medium">{item.display}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {item.value} {item.unit}
                          {item.loinc_code && ` · LOINC: ${item.loinc_code}`}
                        </p>
                      </div>
                    )}
                    isTransferred={isTransferred}
                    onTransfer={(index, data) => transferMutation.mutate({ type: 'observations', index, data })}
                    isPending={transferMutation.isPending}
                  />

                  <FhirSection
                    title="Prozeduren"
                    icon={<Scissors className="h-3.5 w-3.5 text-rose-500" />}
                    items={analysis.extracted_fhir.procedures || []}
                    type="procedures"
                    renderItem={(item) => (
                      <div>
                        <p className="text-xs font-medium">{item.display}</p>
                        <p className="text-[10px] text-muted-foreground">{item.code}</p>
                      </div>
                    )}
                    isTransferred={isTransferred}
                    onTransfer={(index, data) => transferMutation.mutate({ type: 'procedures', index, data })}
                    isPending={transferMutation.isPending}
                  />
                </>
              ) : (
                <div className="flex flex-col items-center justify-center gap-2 py-8">
                  <Database className="h-6 w-6 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Keine FHIR-Daten extrahiert</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ── Reusable FHIR Section ── */
function FhirSection<T extends Record<string, unknown>>({
  title,
  icon,
  items,
  type,
  renderItem,
  isTransferred,
  onTransfer,
  isPending,
}: {
  title: string;
  icon: React.ReactNode;
  items: T[];
  type: string;
  renderItem: (item: T) => React.ReactNode;
  isTransferred: (type: string, index: number) => boolean;
  onTransfer: (index: number, data: T) => void;
  isPending: boolean;
}) {
  if (items.length === 0) return null;

  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1.5">
        {icon}
        <h4 className="text-[11px] font-semibold">{title}</h4>
        <Badge variant="secondary" className="ml-auto h-4 px-1 text-[9px]">
          {items.length}
        </Badge>
      </div>
      <div className="space-y-1">
        {items.map((item, i) => {
          const done = isTransferred(type, i);
          return (
            <Card key={i} className={`transition-colors ${done ? 'bg-emerald-50/50 dark:bg-emerald-950/20' : ''}`}>
              <div className="flex items-center gap-2 p-2">
                <div className="min-w-0 flex-1">{renderItem(item)}</div>
                {done ? (
                  <Badge variant="outline" className="shrink-0 text-[9px] text-emerald-600 border-emerald-200">
                    <CheckCircle className="mr-0.5 h-2.5 w-2.5" /> Gespeichert
                  </Badge>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    className="shrink-0 h-6 px-2 text-[10px]"
                    onClick={() => onTransfer(i, item)}
                    disabled={isPending}
                  >
                    <Database className="mr-1 h-2.5 w-2.5" />
                    Übernehmen
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
