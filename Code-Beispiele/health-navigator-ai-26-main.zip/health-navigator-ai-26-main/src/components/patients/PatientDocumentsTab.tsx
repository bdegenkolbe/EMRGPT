import { useState, useCallback } from 'react';
import JSZip from 'jszip';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useDropzone } from 'react-dropzone';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card } from '@/components/ui/card';
import {
  Upload, FileText, Image, File, Trash2,
  Loader2, Download, Calendar, Brain, CheckCircle, AlertTriangle,
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const ACCEPTED_TYPES: Record<string, string[]> = {
  'application/pdf': ['.pdf'],
  'application/msword': ['.doc'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'image/png': ['.png'],
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/webp': ['.webp'],
  'application/zip': ['.zip'],
  'application/x-zip-compressed': ['.zip'],
};

const MIME_LABELS: Record<string, string> = {
  'application/pdf': 'PDF',
  'application/msword': 'DOC',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'DOCX',
  'image/png': 'PNG',
  'image/jpeg': 'JPEG',
  'image/webp': 'WEBP',
};

interface PatientDocument {
  id: string;
  fhir_id: string;
  type_display: string | null;
  type_code: string | null;
  description: string | null;
  content_type: string | null;
  storage_path: string | null;
  date: string | null;
  status: string;
  author_display: string | null;
  created_at: string;
  analysis_status: string | null;
  analysis_result: Record<string, unknown> | null;
  transferred_resources: Record<string, string[]> | null;
}

interface Props {
  patientId: string;
  onSelectDocument?: (doc: PatientDocument) => void;
}

export function PatientDocumentsTab({ patientId, onSelectDocument }: Props) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState(false);

  // Fetch existing documents
  const { data: documents = [], isLoading } = useQuery({
    queryKey: ['patient-documents', patientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fhir_document_references')
        .select('*')
        .eq('patient_id', patientId)
        .order('date', { ascending: false });
      if (error) throw error;
      return data as unknown as PatientDocument[];
    },
    enabled: !!patientId && !!user,
    refetchInterval: (query) => {
      const docs = query.state.data || [];
      const hasPending = docs.some(d => d.analysis_status === 'analyzing' || d.analysis_status === 'pending');
      return hasPending ? 4000 : false;
    },
  });

  // Upload handler
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!user || acceptedFiles.length === 0) return;

    setUploading(true);
    let successCount = 0;

    // Extract files from ZIPs
    const allFiles: File[] = [];
    for (const file of acceptedFiles) {
      if (file.type === 'application/zip' || file.type === 'application/x-zip-compressed' || file.name.endsWith('.zip')) {
        try {
          const zip = await JSZip.loadAsync(file);
          for (const [name, entry] of Object.entries(zip.files)) {
            if (entry.dir || name.startsWith('__MACOSX')) continue;
            const ext = name.split('.').pop()?.toLowerCase();
            if (!ext || !['pdf', 'doc', 'docx', 'png', 'jpg', 'jpeg', 'webp'].includes(ext)) continue;
            const blob = await entry.async('blob');
            const mimeType = ext === 'pdf' ? 'application/pdf' :
                    ext === 'doc' ? 'application/msword' :
                    ext === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' :
                    ext === 'png' ? 'image/png' :
                    ext === 'webp' ? 'image/webp' : 'image/jpeg';
            const extracted = new window.File([blob], name.split('/').pop() || name, {
              type: mimeType,
            });
            allFiles.push(extracted);
          }
        } catch (err) {
          console.error('ZIP extraction error:', err);
          toast.error(`ZIP konnte nicht entpackt werden: ${file.name}`);
        }
      } else {
        allFiles.push(file);
      }
    }

    try {
      for (const file of allFiles) {
        const fhirId = `doc-${crypto.randomUUID()}`;
        const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
        const storagePath = `${user.id}/${patientId}/${fhirId}_${safeName}`;

        // Upload file to storage
        const { error: uploadError } = await supabase.storage
          .from('patient-documents')
          .upload(storagePath, file, { contentType: file.type });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          toast.error(`Upload fehlgeschlagen: ${file.name}`);
          continue;
        }

        // Determine document type
        const isImage = file.type.startsWith('image/');
        const isPdf = file.type === 'application/pdf';
        const typeCode = isImage ? '55113-5' : isPdf ? '11502-2' : '34133-9';
        const typeDisplay = isImage ? 'Bilddokument' : isPdf ? 'PDF-Dokument' : 'Dokument';

        // Create FHIR DocumentReference
        const fhirResource = {
          resourceType: 'DocumentReference',
          id: fhirId,
          status: 'current',
          type: {
            coding: [{ system: 'http://loinc.org', code: typeCode, display: typeDisplay }],
          },
          subject: { reference: `Patient/${patientId}` },
          date: new Date().toISOString(),
          author: [{ display: user.email }],
          description: file.name,
          content: [{
            attachment: {
              contentType: file.type,
              title: file.name,
              size: file.size,
            },
          }],
        };

        const { data: insertedDoc, error: dbError } = await supabase
          .from('fhir_document_references')
          .insert({
            fhir_id: fhirId,
            patient_id: patientId,
            status: 'current',
            type_code: typeCode,
            type_display: typeDisplay,
            description: file.name,
            content_type: file.type,
            storage_path: storagePath,
            date: new Date().toISOString(),
            author_display: user.email,
            fhir_resource: fhirResource,
          } as any)
          .select('id')
          .single();

        if (dbError) {
          console.error('DB error:', dbError);
          toast.error(`Speichern fehlgeschlagen: ${file.name}`);
          continue;
        }

        // Auto-trigger KI analysis
        if (insertedDoc?.id) {
          supabase.functions.invoke('document-analyze', {
            body: { documentId: insertedDoc.id },
          }).catch(err => console.error('Auto-analyze error:', err));
        }

        successCount++;
      }

      if (successCount > 0) {
        toast.success(`${successCount} Dokument${successCount > 1 ? 'e' : ''} hochgeladen – KI-Analyse gestartet`);
        queryClient.invalidateQueries({ queryKey: ['patient-documents', patientId] });
      }
    } catch (err: any) {
      console.error('Upload error:', err);
      toast.error('Upload fehlgeschlagen');
    } finally {
      setUploading(false);
    }
  }, [user, patientId, queryClient]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_TYPES,
    maxSize: 20 * 1024 * 1024,
    disabled: uploading,
  });

  // Download document
  const handleDownload = async (doc: PatientDocument) => {
    if (!doc.storage_path) return;
    const { data } = await supabase.storage
      .from('patient-documents')
      .createSignedUrl(doc.storage_path, 300);

    if (data?.signedUrl) {
      window.open(data.signedUrl, '_blank');
    } else {
      toast.error('Download-Link konnte nicht erstellt werden');
    }
  };

  // Delete document
  const handleDelete = async (doc: PatientDocument) => {
    try {
      if (doc.storage_path) {
        await supabase.storage
          .from('patient-documents')
          .remove([doc.storage_path]);
      }
      await supabase
        .from('fhir_document_references')
        .delete()
        .eq('id', doc.id);

      queryClient.invalidateQueries({ queryKey: ['patient-documents', patientId] });
      toast.success('Dokument gelöscht');
    } catch {
      toast.error('Löschen fehlgeschlagen');
    }
  };

  const getFileIcon = (contentType: string | null) => {
    if (contentType?.startsWith('image/')) return <Image className="h-4 w-4 text-emerald-600" />;
    if (contentType === 'application/pdf') return <FileText className="h-4 w-4 text-red-600" />;
    return <File className="h-4 w-4 text-muted-foreground" />;
  };

  return (
    <ScrollArea className="h-full">
      <div className="space-y-2 p-2">
        {/* Dropzone */}
        <div
          {...getRootProps()}
          className={`
            flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 transition-colors min-h-[140px]
            ${isDragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50 hover:bg-muted/30'}
            ${uploading ? 'pointer-events-none opacity-60' : ''}
          `}
        >
          <input {...getInputProps()} />
          {uploading ? (
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          ) : (
            <Upload className={`h-8 w-8 ${isDragActive ? 'text-primary' : 'text-muted-foreground'}`} />
          )}
          <p className="mt-2 text-center text-xs text-muted-foreground">
            {isDragActive
              ? 'Dateien hier ablegen...'
              : uploading
                ? 'Wird hochgeladen...'
                : 'PDF, Word, Bilder oder ZIP hierher ziehen'}
          </p>
          <p className="mt-0.5 text-[10px] text-muted-foreground/60">Mehrere Dateien möglich · Max. 20 MB pro Datei</p>
        </div>

        {/* Document list */}
        {isLoading ? (
          <div className="flex items-center justify-center p-6">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : documents.length === 0 ? (
          <p className="p-3 text-center text-xs text-muted-foreground">
            Noch keine Dokumente hochgeladen.
          </p>
        ) : (
          documents.map((doc) => (
            <Card
              key={doc.id}
              className="group cursor-pointer transition-colors hover:bg-muted/30"
              onClick={() => onSelectDocument?.(doc)}
            >
              <div className="flex items-start gap-2 p-2.5">
                {getFileIcon(doc.content_type)}
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium leading-snug text-foreground line-clamp-2">
                    {doc.description || doc.type_display || 'Dokument'}
                  </p>
                  <div className="mt-0.5 flex flex-wrap items-center gap-1.5">
                    {doc.content_type && (
                      <Badge variant="outline" className="h-4 px-1 text-[9px]">
                        {MIME_LABELS[doc.content_type] || doc.content_type.split('/')[1]?.toUpperCase() || 'FILE'}
                      </Badge>
                    )}
                    {doc.analysis_status === 'completed' && (
                      <Badge variant="outline" className="h-4 px-1 text-[9px] text-emerald-600 border-emerald-200">
                        <CheckCircle className="mr-0.5 h-2 w-2" /> KI
                      </Badge>
                    )}
                    {doc.analysis_status === 'analyzing' && (
                      <Badge variant="outline" className="h-4 px-1 text-[9px] text-primary">
                        <Loader2 className="mr-0.5 h-2 w-2 animate-spin" /> ...
                      </Badge>
                    )}
                    {doc.analysis_status === 'error' && (
                      <Badge variant="outline" className="h-4 px-1 text-[9px] text-destructive">
                        <AlertTriangle className="mr-0.5 h-2 w-2" /> !
                      </Badge>
                    )}
                    {doc.date && (
                      <span className="flex items-center gap-0.5 text-[9px] text-muted-foreground">
                        <Calendar className="h-2.5 w-2.5" />
                        {format(new Date(doc.date), 'dd.MM.yyyy')}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={(e) => { e.stopPropagation(); handleDownload(doc); }}
                    title="Herunterladen"
                  >
                    <Download className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-destructive hover:text-destructive"
                    onClick={(e) => { e.stopPropagation(); handleDelete(doc); }}
                    title="Löschen"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </ScrollArea>
  );
}
