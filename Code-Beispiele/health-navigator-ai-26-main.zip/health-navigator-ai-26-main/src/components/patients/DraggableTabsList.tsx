import { useState, useEffect, useCallback } from 'react';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  horizontalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import type { ReactNode } from 'react';

interface TabDef {
  value: string;
  label: string;
  icon: ReactNode;
}

interface Props {
  tabs: TabDef[];
  order: string[];
  onOrderChange: (order: string[]) => void;
  className?: string;
}

function SortableTab({ tab }: { tab: TabDef }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: tab.value });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 10 : undefined,
    opacity: isDragging ? 0.7 : 1,
  };

  return (
    <TabsTrigger
      ref={setNodeRef}
      value={tab.value}
      style={style}
      className={cn('gap-1 text-[11px] cursor-grab active:cursor-grabbing', isDragging && 'shadow-md')}
      {...attributes}
      {...listeners}
    >
      {tab.icon} {tab.label}
    </TabsTrigger>
  );
}

export function DraggableTabsList({ tabs, order, onOrderChange, className }: Props) {
  const [sortedTabs, setSortedTabs] = useState<TabDef[]>([]);

  useEffect(() => {
    const ordered = order
      .map((v) => tabs.find((t) => t.value === v))
      .filter(Boolean) as TabDef[];
    const missing = tabs.filter((t) => !order.includes(t.value));
    setSortedTabs([...ordered, ...missing]);
  }, [order, tabs]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
  );

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    setSortedTabs((prev) => {
      const oldIndex = prev.findIndex((t) => t.value === active.id);
      const newIndex = prev.findIndex((t) => t.value === over.id);
      const newTabs = arrayMove(prev, oldIndex, newIndex);
      onOrderChange(newTabs.map((t) => t.value));
      return newTabs;
    });
  }, [onOrderChange]);

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={sortedTabs.map((t) => t.value)} strategy={horizontalListSortingStrategy}>
        <TabsList className={cn('h-8', className)}>
          {sortedTabs.map((tab) => (
            <SortableTab key={tab.value} tab={tab} />
          ))}
        </TabsList>
      </SortableContext>
    </DndContext>
  );
}
