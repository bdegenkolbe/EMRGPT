import { useFhirPatientData } from '@/hooks/useFhirPatients';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Pill } from 'lucide-react';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

interface Props { patientId: string; }

export function PatientMedications({ patientId }: Props) {
  const { medications } = useFhirPatientData(patientId);

  if (medications.isLoading) return <p className="p-4 text-sm text-muted-foreground">Laden...</p>;
  const data = medications.data || [];
  const active = data.filter(m => m.status === 'active');
  const other = data.filter(m => m.status !== 'active');

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-4">
        {active.length > 0 && (
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">Aktive Medikation ({active.length})</h3>
            <div className="space-y-2">
              {active.map(m => (
                <Card key={m.id}>
                  <CardContent className="p-3 flex items-start gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500/10 flex-shrink-0">
                      <Pill className="h-4 w-4 text-blue-500" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-foreground">{m.medication_display || 'Unbekannt'}</p>
                      {m.dosage_text && <p className="text-xs text-muted-foreground mt-0.5">{m.dosage_text}</p>}
                      <div className="flex flex-wrap gap-1 mt-1">
                        {m.medication_code && <Badge variant="outline" className="text-[10px] font-mono">{m.medication_code}</Badge>}
                        {m.dosage_route && <Badge variant="secondary" className="text-[10px]">{m.dosage_route}</Badge>}
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[10px] bg-emerald-500/10 text-emerald-600 border-emerald-500/20">aktiv</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {other.length > 0 && (
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground mb-2">Abgesetzte / Andere ({other.length})</h3>
            <div className="space-y-2">
              {other.map(m => (
                <Card key={m.id} className="opacity-60">
                  <CardContent className="p-3 flex items-start gap-3">
                    <Pill className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div className="min-w-0">
                      <p className="text-sm text-foreground">{m.medication_display || 'Unbekannt'}</p>
                      {m.dosage_text && <p className="text-xs text-muted-foreground">{m.dosage_text}</p>}
                    </div>
                    <Badge variant="outline" className="text-[10px] ml-auto">{m.status}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {data.length === 0 && <p className="text-sm text-muted-foreground">Keine Medikation dokumentiert.</p>}
      </div>
    </ScrollArea>
  );
}
