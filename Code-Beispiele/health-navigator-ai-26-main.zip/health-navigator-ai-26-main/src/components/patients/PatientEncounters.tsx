import { useFhirPatientData } from '@/hooks/useFhirPatients';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Building2 } from 'lucide-react';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

interface Props { patientId: string; }

const classLabels: Record<string, string> = {
  AMB: 'Ambulant',
  IMP: 'Stationär',
  EMER: 'Notfall',
  HH: 'Hausbesuch',
  ambulatory: 'Ambulant',
  inpatient: 'Stationär',
  emergency: 'Notfall',
};

const statusColors: Record<string, string> = {
  'in-progress': 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  finished: 'bg-muted text-muted-foreground',
  planned: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  arrived: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
};

export function PatientEncounters({ patientId }: Props) {
  const { encounters } = useFhirPatientData(patientId);

  if (encounters.isLoading) return <p className="p-4 text-sm text-muted-foreground">Laden...</p>;
  const data = encounters.data || [];

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-2">
        <h3 className="text-sm font-semibold text-foreground mb-3">Aufenthalte ({data.length})</h3>
        {data.length === 0 ? (
          <p className="text-sm text-muted-foreground">Keine Aufenthalte dokumentiert.</p>
        ) : data.map(e => (
          <Card key={e.id}>
            <CardContent className="p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <Building2 className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {e.type_display || classLabels[e.class || ''] || e.class || 'Aufenthalt'}
                    </p>
                    {e.service_provider && (
                      <p className="text-xs text-muted-foreground">{e.service_provider}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      {e.period_start ? format(new Date(e.period_start), 'dd.MM.yyyy HH:mm', { locale: de }) : '?'}
                      {' → '}
                      {e.period_end ? format(new Date(e.period_end), 'dd.MM.yyyy HH:mm', { locale: de }) : 'laufend'}
                    </p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge variant="outline" className={`text-[10px] ${statusColors[e.status] || ''}`}>
                    {e.status}
                  </Badge>
                  {e.class && (
                    <Badge variant="secondary" className="text-[10px]">
                      {classLabels[e.class] || e.class}
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </ScrollArea>
  );
}
