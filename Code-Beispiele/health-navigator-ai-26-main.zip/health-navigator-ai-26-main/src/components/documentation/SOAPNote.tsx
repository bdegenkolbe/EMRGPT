import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, Stethoscope, ClipboardList, FileText, Edit } from 'lucide-react';

interface Observation {
  id: string;
  raw_input: string;
  normalized_value?: string | null;
  hpo_codes?: string[] | null;
  severity?: string | null;
  onset?: string | null;
  duration?: string | null;
  negated?: boolean | null;
}

interface SOAPNoteProps {
  chiefComplaint: string;
  historyOfPresentIllness: string;
  reviewOfSystems?: string[];
  observations: Observation[];
  hpoCodes: string[];
  meshTerms: string[];
  redFlags: string[];
  summary?: string;
  planNotes?: string;
  patientIdentifier?: string;
  sessionDate: string;
  clinicalView: string;
}

export function SOAPNote({
  chiefComplaint,
  historyOfPresentIllness,
  reviewOfSystems = [],
  observations,
  hpoCodes,
  meshTerms,
  redFlags,
  summary,
  planNotes,
  patientIdentifier,
  sessionDate,
  clinicalView,
}: SOAPNoteProps) {
  const { t } = useTranslation();

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">{t('documentation.soapNote')}</h2>
          <p className="text-sm text-muted-foreground">
            {sessionDate} • {t(`medical.views.${clinicalView}`)}
            {patientIdentifier && ` • ${patientIdentifier}`}
          </p>
        </div>
      </div>

      {/* Red Flags Alert */}
      {redFlags.length > 0 && (
        <Card className="border-destructive bg-destructive/10">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              {t('documentation.redFlags')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-1">
              {redFlags.map((flag, i) => (
                <li key={i} className="text-sm text-destructive">• {flag}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Subjective */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Stethoscope className="h-5 w-5 text-primary" />
            {t('documentation.subjective')} (S)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="text-sm font-semibold text-muted-foreground mb-1">
              {t('documentation.chiefComplaint')}
            </h4>
            <p className="text-sm">{chiefComplaint || '—'}</p>
          </div>
          
          <Separator />
          
          <div>
            <h4 className="text-sm font-semibold text-muted-foreground mb-1">
              {t('documentation.hpi')}
            </h4>
            <p className="text-sm whitespace-pre-wrap">{historyOfPresentIllness || '—'}</p>
          </div>

          {reviewOfSystems.length > 0 && (
            <>
              <Separator />
              <div>
                <h4 className="text-sm font-semibold text-muted-foreground mb-1">
                  {t('documentation.ros')}
                </h4>
                <ul className="text-sm space-y-1">
                  {reviewOfSystems.map((item, i) => (
                    <li key={i}>• {item}</li>
                  ))}
                </ul>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Objective */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <ClipboardList className="h-5 w-5 text-primary" />
            {t('documentation.objective')} (O)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <h4 className="text-sm font-semibold text-muted-foreground mb-2">
            {t('documentation.observations')}
          </h4>
          {observations.length > 0 ? (
            <div className="space-y-3">
              {observations.map((obs) => (
                <div key={obs.id} className="rounded-lg border p-3">
                  <div className="flex items-start justify-between gap-2">
                    <p className={`text-sm ${obs.negated ? 'line-through text-muted-foreground' : ''}`}>
                      {obs.raw_input}
                    </p>
                    {obs.negated && (
                      <Badge variant="outline" className="text-xs">
                        {t('documentation.negated')}
                      </Badge>
                    )}
                  </div>
                  
                  {(obs.severity || obs.onset || obs.duration) && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {obs.severity && (
                        <Badge variant="secondary" className="text-xs">
                          {t('documentation.severity')}: {obs.severity}
                        </Badge>
                      )}
                      {obs.onset && (
                        <Badge variant="secondary" className="text-xs">
                          {t('documentation.onset')}: {obs.onset}
                        </Badge>
                      )}
                      {obs.duration && (
                        <Badge variant="secondary" className="text-xs">
                          {t('documentation.duration')}: {obs.duration}
                        </Badge>
                      )}
                    </div>
                  )}
                  
                  {obs.hpo_codes && obs.hpo_codes.length > 0 && (
                    <p className="text-xs text-muted-foreground mt-2 font-mono">
                      HPO: {obs.hpo_codes.join(', ')}
                    </p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">—</p>
          )}
        </CardContent>
      </Card>

      {/* Assessment */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <FileText className="h-5 w-5 text-primary" />
            {t('documentation.assessment')} (A)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {summary && (
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-1">
                {t('documentation.summary')}
              </h4>
              <p className="text-sm whitespace-pre-wrap">{summary}</p>
            </div>
          )}

          {hpoCodes.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-2">
                {t('documentation.hpoCodes')}
              </h4>
              <div className="flex flex-wrap gap-1">
                {hpoCodes.map((code, i) => (
                  <Badge key={i} variant="outline" className="text-xs font-mono">
                    {code}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {meshTerms.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-2">
                {t('documentation.meshTerms')}
              </h4>
              <div className="flex flex-wrap gap-1">
                {meshTerms.map((term, i) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    {term}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Plan */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Edit className="h-5 w-5 text-primary" />
            {t('documentation.plan')} (P)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground italic">
            {planNotes || t('documentation.planPlaceholder')}
          </p>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <p className="text-xs text-muted-foreground text-center">
        {t('documentation.disclaimer')}
      </p>
    </div>
  );
}
