import { useTranslation } from 'react-i18next';
import { FileText, FileJson, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { downloadSOAPNotePDF } from '@/lib/export/pdfGenerator';
import { formatSessionForExport, downloadSessionJSON, generateFHIRBundle } from '@/lib/export/jsonExporter';
import { useToast } from '@/hooks/use-toast';

interface ExportButtonsProps {
  session: {
    id: string;
    user_id: string;
    patient_identifier?: string | null;
    clinical_view: string;
    language: string;
    status: string;
    started_at?: string | null;
    completed_at?: string | null;
    created_at?: string | null;
  };
  observations: Array<{
    id: string;
    raw_input: string;
    normalized_value?: string | null;
    language: string;
    hpo_codes?: string[] | null;
    rxnorm_codes?: string[] | null;
    mesh_terms?: string[] | null;
    negated?: boolean | null;
    onset?: string | null;
    duration?: string | null;
    severity?: string | null;
    confidence?: number | null;
    provenance?: string | null;
    created_at?: string | null;
  }>;
  soapData: {
    chiefComplaint: string;
    historyOfPresentIllness: string;
    reviewOfSystems?: string[];
    redFlags: string[];
    summary?: string;
  };
  evidenceRequests?: Array<{
    id: string;
    query_context: Record<string, unknown>;
    query_strings: Record<string, unknown>;
    sources: string[];
    created_at?: string | null;
  }>;
  evidenceItems?: Array<{
    id: string;
    source: string;
    external_id: string;
    title: string;
    year?: number | null;
    venue?: string | null;
    url?: string | null;
    snippet?: string | null;
    study_type?: string | null;
    relevance_score?: number | null;
    created_at?: string | null;
  }>;
}

export function ExportButtons({
  session,
  observations,
  soapData,
  evidenceRequests,
  evidenceItems,
}: ExportButtonsProps) {
  const { t } = useTranslation();
  const { toast } = useToast();

  const handlePDFExport = () => {
    try {
      const hpoCodes = observations
        .flatMap(o => o.hpo_codes || [])
        .filter((code, i, arr) => arr.indexOf(code) === i);
      
      const meshTerms = observations
        .flatMap(o => o.mesh_terms || [])
        .filter((term, i, arr) => arr.indexOf(term) === i);

      downloadSOAPNotePDF({
        patientIdentifier: session.patient_identifier ?? undefined,
        sessionDate: new Date(session.created_at || Date.now()).toLocaleDateString('de-DE'),
        clinicalView: session.clinical_view,
        language: session.language,
        subjective: {
          chiefComplaint: soapData.chiefComplaint,
          historyOfPresentIllness: soapData.historyOfPresentIllness,
          reviewOfSystems: soapData.reviewOfSystems,
        },
        objective: {
          observations: observations.map(o => ({
            raw_input: o.raw_input,
            normalized_value: o.normalized_value ?? undefined,
            hpo_codes: o.hpo_codes ?? undefined,
            severity: o.severity ?? undefined,
            onset: o.onset ?? undefined,
            duration: o.duration ?? undefined,
            negated: o.negated ?? undefined,
          })),
        },
        assessment: {
          hpoCodes,
          meshTerms,
          redFlags: soapData.redFlags,
          summary: soapData.summary,
        },
        plan: {},
        metadata: {
          sessionId: session.id,
          userId: session.user_id,
          createdAt: session.created_at || new Date().toISOString(),
          completedAt: session.completed_at ?? undefined,
        },
      });

      toast({
        title: t('export.pdfSuccess'),
        description: t('export.pdfSuccessDescription'),
      });
    } catch (error) {
      console.error('PDF export error:', error);
      toast({
        variant: 'destructive',
        title: t('export.error'),
        description: String(error),
      });
    }
  };

  const handleJSONExport = () => {
    try {
      const exportData = formatSessionForExport(
        session,
        observations,
        evidenceRequests,
        evidenceItems
      );
      downloadSessionJSON(exportData);

      toast({
        title: t('export.jsonSuccess'),
        description: t('export.jsonSuccessDescription'),
      });
    } catch (error) {
      console.error('JSON export error:', error);
      toast({
        variant: 'destructive',
        title: t('export.error'),
        description: String(error),
      });
    }
  };

  const handleFHIRExport = () => {
    try {
      const exportData = formatSessionForExport(
        session,
        observations,
        evidenceRequests,
        evidenceItems
      );
      const fhirBundle = generateFHIRBundle(exportData);
      
      const jsonString = JSON.stringify(fhirBundle, null, 2);
      const blob = new Blob([jsonString], { type: 'application/fhir+json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `fhir-bundle-${session.id.slice(0, 8)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: t('export.fhirSuccess'),
        description: t('export.fhirSuccessDescription'),
      });
    } catch (error) {
      console.error('FHIR export error:', error);
      toast({
        variant: 'destructive',
        title: t('export.error'),
        description: String(error),
      });
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          {t('export.title')}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handlePDFExport}>
          <FileText className="mr-2 h-4 w-4" />
          {t('export.pdf')}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleJSONExport}>
          <FileJson className="mr-2 h-4 w-4" />
          {t('export.json')}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleFHIRExport}>
          <FileJson className="mr-2 h-4 w-4" />
          {t('export.fhir')}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
