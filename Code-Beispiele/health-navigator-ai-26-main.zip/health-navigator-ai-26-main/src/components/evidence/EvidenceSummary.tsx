import { AlertCircle, Info, Clock, Search } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useTranslation } from 'react-i18next';

interface EvidenceSummaryProps {
  summary: string;
  queryTerms: string[];
  sources: string[];
  searchDate: string;
  pmids?: string[];
  disclaimer?: string;
}

export function EvidenceSummary({
  summary,
  queryTerms,
  sources,
  searchDate,
  pmids = [],
  disclaimer,
}: EvidenceSummaryProps) {
  const { t } = useTranslation();

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="rounded-lg border bg-card p-4">
        <h3 className="mb-2 text-sm font-semibold">
          {t('evidence.summaryTitle')}
        </h3>
        <p className="text-sm text-muted-foreground whitespace-pre-wrap">
          {summary}
        </p>
      </div>

      {/* Disclaimer */}
      <Alert variant="default">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>{t('evidence.disclaimerTitle')}</AlertTitle>
        <AlertDescription className="text-xs">
          {disclaimer || t('evidence.disclaimerText')}
        </AlertDescription>
      </Alert>

      {/* Audit Info */}
      <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
        <h4 className="text-xs font-semibold uppercase text-muted-foreground">
          {t('evidence.auditInfo')}
        </h4>

        <div className="grid gap-2 text-xs">
          {/* Search Date */}
          <div className="flex items-start gap-2">
            <Clock className="h-3 w-3 mt-0.5 text-muted-foreground" />
            <div>
              <span className="font-medium">{t('evidence.searchDate')}: </span>
              <span className="text-muted-foreground">{searchDate}</span>
            </div>
          </div>

          {/* Query Terms */}
          <div className="flex items-start gap-2">
            <Search className="h-3 w-3 mt-0.5 text-muted-foreground" />
            <div>
              <span className="font-medium">{t('evidence.queryTerms')}: </span>
              <span className="text-muted-foreground">
                {queryTerms.join(', ')}
              </span>
            </div>
          </div>

          {/* Sources */}
          <div className="flex items-start gap-2">
            <Info className="h-3 w-3 mt-0.5 text-muted-foreground" />
            <div>
              <span className="font-medium">{t('evidence.sources')}: </span>
              <span className="text-muted-foreground">
                {sources.join(', ')}
              </span>
            </div>
          </div>

          {/* PMIDs */}
          {pmids.length > 0 && (
            <div className="flex items-start gap-2">
              <Info className="h-3 w-3 mt-0.5 text-muted-foreground" />
              <div>
                <span className="font-medium">PMIDs: </span>
                <span className="text-muted-foreground font-mono text-xs">
                  {pmids.join(', ')}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
