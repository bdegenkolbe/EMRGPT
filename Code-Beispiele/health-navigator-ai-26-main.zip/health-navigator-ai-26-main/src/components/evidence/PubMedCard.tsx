import { ExternalLink, FileText, Calendar, BookOpen } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface PubMedCardProps {
  title: string;
  authors?: string;
  journal?: string;
  year?: number;
  pmid: string;
  abstract?: string;
  studyType?: string;
  relevanceScore?: number;
}

export function PubMedCard({
  title,
  authors,
  journal,
  year,
  pmid,
  abstract,
  studyType,
  relevanceScore,
}: PubMedCardProps) {
  const pubmedUrl = `https://pubmed.ncbi.nlm.nih.gov/${pmid}/`;
  const externalTarget = (() => {
    if (typeof window === 'undefined') return '_blank' as const;
    const inIframe = (() => {
      try {
        return window.self !== window.top;
      } catch {
        return true;
      }
    })();
    if (inIframe) return '_top' as const;

    const ua = navigator.userAgent;
    const isSafari = /Safari/i.test(ua) && !/Chrome|Chromium|Edg|OPR/i.test(ua);
    return isSafari ? ('_self' as const) : ('_blank' as const);
  })();

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-sm font-medium leading-tight line-clamp-2">
            {title}
          </CardTitle>
          {relevanceScore !== undefined && (
            <Badge variant="secondary" className="shrink-0">
              {Math.round(relevanceScore * 100)}%
            </Badge>
          )}
        </div>
        {authors && (
          <p className="text-xs text-muted-foreground line-clamp-1">
            {authors}
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {journal && (
            <span className="flex items-center gap-1">
              <BookOpen className="h-3 w-3" />
              {journal}
            </span>
          )}
          {year && (
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {year}
            </span>
          )}
          {studyType && (
            <Badge variant="outline" className="text-xs">
              {studyType}
            </Badge>
          )}
        </div>

        {abstract && (
          <p className="text-xs text-muted-foreground line-clamp-3">
            {abstract}
          </p>
        )}

        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            PMID: {pmid}
          </Badge>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            asChild
          >
            <a href={pubmedUrl} target={externalTarget} rel="noopener noreferrer">
              <ExternalLink className="mr-1 h-3 w-3" />
              PubMed
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
