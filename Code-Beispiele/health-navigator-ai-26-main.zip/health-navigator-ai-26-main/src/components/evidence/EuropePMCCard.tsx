import { ExternalLink, Calendar, BookOpen, Globe } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface EuropePMCCardProps {
  title: string;
  authors?: string;
  journal?: string;
  year?: number;
  pmid?: string;
  pmcid?: string;
  doi?: string;
  abstract?: string;
  isOpenAccess?: boolean;
  citedByCount?: number;
}

export function EuropePMCCard({
  title,
  authors,
  journal,
  year,
  pmid,
  pmcid,
  doi,
  abstract,
  isOpenAccess,
  citedByCount,
}: EuropePMCCardProps) {
  const getUrl = () => {
    if (pmcid) return `https://europepmc.org/article/PMC/${pmcid}`;
    if (pmid) return `https://europepmc.org/article/MED/${pmid}`;
    if (doi) return `https://doi.org/${doi}`;
    return 'https://europepmc.org';
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-sm font-medium leading-tight line-clamp-2">
            {title}
          </CardTitle>
          {isOpenAccess && (
            <Badge className="shrink-0 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
              Open Access
            </Badge>
          )}
        </div>
        {authors && (
          <p className="text-xs text-muted-foreground line-clamp-1">
            {authors}
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {journal && (
            <span className="flex items-center gap-1">
              <BookOpen className="h-3 w-3" />
              {journal}
            </span>
          )}
          {year && (
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {year}
            </span>
          )}
          {citedByCount !== undefined && citedByCount > 0 && (
            <Badge variant="outline" className="text-xs">
              {citedByCount} Zitierungen
            </Badge>
          )}
        </div>

        {abstract && (
          <p className="text-xs text-muted-foreground line-clamp-3">
            {abstract}
          </p>
        )}

        <div className="flex flex-wrap items-center gap-2">
          {pmcid && (
            <Badge variant="secondary" className="text-xs">
              PMC{pmcid}
            </Badge>
          )}
          {pmid && (
            <Badge variant="secondary" className="text-xs">
              PMID: {pmid}
            </Badge>
          )}
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            asChild
          >
            <a href={getUrl()} target="_blank" rel="noopener noreferrer">
              <Globe className="mr-1 h-3 w-3" />
              Europe PMC
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
