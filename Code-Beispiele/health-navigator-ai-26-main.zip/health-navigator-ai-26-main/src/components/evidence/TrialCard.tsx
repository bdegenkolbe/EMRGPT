import { ExternalLink, Users, MapPin, Calendar, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface TrialCardProps {
  title: string;
  nctId: string;
  status: string;
  phase?: string;
  conditions?: string[];
  interventions?: string[];
  locations?: string[];
  startDate?: string;
  enrollment?: number;
}

const statusColors: Record<string, string> = {
  'Recruiting': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100',
  'Active, not recruiting': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100',
  'Completed': 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100',
  'Terminated': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100',
  'Withdrawn': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-100',
};

export function TrialCard({
  title,
  nctId,
  status,
  phase,
  conditions,
  interventions,
  locations,
  startDate,
  enrollment,
}: TrialCardProps) {
  const trialUrl = `https://clinicaltrials.gov/study/${nctId}`;

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-sm font-medium leading-tight line-clamp-2">
            {title}
          </CardTitle>
          <Badge className={statusColors[status] || 'bg-secondary'}>
            {status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {phase && (
            <Badge variant="outline" className="text-xs">
              {phase}
            </Badge>
          )}
          {startDate && (
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {startDate}
            </span>
          )}
          {enrollment && (
            <span className="flex items-center gap-1">
              <Users className="h-3 w-3" />
              {enrollment} Teilnehmer
            </span>
          )}
        </div>

        {conditions && conditions.length > 0 && (
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground flex items-center gap-1">
              <Activity className="h-3 w-3" />
              Erkrankungen
            </p>
            <div className="flex flex-wrap gap-1">
              {conditions.slice(0, 3).map((condition, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  {condition}
                </Badge>
              ))}
              {conditions.length > 3 && (
                <Badge variant="secondary" className="text-xs">
                  +{conditions.length - 3}
                </Badge>
              )}
            </div>
          </div>
        )}

        {locations && locations.length > 0 && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" />
            <span className="line-clamp-1">
              {locations.slice(0, 2).join(', ')}
              {locations.length > 2 && ` +${locations.length - 2}`}
            </span>
          </div>
        )}

        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {nctId}
          </Badge>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            asChild
          >
            <a href={trialUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="mr-1 h-3 w-3" />
              ClinicalTrials.gov
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
