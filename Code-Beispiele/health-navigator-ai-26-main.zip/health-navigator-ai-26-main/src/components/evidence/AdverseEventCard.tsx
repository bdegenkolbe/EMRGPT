import { ExternalLink, AlertTriangle, Calendar, User, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface AdverseEventCardProps {
  safetyReportId: string;
  receiveDate?: string;
  serious?: boolean;
  seriousnessReason?: string;
  reactions?: string[];
  patientAge?: string;
  patientSex?: string;
  drugName?: string;
}

export function AdverseEventCard({
  safetyReportId,
  receiveDate,
  serious,
  seriousnessReason,
  reactions = [],
  patientAge,
  patientSex,
  drugName,
}: AdverseEventCardProps) {
  const fdaUrl = `https://www.fda.gov/safety/medwatch-fda-safety-information-and-adverse-event-reporting-program`;

  const sexLabel = patientSex === '1' ? 'Männlich' : patientSex === '2' ? 'Weiblich' : undefined;

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-sm font-medium leading-tight line-clamp-2">
            {drugName || 'Unbekanntes Medikament'}
          </CardTitle>
          {serious && (
            <Badge variant="destructive" className="shrink-0 flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" />
              Schwerwiegend
            </Badge>
          )}
        </div>
        {seriousnessReason && (
          <p className="text-xs text-muted-foreground">
            {seriousnessReason}
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {receiveDate && (
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {receiveDate.slice(0, 4)}-{receiveDate.slice(4, 6)}-{receiveDate.slice(6, 8)}
            </span>
          )}
          {(patientAge || sexLabel) && (
            <span className="flex items-center gap-1">
              <User className="h-3 w-3" />
              {patientAge && `${patientAge} Jahre`}
              {patientAge && sexLabel && ', '}
              {sexLabel}
            </span>
          )}
        </div>

        {reactions.length > 0 && (
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground flex items-center gap-1">
              <Activity className="h-3 w-3" />
              Gemeldete Reaktionen
            </p>
            <div className="flex flex-wrap gap-1">
              {reactions.slice(0, 5).map((reaction, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  {reaction}
                </Badge>
              ))}
              {reactions.length > 5 && (
                <Badge variant="secondary" className="text-xs">
                  +{reactions.length - 5}
                </Badge>
              )}
            </div>
          </div>
        )}

        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            ID: {safetyReportId}
          </Badge>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            asChild
          >
            <a href={fdaUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="mr-1 h-3 w-3" />
              FDA MedWatch
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
