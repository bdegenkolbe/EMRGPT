import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Loader2, RefreshCw, BookOpen, FlaskConical, AlertTriangle, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PubMedCard } from './PubMedCard';
import { TrialCard } from './TrialCard';
import { AdverseEventCard } from './AdverseEventCard';
import { EuropePMCCard } from './EuropePMCCard';
import { EvidenceSummary } from './EvidenceSummary';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface EvidenceItem {
  id: string;
  source: string;
  external_id: string;
  title: string;
  year?: number;
  venue?: string;
  url?: string;
  snippet?: string;
  study_type?: string;
  relevance_score?: number;
  provenance?: Record<string, unknown>;
}

interface AdverseEvent {
  safetyReportId: string;
  receiveDate?: string;
  serious?: boolean;
  seriousnessReason?: string;
  reactions: string[];
  patientAge?: string;
  patientSex?: string;
  drugName?: string;
}

interface EuropePMCArticle {
  id: string;
  title: string;
  authors?: string;
  journal?: string;
  year?: number;
  pmid?: string;
  pmcid?: string;
  doi?: string;
  abstract?: string;
  isOpenAccess?: boolean;
  citedByCount?: number;
}

interface EvidencePanelProps {
  sessionId: string;
  observations?: Array<{
    hpo_codes?: string[];
    mesh_terms?: string[];
    normalized_value?: string;
  }>;
}

export function EvidencePanel({ sessionId, observations = [] }: EvidencePanelProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [evidenceItems, setEvidenceItems] = useState<EvidenceItem[]>([]);
  const [adverseEvents, setAdverseEvents] = useState<AdverseEvent[]>([]);
  const [europePMCArticles, setEuropePMCArticles] = useState<EuropePMCArticle[]>([]);
  const [summary, setSummary] = useState<string>('');
  const [queryTerms, setQueryTerms] = useState<string[]>([]);
  const [searchDate, setSearchDate] = useState<string>('');

  const pubmedItems = evidenceItems.filter(item => item.source === 'pubmed');
  const trialItems = evidenceItems.filter(item => item.source === 'clinicaltrials');

  // Extract search terms from observations
  const getSearchTerms = () => {
    const terms: string[] = [];
    observations.forEach(obs => {
      if (obs.normalized_value) {
        terms.push(obs.normalized_value);
      }
      if (obs.mesh_terms) {
        terms.push(...obs.mesh_terms);
      }
    });
    return [...new Set(terms)].slice(0, 3); // Max 3 unique terms
  };

  const fetchOpenFDA = async (searchTerms: string[]) => {
    if (searchTerms.length === 0) return;
    
    try {
      const query = searchTerms.join(' ');
      const { data, error } = await supabase.functions.invoke('evidence-openfda', {
        body: { 
          action: 'events',
          query,
          limit: 10
        },
      });

      if (error) {
        console.error('OpenFDA error:', error);
        return;
      }

      if (data?.events) {
        setAdverseEvents(data.events);
      }
    } catch (error) {
      console.error('OpenFDA fetch error:', error);
    }
  };

  const fetchEuropePMC = async (searchTerms: string[]) => {
    if (searchTerms.length === 0) return;
    
    try {
      const query = searchTerms.join(' AND ');
      const { data, error } = await supabase.functions.invoke('evidence-europepmc', {
        body: { 
          action: 'search',
          query,
          pageSize: 10,
          openAccess: true
        },
      });

      if (error) {
        console.error('Europe PMC error:', error);
        return;
      }

      if (data?.results) {
        const articles: EuropePMCArticle[] = data.results.map((r: Record<string, unknown>) => ({
          id: r.id as string,
          title: r.title as string,
          authors: r.authorString as string,
          journal: r.journalTitle as string,
          year: r.pubYear ? parseInt(r.pubYear as string) : undefined,
          pmid: r.pmid as string,
          pmcid: r.pmcid as string,
          doi: r.doi as string,
          abstract: r.abstractText as string,
          isOpenAccess: r.isOpenAccess === 'Y',
          citedByCount: r.citedByCount as number,
        }));
        setEuropePMCArticles(articles);
      }
    } catch (error) {
      console.error('Europe PMC fetch error:', error);
    }
  };

  const fetchEvidence = async () => {
    setIsLoading(true);
    try {
      const searchTerms = getSearchTerms();
      
      // Fetch from all sources in parallel
      const [aggregateResult] = await Promise.all([
        supabase.functions.invoke('evidence-aggregate', {
          body: { sessionId },
        }),
        fetchOpenFDA(searchTerms),
        fetchEuropePMC(searchTerms),
      ]);

      if (aggregateResult.error) throw aggregateResult.error;

      const data = aggregateResult.data;
      if (data.items) {
        setEvidenceItems(data.items);
      }
      if (data.summary) {
        setSummary(data.summary);
      }
      if (data.queryTerms) {
        setQueryTerms(data.queryTerms);
      }
      setSearchDate(new Date().toLocaleString('de-DE'));

      const totalCount = (data.items?.length || 0) + adverseEvents.length + europePMCArticles.length;
      toast({
        title: t('evidence.fetchSuccess'),
        description: t('evidence.fetchSuccessDescription', { count: totalCount }),
      });
    } catch (error) {
      console.error('Evidence fetch error:', error);
      toast({
        variant: 'destructive',
        title: t('evidence.fetchError'),
        description: t('evidence.fetchErrorDescription'),
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Load existing evidence on mount
  useEffect(() => {
    const loadExistingEvidence = async () => {
      try {
        const { data: requests } = await supabase
          .from('evidence_requests')
          .select('id, query_strings, sources, created_at')
          .eq('session_id', sessionId)
          .order('created_at', { ascending: false })
          .limit(1);

        if (requests && requests.length > 0) {
          const latestRequest = requests[0];
          setSearchDate(new Date(latestRequest.created_at).toLocaleString('de-DE'));
          
          const queryStrings = latestRequest.query_strings as { terms?: string[] };
          if (queryStrings?.terms) {
            setQueryTerms(queryStrings.terms);
          }

          const { data: items } = await supabase
            .from('evidence_items')
            .select('*')
            .eq('request_id', latestRequest.id);

          if (items) {
            setEvidenceItems(items as EvidenceItem[]);
          }
        }

        // Also load from openFDA and Europe PMC
        const searchTerms = getSearchTerms();
        if (searchTerms.length > 0) {
          await Promise.all([
            fetchOpenFDA(searchTerms),
            fetchEuropePMC(searchTerms),
          ]);
        }
      } catch (error) {
        console.error('Error loading evidence:', error);
      }
    };

    if (sessionId) {
      loadExistingEvidence();
    }
  }, [sessionId, observations]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold">{t('evidence.title')}</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={fetchEvidence}
          disabled={isLoading}
        >
          {isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="mr-2 h-4 w-4" />
          )}
          {t('evidence.refresh')}
        </Button>
      </div>

      <Tabs defaultValue="summary" className="flex-1 flex flex-col">
        <TabsList className="w-full justify-start rounded-none border-b px-4 flex-wrap h-auto py-1">
          <TabsTrigger value="summary" className="text-xs">
            {t('evidence.tabSummary')}
          </TabsTrigger>
          <TabsTrigger value="pubmed" className="flex items-center gap-1 text-xs">
            <BookOpen className="h-3 w-3" />
            PubMed ({pubmedItems.length})
          </TabsTrigger>
          <TabsTrigger value="europepmc" className="flex items-center gap-1 text-xs">
            <Globe className="h-3 w-3" />
            Europe PMC ({europePMCArticles.length})
          </TabsTrigger>
          <TabsTrigger value="trials" className="flex items-center gap-1 text-xs">
            <FlaskConical className="h-3 w-3" />
            Studien ({trialItems.length})
          </TabsTrigger>
          <TabsTrigger value="fda" className="flex items-center gap-1 text-xs">
            <AlertTriangle className="h-3 w-3" />
            FDA ({adverseEvents.length})
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1 p-4">
          <TabsContent value="summary" className="mt-0">
            {summary ? (
              <EvidenceSummary
                summary={summary}
                queryTerms={queryTerms}
                sources={['PubMed', 'Europe PMC', 'ClinicalTrials.gov', 'openFDA']}
                searchDate={searchDate}
                pmids={pubmedItems.map(item => item.external_id)}
              />
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <BookOpen className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>{t('evidence.noData')}</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-4"
                  onClick={fetchEvidence}
                  disabled={isLoading}
                >
                  {t('evidence.startSearch')}
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="pubmed" className="mt-0">
            {pubmedItems.length > 0 ? (
              <div className="grid gap-4">
                {pubmedItems.map((item) => (
                  <PubMedCard
                    key={item.id}
                    title={item.title}
                    journal={item.venue}
                    year={item.year}
                    pmid={item.external_id}
                    abstract={item.snippet}
                    studyType={item.study_type}
                    relevanceScore={item.relevance_score ?? undefined}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <p>{t('evidence.noPubMed')}</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="europepmc" className="mt-0">
            {europePMCArticles.length > 0 ? (
              <div className="grid gap-4">
                {europePMCArticles.map((article) => (
                  <EuropePMCCard
                    key={article.id}
                    title={article.title}
                    authors={article.authors}
                    journal={article.journal}
                    year={article.year}
                    pmid={article.pmid}
                    pmcid={article.pmcid}
                    doi={article.doi}
                    abstract={article.abstract}
                    isOpenAccess={article.isOpenAccess}
                    citedByCount={article.citedByCount}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Globe className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>Keine Europe PMC Artikel gefunden</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="trials" className="mt-0">
            {trialItems.length > 0 ? (
              <div className="grid gap-4">
                {trialItems.map((item) => {
                  const prov = item.provenance as Record<string, unknown> | undefined;
                  return (
                    <TrialCard
                      key={item.id}
                      title={item.title}
                      nctId={item.external_id}
                      status={(prov?.status as string) || 'Unknown'}
                      phase={prov?.phase as string}
                      conditions={prov?.conditions as string[]}
                      startDate={prov?.startDate as string}
                      enrollment={prov?.enrollment as number}
                    />
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <FlaskConical className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>{t('evidence.noTrials')}</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="fda" className="mt-0">
            {adverseEvents.length > 0 ? (
              <div className="grid gap-4">
                {adverseEvents.map((event, index) => (
                  <AdverseEventCard
                    key={event.safetyReportId || index}
                    safetyReportId={event.safetyReportId}
                    receiveDate={event.receiveDate}
                    serious={event.serious}
                    seriousnessReason={event.seriousnessReason}
                    reactions={event.reactions}
                    patientAge={event.patientAge}
                    patientSex={event.patientSex}
                    drugName={event.drugName}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <AlertTriangle className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>Keine FDA Nebenwirkungsmeldungen gefunden</p>
              </div>
            )}
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
