import { useState } from 'react';
import { Search, Loader2, FileText, BookOpen, Sparkles, ChevronDown, ChevronRight, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ChunkResult {
  chunk_id: string;
  section_title: string | null;
  content: string;
  page_number: number | null;
  similarity: number;
}

interface GroupedResult {
  guideline_id: string;
  guideline_title: string;
  chunks: ChunkResult[];
}

interface SearchResponse {
  success: boolean;
  results: any[];
  grouped: GroupedResult[];
  total_chunks: number;
  code_filter_applied: boolean;
  matching_guidelines: number | null;
}

export function GuidelineSearchTest() {
  const { toast } = useToast();
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<SearchResponse | null>(null);
  const [expandedGuidelines, setExpandedGuidelines] = useState<Set<string>>(new Set());

  const performSearch = async () => {
    if (!query.trim()) {
      toast({ variant: 'destructive', title: 'Bitte Suchanfrage eingeben' });
      return;
    }

    setIsSearching(true);
    setResults(null);

    try {
      const { data, error } = await supabase.functions.invoke('guidelines-search', {
        body: {
          query: query.trim(),
          match_count: 10,
          match_threshold: 0.3,
        },
      });

      if (error) throw error;

      setResults(data);
      
      // Auto-expand first result
      if (data?.grouped?.length > 0) {
        setExpandedGuidelines(new Set([data.grouped[0].guideline_id]));
      }
    } catch (err: any) {
      console.error('Search error:', err);
      toast({
        variant: 'destructive',
        title: 'Suchfehler',
        description: err.message || 'Die Suche konnte nicht durchgeführt werden.',
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !isSearching) {
      performSearch();
    }
  };

  const toggleGuideline = (id: string) => {
    setExpandedGuidelines(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const formatSimilarity = (sim: number) => {
    return `${Math.round(sim * 100)}%`;
  };

  const exampleQueries = [
    'Diagnostik bei Kopfschmerzen',
    'Therapie der arteriellen Hypertonie',
    'Differentialdiagnose Dyspnoe',
    'Behandlung von Diabetes Typ 2',
    'Antikoagulation bei Vorhofflimmern',
  ];

  return (
    <div className="space-y-6">
      {/* Search Input */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="h-5 w-5 text-primary" />
            RAG-Suche testen
          </CardTitle>
          <CardDescription>
            Testen Sie die semantische Suche über Ihre eingebetteten Leitlinien
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Medizinische Frage oder Symptom eingeben..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                className="pl-9"
                disabled={isSearching}
              />
            </div>
            <Button onClick={performSearch} disabled={isSearching || !query.trim()}>
              {isSearching ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                'Suchen'
              )}
            </Button>
          </div>

          {/* Example queries */}
          {!results && (
            <div className="flex flex-wrap gap-2">
              <span className="text-xs text-muted-foreground">Beispiele:</span>
              {exampleQueries.map((eq) => (
                <Button
                  key={eq}
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs"
                  onClick={() => setQuery(eq)}
                >
                  {eq}
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {isSearching && (
        <Card>
          <CardContent className="flex items-center justify-center py-12">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-3" />
              <p className="text-muted-foreground">Durchsuche Leitlinien...</p>
            </div>
          </CardContent>
        </Card>
      )}

      {results && (
        <div className="space-y-4">
          {/* Stats */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <FileText className="h-4 w-4" />
              {results.grouped.length} Leitlinien
            </span>
            <span>•</span>
            <span>{results.total_chunks} relevante Abschnitte</span>
          </div>

          {/* No results */}
          {results.grouped.length === 0 && (
            <Card>
              <CardContent className="py-8 text-center">
                <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                <h3 className="font-medium mb-1">Keine Ergebnisse</h3>
                <p className="text-sm text-muted-foreground">
                  Es wurden keine passenden Leitlinienabschnitte gefunden.
                  <br />
                  Versuchen Sie eine andere Formulierung oder prüfen Sie, ob Leitlinien eingebettet sind.
                </p>
              </CardContent>
            </Card>
          )}

          {/* Grouped results */}
          <ScrollArea className="h-[500px]">
            <div className="space-y-3 pr-4">
              {results.grouped.map((group) => (
                <Card key={group.guideline_id}>
                  <Collapsible
                    open={expandedGuidelines.has(group.guideline_id)}
                    onOpenChange={() => toggleGuideline(group.guideline_id)}
                  >
                    <CollapsibleTrigger asChild>
                      <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors pb-3">
                        <div className="flex items-center gap-2">
                          {expandedGuidelines.has(group.guideline_id) ? (
                            <ChevronDown className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-muted-foreground" />
                          )}
                          <BookOpen className="h-4 w-4 text-primary" />
                          <span className="font-medium flex-1">{group.guideline_title}</span>
                          <Badge variant="secondary">{group.chunks.length} Treffer</Badge>
                        </div>
                      </CardHeader>
                    </CollapsibleTrigger>

                    <CollapsibleContent>
                      <CardContent className="pt-0 space-y-3">
                        {group.chunks.map((chunk, idx) => (
                          <div
                            key={chunk.chunk_id}
                            className="p-3 rounded-lg border bg-muted/30"
                          >
                            <div className="flex items-center gap-2 mb-2 text-xs text-muted-foreground">
                              <Badge variant="outline" className="font-mono">
                                {formatSimilarity(chunk.similarity)} Match
                              </Badge>
                              {chunk.page_number && (
                                <span>Seite {chunk.page_number}</span>
                              )}
                              {chunk.section_title && (
                                <>
                                  <span>•</span>
                                  <span className="truncate">{chunk.section_title}</span>
                                </>
                              )}
                            </div>
                            <p className="text-sm leading-relaxed whitespace-pre-wrap">
                              {chunk.content.length > 500
                                ? `${chunk.content.slice(0, 500)}...`
                                : chunk.content}
                            </p>
                          </div>
                        ))}
                      </CardContent>
                    </CollapsibleContent>
                  </Collapsible>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}
