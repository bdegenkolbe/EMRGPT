import { useState, useCallback } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Loader2, Upload, CheckCircle, AlertCircle, Edit2, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { MultiPdfDropzone, FileWithMetadata, ExtractedMetadata } from './MultiPdfDropzone';
import { cn } from '@/lib/utils';

interface BatchUploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function BatchUploadDialog({ open, onOpenChange }: BatchUploadDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [files, setFiles] = useState<FileWithMetadata[]>([]);
  const [expandedFile, setExpandedFile] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({ current: 0, total: 0 });

  // Generate unique ID for files
  const generateId = () => Math.random().toString(36).substring(2, 11);

  // Handle new files added
  const handleFilesAdded = useCallback(async (newFiles: File[]) => {
    // Create file entries with pending status
    const fileEntries: FileWithMetadata[] = newFiles.map(file => ({
      id: generateId(),
      file,
      status: 'pending' as const,
      progress: 0,
    }));

    setFiles(prev => [...prev, ...fileEntries]);

    // Process each file for metadata extraction
    for (const entry of fileEntries) {
      await extractMetadata(entry);
    }
  }, []);

  // Extract metadata from a single file
  const extractMetadata = async (fileEntry: FileWithMetadata) => {
    setFiles(prev => prev.map(f => 
      f.id === fileEntry.id 
        ? { ...f, status: 'extracting' as const, progress: 10 }
        : f
    ));

    try {
      const file = fileEntry.file;

      // Check if it's a text file - handle locally
      if (file.type === 'text/plain' || file.name.endsWith('.txt') || file.name.endsWith('.md')) {
        setFiles(prev => prev.map(f => 
          f.id === fileEntry.id ? { ...f, progress: 50 } : f
        ));
        
        const text = await file.text();
        const metadata: ExtractedMetadata = {
          title: file.name.replace(/\.[^/.]+$/, ''),
          textContent: text,
        };

        setFiles(prev => prev.map(f => 
          f.id === fileEntry.id 
            ? { ...f, status: 'extracted' as const, progress: 100, metadata }
            : f
        ));
        return;
      }

      // For PDFs, call the parsing edge function
      setFiles(prev => prev.map(f => 
        f.id === fileEntry.id ? { ...f, progress: 20 } : f
      ));
      
      // Convert to base64
      const arrayBuffer = await file.arrayBuffer();
      const base64 = btoa(
        new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
      );
      
      setFiles(prev => prev.map(f => 
        f.id === fileEntry.id ? { ...f, progress: 40 } : f
      ));

      // Call parsing function
      const { data, error } = await supabase.functions.invoke('guidelines-parse', {
        body: {
          file_base64: base64,
          file_name: file.name,
          file_size: file.size,
        },
      });

      setFiles(prev => prev.map(f => 
        f.id === fileEntry.id ? { ...f, progress: 80 } : f
      ));

      if (error) throw error;

      const metadata: ExtractedMetadata = {
        title: data?.title || file.name.replace(/\.[^/.]+$/, ''),
        description: data?.description,
        source: data?.source,
        version: data?.version,
        validFrom: data?.validFrom,
        validUntil: data?.validUntil,
        pageCount: data?.pageCount,
        author: data?.author,
        keywords: data?.keywords,
        textContent: data?.textContent || '',
        // Medical codes from parsing
        icd10Codes: data?.icd10Codes || [],
        hpoCodes: data?.hpoCodes || [],
        snomedCodes: data?.snomedCodes || [],
      };

      setFiles(prev => prev.map(f => 
        f.id === fileEntry.id 
          ? { ...f, status: 'extracted' as const, progress: 100, metadata }
          : f
      ));

    } catch (err) {
      console.error('Extraction error:', err);
      setFiles(prev => prev.map(f => 
        f.id === fileEntry.id 
          ? { 
              ...f, 
              status: 'error' as const, 
              error: 'Metadaten-Extraktion fehlgeschlagen',
              metadata: {
                title: fileEntry.file.name.replace(/\.[^/.]+$/, ''),
                textContent: '',
              }
            }
          : f
      ));
    }
  };

  // Remove a file
  const handleFileRemove = useCallback((fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
    if (expandedFile === fileId) {
      setExpandedFile(null);
    }
  }, [expandedFile]);

  // Update metadata for a file
  const updateMetadata = useCallback((fileId: string, field: keyof ExtractedMetadata, value: string) => {
    setFiles(prev => prev.map(f => 
      f.id === fileId 
        ? { ...f, metadata: { ...f.metadata, [field]: value } }
        : f
    ));
  }, []);

  // Helper to validate and parse date strings
  const parseDate = (dateStr: string | undefined): string | null => {
    if (!dateStr || dateStr === 'Unbekannt' || dateStr.trim() === '') {
      return null;
    }
    // Check if it's already a valid ISO date (YYYY-MM-DD)
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      return dateStr;
    }
    // Handle YYYY-MM format by adding day
    if (/^\d{4}-\d{2}$/.test(dateStr)) {
      return `${dateStr}-01`;
    }
    // Handle YYYY format
    if (/^\d{4}$/.test(dateStr)) {
      return `${dateStr}-01-01`;
    }
    // Try to parse other formats
    const date = new Date(dateStr);
    if (!isNaN(date.getTime())) {
      return date.toISOString().split('T')[0];
    }
    return null;
  };

  // Upload all files
  const handleUploadAll = async () => {
    const readyFiles = files.filter(f => 
      (f.status === 'extracted' || f.status === 'error') && 
      f.metadata?.title && 
      f.metadata?.textContent
    );

    if (readyFiles.length === 0) {
      toast({
        variant: 'destructive',
        title: 'Keine Dateien bereit',
        description: 'Bitte warten Sie, bis die Metadaten-Analyse abgeschlossen ist.',
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress({ current: 0, total: readyFiles.length });

    let successCount = 0;
    let errorCount = 0;

    for (let i = 0; i < readyFiles.length; i++) {
      const fileEntry = readyFiles[i];
      setUploadProgress({ current: i + 1, total: readyFiles.length });

      try {
        // Create guideline record with validated dates and detected codes
        const { data: guideline, error: insertError } = await supabase
          .from('guidelines')
          .insert({
            title: fileEntry.metadata!.title!,
            description: fileEntry.metadata?.description || null,
            source: fileEntry.metadata?.source || null,
            version: fileEntry.metadata?.version || null,
            valid_from: parseDate(fileEntry.metadata?.validFrom),
            valid_until: parseDate(fileEntry.metadata?.validUntil),
            file_name: fileEntry.file.name,
            file_size: fileEntry.file.size,
            mime_type: fileEntry.file.type || 'application/pdf',
            detected_icd10_codes: fileEntry.metadata?.icd10Codes?.length ? fileEntry.metadata.icd10Codes : null,
            detected_hpo_codes: fileEntry.metadata?.hpoCodes?.length ? fileEntry.metadata.hpoCodes : null,
            detected_snomed_codes: fileEntry.metadata?.snomedCodes?.length ? fileEntry.metadata.snomedCodes : null,
          })
          .select()
          .single();

        if (insertError) throw insertError;

        // Trigger embedding
        await supabase.functions.invoke('guidelines-embed', {
          body: {
            guideline_id: guideline.id,
            content: fileEntry.metadata!.textContent!,
          },
        });

        successCount++;
      } catch (err) {
        console.error('Upload error for', fileEntry.file.name, err);
        errorCount++;
      }
    }

    setIsUploading(false);
    queryClient.invalidateQueries({ queryKey: ['guidelines'] });

    if (successCount > 0) {
      toast({
        title: 'Speichern abgeschlossen',
        description: `${successCount} Leitlinie${successCount !== 1 ? 'n' : ''} erfolgreich gespeichert.${errorCount > 0 ? ` ${errorCount} Fehler.` : ''}`,
      });
    }

    if (errorCount === 0) {
      onOpenChange(false);
      setFiles([]);
    }
  };

  const readyCount = files.filter(f => 
    (f.status === 'extracted' || f.status === 'error') && 
    f.metadata?.title && 
    f.metadata?.textContent
  ).length;

  const processingCount = files.filter(f => f.status === 'extracting' || f.status === 'pending').length;

  return (
    <Dialog open={open} onOpenChange={(value) => {
      if (!isUploading) {
        onOpenChange(value);
        if (!value) setFiles([]);
      }
    }}>
      <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Mehrere Leitlinien hochladen
          </DialogTitle>
          <DialogDescription>
            Ziehen Sie mehrere PDF-Dateien in die Dropzone. Metadaten werden automatisch per KI analysiert.
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden py-4">
          <MultiPdfDropzone
            files={files}
            onFilesAdded={handleFilesAdded}
            onFileRemove={handleFileRemove}
            isProcessing={isUploading}
          />

          {/* Editable metadata for each file */}
          {files.length > 0 && files.some(f => f.status === 'extracted' || f.status === 'error') && (
            <ScrollArea className="mt-4 max-h-[350px]">
              <div className="space-y-2 pr-4">
                {files.filter(f => f.status === 'extracted' || f.status === 'error').map((fileEntry) => (
                  <Collapsible 
                    key={fileEntry.id}
                    open={expandedFile === fileEntry.id}
                    onOpenChange={(isOpen) => setExpandedFile(isOpen ? fileEntry.id : null)}
                  >
                    <CollapsibleTrigger asChild>
                      <div 
                        className={cn(
                          "flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors hover:bg-muted/50",
                          expandedFile === fileEntry.id && "border-primary/30 bg-primary/5"
                        )}
                      >
                        <Edit2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">
                            {fileEntry.metadata?.title || fileEntry.file.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {fileEntry.metadata?.source || 'Quelle nicht erkannt'} 
                            {fileEntry.metadata?.version && ` • ${fileEntry.metadata.version}`}
                          </p>
                        </div>
                        <Badge variant="outline" className="text-xs flex-shrink-0">
                          Bearbeiten
                        </Badge>
                        {expandedFile === fileEntry.id 
                          ? <ChevronUp className="h-4 w-4 text-muted-foreground" />
                          : <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        }
                      </div>
                    </CollapsibleTrigger>
                    
                    <CollapsibleContent>
                      <div className="p-4 border border-t-0 rounded-b-lg bg-muted/20 space-y-3">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Titel *</Label>
                            <Input
                              value={fileEntry.metadata?.title || ''}
                              onChange={(e) => updateMetadata(fileEntry.id, 'title', e.target.value)}
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Quelle</Label>
                            <Input
                              value={fileEntry.metadata?.source || ''}
                              onChange={(e) => updateMetadata(fileEntry.id, 'source', e.target.value)}
                              placeholder="z.B. AWMF, DEGAM"
                              className="h-8 text-sm"
                            />
                          </div>
                        </div>
                        
                        <div className="grid gap-1.5">
                          <Label className="text-xs">Beschreibung</Label>
                          <Textarea
                            value={fileEntry.metadata?.description || ''}
                            onChange={(e) => updateMetadata(fileEntry.id, 'description', e.target.value)}
                            rows={2}
                            className="text-sm resize-none"
                          />
                        </div>
                        
                        <div className="grid grid-cols-3 gap-3">
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Version</Label>
                            <Input
                              value={fileEntry.metadata?.version || ''}
                              onChange={(e) => updateMetadata(fileEntry.id, 'version', e.target.value)}
                              placeholder="z.B. S3, 2023"
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Gültig ab</Label>
                            <Input
                              type="date"
                              value={fileEntry.metadata?.validFrom || ''}
                              onChange={(e) => updateMetadata(fileEntry.id, 'validFrom', e.target.value)}
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="grid gap-1.5">
                            <Label className="text-xs">Gültig bis</Label>
                            <Input
                              type="date"
                              value={fileEntry.metadata?.validUntil || ''}
                              onChange={(e) => updateMetadata(fileEntry.id, 'validUntil', e.target.value)}
                              className="h-8 text-sm"
                            />
                          </div>
                        </div>

                        {/* Extracted codes display */}
                        {((fileEntry.metadata?.icd10Codes?.length ?? 0) > 0 || 
                          (fileEntry.metadata?.hpoCodes?.length ?? 0) > 0 || 
                          (fileEntry.metadata?.snomedCodes?.length ?? 0) > 0) && (
                          <div className="p-3 rounded-lg bg-muted/50 space-y-2">
                            <p className="text-xs font-medium text-muted-foreground">Erkannte medizinische Codes:</p>
                            <div className="flex flex-wrap gap-1.5">
                              {fileEntry.metadata?.icd10Codes?.slice(0, 8).map((code) => (
                                <Badge key={code} variant="outline" className="text-xs bg-primary/10 text-primary border-primary/30">
                                  ICD-10: {code}
                                </Badge>
                              ))}
                              {(fileEntry.metadata?.icd10Codes?.length ?? 0) > 8 && (
                                <Badge variant="outline" className="text-xs">
                                  +{(fileEntry.metadata?.icd10Codes?.length ?? 0) - 8} weitere
                                </Badge>
                              )}
                              {fileEntry.metadata?.hpoCodes?.slice(0, 6).map((code) => (
                                <Badge key={code} variant="secondary" className="text-xs">
                                  HPO: {code}
                                </Badge>
                              ))}
                              {(fileEntry.metadata?.hpoCodes?.length ?? 0) > 6 && (
                                <Badge variant="outline" className="text-xs">
                                  +{(fileEntry.metadata?.hpoCodes?.length ?? 0) - 6} weitere
                                </Badge>
                              )}
                              {fileEntry.metadata?.snomedCodes?.slice(0, 6).map((code) => (
                                <Badge key={code} variant="outline" className="text-xs bg-accent text-accent-foreground border-accent">
                                  SNOMED: {code}
                                </Badge>
                              ))}
                              {(fileEntry.metadata?.snomedCodes?.length ?? 0) > 6 && (
                                <Badge variant="outline" className="text-xs">
                                  +{(fileEntry.metadata?.snomedCodes?.length ?? 0) - 6} weitere
                                </Badge>
                              )}
                            </div>
                          </div>
                        )}

                        {fileEntry.metadata?.textContent && (
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <CheckCircle className="h-3 w-3 text-primary" />
                            <span>
                              {fileEntry.metadata.textContent.split(/\s+/).length} Wörter extrahiert
                              {fileEntry.metadata.pageCount && ` • ${fileEntry.metadata.pageCount} Seiten`}
                            </span>
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
        
        {isUploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Hochladen...</span>
              <span>{uploadProgress.current} / {uploadProgress.total}</span>
            </div>
            <Progress value={(uploadProgress.current / uploadProgress.total) * 100} />
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={() => { onOpenChange(false); setFiles([]); }}
            disabled={isUploading}
          >
            Abbrechen
          </Button>
          <Button 
            onClick={handleUploadAll}
            disabled={isUploading || processingCount > 0 || readyCount === 0}
            className="gap-2"
          >
            {isUploading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Wird hochgeladen...
              </>
            ) : processingCount > 0 ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                {processingCount} wird analysiert...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4" />
                {readyCount} Leitlinie{readyCount !== 1 ? 'n' : ''} speichern
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
