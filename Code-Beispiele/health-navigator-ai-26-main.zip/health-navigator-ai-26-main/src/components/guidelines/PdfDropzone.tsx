import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, Upload, X, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface ExtractedMetadata {
  title?: string;
  description?: string;
  source?: string;
  version?: string;
  validFrom?: string;
  validUntil?: string;
  pageCount?: number;
  author?: string;
  keywords?: string[];
}

interface PdfDropzoneProps {
  onFileAccepted: (file: File) => void;
  onMetadataExtracted?: (metadata: ExtractedMetadata, textContent: string) => void;
  onExtractStart?: () => void;
  onExtractError?: (error: string) => void;
  isExtracting?: boolean;
  extractProgress?: number;
  className?: string;
}

export function PdfDropzone({
  onFileAccepted,
  onMetadataExtracted,
  onExtractStart,
  onExtractError,
  isExtracting = false,
  extractProgress = 0,
  className,
}: PdfDropzoneProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setSelectedFile(file);
      onFileAccepted(file);
    }
  }, [onFileAccepted]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
    },
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024, // 50MB
    onDragEnter: () => setDragActive(true),
    onDragLeave: () => setDragActive(false),
  });

  const removeFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedFile(null);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <Card
      {...getRootProps()}
      className={cn(
        "cursor-pointer transition-all duration-200 border-2 border-dashed",
        isDragActive || dragActive
          ? "border-primary bg-primary/5 scale-[1.02]"
          : "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/30",
        isExtracting && "pointer-events-none opacity-80",
        className
      )}
    >
      <CardContent className="p-8">
        <input {...getInputProps()} />
        
        {!selectedFile ? (
          <div className="flex flex-col items-center text-center gap-4">
            <div className={cn(
              "p-4 rounded-full transition-colors",
              isDragActive ? "bg-primary/20" : "bg-muted"
            )}>
              <Upload className={cn(
                "h-8 w-8 transition-colors",
                isDragActive ? "text-primary" : "text-muted-foreground"
              )} />
            </div>
            <div>
              <p className="font-medium text-lg">
                {isDragActive 
                  ? "PDF hier ablegen"
                  : "PDF-Datei hierher ziehen"
                }
              </p>
              <p className="text-muted-foreground text-sm mt-1">
                oder klicken zum Auswählen (max. 50 MB)
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <FileText className="h-4 w-4" />
              <span>PDF, TXT, MD werden unterstützt</span>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-4">
            <div className={cn(
              "p-3 rounded-lg",
              isExtracting ? "bg-primary/10" : "bg-muted"
            )}>
              <FileText className={cn(
                "h-8 w-8",
                isExtracting ? "text-primary" : "text-muted-foreground"
              )} />
            </div>
            
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{selectedFile.name}</p>
              <p className="text-sm text-muted-foreground">
                {formatFileSize(selectedFile.size)}
              </p>
              
              {isExtracting && (
                <div className="mt-2 space-y-1">
                  <div className="flex items-center gap-2 text-sm text-primary">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Metadaten werden extrahiert...</span>
                  </div>
                  <Progress value={extractProgress} className="h-1.5" />
                </div>
              )}
            </div>
            
            {!isExtracting && (
              <Button
                variant="ghost"
                size="icon"
                onClick={removeFile}
                className="flex-shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
