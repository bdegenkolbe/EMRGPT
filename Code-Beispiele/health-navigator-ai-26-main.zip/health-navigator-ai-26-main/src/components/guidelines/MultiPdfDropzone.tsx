import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, Upload, X, Loader2, CheckCircle, AlertCircle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

export interface ExtractedMetadata {
  title?: string;
  description?: string;
  source?: string;
  version?: string;
  validFrom?: string;
  validUntil?: string;
  pageCount?: number;
  author?: string;
  keywords?: string[];
  textContent?: string;
  // Medical codes detected in the document
  icd10Codes?: string[];
  hpoCodes?: string[];
  snomedCodes?: string[];
}

export interface FileWithMetadata {
  id: string;
  file: File;
  status: 'pending' | 'extracting' | 'extracted' | 'error';
  progress: number;
  metadata?: ExtractedMetadata;
  error?: string;
}

interface MultiPdfDropzoneProps {
  files: FileWithMetadata[];
  onFilesAdded: (newFiles: File[]) => void;
  onFileRemove: (fileId: string) => void;
  isProcessing?: boolean;
  className?: string;
}

export function MultiPdfDropzone({
  files,
  onFilesAdded,
  onFileRemove,
  isProcessing = false,
  className,
}: MultiPdfDropzoneProps) {
  const [dragActive, setDragActive] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onFilesAdded(acceptedFiles);
    }
  }, [onFilesAdded]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
    },
    maxSize: 50 * 1024 * 1024, // 50MB per file
    onDragEnter: () => setDragActive(true),
    onDragLeave: () => setDragActive(false),
    disabled: isProcessing,
  });

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getStatusIcon = (status: FileWithMetadata['status']) => {
    switch (status) {
      case 'extracting':
        return <Loader2 className="h-4 w-4 animate-spin text-primary" />;
      case 'extracted':
        return <CheckCircle className="h-4 w-4 text-primary" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-destructive" />;
      default:
        return <FileText className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: FileWithMetadata['status']) => {
    switch (status) {
      case 'extracting':
        return <Badge variant="secondary" className="text-xs">Analysiere...</Badge>;
      case 'extracted':
        return <Badge className="text-xs bg-primary/10 text-primary border-primary/20">Bereit</Badge>;
      case 'error':
        return <Badge variant="destructive" className="text-xs">Fehler</Badge>;
      default:
        return <Badge variant="outline" className="text-xs">Wartend</Badge>;
    }
  };

  const completedCount = files.filter(f => f.status === 'extracted').length;
  const processingCount = files.filter(f => f.status === 'extracting').length;

  return (
    <div className={cn("space-y-4", className)}>
      {/* Dropzone */}
      <Card
        {...getRootProps()}
        className={cn(
          "cursor-pointer transition-all duration-200 border-2 border-dashed",
          isDragActive || dragActive
            ? "border-primary bg-primary/5 scale-[1.01]"
            : "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/30",
          isProcessing && "pointer-events-none opacity-60"
        )}
      >
        <CardContent className="p-6">
          <input {...getInputProps()} />
          
          <div className="flex flex-col items-center text-center gap-3">
            <div className={cn(
              "p-3 rounded-full transition-colors",
              isDragActive ? "bg-primary/20" : "bg-muted"
            )}>
              <Upload className={cn(
                "h-6 w-6 transition-colors",
                isDragActive ? "text-primary" : "text-muted-foreground"
              )} />
            </div>
            <div>
              <p className="font-medium">
                {isDragActive 
                  ? "PDFs hier ablegen"
                  : "Mehrere PDF-Dateien hierher ziehen"
                }
              </p>
              <p className="text-muted-foreground text-sm mt-1">
                oder klicken zum Auswählen (max. 50 MB pro Datei)
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Sparkles className="h-4 w-4" />
              <span>Metadaten werden automatisch per KI extrahiert</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* File List */}
      {files.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="font-medium text-sm">
                  {files.length} Datei{files.length !== 1 && 'en'}
                </span>
                {processingCount > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    {processingCount} wird analysiert
                  </Badge>
                )}
                {completedCount > 0 && (
                  <Badge className="text-xs bg-primary/10 text-primary border-primary/20">
                    {completedCount} bereit
                  </Badge>
                )}
              </div>
            </div>

            <ScrollArea className="max-h-[300px]">
              <div className="space-y-2">
                {files.map((fileItem) => (
                  <div 
                    key={fileItem.id}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border transition-colors",
                      fileItem.status === 'extracted' && "border-primary/20 bg-primary/5",
                      fileItem.status === 'error' && "border-destructive/20 bg-destructive/5",
                      fileItem.status === 'extracting' && "border-primary/30",
                      fileItem.status === 'pending' && "border-muted"
                    )}
                  >
                    <div className="flex-shrink-0">
                      {getStatusIcon(fileItem.status)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">
                        {fileItem.metadata?.title || fileItem.file.name}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{formatFileSize(fileItem.file.size)}</span>
                        {fileItem.metadata?.source && (
                          <>
                            <span>•</span>
                            <span>{fileItem.metadata.source}</span>
                          </>
                        )}
                        {fileItem.metadata?.pageCount && (
                          <>
                            <span>•</span>
                            <span>{fileItem.metadata.pageCount} Seiten</span>
                          </>
                        )}
                        {/* Medical codes count */}
                        {(fileItem.metadata?.icd10Codes?.length || fileItem.metadata?.hpoCodes?.length || fileItem.metadata?.snomedCodes?.length) && (
                          <>
                            <span>•</span>
                            <span className="text-primary">
                              {(fileItem.metadata?.icd10Codes?.length || 0) + 
                               (fileItem.metadata?.hpoCodes?.length || 0) + 
                               (fileItem.metadata?.snomedCodes?.length || 0)} Codes
                            </span>
                          </>
                        )}
                      </div>
                      
                      {fileItem.status === 'extracting' && (
                        <Progress value={fileItem.progress} className="h-1 mt-2" />
                      )}
                      
                      {fileItem.error && (
                        <p className="text-xs text-destructive mt-1">{fileItem.error}</p>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {getStatusBadge(fileItem.status)}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={(e) => {
                          e.stopPropagation();
                          onFileRemove(fileItem.id);
                        }}
                        disabled={isProcessing && fileItem.status === 'extracting'}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
