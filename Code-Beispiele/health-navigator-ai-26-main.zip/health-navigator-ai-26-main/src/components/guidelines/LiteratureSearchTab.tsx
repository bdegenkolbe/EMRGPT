import { useState } from 'react';
import { 
  Search, 
  Loader2, 
  Globe, 
  ExternalLink, 
  MessageSquare, 
  Send,
  BookOpen,
  Sparkles,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface EuropePMCArticle {
  id: string;
  title: string;
  authors?: string;
  journal?: string;
  year?: number;
  pmid?: string;
  doi?: string;
  abstract?: string;
  isOpenAccess?: boolean;
  citedByCount?: number;
}

interface RAGResult {
  chunk_id: string;
  guideline_id: string;
  guideline_title: string;
  content: string;
  similarity: number;
}

interface AIResponse {
  answer: string;
  sources: {
    type: 'guideline' | 'literature';
    title: string;
    snippet?: string;
  }[];
}

export function LiteratureSearchTab() {
  const { toast } = useToast();
  
  // Literature search state
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [articles, setArticles] = useState<EuropePMCArticle[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  
  // AI Q&A state
  const [question, setQuestion] = useState('');
  const [isAskingAI, setIsAskingAI] = useState(false);
  const [aiResponse, setAiResponse] = useState<AIResponse | null>(null);
  const [expandedArticles, setExpandedArticles] = useState<Set<string>>(new Set());
  const [rateLimitError, setRateLimitError] = useState(false);

  const searchLiterature = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setHasSearched(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('evidence-europepmc', {
        body: { query: searchQuery.trim(), limit: 20 }
      });
      
      if (error) throw error;
      setArticles(data?.articles || []);
    } catch (err: any) {
      console.error('Search error:', err);
      toast({
        variant: 'destructive',
        title: 'Suchfehler',
        description: err.message || 'Die Literatursuche konnte nicht durchgeführt werden.'
      });
    } finally {
      setIsSearching(false);
    }
  };

  const askAI = async () => {
    if (!question.trim()) return;
    
    setIsAskingAI(true);
    setAiResponse(null);
    setRateLimitError(false);
    
    try {
      // First, search local guidelines (RAG)
      const { data: ragData } = await supabase.functions.invoke('guidelines-search', {
        body: { query: question.trim(), match_count: 5, match_threshold: 0.4 }
      });
      
      // Then search Europe PMC for external literature
      const { data: pmcData } = await supabase.functions.invoke('evidence-europepmc', {
        body: { query: question.trim(), limit: 5 }
      });
      
      // Build context from both sources
      const guidelineContext = ragData?.results?.map((r: RAGResult) => 
        `[Leitlinie: ${r.guideline_title}]\n${r.content}`
      ).join('\n\n') || '';
      
      const literatureContext = pmcData?.articles?.slice(0, 3).map((a: EuropePMCArticle) =>
        `[Artikel: ${a.title} (${a.year})]\n${a.abstract || 'Kein Abstract verfügbar'}`
      ).join('\n\n') || '';
      
      // Call AI to synthesize answer
      const { data: aiData, error: aiError } = await supabase.functions.invoke('ai-chat', {
        body: {
          messages: [
            {
              role: 'system',
              content: `Du bist ein medizinischer Assistent, der Fragen basierend auf Leitlinien und wissenschaftlicher Literatur beantwortet. 
Antworte präzise und evidenzbasiert. Zitiere deine Quellen.

VERFÜGBARE QUELLEN:

=== LEITLINIEN ===
${guidelineContext || 'Keine passenden Leitlinien gefunden.'}

=== WISSENSCHAFTLICHE LITERATUR ===
${literatureContext || 'Keine passende Literatur gefunden.'}`
            },
            {
              role: 'user',
              content: question.trim()
            }
          ],
          model: 'google/gemini-3-flash-preview'
        }
      });
      
      // Handle specific error codes
      if (aiError) {
        const errorMessage = aiError.message || '';
        const errorContext = aiError.context || {};
        const status = errorContext.status;
        
        if (status === 429 || errorMessage.includes('429') || errorMessage.includes('Rate limit')) {
          setRateLimitError(true);
          toast({
            variant: 'destructive',
            title: 'Anfragelimit erreicht',
            description: 'Zu viele Anfragen. Bitte warten Sie einen Moment und versuchen Sie es erneut.'
          });
          return;
        }
        
        if (status === 402 || errorMessage.includes('402') || errorMessage.includes('Payment required')) {
          toast({
            variant: 'destructive',
            title: 'Credits aufgebraucht',
            description: 'Die KI-Credits sind erschöpft. Bitte laden Sie Ihr Guthaben auf.'
          });
          return;
        }
        
        throw aiError;
      }
      
      // Also check for error in response data
      if (aiData?.error) {
        const errorMsg = typeof aiData.error === 'string' ? aiData.error : JSON.stringify(aiData.error);
        
        if (errorMsg.includes('429') || errorMsg.includes('Rate limit')) {
          setRateLimitError(true);
          toast({
            variant: 'destructive',
            title: 'Anfragelimit erreicht',
            description: 'Zu viele Anfragen. Bitte warten Sie einen Moment und versuchen Sie es erneut.'
          });
          return;
        }
        
        if (errorMsg.includes('402') || errorMsg.includes('Payment required')) {
          toast({
            variant: 'destructive',
            title: 'Credits aufgebraucht',
            description: 'Die KI-Credits sind erschöpft. Bitte laden Sie Ihr Guthaben auf.'
          });
          return;
        }
        
        throw new Error(errorMsg);
      }
      
      // Build response with sources
      const sources: AIResponse['sources'] = [];
      
      ragData?.results?.slice(0, 3).forEach((r: RAGResult) => {
        sources.push({
          type: 'guideline',
          title: r.guideline_title,
          snippet: r.content.slice(0, 150) + '...'
        });
      });
      
      pmcData?.articles?.slice(0, 3).forEach((a: EuropePMCArticle) => {
        sources.push({
          type: 'literature',
          title: `${a.title} (${a.year})`,
          snippet: a.abstract?.slice(0, 150) + '...'
        });
      });
      
      setAiResponse({
        answer: aiData?.content || aiData?.message || 'Keine Antwort erhalten.',
        sources
      });
      
    } catch (err: any) {
      console.error('AI error:', err);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: err.message || 'Die KI-Anfrage konnte nicht verarbeitet werden.'
      });
    } finally {
      setIsAskingAI(false);
    }
  };

  const toggleArticle = (id: string) => {
    setExpandedArticles(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const exampleQuestions = [
    'Welche Therapieoptionen gibt es bei Hypertonie?',
    'Wie wird Diabetes Typ 2 diagnostiziert?',
    'Was sind die Warnsignale bei Kopfschmerzen?',
  ];

  return (
    <Tabs defaultValue="ask" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="ask" className="gap-2">
          <MessageSquare className="h-4 w-4" />
          Fragen stellen
        </TabsTrigger>
        <TabsTrigger value="search" className="gap-2">
          <Globe className="h-4 w-4" />
          Literatursuche
        </TabsTrigger>
      </TabsList>

      {/* AI Q&A Tab */}
      <TabsContent value="ask" className="mt-6 space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Sparkles className="h-5 w-5 text-primary" />
              KI-Fragen zu Leitlinien & Literatur
            </CardTitle>
            <CardDescription>
              Stellen Sie Fragen – die KI durchsucht Ihre Leitlinien und externe Literatur
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Textarea
                placeholder="Ihre medizinische Frage..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                rows={3}
                disabled={isAskingAI}
              />
              <div className="flex items-center justify-between">
                <div className="flex flex-wrap gap-2">
                  {exampleQuestions.map((eq) => (
                    <Button
                      key={eq}
                      variant="outline"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() => setQuestion(eq)}
                      disabled={isAskingAI}
                    >
                      {eq.slice(0, 30)}...
                    </Button>
                  ))}
                </div>
                <div className="flex gap-2">
                  {rateLimitError && (
                    <Button variant="outline" onClick={askAI} disabled={isAskingAI}>
                      <Loader2 className={`h-4 w-4 mr-2 ${isAskingAI ? 'animate-spin' : 'hidden'}`} />
                      Erneut versuchen
                    </Button>
                  )}
                  <Button onClick={askAI} disabled={isAskingAI || !question.trim()}>
                    {isAskingAI ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Send className="h-4 w-4 mr-2" />
                    )}
                    Fragen
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Response */}
        {isAskingAI && (
          <Card>
            <CardContent className="flex items-center justify-center py-12">
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-3" />
                <p className="text-muted-foreground">Durchsuche Leitlinien und Literatur...</p>
              </div>
            </CardContent>
          </Card>
        )}

        {aiResponse && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Antwort
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <p className="whitespace-pre-wrap">{aiResponse.answer}</p>
              </div>
              
              {aiResponse.sources.length > 0 && (
                <div className="pt-4 border-t">
                  <p className="text-sm font-medium mb-2">Quellen:</p>
                  <div className="space-y-2">
                    {aiResponse.sources.map((source, idx) => (
                      <div key={idx} className="p-2 rounded bg-muted/50 text-sm">
                        <div className="flex items-center gap-2">
                          {source.type === 'guideline' ? (
                            <BookOpen className="h-3 w-3 text-primary" />
                          ) : (
                            <Globe className="h-3 w-3 text-primary" />
                          )}
                          <span className="font-medium">{source.title}</span>
                        </div>
                        {source.snippet && (
                          <p className="text-xs text-muted-foreground mt-1">{source.snippet}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </TabsContent>

      {/* Literature Search Tab */}
      <TabsContent value="search" className="mt-6 space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Globe className="h-5 w-5 text-primary" />
              Europe PMC Literatursuche
            </CardTitle>
            <CardDescription>
              Durchsuchen Sie PubMed und europäische Literatur-Datenbanken
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Suchbegriff eingeben..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && searchLiterature()}
                  className="pl-9"
                  disabled={isSearching}
                />
              </div>
              <Button onClick={searchLiterature} disabled={isSearching || !searchQuery.trim()}>
                {isSearching ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  'Suchen'
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Search Results */}
        {isSearching && (
          <Card>
            <CardContent className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </CardContent>
          </Card>
        )}

        {hasSearched && !isSearching && (
          <div className="space-y-3">
            <div className="text-sm text-muted-foreground">
              {articles.length} Artikel gefunden
            </div>

            {articles.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  Keine Artikel gefunden
                </CardContent>
              </Card>
            ) : (
              <ScrollArea className="h-[500px]">
                <div className="space-y-3 pr-4">
                  {articles.map((article) => (
                    <Card key={article.id} className="hover:bg-muted/50 transition-colors">
                      <Collapsible
                        open={expandedArticles.has(article.id)}
                        onOpenChange={() => toggleArticle(article.id)}
                      >
                        <CollapsibleTrigger asChild>
                          <CardContent className="p-4 cursor-pointer">
                            <div className="flex items-start gap-2">
                              {expandedArticles.has(article.id) ? (
                                <ChevronDown className="h-4 w-4 mt-1 text-muted-foreground flex-shrink-0" />
                              ) : (
                                <ChevronRight className="h-4 w-4 mt-1 text-muted-foreground flex-shrink-0" />
                              )}
                              <div className="flex-1">
                                <h3 className="font-medium leading-tight">
                                  {article.title}
                                </h3>
                                <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground mt-1">
                                  {article.authors && <span>{article.authors}</span>}
                                  {article.journal && <span>• {article.journal}</span>}
                                  {article.year && <span>• {article.year}</span>}
                                </div>
                                <div className="flex items-center gap-2 mt-2">
                                  {article.isOpenAccess && (
                                    <Badge variant="secondary" className="text-xs">Open Access</Badge>
                                  )}
                                  {article.citedByCount && article.citedByCount > 0 && (
                                    <Badge variant="outline" className="text-xs">
                                      {article.citedByCount} Zitierungen
                                    </Badge>
                                  )}
                                  {article.pmid && (
                                    <Badge variant="outline" className="font-mono text-xs">
                                      PMID: {article.pmid}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              {article.pmid && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="flex-shrink-0"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    window.open(`https://pubmed.ncbi.nlm.nih.gov/${article.pmid}`, '_blank');
                                  }}
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          </CardContent>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          {article.abstract && (
                            <div className="px-4 pb-4 pt-0">
                              <div className="p-3 bg-muted/50 rounded-lg text-sm">
                                <p className="font-medium mb-1">Abstract:</p>
                                <p className="text-muted-foreground">{article.abstract}</p>
                              </div>
                            </div>
                          )}
                        </CollapsibleContent>
                      </Collapsible>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
        )}
      </TabsContent>
    </Tabs>
  );
}
