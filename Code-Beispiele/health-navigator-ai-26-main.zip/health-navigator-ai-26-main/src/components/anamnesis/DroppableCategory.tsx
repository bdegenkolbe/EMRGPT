import { useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { cn } from '@/lib/utils';

interface DroppableCategoryProps {
  categoryKey: string;
  items: string[];
  children: React.ReactNode;
  isOver?: boolean;
}

export function DroppableCategory({ 
  categoryKey, 
  items, 
  children,
}: DroppableCategoryProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: `category-${categoryKey}`,
    data: {
      type: 'category',
      categoryKey,
    },
  });

  return (
    <SortableContext
      id={categoryKey}
      items={items}
      strategy={verticalListSortingStrategy}
    >
      <div 
        ref={setNodeRef}
        className={cn(
          "space-y-2 min-h-[40px] rounded-md transition-colors",
          isOver && "bg-primary/10 ring-2 ring-primary/30 ring-dashed"
        )}
      >
        {children}
      </div>
    </SortableContext>
  );
}
