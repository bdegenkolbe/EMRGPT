import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import {
  BookOpen,
  Search,
  Loader2,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Sparkles,
  AlertCircle,
  Globe,
  Calendar,
  FileText,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface GuidelineSearchProps {
  hpoCodes?: string[];
  icd10Codes?: string[];
  snomedCodes?: string[];
  sessionContext?: string;
  onInsertRecommendation?: (text: string) => void;
}

interface SearchResult {
  chunk_id: string;
  guideline_id: string;
  guideline_title: string;
  section_title: string | null;
  content: string;
  page_number: number | null;
  similarity: number;
}

interface GroupedResult {
  guideline_id: string;
  guideline_title: string;
  chunks: {
    chunk_id: string;
    section_title: string | null;
    content: string;
    page_number: number | null;
    similarity: number;
  }[];
}

interface EuropePMCArticle {
  id: string;
  source: string;
  pmid: string | null;
  pmcid: string | null;
  doi: string | null;
  title: string;
  authors: string[];
  journal: string;
  year: number | null;
  abstract: string;
  isOpenAccess: boolean;
  citedByCount: number;
  fullTextUrl: string | null;
  europePmcUrl: string;
  meshTerms: string[];
  keywords: string[];
}
 
export function GuidelineSearch({ hpoCodes, icd10Codes, snomedCodes, sessionContext, onInsertRecommendation }: GuidelineSearchProps) {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedGuidelines, setExpandedGuidelines] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<'guidelines' | 'literature'>('guidelines');

  // Guidelines search mutation
  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      const { data, error } = await supabase.functions.invoke('guidelines-search', {
        body: {
          query,
          hpo_codes: hpoCodes,
          icd10_codes: icd10Codes,
          snomed_codes: snomedCodes,
          match_count: 10,
          match_threshold: 0.4,
        },
      });

      if (error) throw error;
      return data as { results: SearchResult[]; grouped: GroupedResult[]; total_chunks: number };
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Suche fehlgeschlagen',
        description: error.message,
      });
    },
  });

  // Europe PMC search mutation
  const europePmcMutation = useMutation({
    mutationFn: async (query: string) => {
      const { data, error } = await supabase.functions.invoke('evidence-europepmc', {
        body: {
          query,
          pageSize: 15,
          openAccess: false,
          sort: 'RELEVANCE',
        },
      });

      if (error) throw error;
      return data as { articles: EuropePMCArticle[]; totalCount: number; query: string };
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Europe PMC Suche fehlgeschlagen',
        description: error.message,
      });
    },
  });

  // Auto-search guidelines when codes change
  const autoSearchQuery = useQuery({
    queryKey: ['guideline-auto-search', hpoCodes, icd10Codes, snomedCodes],
    queryFn: async () => {
      if (!hpoCodes?.length) return null;
      
      const { data, error } = await supabase.functions.invoke('guidelines-search', {
        body: {
          query: sessionContext || 'Diagnostik und Therapieempfehlungen',
          hpo_codes: hpoCodes,
          icd10_codes: icd10Codes,
          snomed_codes: snomedCodes,
          match_count: 5,
          match_threshold: 0.5,
        },
      });

      if (error) throw error;
      return data as { results: SearchResult[]; grouped: GroupedResult[]; total_chunks: number };
    },
    enabled: (hpoCodes?.length ?? 0) > 0 || (icd10Codes?.length ?? 0) > 0 || (snomedCodes?.length ?? 0) > 0,
    staleTime: 5 * 60 * 1000,
  });

  // Auto-search Europe PMC when codes change
  const europePmcAutoQuery = useQuery({
    queryKey: ['europepmc-auto-search', hpoCodes, icd10Codes],
    queryFn: async () => {
      // Build query from codes
      const queryParts: string[] = [];
      if (hpoCodes?.length) {
        queryParts.push(`(${hpoCodes.slice(0, 3).join(' OR ')})`);
      }
      if (icd10Codes?.length) {
        queryParts.push(`(${icd10Codes.slice(0, 3).join(' OR ')})`);
      }
      if (sessionContext) {
        queryParts.push(sessionContext);
      }
      
      const query = queryParts.join(' AND ') || 'clinical guidelines';
      
      const { data, error } = await supabase.functions.invoke('evidence-europepmc', {
        body: {
          query,
          pageSize: 5,
          openAccess: false,
          sort: 'RELEVANCE',
        },
      });

      if (error) throw error;
      return data as { articles: EuropePMCArticle[]; totalCount: number; query: string };
    },
    enabled: (hpoCodes?.length ?? 0) > 0 || (icd10Codes?.length ?? 0) > 0,
    staleTime: 5 * 60 * 1000,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      if (activeTab === 'guidelines') {
        searchMutation.mutate(searchQuery);
      } else {
        europePmcMutation.mutate(searchQuery);
      }
    }
  };

  const toggleGuideline = (id: string) => {
    setExpandedGuidelines(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const insertText = (text: string) => {
    if (onInsertRecommendation) {
      onInsertRecommendation(text);
      toast({ title: 'Empfehlung eingefügt' });
    }
  };

  const hasAutoResults = autoSearchQuery.data?.total_chunks && autoSearchQuery.data.total_chunks > 0;
  const hasEuropePmcAutoResults = (europePmcAutoQuery.data?.articles?.length ?? 0) > 0;
  const searchResults = searchMutation.data?.grouped || [];
  const europePmcResults = europePmcMutation.data?.articles || [];
  const totalBadgeCount = (autoSearchQuery.data?.total_chunks || 0) + (europePmcAutoQuery.data?.articles?.length || 0);
 
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <BookOpen className="h-4 w-4" />
          Leitlinien
          {totalBadgeCount > 0 && (
            <Badge variant="secondary" className="ml-1">
              {totalBadgeCount}
            </Badge>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Leitlinien & Literatur
          </DialogTitle>
          <DialogDescription>
            Durchsuchen Sie interne Leitlinien und wissenschaftliche Literatur via Europe PMC
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'guidelines' | 'literature')} className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="guidelines" className="gap-2">
              <BookOpen className="h-4 w-4" />
              Leitlinien
              {hasAutoResults && <Badge variant="secondary" className="ml-1">{autoSearchQuery.data?.total_chunks}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="literature" className="gap-2">
              <Globe className="h-4 w-4" />
              Europe PMC
              {hasEuropePmcAutoResults && <Badge variant="secondary" className="ml-1">{europePmcAutoQuery.data?.articles?.length}</Badge>}
            </TabsTrigger>
          </TabsList>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={activeTab === 'guidelines' 
                  ? "z.B. Therapie bei akuten Bauchschmerzen..." 
                  : "z.B. diabetes mellitus treatment guidelines..."
                }
                className="pl-9"
              />
            </div>
            <Button 
              type="submit" 
              disabled={(activeTab === 'guidelines' ? searchMutation.isPending : europePmcMutation.isPending) || !searchQuery.trim()}
            >
              {(activeTab === 'guidelines' ? searchMutation.isPending : europePmcMutation.isPending) ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                'Suchen'
              )}
            </Button>
          </form>

          {/* Code Context Info */}
          {((hpoCodes?.length ?? 0) > 0 || (icd10Codes?.length ?? 0) > 0 || (snomedCodes?.length ?? 0) > 0) && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground flex-wrap">
              <Sparkles className="h-4 w-4" />
              <span>Filter aktiv:</span>
              {hpoCodes?.length ? <Badge variant="outline">{hpoCodes.length} HPO</Badge> : null}
              {icd10Codes?.length ? <Badge variant="outline">{icd10Codes.length} ICD-10</Badge> : null}
              {snomedCodes?.length ? <Badge variant="outline">{snomedCodes.length} SNOMED</Badge> : null}
            </div>
          )}

          {/* Guidelines Tab */}
          <TabsContent value="guidelines" className="mt-0">
            <ScrollArea className="h-[50vh]">
              {/* Auto-search results */}
              {hasAutoResults && !searchMutation.data && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Sparkles className="h-4 w-4 text-primary" />
                    Automatisch gefundene Empfehlungen
                  </div>
                  {autoSearchQuery.data?.grouped.map((group) => (
                    <GuidelineResultCard
                      key={group.guideline_id}
                      group={group}
                      expanded={expandedGuidelines.has(group.guideline_id)}
                      onToggle={() => toggleGuideline(group.guideline_id)}
                      onInsert={insertText}
                    />
                  ))}
                </div>
              )}

              {/* Manual search results */}
              {searchResults.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Search className="h-4 w-4" />
                    Suchergebnisse ({searchMutation.data?.total_chunks} Treffer)
                  </div>
                  {searchResults.map((group) => (
                    <GuidelineResultCard
                      key={group.guideline_id}
                      group={group}
                      expanded={expandedGuidelines.has(group.guideline_id)}
                      onToggle={() => toggleGuideline(group.guideline_id)}
                      onInsert={insertText}
                    />
                  ))}
                </div>
              )}

              {/* Empty state */}
              {!hasAutoResults && !searchMutation.data && !searchMutation.isPending && (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="font-medium">Keine Leitlinien gefunden</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Geben Sie einen Suchbegriff ein oder laden Sie Leitlinien im Admin-Bereich hoch.
                  </p>
                </div>
              )}

              {/* Search loading */}
              {searchMutation.isPending && (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              )}

              {/* Search error */}
              {searchMutation.isError && (
                <div className="flex items-center gap-2 p-4 text-destructive">
                  <AlertCircle className="h-5 w-5" />
                  <span>{searchMutation.error.message}</span>
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          {/* Europe PMC Tab */}
          <TabsContent value="literature" className="mt-0">
            <ScrollArea className="h-[50vh]">
              {/* Auto-search results */}
              {hasEuropePmcAutoResults && !europePmcMutation.data && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Sparkles className="h-4 w-4 text-primary" />
                    Relevante Literatur ({europePmcAutoQuery.data?.totalCount} Treffer)
                  </div>
                  <div className="grid gap-3">
                    {europePmcAutoQuery.data?.articles.map((article) => (
                      <EuropePMCArticleCard
                        key={article.id}
                        article={article}
                        onInsert={insertText}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Manual search results */}
              {europePmcResults.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Search className="h-4 w-4" />
                    Suchergebnisse ({europePmcMutation.data?.totalCount} Treffer)
                  </div>
                  <div className="grid gap-3">
                    {europePmcResults.map((article) => (
                      <EuropePMCArticleCard
                        key={article.id}
                        article={article}
                        onInsert={insertText}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Empty state */}
              {!hasEuropePmcAutoResults && !europePmcMutation.data && !europePmcMutation.isPending && (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Globe className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="font-medium">Keine Literatur gefunden</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Suchen Sie nach wissenschaftlichen Artikeln über Europe PMC.
                  </p>
                </div>
              )}

              {/* Search loading */}
              {europePmcMutation.isPending && (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              )}

              {/* Search error */}
              {europePmcMutation.isError && (
                <div className="flex items-center gap-2 p-4 text-destructive">
                  <AlertCircle className="h-5 w-5" />
                  <span>{europePmcMutation.error.message}</span>
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// Guideline Result Card
interface GuidelineResultCardProps {
  group: GroupedResult;
  expanded: boolean;
  onToggle: () => void;
  onInsert: (text: string) => void;
}

function GuidelineResultCard({ group, expanded, onToggle, onInsert }: GuidelineResultCardProps) {
  return (
    <Card>
      <Collapsible open={expanded}>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors py-3" onClick={onToggle}>
            <div className="flex items-center gap-2">
              {expanded ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
              <CardTitle className="text-base">{group.guideline_title}</CardTitle>
              <Badge variant="secondary">{group.chunks.length} Abschnitte</Badge>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="pt-0 space-y-3">
            {group.chunks.map((chunk) => (
              <div key={chunk.chunk_id} className="border rounded-lg p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    {chunk.section_title && (
                      <p className="text-sm font-medium">{chunk.section_title}</p>
                    )}
                    <Badge variant="outline" className="text-xs">
                      {Math.round(chunk.similarity * 100)}% Relevanz
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onInsert(chunk.content)}
                    title="In Notizen einfügen"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-4">
                  {chunk.content}
                </p>
              </div>
            ))}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}

// Europe PMC Article Card
interface EuropePMCArticleCardProps {
  article: EuropePMCArticle;
  onInsert: (text: string) => void;
}

function EuropePMCArticleCard({ article, onInsert }: EuropePMCArticleCardProps) {
  const getUrl = () => {
    if (article.pmcid) return `https://europepmc.org/article/PMC/${article.pmcid}`;
    if (article.pmid) return `https://europepmc.org/article/MED/${article.pmid}`;
    if (article.doi) return `https://doi.org/${article.doi}`;
    return article.europePmcUrl;
  };

  const handleInsert = () => {
    const citation = `${article.title}. ${article.authors.slice(0, 3).join(', ')}${article.authors.length > 3 ? ' et al.' : ''}. ${article.journal} (${article.year}). ${article.pmid ? `PMID: ${article.pmid}` : article.doi ? `DOI: ${article.doi}` : ''}`;
    onInsert(citation);
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-sm font-medium leading-tight line-clamp-2">
            {article.title}
          </CardTitle>
          {article.isOpenAccess && (
            <Badge variant="default" className="shrink-0">
              Open Access
            </Badge>
          )}
        </div>
        {article.authors.length > 0 && (
          <p className="text-xs text-muted-foreground line-clamp-1">
            {article.authors.slice(0, 3).join(', ')}{article.authors.length > 3 ? ' et al.' : ''}
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {article.journal && (
            <span className="flex items-center gap-1">
              <FileText className="h-3 w-3" />
              {article.journal}
            </span>
          )}
          {article.year && (
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {article.year}
            </span>
          )}
          {article.citedByCount > 0 && (
            <Badge variant="outline" className="text-xs">
              {article.citedByCount} Zitierungen
            </Badge>
          )}
        </div>

        {article.abstract && (
          <p className="text-xs text-muted-foreground line-clamp-3">
            {article.abstract}
          </p>
        )}

        <div className="flex flex-wrap items-center gap-2">
          {article.pmcid && (
            <Badge variant="secondary" className="text-xs">
              PMC{article.pmcid}
            </Badge>
          )}
          {article.pmid && (
            <Badge variant="secondary" className="text-xs">
              PMID: {article.pmid}
            </Badge>
          )}
          <div className="flex-1" />
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            onClick={handleInsert}
            title="Zitat einfügen"
          >
            <ExternalLink className="mr-1 h-3 w-3" />
            Einfügen
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            asChild
          >
            <a href={getUrl()} target="_blank" rel="noopener noreferrer">
              <Globe className="mr-1 h-3 w-3" />
              Europe PMC
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}