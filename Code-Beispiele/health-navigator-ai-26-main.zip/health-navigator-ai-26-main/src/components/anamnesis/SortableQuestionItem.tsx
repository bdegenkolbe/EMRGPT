import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Pencil, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface QuestionItem {
  question?: string;
  text?: string;
  followUp?: string[];
  options?: string[];
  type?: string;
}

interface SortableQuestionItemProps {
  id: string;
  question: QuestionItem;
  index: number;
  isGerman: boolean;
  editable: boolean;
  isEditing: boolean;
  editValue: string;
  onEditValueChange: (value: string) => void;
  onStartEdit: () => void;
  onSaveEdit: () => void;
  onCancelEdit: () => void;
  onDelete: () => void;
}

export function SortableQuestionItem({
  id,
  question,
  index,
  isGerman,
  editable,
  isEditing,
  editValue,
  onEditValueChange,
  onStartEdit,
  onSaveEdit,
  onCancelEdit,
  onDelete,
}: SortableQuestionItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const questionText = question.question || question.text || '';

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "bg-background rounded-md p-3 border border-border/50 transition-colors group",
        isDragging && "opacity-50 shadow-lg ring-2 ring-primary",
        isEditing ? "ring-2 ring-primary" : "hover:border-border"
      )}
    >
      <div className="flex items-start gap-2">
        {/* Drag handle */}
        {editable && !isEditing && (
          <button
            {...attributes}
            {...listeners}
            className="mt-0.5 cursor-grab active:cursor-grabbing touch-none text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
            aria-label={isGerman ? 'Ziehen zum Sortieren' : 'Drag to reorder'}
          >
            <GripVertical className="h-4 w-4" />
          </button>
        )}
        
        <span className="text-xs font-mono text-muted-foreground mt-0.5">
          {index + 1}.
        </span>
        
        <div className="flex-1 space-y-2">
          {isEditing ? (
            <div className="space-y-2">
              <Textarea
                value={editValue}
                onChange={(e) => onEditValueChange(e.target.value)}
                className="text-sm min-h-[60px]"
                autoFocus
                placeholder={isGerman ? 'Frage eingeben...' : 'Enter question...'}
              />
              <div className="flex items-center gap-1">
                <Button
                  size="sm"
                  variant="default"
                  onClick={onSaveEdit}
                  className="gap-1 h-7"
                >
                  {isGerman ? 'OK' : 'OK'}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={onCancelEdit}
                  className="gap-1 h-7"
                >
                  {isGerman ? 'Abbrechen' : 'Cancel'}
                </Button>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm flex-1">
                  {questionText || '-'}
                </p>
                
                {/* Edit/Delete buttons */}
                {editable && (
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6"
                          onClick={(e) => {
                            e.stopPropagation();
                            onStartEdit();
                          }}
                        >
                          <Pencil className="h-3 w-3" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        {isGerman ? 'Bearbeiten' : 'Edit'}
                      </TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6 text-destructive hover:text-destructive"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDelete();
                          }}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        {isGerman ? 'Löschen' : 'Delete'}
                      </TooltipContent>
                    </Tooltip>
                  </div>
                )}
              </div>
              
              {/* Options if present */}
              {question.options && question.options.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {question.options.map((opt, optIdx) => (
                    <Badge key={optIdx} variant="outline" className="text-xs">
                      {opt}
                    </Badge>
                  ))}
                </div>
              )}
              
              {/* Follow-up questions if present */}
              {question.followUp && question.followUp.length > 0 && (
                <div className="ml-4 space-y-1 border-l border-dashed border-muted-foreground/30 pl-3">
                  <p className="text-xs text-muted-foreground font-medium">
                    {isGerman ? 'Nachfragen:' : 'Follow-up:'}
                  </p>
                  {question.followUp.map((fu, fuIdx) => (
                    <p key={fuIdx} className="text-xs text-muted-foreground">
                      • {fu}
                    </p>
                  ))}
                </div>
              )}
              
              {/* Question type badge */}
              {question.type && (
                <Badge variant="secondary" className="text-[10px]">
                  {question.type}
                </Badge>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
