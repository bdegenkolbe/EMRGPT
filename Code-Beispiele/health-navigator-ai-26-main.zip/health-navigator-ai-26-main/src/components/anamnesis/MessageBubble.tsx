import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { VoiceOutput } from './VoiceOutput';
import { AlertTriangle, Brain, Stethoscope, FileCode2, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface OntologyCodeEntry {
  code: string;
  label?: string;
  confidence?: number;
}

interface OntologyCodes {
  hpo?: OntologyCodeEntry[];
  snomed?: OntologyCodeEntry[];
  icd10?: OntologyCodeEntry[];
  rxnorm?: OntologyCodeEntry[];
  mesh?: OntologyCodeEntry[];
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  isRedFlag?: boolean;
  ontologyCodes?: OntologyCodes;
}

interface MessageBubbleProps {
  message: Message;
  language?: string;
}

function OntologyBadge({ 
  code, 
  label, 
  confidence, 
  type,
  onClick,
}: OntologyCodeEntry & { 
  type: 'hpo' | 'snomed' | 'icd10' | 'rxnorm' | 'mesh';
  onClick?: () => void;
}) {
  const typeConfig = {
    hpo: { 
      label: 'HPO', 
      icon: Brain, 
      className: 'bg-violet-100 text-violet-800 border-violet-200 dark:bg-violet-900/30 dark:text-violet-300 dark:border-violet-800',
      clickable: true,
    },
    snomed: { 
      label: 'SNOMED', 
      icon: Stethoscope, 
      className: 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800',
      clickable: true,
    },
    icd10: { 
      label: 'ICD-10', 
      icon: FileCode2, 
      className: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-800',
      clickable: true,
    },
    rxnorm: { 
      label: 'RxNorm', 
      icon: FileCode2, 
      className: 'bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-800',
      clickable: false,
    },
    mesh: { 
      label: 'MeSH', 
      icon: FileCode2, 
      className: 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800',
      clickable: false,
    },
  };

  const config = typeConfig[type];
  const Icon = config.icon;
  const isClickable = config.clickable && onClick;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge 
          variant="outline" 
          className={cn(
            'text-[10px] font-mono transition-all group',
            config.className,
            isClickable 
              ? 'cursor-pointer hover:scale-105 hover:ring-1 hover:ring-primary/50' 
              : 'cursor-help'
          )}
          onClick={isClickable ? onClick : undefined}
        >
          <Icon className="h-2.5 w-2.5 mr-1" />
          {code}
          {confidence !== undefined && confidence < 1 && (
            <span className="ml-1 opacity-60">{Math.round(confidence * 100)}%</span>
          )}
          {isClickable && (
            <ExternalLink className="h-2 w-2 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
          )}
        </Badge>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs">
        <div className="space-y-1">
          <div className="font-semibold text-xs">{config.label}: {code}</div>
          {label && <div className="text-xs text-muted-foreground">{label}</div>}
          {confidence !== undefined && (
            <div className="text-xs text-muted-foreground">
              Konfidenz: {Math.round(confidence * 100)}%
            </div>
          )}
          {isClickable && (
            <div className="text-xs text-primary mt-1">
              Klicken zum Öffnen im {config.label}-Browser
            </div>
          )}
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

function OntologyCodesDisplay({ codes }: { codes: OntologyCodes }) {
  const navigate = useNavigate();
  
  const hasAny = codes.hpo?.length || codes.snomed?.length || codes.icd10?.length || 
                 codes.rxnorm?.length || codes.mesh?.length;
  
  if (!hasAny) return null;

  const navigateToHpo = (code: string) => {
    navigate(`/ontology?tab=hpo&search=${encodeURIComponent(code)}`);
  };

  const navigateToSnomed = (code: string) => {
    navigate(`/ontology?tab=snomed&search=${encodeURIComponent(code)}`);
  };

  const navigateToIcd10 = (code: string) => {
    navigate(`/ontology?tab=icd10&search=${encodeURIComponent(code)}`);
  };

  return (
    <div className="flex flex-wrap gap-1 mt-2 pt-2 border-t border-primary-foreground/10">
      {codes.hpo?.map((entry, i) => (
        <OntologyBadge 
          key={`hpo-${i}`} 
          {...entry} 
          type="hpo" 
          onClick={() => navigateToHpo(entry.code)}
        />
      ))}
      {codes.snomed?.map((entry, i) => (
        <OntologyBadge 
          key={`snomed-${i}`} 
          {...entry} 
          type="snomed" 
          onClick={() => navigateToSnomed(entry.code)}
        />
      ))}
      {codes.icd10?.map((entry, i) => (
        <OntologyBadge 
          key={`icd10-${i}`} 
          {...entry} 
          type="icd10" 
          onClick={() => navigateToIcd10(entry.code)}
        />
      ))}
      {codes.rxnorm?.map((entry, i) => (
        <OntologyBadge key={`rxnorm-${i}`} {...entry} type="rxnorm" />
      ))}
      {codes.mesh?.map((entry, i) => (
        <OntologyBadge key={`mesh-${i}`} {...entry} type="mesh" />
      ))}
    </div>
  );
}

export function MessageBubble({ message, language = 'de-DE' }: MessageBubbleProps) {
  const isUser = message.role === 'user';
  const isSystem = message.role === 'system';

  if (isSystem) {
    return (
      <div className="flex justify-center my-2">
        <div className="rounded-full bg-muted px-4 py-1 text-xs text-muted-foreground">
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'flex gap-2 my-3',
        isUser ? 'justify-end' : 'justify-start'
      )}
    >
      <div
        className={cn(
          'max-w-[80%] rounded-2xl px-4 py-3',
          isUser
            ? 'bg-primary text-primary-foreground rounded-br-md'
            : 'bg-muted rounded-bl-md',
          message.isRedFlag && !isUser && 'border-2 border-destructive bg-destructive/10'
        )}
      >
        {message.isRedFlag && !isUser && (
          <div className="flex items-center gap-2 text-destructive mb-2">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase">Wichtiger Hinweis</span>
          </div>
        )}
        
        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
        
        {/* Display ontology codes for user messages */}
        {isUser && message.ontologyCodes && (
          <OntologyCodesDisplay codes={message.ontologyCodes} />
        )}
        
        <div className="flex items-center justify-between mt-1">
          <span className={cn(
            'text-xs',
            isUser ? 'text-primary-foreground/70' : 'text-muted-foreground'
          )}>
            {message.timestamp.toLocaleTimeString(language, { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </span>
          
          {!isUser && (
            <VoiceOutput text={message.content} language={language} />
          )}
        </div>
      </div>
    </div>
  );
}
