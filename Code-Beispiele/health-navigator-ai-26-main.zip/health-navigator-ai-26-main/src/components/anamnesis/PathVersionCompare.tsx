 import { useState } from 'react';
 import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
 import { Button } from '@/components/ui/button';
 import { Badge } from '@/components/ui/badge';
 import { Card, CardContent } from '@/components/ui/card';
 import { ScrollArea } from '@/components/ui/scroll-area';
 import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
 import { GitBranch, ArrowRight, Clock, Stethoscope, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
 import { MermaidDiagram } from './MermaidDiagram';
 import { format } from 'date-fns';
 import { de } from 'date-fns/locale';
 import { cn } from '@/lib/utils';
 
 interface DifferentialDiagnosis {
   name: string;
   probability: number;
   icd10?: string;
   reasoning: string;
 }
 
 interface PathVersion {
   id: string;
   version: number;
   hpo_codes: string[];
   differential_diagnoses: DifferentialDiagnosis[];
   mermaid_diagram: string | null;
   ai_reasoning: string | null;
   question_tree: Record<string, unknown>;
   created_at: string;
   updated_at: string;
 }
 
 interface PathVersionCompareProps {
   open: boolean;
   onOpenChange: (open: boolean) => void;
   versions: PathVersion[];
   hpoLabels: Record<string, { label_de: string; label_en: string }>;
 }
 
 export function PathVersionCompare({ open, onOpenChange, versions, hpoLabels }: PathVersionCompareProps) {
   const [leftIndex, setLeftIndex] = useState(0);
   const [rightIndex, setRightIndex] = useState(1);
 
   // Sort versions by version number descending
   const sortedVersions = [...versions].sort((a, b) => b.version - a.version);
   
   const leftVersion = sortedVersions[leftIndex];
   const rightVersion = sortedVersions[rightIndex];
 
   if (!leftVersion || versions.length < 2) {
     return (
       <Dialog open={open} onOpenChange={onOpenChange}>
         <DialogContent className="max-w-lg">
           <DialogHeader>
             <DialogTitle>Versionsvergleich</DialogTitle>
             <DialogDescription>
               Es sind mindestens 2 Versionen erforderlich, um einen Vergleich anzuzeigen.
             </DialogDescription>
           </DialogHeader>
         </DialogContent>
       </Dialog>
     );
   }
 
   const getHpoLabel = (code: string) => hpoLabels[code]?.label_de || code;
 
   // Compare differential diagnoses
   const compareDiagnoses = () => {
     const leftDiags = new Set(leftVersion.differential_diagnoses.map(d => d.name));
     const rightDiags = new Set(rightVersion?.differential_diagnoses.map(d => d.name) || []);
     
     const added = rightVersion?.differential_diagnoses.filter(d => !leftDiags.has(d.name)) || [];
     const removed = leftVersion.differential_diagnoses.filter(d => !rightDiags.has(d.name));
     const unchanged = leftVersion.differential_diagnoses.filter(d => rightDiags.has(d.name));
     
     return { added, removed, unchanged };
   };
 
   const diagComparison = rightVersion ? compareDiagnoses() : { added: [], removed: [], unchanged: [] };
 
   return (
     <Dialog open={open} onOpenChange={onOpenChange}>
       <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
         <DialogHeader>
           <DialogTitle className="flex items-center gap-2">
             <GitBranch className="h-5 w-5" />
             Versionsvergleich
           </DialogTitle>
           <DialogDescription>
             Vergleiche verschiedene Versionen des Anamnesepfads
           </DialogDescription>
         </DialogHeader>
         
         {/* Version Selectors */}
         <div className="flex items-center justify-center gap-4 py-2">
           <div className="flex items-center gap-2">
             <Button
               variant="ghost"
               size="icon"
               className="h-8 w-8"
               disabled={leftIndex >= sortedVersions.length - 1}
               onClick={() => setLeftIndex(i => Math.min(i + 1, sortedVersions.length - 1))}
             >
               <ChevronLeft className="h-4 w-4" />
             </Button>
             <Badge variant="outline" className="px-3 py-1">
               v{leftVersion.version}
               <span className="ml-2 text-xs text-muted-foreground">
                 {format(new Date(leftVersion.updated_at), 'dd.MM.yy HH:mm', { locale: de })}
               </span>
             </Badge>
             <Button
               variant="ghost"
               size="icon"
               className="h-8 w-8"
               disabled={leftIndex <= 0 || leftIndex - 1 === rightIndex}
               onClick={() => setLeftIndex(i => Math.max(i - 1, 0))}
             >
               <ChevronRight className="h-4 w-4" />
             </Button>
           </div>
           
           <ArrowRight className="h-5 w-5 text-muted-foreground" />
           
           <div className="flex items-center gap-2">
             <Button
               variant="ghost"
               size="icon"
               className="h-8 w-8"
               disabled={rightIndex >= sortedVersions.length - 1 || rightIndex + 1 === leftIndex}
               onClick={() => setRightIndex(i => Math.min(i + 1, sortedVersions.length - 1))}
             >
               <ChevronLeft className="h-4 w-4" />
             </Button>
             <Badge variant="secondary" className="px-3 py-1">
               v{rightVersion?.version || '-'}
               <span className="ml-2 text-xs text-muted-foreground">
                 {rightVersion ? format(new Date(rightVersion.updated_at), 'dd.MM.yy HH:mm', { locale: de }) : '-'}
               </span>
             </Badge>
             <Button
               variant="ghost"
               size="icon"
               className="h-8 w-8"
               disabled={rightIndex <= 0}
               onClick={() => setRightIndex(i => Math.max(i - 1, 0))}
             >
               <ChevronRight className="h-4 w-4" />
             </Button>
           </div>
         </div>
 
         <Tabs defaultValue="diagnoses" className="flex-1">
           <TabsList className="grid w-full grid-cols-3">
             <TabsTrigger value="diagnoses" className="gap-1">
               <Stethoscope className="h-3 w-3" />
               Diagnosen
             </TabsTrigger>
             <TabsTrigger value="diagram" className="gap-1">
               <GitBranch className="h-3 w-3" />
               Diagramm
             </TabsTrigger>
             <TabsTrigger value="reasoning" className="gap-1">
               <Sparkles className="h-3 w-3" />
               Begründung
             </TabsTrigger>
           </TabsList>
           
           {/* Diagnoses Comparison */}
           <TabsContent value="diagnoses" className="mt-4">
             <ScrollArea className="h-[400px]">
               <div className="space-y-4">
                 {/* Added diagnoses */}
                 {diagComparison.added.length > 0 && (
                   <div className="space-y-2">
                     <h4 className="text-sm font-medium text-primary flex items-center gap-1">
                       + Neu hinzugefügt ({diagComparison.added.length})
                     </h4>
                     <div className="grid gap-2 md:grid-cols-2">
                       {diagComparison.added.map((dd, idx) => (
                        <Card key={idx} className="bg-accent/50 border-primary/30">
                           <CardContent className="p-3">
                             <div className="flex items-start justify-between mb-1">
                               <span className="font-medium">{dd.name}</span>
                               <Badge variant="secondary">{Math.round(dd.probability * 100)}%</Badge>
                             </div>
                             {dd.icd10 && <span className="text-xs font-mono text-muted-foreground">ICD-10: {dd.icd10}</span>}
                             <p className="text-xs text-muted-foreground mt-1">{dd.reasoning}</p>
                           </CardContent>
                         </Card>
                       ))}
                     </div>
                   </div>
                 )}
                 
                 {/* Removed diagnoses */}
                 {diagComparison.removed.length > 0 && (
                   <div className="space-y-2">
                     <h4 className="text-sm font-medium text-destructive flex items-center gap-1">
                       − Entfernt ({diagComparison.removed.length})
                     </h4>
                     <div className="grid gap-2 md:grid-cols-2">
                       {diagComparison.removed.map((dd, idx) => (
                        <Card key={idx} className="bg-destructive/10 border-destructive/30 opacity-75">
                           <CardContent className="p-3">
                             <div className="flex items-start justify-between mb-1">
                               <span className="font-medium line-through">{dd.name}</span>
                               <Badge variant="outline">{Math.round(dd.probability * 100)}%</Badge>
                             </div>
                             {dd.icd10 && <span className="text-xs font-mono text-muted-foreground">ICD-10: {dd.icd10}</span>}
                           </CardContent>
                         </Card>
                       ))}
                     </div>
                   </div>
                 )}
                 
                 {/* Unchanged diagnoses */}
                 {diagComparison.unchanged.length > 0 && (
                   <div className="space-y-2">
                     <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-1">
                       = Unverändert ({diagComparison.unchanged.length})
                     </h4>
                     <div className="grid gap-2 md:grid-cols-2">
                       {diagComparison.unchanged.map((dd, idx) => (
                         <Card key={idx} className="bg-muted/30">
                           <CardContent className="p-3">
                             <div className="flex items-start justify-between mb-1">
                               <span className="font-medium">{dd.name}</span>
                               <Badge variant="secondary">{Math.round(dd.probability * 100)}%</Badge>
                             </div>
                             {dd.icd10 && <span className="text-xs font-mono text-muted-foreground">ICD-10: {dd.icd10}</span>}
                           </CardContent>
                         </Card>
                       ))}
                     </div>
                   </div>
                 )}
                 
                 {diagComparison.added.length === 0 && diagComparison.removed.length === 0 && diagComparison.unchanged.length === 0 && (
                   <p className="text-center text-muted-foreground py-8">Keine Diagnosen zum Vergleichen</p>
                 )}
               </div>
             </ScrollArea>
           </TabsContent>
           
           {/* Diagram Comparison */}
           <TabsContent value="diagram" className="mt-4">
             <div className="grid gap-4 md:grid-cols-2">
               <div className="space-y-2">
                 <div className="flex items-center gap-2">
                   <Badge variant="outline">v{leftVersion.version}</Badge>
                   <span className="text-xs text-muted-foreground">Vorher</span>
                 </div>
                 <Card className="bg-muted/30">
                   <CardContent className="p-2">
                     {leftVersion.mermaid_diagram ? (
                       <MermaidDiagram diagram={leftVersion.mermaid_diagram} className="max-h-[300px]" />
                     ) : (
                       <p className="text-center text-muted-foreground py-8">Kein Diagramm</p>
                     )}
                   </CardContent>
                 </Card>
               </div>
               <div className="space-y-2">
                 <div className="flex items-center gap-2">
                   <Badge variant="secondary">v{rightVersion?.version || '-'}</Badge>
                   <span className="text-xs text-muted-foreground">Nachher</span>
                 </div>
                 <Card className="bg-muted/30">
                   <CardContent className="p-2">
                     {rightVersion?.mermaid_diagram ? (
                       <MermaidDiagram diagram={rightVersion.mermaid_diagram} className="max-h-[300px]" />
                     ) : (
                       <p className="text-center text-muted-foreground py-8">Kein Diagramm</p>
                     )}
                   </CardContent>
                 </Card>
               </div>
             </div>
           </TabsContent>
           
           {/* Reasoning Comparison */}
           <TabsContent value="reasoning" className="mt-4">
             <div className="grid gap-4 md:grid-cols-2">
               <div className="space-y-2">
                 <div className="flex items-center gap-2">
                   <Badge variant="outline">v{leftVersion.version}</Badge>
                   <span className="text-xs text-muted-foreground">Vorher</span>
                 </div>
                 <Card className="bg-muted/30">
                   <CardContent className="p-3">
                     <p className="text-sm">{leftVersion.ai_reasoning || 'Keine Begründung vorhanden'}</p>
                   </CardContent>
                 </Card>
               </div>
               <div className="space-y-2">
                 <div className="flex items-center gap-2">
                   <Badge variant="secondary">v{rightVersion?.version || '-'}</Badge>
                   <span className="text-xs text-muted-foreground">Nachher</span>
                 </div>
                 <Card className={cn(
                   "bg-muted/30",
                   rightVersion?.ai_reasoning !== leftVersion.ai_reasoning && "ring-2 ring-primary/20"
                 )}>
                   <CardContent className="p-3">
                     <p className="text-sm">{rightVersion?.ai_reasoning || 'Keine Begründung vorhanden'}</p>
                   </CardContent>
                 </Card>
               </div>
             </div>
           </TabsContent>
         </Tabs>
       </DialogContent>
     </Dialog>
   );
 }