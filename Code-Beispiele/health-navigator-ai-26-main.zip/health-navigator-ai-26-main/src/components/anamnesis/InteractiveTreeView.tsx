import { useState, useMemo, useCallback } from 'react';
import { 
  ChevronDown, 
  ChevronRight, 
  Circle, 
  CheckCircle2,
  AlertTriangle,
  ArrowDown,
  Maximize2,
  Minimize2,
  Target,
  Activity,
  Stethoscope,
  ClipboardCheck,
  Pill,
  Users,
  Heart,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface InteractiveTreeViewProps {
  diagram: string;
  className?: string;
  onNodeClick?: (nodeId: string, nodeLabel: string) => void;
}

interface TreeNode {
  id: string;
  label: string;
  type: 'start' | 'question' | 'decision' | 'action' | 'end' | 'category';
  children: TreeNode[];
  category?: string;
  isRedFlag?: boolean;
  connections?: Array<{ to: string; label?: string }>;
}

interface ParsedSubgraph {
  id: string;
  label: string;
  nodes: Array<{ id: string; label: string; shape?: string }>;
}

// Category icons and colors
const CATEGORY_CONFIG: Record<string, { icon: React.ElementType; color: string; bgColor: string }> = {
  'Chief_Complaint': { icon: AlertCircle, color: 'text-red-500', bgColor: 'bg-red-50 dark:bg-red-950/30' },
  'ChiefComplaint': { icon: AlertCircle, color: 'text-red-500', bgColor: 'bg-red-50 dark:bg-red-950/30' },
  'chief_complaint': { icon: AlertCircle, color: 'text-red-500', bgColor: 'bg-red-50 dark:bg-red-950/30' },
  'HPI': { icon: Activity, color: 'text-blue-500', bgColor: 'bg-blue-50 dark:bg-blue-950/30' },
  'hpi': { icon: Activity, color: 'text-blue-500', bgColor: 'bg-blue-50 dark:bg-blue-950/30' },
  'ROS': { icon: Stethoscope, color: 'text-cyan-500', bgColor: 'bg-cyan-50 dark:bg-cyan-950/30' },
  'ros': { icon: Stethoscope, color: 'text-cyan-500', bgColor: 'bg-cyan-50 dark:bg-cyan-950/30' },
  'PMH': { icon: ClipboardCheck, color: 'text-orange-500', bgColor: 'bg-orange-50 dark:bg-orange-950/30' },
  'pmh': { icon: ClipboardCheck, color: 'text-orange-500', bgColor: 'bg-orange-50 dark:bg-orange-950/30' },
  'Medications': { icon: Pill, color: 'text-purple-500', bgColor: 'bg-purple-50 dark:bg-purple-950/30' },
  'medications': { icon: Pill, color: 'text-purple-500', bgColor: 'bg-purple-50 dark:bg-purple-950/30' },
  'Social': { icon: Users, color: 'text-green-500', bgColor: 'bg-green-50 dark:bg-green-950/30' },
  'social': { icon: Users, color: 'text-green-500', bgColor: 'bg-green-50 dark:bg-green-950/30' },
  'Family': { icon: Heart, color: 'text-pink-500', bgColor: 'bg-pink-50 dark:bg-pink-950/30' },
  'family': { icon: Heart, color: 'text-pink-500', bgColor: 'bg-pink-50 dark:bg-pink-950/30' },
  'Assessment': { icon: Target, color: 'text-amber-500', bgColor: 'bg-amber-50 dark:bg-amber-950/30' },
  'assessment': { icon: Target, color: 'text-amber-500', bgColor: 'bg-amber-50 dark:bg-amber-950/30' },
  'RedFlags': { icon: AlertTriangle, color: 'text-red-600', bgColor: 'bg-red-100 dark:bg-red-950/50' },
  'red_flags': { icon: AlertTriangle, color: 'text-red-600', bgColor: 'bg-red-100 dark:bg-red-950/50' },
  'Differential': { icon: HelpCircle, color: 'text-indigo-500', bgColor: 'bg-indigo-50 dark:bg-indigo-950/30' },
  'differential': { icon: HelpCircle, color: 'text-indigo-500', bgColor: 'bg-indigo-50 dark:bg-indigo-950/30' },
};

const CATEGORY_LABELS: Record<string, string> = {
  'Chief_Complaint': 'Hauptbeschwerde',
  'ChiefComplaint': 'Hauptbeschwerde',
  'chief_complaint': 'Hauptbeschwerde',
  'HPI': 'Aktuelle Beschwerden',
  'hpi': 'Aktuelle Beschwerden',
  'ROS': 'Systemübersicht',
  'ros': 'Systemübersicht',
  'PMH': 'Vorerkrankungen',
  'pmh': 'Vorerkrankungen',
  'Medications': 'Medikamente',
  'medications': 'Medikamente',
  'Social': 'Sozialanamnese',
  'social': 'Sozialanamnese',
  'Family': 'Familienanamnese',
  'family': 'Familienanamnese',
  'Assessment': 'Beurteilung',
  'assessment': 'Beurteilung',
  'RedFlags': 'Red Flags',
  'red_flags': 'Red Flags',
  'Differential': 'Differentialdiagnosen',
  'differential': 'Differentialdiagnosen',
};

// Tree Node Component
function TreeNodeComponent({ 
  node, 
  depth = 0,
  isLast = false,
  expandedNodes,
  completedNodes,
  onToggle,
  onComplete,
  onNodeClick
}: {
  node: TreeNode;
  depth?: number;
  isLast?: boolean;
  expandedNodes: Set<string>;
  completedNodes: Set<string>;
  onToggle: (id: string) => void;
  onComplete: (id: string) => void;
  onNodeClick?: (nodeId: string, nodeLabel: string) => void;
}) {
  const hasChildren = node.children.length > 0;
  const isExpanded = expandedNodes.has(node.id);
  const isCompleted = completedNodes.has(node.id);
  const config = node.category ? CATEGORY_CONFIG[node.category] : null;
  const Icon = config?.icon || Circle;

  const getNodeStyle = () => {
    if (node.type === 'category') {
      return cn(
        "border-l-4 rounded-lg p-3 cursor-pointer transition-all",
        config?.bgColor || 'bg-muted',
        isExpanded ? 'ring-2 ring-primary/20' : 'hover:shadow-md'
      );
    }
    if (node.isRedFlag) {
      return "bg-red-50 dark:bg-red-950/30 border-l-2 border-red-500 rounded-md p-2";
    }
    if (isCompleted) {
      return "bg-green-50 dark:bg-green-950/30 border-l-2 border-green-500 rounded-md p-2 opacity-75";
    }
    return "bg-card border rounded-md p-2 hover:bg-accent/50 transition-colors";
  };

  return (
    <div className="relative">
      {/* Connection line from parent */}
      {depth > 0 && (
        <div 
          className="absolute left-0 top-0 w-4 border-l-2 border-b-2 border-muted-foreground/20 rounded-bl-md"
          style={{ 
            height: '1.25rem',
            marginLeft: '-1rem'
          }}
        />
      )}
      
      <div className={cn("mb-2", depth > 0 && "ml-4")}>
        <div 
          className={getNodeStyle()}
          style={{ 
            marginLeft: depth > 0 ? '0.5rem' : 0,
            borderLeftColor: config ? undefined : (node.isRedFlag ? undefined : 'transparent')
          }}
        >
          <div 
            className="flex items-start gap-2 cursor-pointer"
            onClick={() => {
              if (hasChildren) onToggle(node.id);
              if (onNodeClick) onNodeClick(node.id, node.label);
            }}
          >
            {/* Expand/Collapse or Status Icon */}
            <div className="flex-shrink-0 mt-0.5">
              {hasChildren ? (
                <button 
                  className="p-0.5 rounded hover:bg-muted"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggle(node.id);
                  }}
                >
                  {isExpanded ? (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  )}
                </button>
              ) : (
                <button
                  className="p-0.5 rounded hover:bg-muted"
                  onClick={(e) => {
                    e.stopPropagation();
                    onComplete(node.id);
                  }}
                  title={isCompleted ? "Als unerledigt markieren" : "Als erledigt markieren"}
                >
                  {isCompleted ? (
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                  ) : (
                    <Circle className="h-4 w-4 text-muted-foreground" />
                  )}
                </button>
              )}
            </div>

            {/* Node Content */}
            <div className="flex-1 min-w-0">
              {node.type === 'category' ? (
                <div className="flex items-center gap-2">
                  <Icon className={cn("h-4 w-4", config?.color)} />
                  <span className="font-medium text-sm">
                    {CATEGORY_LABELS[node.category || ''] || node.label}
                  </span>
                  <Badge variant="secondary" className="text-xs ml-auto">
                    {node.children.length}
                  </Badge>
                </div>
              ) : (
                <div>
                  <p className={cn(
                    "text-sm leading-relaxed",
                    isCompleted && "line-through text-muted-foreground"
                  )}>
                    {node.label}
                  </p>
                  {node.isRedFlag && (
                    <Badge variant="destructive" className="text-xs mt-1">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Red Flag
                    </Badge>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Children */}
        {hasChildren && isExpanded && (
          <div className="mt-1 relative">
            {/* Vertical connector line */}
            <div 
              className="absolute left-2 top-0 bottom-4 border-l-2 border-muted-foreground/20"
              style={{ marginLeft: depth > 0 ? '0.5rem' : 0 }}
            />
            {node.children.map((child, idx) => (
              <TreeNodeComponent
                key={child.id}
                node={child}
                depth={depth + 1}
                isLast={idx === node.children.length - 1}
                expandedNodes={expandedNodes}
                completedNodes={completedNodes}
                onToggle={onToggle}
                onComplete={onComplete}
                onNodeClick={onNodeClick}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function InteractiveTreeView({ diagram, className, onNodeClick }: InteractiveTreeViewProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [completedNodes, setCompletedNodes] = useState<Set<string>>(new Set());
  const [showCompleted, setShowCompleted] = useState(true);

  // Parse Mermaid diagram into tree structure
  const treeData = useMemo((): TreeNode[] => {
    if (!diagram?.trim()) return [];

    const subgraphs: ParsedSubgraph[] = [];
    const globalConnections: Array<{ from: string; to: string; label?: string }> = [];
    const standaloneNodes: Array<{ id: string; label: string }> = [];
    const nodesInSubgraphs = new Set<string>();

    // Extract subgraphs
    const subgraphRegex = /subgraph\s+(\w+)\s*\[([^\]]+)\]([^]*?)end/gi;
    let match;

    while ((match = subgraphRegex.exec(diagram)) !== null) {
      const [, id, label, content] = match;
      const nodes: Array<{ id: string; label: string; shape?: string }> = [];

      // Parse nodes - handle different shapes
      // [Label] = rectangle, {Label} = diamond, (Label) = rounded, ((Label)) = circle
      const nodePatterns = [
        /(\w+)\s*\[["']?([^\]"']+)["']?\]/g,  // [Label]
        /(\w+)\s*\{["']?([^\}"']+)["']?\}/g,  // {Label}
        /(\w+)\s*\(\(["']?([^\)"']+)["']?\)\)/g,  // ((Label))
        /(\w+)\s*\(["']?([^\)"']+)["']?\)/g,  // (Label)
      ];

      for (const pattern of nodePatterns) {
        let nodeMatch;
        while ((nodeMatch = pattern.exec(content)) !== null) {
          const [, nodeId, nodeLabel] = nodeMatch;
          if (nodeId && nodeLabel && !nodeId.match(/subgraph|end/i)) {
            const exists = nodes.some(n => n.id === nodeId);
            if (!exists) {
              nodes.push({ id: nodeId, label: nodeLabel.trim() });
              nodesInSubgraphs.add(nodeId);
            }
          }
        }
      }

      subgraphs.push({ id, label: label.trim(), nodes });
    }

    // Parse global connections
    const connRegex = /(\w+)\s*--+>?\s*(?:\|([^|]+)\|)?\s*(\w+)/g;
    while ((match = connRegex.exec(diagram)) !== null) {
      const [, from, label, to] = match;
      if (from && to && !from.match(/subgraph|end|flowchart/i) && !to.match(/subgraph|end/i)) {
        globalConnections.push({ from, to, label: label?.trim() });
      }
    }

    // Parse standalone nodes
    const allNodePatterns = [
      /(\w+)\s*\[["']?([^\]"']+)["']?\]/g,
      /(\w+)\s*\{["']?([^\}"']+)["']?\}/g,
      /(\w+)\s*\(\(["']?([^\)"']+)["']?\)\)/g,
      /(\w+)\s*\(["']?([^\)"']+)["']?\)/g,
    ];

    for (const pattern of allNodePatterns) {
      while ((match = pattern.exec(diagram)) !== null) {
        const [, nodeId, nodeLabel] = match;
        if (nodeId && nodeLabel && !nodesInSubgraphs.has(nodeId) && !nodeId.match(/subgraph/i)) {
          const exists = standaloneNodes.some(n => n.id === nodeId);
          if (!exists) {
            standaloneNodes.push({ id: nodeId, label: nodeLabel.trim() });
          }
        }
      }
    }

    // Build tree structure
    const tree: TreeNode[] = [];

    // Add standalone nodes as start nodes
    standaloneNodes.forEach(node => {
      tree.push({
        id: node.id,
        label: node.label,
        type: node.id.toLowerCase().includes('start') ? 'start' : 'action',
        children: [],
      });
    });

    // Add subgraphs as category nodes
    subgraphs.forEach(subgraph => {
      const isRedFlagCategory = subgraph.id.toLowerCase().includes('red') || 
                                 subgraph.id.toLowerCase().includes('flag');
      
      const categoryNode: TreeNode = {
        id: `category-${subgraph.id}`,
        label: subgraph.label,
        type: 'category',
        category: subgraph.id,
        children: subgraph.nodes.map(node => ({
          id: node.id,
          label: node.label,
          type: 'question',
          children: [],
          isRedFlag: isRedFlagCategory || 
                     node.label.toLowerCase().includes('red flag') ||
                     node.label.toLowerCase().includes('warnsignal'),
        })),
      };
      tree.push(categoryNode);
    });

    return tree;
  }, [diagram]);

  const toggleNode = useCallback((id: string) => {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const toggleComplete = useCallback((id: string) => {
    setCompletedNodes(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const expandAll = useCallback(() => {
    const allIds = new Set<string>();
    const collectIds = (nodes: TreeNode[]) => {
      nodes.forEach(node => {
        if (node.children.length > 0) {
          allIds.add(node.id);
          collectIds(node.children);
        }
      });
    };
    collectIds(treeData);
    setExpandedNodes(allIds);
  }, [treeData]);

  const collapseAll = useCallback(() => {
    setExpandedNodes(new Set());
  }, []);

  const totalNodes = useMemo(() => {
    let count = 0;
    const countNodes = (nodes: TreeNode[]) => {
      nodes.forEach(node => {
        if (node.type !== 'category') count++;
        countNodes(node.children);
      });
    };
    countNodes(treeData);
    return count;
  }, [treeData]);

  const completedCount = completedNodes.size;
  const progress = totalNodes > 0 ? Math.round((completedCount / totalNodes) * 100) : 0;

  if (treeData.length === 0) {
    return (
      <Card className={className}>
        <CardContent className="p-6 text-center text-muted-foreground">
          <HelpCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Keine Baumstruktur im Diagramm erkannt.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={cn("space-y-3", className)}>
      {/* Header Controls */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            {completedCount}/{totalNodes} erledigt
          </Badge>
          {progress > 0 && (
            <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs gap-1"
            onClick={expandAll}
          >
            <Maximize2 className="h-3 w-3" />
            Alle öffnen
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs gap-1"
            onClick={collapseAll}
          >
            <Minimize2 className="h-3 w-3" />
            Alle schließen
          </Button>
        </div>
      </div>

      {/* Tree */}
      <ScrollArea className="max-h-[500px]">
        <div className="pr-4">
          {treeData.map((node, idx) => (
            <TreeNodeComponent
              key={node.id}
              node={node}
              isLast={idx === treeData.length - 1}
              expandedNodes={expandedNodes}
              completedNodes={completedNodes}
              onToggle={toggleNode}
              onComplete={toggleComplete}
              onNodeClick={onNodeClick}
            />
          ))}
        </div>
      </ScrollArea>

      {/* Legend */}
      <div className="flex items-center gap-4 pt-2 border-t text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <Circle className="h-3 w-3" />
          <span>Offen</span>
        </div>
        <div className="flex items-center gap-1">
          <CheckCircle2 className="h-3 w-3 text-green-500" />
          <span>Erledigt</span>
        </div>
        <div className="flex items-center gap-1">
          <AlertTriangle className="h-3 w-3 text-red-500" />
          <span>Red Flag</span>
        </div>
      </div>
    </div>
  );
}
