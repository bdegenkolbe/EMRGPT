import { useState, useEffect } from 'react';
import { useRef } from 'react';
import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  AlertTriangle, 
  Clock, 
  Activity, 
  Pill, 
  CheckCircle2, 
  XCircle,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Download,
  FileText,
  FileJson,
  Sparkles,
  Pencil,
  Trash2,
  MoreHorizontal,
  Loader2,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
 import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
 import { Badge } from '@/components/ui/badge';
 import { Button } from '@/components/ui/button';
 import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useSnomed, SnomedConcept } from '@/hooks/useSnomed';
import { jsPDF } from 'jspdf';
 
 interface Observation {
   id: string;
   raw_input: string;
   normalized_value: string | null;
   hpo_codes: string[] | null;
   negated: boolean | null;
   onset: string | null;
   duration: string | null;
   severity: string | null;
   confidence: number | null;
   created_at: string | null;
 }
 
 interface ObservationsSummaryProps {
   sessionId: string;
   language?: string;
   isExpanded?: boolean;
  showExport?: boolean;
  refreshTrigger?: number;
  onObservationsChange?: () => void;
 }
 
 export function ObservationsSummary({ 
   sessionId, 
   language = 'de',
  isExpanded = false,
  showExport = true,
  refreshTrigger = 0,
  onObservationsChange
 }: ObservationsSummaryProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [observations, setObservations] = useState<Observation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(isExpanded);
  const [newSymptomIds, setNewSymptomIds] = useState<Set<string>>(new Set());
  const [showNewIndicator, setShowNewIndicator] = useState(false);
  const [showSnomedCodes, setShowSnomedCodes] = useState(false);
  const [snomedCodes, setSnomedCodes] = useState<Map<string, SnomedConcept[]>>(new Map());
  const [loadingSnomedFor, setLoadingSnomedFor] = useState<Set<string>>(new Set());
  const previousCountRef = useRef<number>(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const isGerman = language === 'de';

  // SNOMED hook
  const { searchConcepts, isSearching: isSnomedSearching } = useSnomed({ language });

  // Play notification sound using Web Audio API
  const playNotificationSound = useCallback(() => {
    try {
      // Create audio context if not exists
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      }
      
      const ctx = audioContextRef.current;
      
      // Resume context if suspended (autoplay policy)
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      
      // Create a pleasant notification sound
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      // Two-tone chime (C5 -> E5)
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      oscillator.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
      
      // Fade in and out
      gainNode.gain.setValueAtTime(0, ctx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.05);
      gainNode.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.15);
      gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.3);
      
      oscillator.start(ctx.currentTime);
      oscillator.stop(ctx.currentTime + 0.3);
    } catch (error) {
      console.log('Could not play notification sound:', error);
    }
  }, []);

  // Edit/Delete state
  const [editingObservation, setEditingObservation] = useState<Observation | null>(null);
  const [deletingObservation, setDeletingObservation] = useState<Observation | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [editForm, setEditForm] = useState({
    normalized_value: '',
    onset: '',
    duration: '',
    severity: '',
    negated: false,
  });
 
  // Open edit dialog
  const handleEdit = (obs: Observation) => {
    setEditForm({
      normalized_value: obs.normalized_value || obs.raw_input,
      onset: obs.onset || '',
      duration: obs.duration || '',
      severity: obs.severity || '',
      negated: obs.negated || false,
    });
    setEditingObservation(obs);
  };

  // Save edited observation
  const handleSaveEdit = async () => {
    if (!editingObservation) return;
    
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('observations')
        .update({
          normalized_value: editForm.normalized_value || null,
          onset: editForm.onset || null,
          duration: editForm.duration || null,
          severity: editForm.severity || null,
          negated: editForm.negated,
        })
        .eq('id', editingObservation.id);

      if (error) throw error;

      toast({
        title: isGerman ? 'Gespeichert' : 'Saved',
        description: isGerman ? 'Das Symptom wurde aktualisiert.' : 'The symptom was updated.',
      });

      setEditingObservation(null);
      loadObservations();
      onObservationsChange?.();
    } catch (error) {
      console.error('Error updating observation:', error);
      toast({
        variant: 'destructive',
        title: isGerman ? 'Fehler' : 'Error',
        description: String(error),
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Delete observation
  const handleDelete = async () => {
    if (!deletingObservation) return;
    
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('observations')
        .delete()
        .eq('id', deletingObservation.id);

      if (error) throw error;

      toast({
        title: isGerman ? 'Gelöscht' : 'Deleted',
        description: isGerman ? 'Das Symptom wurde entfernt.' : 'The symptom was removed.',
      });

      setDeletingObservation(null);
      loadObservations();
      onObservationsChange?.();
    } catch (error) {
      console.error('Error deleting observation:', error);
      toast({
        variant: 'destructive',
        title: isGerman ? 'Fehler' : 'Error',
        description: String(error),
      });
    } finally {
      setIsSaving(false);
    }
  };

   useEffect(() => {
     loadObservations();
  }, [sessionId, refreshTrigger]);
 
   const loadObservations = async () => {
     setIsLoading(true);
     try {
       const { data, error } = await supabase
         .from('observations')
         .select('*')
         .eq('session_id', sessionId)
         .order('created_at', { ascending: true });
 
       if (error) throw error;
      const newData = data || [];
      
      // Detect new symptoms
      if (previousCountRef.current > 0 && newData.length > previousCountRef.current) {
        const existingIds = new Set(observations.map(o => o.id));
        const newIds = newData.filter(o => !existingIds.has(o.id)).map(o => o.id);
        
        if (newIds.length > 0) {
          setNewSymptomIds(new Set(newIds));
          setShowNewIndicator(true);
          
          // Play notification sound
          playNotificationSound();
          
          // Clear the "new" highlight after 3 seconds
          setTimeout(() => {
            setNewSymptomIds(new Set());
          }, 3000);
          
          // Clear the badge indicator after 5 seconds
          setTimeout(() => {
            setShowNewIndicator(false);
          }, 5000);
        }
      }
      
      previousCountRef.current = newData.length;
      setObservations(newData);
     } catch (error) {
       console.error('Error loading observations:', error);
     } finally {
       setIsLoading(false);
     }
   };
 
    // Deduplicate observations by normalized_value/raw_input, keeping highest confidence
    const dedup = (obs: typeof observations) => {
      const seen = new Map<string, typeof obs[0]>();
      for (const o of obs) {
        const key = (o.normalized_value || o.raw_input).toLowerCase().trim();
        const existing = seen.get(key);
        if (!existing || (o.confidence ?? 0) > (existing.confidence ?? 0)) {
          seen.set(key, o);
        }
      }
      return Array.from(seen.values());
    };
    const positiveObs = dedup(observations.filter(o => !o.negated));
    const negatedObs = dedup(observations.filter(o => o.negated));
 
   const getSeverityColor = (severity: string | null) => {
     if (!severity) return 'bg-muted text-muted-foreground';
     const s = severity.toLowerCase();
     if (s.includes('schwer') || s.includes('severe') || s.includes('stark')) {
       return 'bg-destructive/15 text-destructive border-destructive/20';
     }
     if (s.includes('mittel') || s.includes('moderate') || s.includes('mäßig')) {
       return 'bg-warning/15 text-warning border-warning/20';
     }
     return 'bg-primary/15 text-primary border-primary/20';
   };
 
  const handlePDFExport = () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 20;
      const contentWidth = pageWidth - 2 * margin;
      let y = margin;

      // Header
      doc.setFillColor(59, 130, 246);
      doc.rect(0, 0, pageWidth, 30, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text(isGerman ? 'Symptom-Zusammenfassung' : 'Symptom Summary', margin, 20);
      
      y = 40;
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(`${isGerman ? 'Datum' : 'Date'}: ${new Date().toLocaleDateString(isGerman ? 'de-DE' : 'en-US')}`, margin, y);
      y += 10;

      // Confirmed symptoms
      if (positiveObs.length > 0) {
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(isGerman ? 'Bestätigte Symptome' : 'Confirmed Symptoms', margin, y);
        y += 8;
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');

        positiveObs.forEach((obs) => {
          if (y > 270) {
            doc.addPage();
            y = margin;
          }
          const text = obs.normalized_value || obs.raw_input;
          const lines = doc.splitTextToSize(`• ${text}`, contentWidth);
          lines.forEach((line: string) => {
            doc.text(line, margin, y);
            y += 5;
          });
          
          const meta: string[] = [];
          if (obs.onset) meta.push(`${isGerman ? 'Beginn' : 'Onset'}: ${obs.onset}`);
          if (obs.duration) meta.push(`${isGerman ? 'Dauer' : 'Duration'}: ${obs.duration}`);
          if (obs.severity) meta.push(`${isGerman ? 'Schweregrad' : 'Severity'}: ${obs.severity}`);
          if (meta.length > 0) {
            doc.setFontSize(8);
            doc.setTextColor(100, 100, 100);
            doc.text(`  ${meta.join(' | ')}`, margin, y);
            y += 4;
            doc.setFontSize(10);
            doc.setTextColor(0, 0, 0);
          }
          
          if (obs.hpo_codes?.length) {
            doc.setFontSize(8);
            doc.setTextColor(59, 130, 246);
            doc.text(`  HPO: ${obs.hpo_codes.join(', ')}`, margin, y);
            y += 5;
            doc.setFontSize(10);
            doc.setTextColor(0, 0, 0);
          }
          y += 2;
        });
      }

      // Denied symptoms
      if (negatedObs.length > 0) {
        y += 5;
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(isGerman ? 'Verneinte Symptome' : 'Denied Symptoms', margin, y);
        y += 8;
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(100, 100, 100);

        negatedObs.forEach((obs) => {
          if (y > 270) {
            doc.addPage();
            y = margin;
          }
          doc.text(`• ${obs.normalized_value || obs.raw_input}`, margin, y);
          y += 5;
        });
      }

      // Footer
      doc.setTextColor(128, 128, 128);
      doc.setFontSize(7);
      const footerY = doc.internal.pageSize.getHeight() - 10;
      doc.text(
        isGerman 
          ? 'Erstellt durch KI-gestützte Anamnese. Ersetzt keine ärztliche Beurteilung.'
          : 'Generated by AI-assisted anamnesis. Does not replace medical evaluation.',
        margin,
        footerY
      );

      doc.save(`symptom-summary-${sessionId.slice(0, 8)}.pdf`);

      toast({
        title: isGerman ? 'PDF exportiert' : 'PDF exported',
        description: isGerman ? 'Die Symptom-Zusammenfassung wurde als PDF gespeichert.' : 'The symptom summary was saved as PDF.',
      });
    } catch (error) {
      console.error('PDF export error:', error);
      toast({
        variant: 'destructive',
        title: isGerman ? 'Export fehlgeschlagen' : 'Export failed',
        description: String(error),
      });
    }
  };

  const handleJSONExport = () => {
    try {
      const exportData = {
        sessionId,
        exportedAt: new Date().toISOString(),
        language,
        summary: {
          totalSymptoms: observations.length,
          confirmedSymptoms: positiveObs.length,
          deniedSymptoms: negatedObs.length,
        },
        observations: observations.map((obs) => ({
          id: obs.id,
          symptom: obs.normalized_value || obs.raw_input,
          rawInput: obs.raw_input,
          negated: obs.negated || false,
          onset: obs.onset || null,
          duration: obs.duration || null,
          severity: obs.severity || null,
          confidence: obs.confidence || null,
          hpoCodes: obs.hpo_codes || [],
          createdAt: obs.created_at,
        })),
      };

      const jsonString = JSON.stringify(exportData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `symptoms-${sessionId.slice(0, 8)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: isGerman ? 'JSON exportiert' : 'JSON exported',
        description: isGerman ? 'Die Symptome wurden als JSON gespeichert.' : 'Symptoms were saved as JSON.',
      });
    } catch (error) {
      console.error('JSON export error:', error);
      toast({
        variant: 'destructive',
        title: isGerman ? 'Export fehlgeschlagen' : 'Export failed',
        description: String(error),
      });
    }
  };

  const handleFHIRExport = () => {
    try {
      const fhirBundle = {
        resourceType: 'Bundle',
        type: 'collection',
        timestamp: new Date().toISOString(),
        entry: observations.map((obs) => ({
          resource: {
            resourceType: 'Observation',
            id: obs.id,
            status: 'final',
            code: {
              coding: obs.hpo_codes?.map((code) => ({
                system: 'http://purl.obolibrary.org/obo/hp.owl',
                code: code,
              })) || [],
              text: obs.normalized_value || obs.raw_input,
            },
            valueString: obs.normalized_value || obs.raw_input,
            effectiveDateTime: obs.created_at,
            interpretation: obs.negated ? [{
              coding: [{
                system: 'http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation',
                code: 'NEG',
                display: 'Negative',
              }],
            }] : undefined,
            component: [
              obs.onset ? {
                code: { text: 'onset' },
                valueString: obs.onset,
              } : null,
              obs.duration ? {
                code: { text: 'duration' },
                valueString: obs.duration,
              } : null,
              obs.severity ? {
                code: { text: 'severity' },
                valueString: obs.severity,
              } : null,
            ].filter(Boolean),
          },
        })),
        meta: {
          lastUpdated: new Date().toISOString(),
          profile: ['http://hl7.org/fhir/StructureDefinition/Bundle'],
        },
      };

      const jsonString = JSON.stringify(fhirBundle, null, 2);
      const blob = new Blob([jsonString], { type: 'application/fhir+json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `fhir-observations-${sessionId.slice(0, 8)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: isGerman ? 'FHIR exportiert' : 'FHIR exported',
        description: isGerman ? 'Die Symptome wurden als FHIR-Bundle gespeichert.' : 'Symptoms were saved as FHIR Bundle.',
      });
    } catch (error) {
      console.error('FHIR export error:', error);
      toast({
        variant: 'destructive',
        title: isGerman ? 'Export fehlgeschlagen' : 'Export failed',
        description: String(error),
      });
    }
  };

   if (isLoading) {
     return (
       <Card className="animate-pulse">
         <CardHeader className="pb-3">
           <div className="h-5 bg-muted rounded w-1/3"></div>
         </CardHeader>
         <CardContent>
           <div className="space-y-2">
             <div className="h-4 bg-muted rounded w-full"></div>
             <div className="h-4 bg-muted rounded w-2/3"></div>
           </div>
         </CardContent>
       </Card>
     );
   }
 
   if (observations.length === 0) {
     return (
       <Card>
         <CardContent className="pt-6 text-center text-muted-foreground">
           <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
           <p>{isGerman ? 'Noch keine Symptome erfasst' : 'No symptoms recorded yet'}</p>
         </CardContent>
       </Card>
     );
   }
 
   return (
   <>
   <Card className={cn(showNewIndicator && "ring-2 ring-primary/50 ring-offset-2 transition-all duration-300")}>
       <Collapsible open={isOpen} onOpenChange={setIsOpen}>
         <CardHeader className="pb-3">
           <CollapsibleTrigger asChild>
             <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
               <CardTitle className="text-base flex items-center gap-2">
                <Activity className={cn("h-4 w-4", showNewIndicator && "text-primary animate-pulse")} />
                 {isGerman ? 'Erfasste Symptome' : 'Recorded Symptoms'}
                <Badge 
                  variant={showNewIndicator ? "default" : "secondary"} 
                  className={cn("ml-2 transition-all", showNewIndicator && "animate-pulse")}
                >
                   {observations.length}
                 </Badge>
                {showNewIndicator && (
                  <Badge variant="outline" className="ml-1 text-xs bg-primary/10 text-primary border-primary/30 animate-pulse flex items-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    {isGerman ? 'Neu!' : 'New!'}
                  </Badge>
                )}
               </CardTitle>
               {isOpen ? (
                 <ChevronUp className="h-4 w-4 text-muted-foreground" />
               ) : (
                 <ChevronDown className="h-4 w-4 text-muted-foreground" />
               )}
             </Button>
           </CollapsibleTrigger>
            {showExport && observations.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 ml-2" onClick={(e) => e.stopPropagation()}>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={handlePDFExport}>
                    <FileText className="mr-2 h-4 w-4" />
                    {isGerman ? 'PDF exportieren' : 'Export PDF'}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleJSONExport}>
                    <FileJson className="mr-2 h-4 w-4" />
                    {isGerman ? 'JSON exportieren' : 'Export JSON'}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleFHIRExport}>
                    <FileJson className="mr-2 h-4 w-4" />
                    FHIR R4
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
         </CardHeader>
         
        <CollapsibleContent>
          <CardContent className="pt-0 space-y-4">
            {/* SNOMED/HPO Toggle */}
            <div className="flex items-center justify-between py-2 px-3 bg-muted/50 rounded-lg">
              <span className="text-xs font-medium text-muted-foreground">
                {isGerman ? 'Terminologie:' : 'Terminology:'}
              </span>
              <div className="flex items-center gap-2">
                <span className={cn("text-xs", !showSnomedCodes && "font-semibold text-primary")}>
                  HPO
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2"
                  onClick={() => {
                    const newShowSnomed = !showSnomedCodes;
                    setShowSnomedCodes(newShowSnomed);
                    
                    // Load SNOMED codes for all observations when toggling on
                    if (newShowSnomed && snomedCodes.size === 0) {
                      observations.forEach(async (obs) => {
                        const searchTerm = obs.normalized_value || obs.raw_input;
                        if (searchTerm && !snomedCodes.has(obs.id)) {
                          setLoadingSnomedFor(prev => new Set(prev).add(obs.id));
                          try {
                            const result = await searchConcepts(searchTerm, 3);
                            if (result && result.concepts) {
                              setSnomedCodes(prev => new Map(prev).set(obs.id, result.concepts));
                            }
                          } finally {
                            setLoadingSnomedFor(prev => {
                              const next = new Set(prev);
                              next.delete(obs.id);
                              return next;
                            });
                          }
                        }
                      });
                    }
                  }}
                >
                  {showSnomedCodes ? (
                    <ToggleRight className="h-4 w-4 text-accent" />
                  ) : (
                    <ToggleLeft className="h-4 w-4" />
                  )}
                </Button>
                <span className={cn("text-xs", showSnomedCodes && "font-semibold text-accent-foreground")}>
                  SNOMED CT
                </span>
              </div>
            </div>

            {/* Positive Observations */}
            {positiveObs.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium flex items-center gap-1.5 text-primary">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {isGerman ? 'Bestätigte Symptome' : 'Confirmed Symptoms'}
                  <Badge variant="outline" className="ml-1 text-xs">{positiveObs.length}</Badge>
                </h4>
                <div className="space-y-2">
                  {positiveObs.map((obs) => (
                    <ObservationItem 
                      key={obs.id} 
                      observation={obs} 
                      isGerman={isGerman} 
                      getSeverityColor={getSeverityColor}
                      isNew={newSymptomIds.has(obs.id)}
                      onEdit={() => handleEdit(obs)}
                      onDelete={() => setDeletingObservation(obs)}
                      showSnomedCodes={showSnomedCodes}
                      snomedCodes={snomedCodes.get(obs.id) || []}
                      isLoadingSnomed={loadingSnomedFor.has(obs.id)}
                    />
                  ))}
                </div>
              </div>
            )}
 
             {/* Negated Observations */}
             {negatedObs.length > 0 && (
               <div className="space-y-2">
                 <h4 className="text-sm font-medium flex items-center gap-1.5 text-muted-foreground">
                   <XCircle className="h-3.5 w-3.5" />
                   {isGerman ? 'Verneinte Symptome' : 'Denied Symptoms'}
                   <Badge variant="outline" className="ml-1 text-xs">{negatedObs.length}</Badge>
                 </h4>
                 <div className="space-y-1">
                   {negatedObs.map((obs) => (
                    <div
                       key={obs.id} 
                      className={cn(
                        "text-sm text-muted-foreground line-through opacity-70 pl-2 flex items-center justify-between group",
                        newSymptomIds.has(obs.id) && "bg-primary/10 rounded px-2 py-1 animate-pulse"
                      )}
                     >
                      <span>{obs.normalized_value || obs.raw_input}</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                          >
                            <MoreHorizontal className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(obs)}>
                            <Pencil className="mr-2 h-4 w-4" />
                            {isGerman ? 'Bearbeiten' : 'Edit'}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => setDeletingObservation(obs)} className="text-destructive focus:text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" />
                            {isGerman ? 'Löschen' : 'Delete'}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                     </div>
                   ))}
                 </div>
               </div>
             )}
           </CardContent>
         </CollapsibleContent>
       </Collapsible>
     </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingObservation} onOpenChange={(open) => !open && setEditingObservation(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{isGerman ? 'Symptom bearbeiten' : 'Edit Symptom'}</DialogTitle>
            <DialogDescription>
              {isGerman 
                ? 'Passen Sie die Details des Symptoms an.' 
                : 'Adjust the details of the symptom.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="normalized_value">{isGerman ? 'Beschreibung' : 'Description'}</Label>
              <Input
                id="normalized_value"
                value={editForm.normalized_value}
                onChange={(e) => setEditForm(prev => ({ ...prev, normalized_value: e.target.value }))}
                placeholder={editingObservation?.raw_input}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="onset">{isGerman ? 'Beginn' : 'Onset'}</Label>
                <Input
                  id="onset"
                  value={editForm.onset}
                  onChange={(e) => setEditForm(prev => ({ ...prev, onset: e.target.value }))}
                  placeholder={isGerman ? 'z.B. vor 2 Tagen' : 'e.g. 2 days ago'}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration">{isGerman ? 'Dauer' : 'Duration'}</Label>
                <Input
                  id="duration"
                  value={editForm.duration}
                  onChange={(e) => setEditForm(prev => ({ ...prev, duration: e.target.value }))}
                  placeholder={isGerman ? 'z.B. 3 Stunden' : 'e.g. 3 hours'}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="severity">{isGerman ? 'Schweregrad' : 'Severity'}</Label>
              <Select
                value={editForm.severity || 'none'}
                onValueChange={(value) => setEditForm(prev => ({ ...prev, severity: value === 'none' ? '' : value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder={isGerman ? 'Schweregrad auswählen' : 'Select severity'} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">{isGerman ? 'Nicht angegeben' : 'Not specified'}</SelectItem>
                  <SelectItem value="leicht">{isGerman ? 'Leicht' : 'Mild'}</SelectItem>
                  <SelectItem value="mittel">{isGerman ? 'Mittel' : 'Moderate'}</SelectItem>
                  <SelectItem value="schwer">{isGerman ? 'Schwer' : 'Severe'}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="negated"
                checked={editForm.negated}
                onChange={(e) => setEditForm(prev => ({ ...prev, negated: e.target.checked }))}
                className="h-4 w-4 rounded border-input"
              />
              <Label htmlFor="negated" className="text-sm font-normal">
                {isGerman ? 'Symptom verneint (nicht vorhanden)' : 'Symptom denied (not present)'}
              </Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingObservation(null)} disabled={isSaving}>
              {isGerman ? 'Abbrechen' : 'Cancel'}
            </Button>
            <Button onClick={handleSaveEdit} disabled={isSaving}>
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isGerman ? 'Speichern' : 'Save'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deletingObservation} onOpenChange={(open) => !open && setDeletingObservation(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{isGerman ? 'Symptom löschen?' : 'Delete symptom?'}</AlertDialogTitle>
            <AlertDialogDescription>
              {isGerman 
                ? `Möchten Sie "${deletingObservation?.normalized_value || deletingObservation?.raw_input}" wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.`
                : `Are you sure you want to delete "${deletingObservation?.normalized_value || deletingObservation?.raw_input}"? This action cannot be undone.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSaving}>
              {isGerman ? 'Abbrechen' : 'Cancel'}
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={isSaving} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isGerman ? 'Löschen' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
   );
 }
 
 interface ObservationItemProps {
   observation: Observation;
  isGerman: boolean;
  getSeverityColor: (severity: string | null) => string;
  isNew?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  showSnomedCodes?: boolean;
  snomedCodes?: SnomedConcept[];
  isLoadingSnomed?: boolean;
}

function ObservationItem({ 
  observation, 
  isGerman, 
  getSeverityColor, 
  isNew = false, 
  onEdit, 
  onDelete,
  showSnomedCodes = false,
  snomedCodes = [],
  isLoadingSnomed = false
}: ObservationItemProps) {
  const { normalized_value, raw_input, hpo_codes, onset, duration, severity, confidence } = observation;

  return (
    <div className={cn(
      "p-3 rounded-lg border bg-card hover:bg-accent/5 transition-all duration-300 group",
      isNew && "ring-2 ring-primary/50 bg-primary/5 animate-pulse"
    )}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className={cn("font-medium text-sm", isNew && "text-primary")}>
            {normalized_value || raw_input}
            {isNew && (
              <Badge variant="outline" className="ml-2 text-[10px] px-1 py-0 h-4 bg-primary/10 text-primary border-primary/30">
                <Sparkles className="h-2.5 w-2.5 mr-0.5" />
                Neu
              </Badge>
            )}
          </p>
          
          {/* Meta info */}
          <div className="flex flex-wrap items-center gap-2 mt-1.5">
            {onset && (
              <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                {onset}
              </span>
            )}
            {duration && (
              <span className="text-xs text-muted-foreground">
                • {duration}
              </span>
            )}
            {severity && (
              <Badge variant="outline" className={cn("text-xs", getSeverityColor(severity))}>
                {severity}
              </Badge>
            )}
            {confidence && confidence >= 0.8 && (
              <Badge variant="secondary" className="text-xs">
                {Math.round(confidence * 100)}%
              </Badge>
            )}
          </div>

          {/* HPO Codes - shown when not in SNOMED mode */}
          {!showSnomedCodes && hpo_codes && hpo_codes.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {hpo_codes.map((code) => (
                <a
                  key={code}
                  href={`https://hpo.jax.org/browse/term/${code}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-xs font-mono bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                >
                  {code}
                  <ExternalLink className="h-2.5 w-2.5" />
                </a>
              ))}
            </div>
          )}

          {/* SNOMED CT Codes - shown when in SNOMED mode */}
          {showSnomedCodes && (
            <div className="flex flex-wrap gap-1 mt-2">
              {isLoadingSnomed ? (
                <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  {isGerman ? 'Suche SNOMED-Codes...' : 'Searching SNOMED codes...'}
                </span>
              ) : snomedCodes.length > 0 ? (
                snomedCodes.slice(0, 3).map((concept) => (
                  <a
                    key={concept.conceptId}
                    href={`https://browser.ihtsdotools.org/?perspective=full&conceptId1=${concept.conceptId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-xs font-mono bg-accent text-accent-foreground hover:bg-accent/80 transition-colors"
                    title={concept.fsn?.term || concept.pt?.term}
                  >
                    {concept.conceptId}
                    <ExternalLink className="h-2.5 w-2.5" />
                  </a>
                ))
              ) : (
                <span className="text-xs text-muted-foreground italic">
                  {isGerman ? 'Keine SNOMED-Codes gefunden' : 'No SNOMED codes found'}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Edit/Delete Actions */}
        {(onEdit || onDelete) && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
              >
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {onEdit && (
                <DropdownMenuItem onClick={onEdit}>
                  <Pencil className="mr-2 h-4 w-4" />
                  {isGerman ? 'Bearbeiten' : 'Edit'}
                </DropdownMenuItem>
              )}
              {onDelete && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
                    <Trash2 className="mr-2 h-4 w-4" />
                    {isGerman ? 'Löschen' : 'Delete'}
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </div>
  );
}