import { useEffect, useRef, useState, useMemo } from 'react';
import mermaid from 'mermaid';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, AlertCircle, Download, Image, FileCode, Maximize2, X, ZoomIn, ZoomOut, ArrowRightLeft, List, GitBranch, TreeDeciduous } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { CollapsibleFlowView } from './CollapsibleFlowView';
import { InteractiveTreeView } from './InteractiveTreeView';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
 
interface MermaidDiagramProps {
  diagram: string;
  className?: string;
  title?: string;
}

// Initialize mermaid with theme
mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  securityLevel: 'loose',
  flowchart: {
    useMaxWidth: true,
    htmlLabels: true,
    curve: 'basis',
    nodeSpacing: 30,
    rankSpacing: 40,
  },
});

export function MermaidDiagram({ diagram, className = '', title = 'diagram' }: MermaidDiagramProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [svgContent, setSvgContent] = useState<string>('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [fullscreenZoom, setFullscreenZoom] = useState(1);
  const [isHorizontal, setIsHorizontal] = useState(true); // Default to horizontal (LR)
  const [viewMode, setViewMode] = useState<'diagram' | 'collapsible' | 'tree'>('diagram');
  const { toast } = useToast();
 
  // Convert diagram direction based on toggle
  const processedDiagram = useMemo(() => {
    if (!diagram?.trim()) return '';
    
    let processed = diagram;
    
    // Convert TB (top-bottom) to LR (left-right) or vice versa
    if (isHorizontal) {
      processed = processed.replace(/flowchart\s+TB/gi, 'flowchart LR');
      processed = processed.replace(/flowchart\s+TD/gi, 'flowchart LR');
    } else {
      processed = processed.replace(/flowchart\s+LR/gi, 'flowchart TB');
      processed = processed.replace(/flowchart\s+RL/gi, 'flowchart TB');
    }
    
    return processed;
  }, [diagram, isHorizontal]);

  useEffect(() => {
    if (!processedDiagram?.trim()) {
      setSvgContent('');
      setError(null);
      setIsLoading(false);
      return;
    }

    let cancelled = false;

    const renderDiagram = async () => {
      setIsLoading(true);
      setError(null);

      try {
        // Generate unique ID for this diagram
        const id = `mermaid-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        const { svg } = await mermaid.render(id, processedDiagram);
        if (!cancelled) setSvgContent(svg);
      } catch (err) {
        console.error('Mermaid render error:', err);
        if (!cancelled) setError(err instanceof Error ? err.message : 'Failed to render diagram');
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    };

    renderDiagram();

    return () => {
      cancelled = true;
    };
  }, [processedDiagram]);
 
  const exportAsSVG = () => {
    if (!svgContent) return;
    
    try {
      const blob = new Blob([svgContent], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${title.replace(/\s+/g, '-').toLowerCase()}.svg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({
        title: 'SVG exportiert',
        description: 'Das Diagramm wurde als SVG heruntergeladen.',
      });
    } catch (err) {
      console.error('SVG export error:', err);
      toast({
        variant: 'destructive',
        title: 'Export fehlgeschlagen',
        description: 'Das Diagramm konnte nicht exportiert werden.',
      });
    }
  };

  const exportAsPNG = async () => {
    if (!svgContent) return;
    
    try {
      // Create a canvas element
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas context not available');
      
      // Create an image from the SVG
      const img = new window.Image();
      const svgBlob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(svgBlob);
      
      await new Promise<void>((resolve, reject) => {
        img.onload = () => {
          // Set canvas size with higher resolution for better quality
          const scale = 2;
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;
          
          // Fill with white background
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // Draw the image
          ctx.scale(scale, scale);
          ctx.drawImage(img, 0, 0);
          
          resolve();
        };
        img.onerror = reject;
        img.src = url;
      });
      
      URL.revokeObjectURL(url);
      
      // Convert to PNG and download
      canvas.toBlob((blob) => {
        if (!blob) throw new Error('Failed to create PNG');
        
        const pngUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = pngUrl;
        link.download = `${title.replace(/\s+/g, '-').toLowerCase()}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(pngUrl);
        
        toast({
          title: 'PNG exportiert',
          description: 'Das Diagramm wurde als PNG heruntergeladen.',
        });
      }, 'image/png');
    } catch (err) {
      console.error('PNG export error:', err);
      toast({
        variant: 'destructive',
        title: 'Export fehlgeschlagen',
        description: 'Das Diagramm konnte nicht exportiert werden.',
      });
    }
  };

  const handleZoomIn = (isFullscreenContext: boolean = false) => {
    if (isFullscreenContext) {
      setFullscreenZoom(prev => Math.min(prev + 0.25, 3));
    } else {
      setZoom(prev => Math.min(prev + 0.25, 3));
    }
  };

  const handleZoomOut = (isFullscreenContext: boolean = false) => {
    if (isFullscreenContext) {
      setFullscreenZoom(prev => Math.max(prev - 0.25, 0.25));
    } else {
      setZoom(prev => Math.max(prev - 0.25, 0.25));
    }
  };

  const handleZoomReset = (isFullscreenContext: boolean = false) => {
    if (isFullscreenContext) {
      setFullscreenZoom(1);
    } else {
      setZoom(1);
    }
  };

  // Reset fullscreen zoom when opening
  useEffect(() => {
    if (isFullscreen) {
      setFullscreenZoom(1);
    }
  }, [isFullscreen]);

   if (isLoading) {
     return (
       <Card className={className}>
         <CardContent className="flex items-center justify-center py-12">
           <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
         </CardContent>
       </Card>
     );
   }
 
   if (error) {
     return (
       <Card className={`border-destructive/50 ${className}`}>
         <CardContent className="flex items-center gap-3 py-6 text-destructive">
           <AlertCircle className="h-5 w-5 flex-shrink-0" />
           <div>
             <p className="font-medium">Diagramm-Fehler</p>
             <p className="text-sm text-muted-foreground">{error}</p>
           </div>
         </CardContent>
       </Card>
     );
   }
 
   return (
    <>
      <div className={`relative ${className}`}>
        {/* View Mode Tabs */}
        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'diagram' | 'collapsible' | 'tree')} className="w-full">
          <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
            <TabsList className="h-8">
              <TabsTrigger value="diagram" className="h-7 text-xs gap-1">
                <GitBranch className="h-3 w-3" />
                Diagramm
              </TabsTrigger>
              <TabsTrigger value="collapsible" className="h-7 text-xs gap-1">
                <List className="h-3 w-3" />
                Kompakt
              </TabsTrigger>
              <TabsTrigger value="tree" className="h-7 text-xs gap-1">
                <TreeDeciduous className="h-3 w-3" />
                Interaktiv
              </TabsTrigger>
            </TabsList>
            
            {viewMode === 'diagram' && (
              <div className="flex items-center gap-1">
                {/* Direction Toggle */}
                <Button
                  variant={isHorizontal ? "default" : "secondary"}
                  size="sm"
                  className="h-7 gap-1 text-xs"
                  onClick={() => setIsHorizontal(!isHorizontal)}
                  title={isHorizontal ? "Vertikal anzeigen" : "Horizontal anzeigen"}
                >
                  <ArrowRightLeft className="h-3 w-3" />
                  {isHorizontal ? "LR" : "TB"}
                </Button>
                {/* Zoom Controls */}
                <div className="flex items-center bg-secondary rounded-md">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7 rounded-r-none"
                    onClick={() => handleZoomOut(false)}
                  >
                    <ZoomOut className="h-3 w-3" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-7 px-1.5 rounded-none text-xs font-mono min-w-[2.5rem]"
                    onClick={() => handleZoomReset(false)}
                  >
                    {Math.round(zoom * 100)}%
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7 rounded-l-none"
                    onClick={() => handleZoomIn(false)}
                  >
                    <ZoomIn className="h-3 w-3" />
                  </Button>
                </div>
                <Button 
                  variant="secondary" 
                  size="icon" 
                  className="h-7 w-7"
                  onClick={() => setIsFullscreen(true)}
                  title="Vollbild"
                >
                  <Maximize2 className="h-3 w-3" />
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="secondary" size="sm" className="gap-1 h-7 text-xs">
                      <Download className="h-3 w-3" />
                      Export
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={exportAsPNG}>
                      <Image className="h-4 w-4 mr-2" />
                      Als PNG
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={exportAsSVG}>
                      <FileCode className="h-4 w-4 mr-2" />
                      Als SVG
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            )}
          </div>

          <TabsContent value="diagram" className="mt-0">
            <div
              ref={containerRef}
              className="overflow-auto cursor-pointer border rounded-md p-2 bg-background"
              onClick={() => setIsFullscreen(true)}
            >
              <div 
                style={{ 
                  transform: `scale(${zoom})`, 
                  transformOrigin: 'top left',
                  transition: 'transform 0.2s ease-out'
                }}
                dangerouslySetInnerHTML={{ __html: svgContent }}
              />
            </div>
          </TabsContent>

          <TabsContent value="collapsible" className="mt-0">
            <CollapsibleFlowView diagram={diagram} />
          </TabsContent>

          <TabsContent value="tree" className="mt-0">
            <InteractiveTreeView diagram={diagram} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Fullscreen Dialog */}
      <Dialog open={isFullscreen} onOpenChange={setIsFullscreen}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] w-full h-full p-0">
          <DialogHeader className="absolute top-0 left-0 right-0 z-10 bg-background/90 backdrop-blur-sm p-4 flex flex-row items-center justify-between border-b">
            <DialogTitle className="text-lg font-semibold">
              {title || 'Entscheidungspfad'}
            </DialogTitle>
            <div className="flex items-center gap-2">
              {/* Direction Toggle in Fullscreen */}
              <Button
                variant={isHorizontal ? "default" : "secondary"}
                size="sm"
                className="h-8 gap-1"
                onClick={() => setIsHorizontal(!isHorizontal)}
                title={isHorizontal ? "Vertikal anzeigen" : "Horizontal anzeigen"}
              >
                <ArrowRightLeft className="h-3 w-3" />
                {isHorizontal ? "Horizontal" : "Vertikal"}
              </Button>
              {/* Fullscreen Zoom Controls */}
              <div className="flex items-center bg-muted rounded-md">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 rounded-r-none"
                  onClick={() => handleZoomOut(true)}
                  title="Verkleinern"
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 px-2 rounded-none text-xs font-mono min-w-[3rem]"
                  onClick={() => handleZoomReset(true)}
                  title="Zoom zurücksetzen"
                >
                  {Math.round(fullscreenZoom * 100)}%
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 rounded-l-none"
                  onClick={() => handleZoomIn(true)}
                  title="Vergrößern"
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="secondary" size="sm" className="gap-1">
                    <Download className="h-3 w-3" />
                    Export
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={exportAsPNG}>
                    <Image className="h-4 w-4 mr-2" />
                    Als PNG
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={exportAsSVG}>
                    <FileCode className="h-4 w-4 mr-2" />
                    Als SVG
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setIsFullscreen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>
          <div 
            className="w-full h-full overflow-auto p-4 pt-20"
          >
            <div 
              className="min-w-full min-h-full flex items-center justify-center"
              style={{ 
                transform: `scale(${fullscreenZoom})`, 
                transformOrigin: 'center center',
                transition: 'transform 0.2s ease-out'
              }}
              dangerouslySetInnerHTML={{ __html: svgContent }}
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
   );
 }