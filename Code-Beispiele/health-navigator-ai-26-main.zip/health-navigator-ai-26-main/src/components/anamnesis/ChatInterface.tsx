import { useState, useRef, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Send, Mic, MicOff, Loader2, CheckCircle, X, PanelRightOpen, PanelRightClose, GitBranch, BookOpen, Zap, FlaskConical, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageBubble, type Message } from './MessageBubble';
import { AnamnesisProgress, type AnamnesisCategory } from './AnamnesisProgress';
import { ObservationsSummary } from './ObservationsSummary';
import { SidebarPathsPanel } from './SidebarPathsPanel';
import { PipelineResultsPanel } from './PipelineResultsPanel';
import { LabValueInput } from './LabValueInput';
import { useVoice } from '@/hooks/useVoice';
import { useAnamnesisPath } from '@/hooks/useAnamnesisPath';
import { usePipelineOrchestration } from '@/hooks/usePipelineOrchestration';
import { supabase } from '@/integrations/supabase/client';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { GuidelineSearch } from './GuidelineSearch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface ChatInterfaceProps {
  sessionId: string;
  clinicalView: string;
  language: string;
  onComplete?: () => void;
}

// Map API category to our category type
function mapCategory(apiCategory?: string): AnamnesisCategory {
  const mapping: Record<string, AnamnesisCategory> = {
    'chief_complaint': 'chief_complaint',
    'hpi': 'hpi',
    'ros': 'ros',
    'pmh': 'pmh',
    'medications': 'medications',
    'social': 'social',
    'family': 'family',
    'summary': 'summary',
  };
  return mapping[apiCategory || ''] || 'chief_complaint';
}

export function ChatInterface({ 
  sessionId, 
  clinicalView, 
  language,
  onComplete 
}: ChatInterfaceProps) {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [currentCategory, setCurrentCategory] = useState<AnamnesisCategory>('chief_complaint');
  const [completedCategories, setCompletedCategories] = useState<AnamnesisCategory[]>([]);
  const [redFlagCount, setRedFlagCount] = useState(0);
  const [questionCount, setQuestionCount] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const hasLoadedHistory = useRef(false);
  const [isEnding, setIsEnding] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);
  const [observationsRefresh, setObservationsRefresh] = useState(0);
  const isMobile = useIsMobile();
  const [pathGenerationCount, setPathGenerationCount] = useState(0);
  const [collectedHpoCodes, setCollectedHpoCodes] = useState<string[]>([]);
  const [showLabInput, setShowLabInput] = useState(false);

  const { 
    isListening, 
    isSupported: voiceSupported, 
    transcript,
    toggleListening,
  } = useVoice({
    language: language === 'de' ? 'de-DE' : 'en-US',
    onResult: (text) => {
      setInput(prev => prev + text);
    },
  });

  const { generatePath, isGenerating: isGeneratingPath } = useAnamnesisPath();
  
  // Pipeline orchestration for enhanced AI processing
  const { 
    runPipeline, 
    isRunning: isPipelineRunning, 
    lastResult: pipelineResult,
  } = usePipelineOrchestration({
    sessionId,
    clinicalView,
    enabled: true,
  });

  const getGreetingMessage = useCallback((): Message => ({
    id: 'greeting',
    role: 'assistant',
    content: language === 'de' 
      ? 'Willkommen zur KI-gestützten Anamnese. Ich werde Ihnen einige Fragen zu Ihren Beschwerden stellen. Bitte antworten Sie so ausführlich wie möglich. Was führt Sie heute zu uns?'
      : 'Welcome to the AI-assisted anamnesis. I will ask you some questions about your symptoms. Please answer as thoroughly as possible. What brings you here today?',
    timestamp: new Date(),
  }), [language]);

  // Load existing messages from database
  useEffect(() => {
    if (hasLoadedHistory.current) return;
    hasLoadedHistory.current = true;

    const loadMessages = async () => {
      setIsLoadingHistory(true);
      try {
        const { data, error } = await supabase
          .from('conversation_messages')
          .select('*')
          .eq('session_id', sessionId)
          .order('created_at', { ascending: true });

        if (error) {
          console.error('Error loading messages:', error);
          setMessages([getGreetingMessage()]);
          return;
        }

        if (data && data.length > 0) {
          // Convert database messages to our Message type
          const loadedMessages: Message[] = data.map((msg) => ({
            id: msg.id,
            role: msg.role as 'user' | 'assistant',
            content: msg.content,
            timestamp: new Date(msg.created_at || Date.now()),
            isRedFlag: msg.is_red_flag || false,
            ontologyCodes: msg.ontology_codes as Message['ontologyCodes'] || undefined,
          }));

          // Count red flags from loaded messages
          const loadedRedFlags = loadedMessages.filter(m => m.isRedFlag).length;
          setRedFlagCount(loadedRedFlags);

          setMessages(loadedMessages);
        } else {
          // No previous messages, show greeting and save it
          const greeting = getGreetingMessage();
          setMessages([greeting]);
          
          // Save greeting to database
          await saveMessage(greeting);
        }
      } catch (error) {
        console.error('Error loading messages:', error);
        setMessages([getGreetingMessage()]);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    loadMessages();
  }, [sessionId, getGreetingMessage]);

  // Ontology codes structure for JSONB storage
  interface OntologyCodeEntry {
    code: string;
    label?: string;
    confidence?: number;
  }

  interface OntologyCodesPayload {
    hpo?: OntologyCodeEntry[];
    snomed?: OntologyCodeEntry[];
    icd10?: OntologyCodeEntry[];
    rxnorm?: OntologyCodeEntry[];
    mesh?: OntologyCodeEntry[];
    [key: string]: OntologyCodeEntry[] | undefined;
  }

  // Save a message to the database
  const saveMessage = async (message: Message, ontologyCodes?: OntologyCodesPayload) => {
    try {
      const { error } = await supabase.from('conversation_messages').insert({
        id: message.id === 'greeting' ? undefined : message.id,
        session_id: sessionId,
        role: message.role,
        content: message.content,
        is_red_flag: message.isRedFlag || false,
        ontology_codes: ontologyCodes ? JSON.parse(JSON.stringify(ontologyCodes)) : null,
      });
      
      if (error) {
        console.error('Error saving message:', error);
      }
    } catch (error) {
      console.error('Error saving message:', error);
    }
  };

  // Update ontology codes for an existing message
  const updateMessageOntologyCodes = async (messageId: string, ontologyCodes: OntologyCodesPayload) => {
    try {
      const { error } = await supabase
        .from('conversation_messages')
        .update({ ontology_codes: JSON.parse(JSON.stringify(ontologyCodes)) })
        .eq('id', messageId);
        
      if (error) {
        console.error('Error updating message ontology codes:', error);
      }
    } catch (error) {
      console.error('Error updating message ontology codes:', error);
    }
  };

  // Handle category navigation
  const handleCategorySelect = async (category: AnamnesisCategory) => {
    if (category === currentCategory || isLoading) return;
    
    setIsLoading(true);
    
    try {
      // Create a system instruction for category switch that considers existing context
      const categoryLabels: Record<AnamnesisCategory, { de: string; en: string }> = {
        chief_complaint: { de: 'Hauptbeschwerde', en: 'Chief Complaint' },
        hpi: { de: 'Aktuelle Beschwerden', en: 'History of Present Illness' },
        ros: { de: 'Systemübersicht', en: 'Review of Systems' },
        pmh: { de: 'Vorerkrankungen', en: 'Past Medical History' },
        medications: { de: 'Medikamente', en: 'Medications' },
        social: { de: 'Sozialanamnese', en: 'Social History' },
        family: { de: 'Familienanamnese', en: 'Family History' },
        summary: { de: 'Zusammenfassung', en: 'Summary' },
      };

      const label = language === 'de' ? categoryLabels[category].de : categoryLabels[category].en;
      
      // Send a special user message that triggers contextual continuation
      const switchRequest = language === 'de'
        ? `[KATEGORIE-WECHSEL zu: ${label}] Bitte stelle eine kontextbezogene Frage zu diesem Thema, basierend auf dem bisherigen Gespräch. Wiederhole keine Informationen, die bereits gegeben wurden.`
        : `[CATEGORY SWITCH to: ${label}] Please ask a contextual question about this topic, based on the conversation so far. Do not repeat information already given.`;
      
      // Build conversation history
      const conversationHistory = messages
        .filter(m => m.id !== 'greeting')
        .map(m => ({
          role: m.role,
          content: m.content,
        }));

      const { data, error } = await supabase.functions.invoke('ai-anamnesis', {
        body: {
          sessionId,
          userMessage: switchRequest,
          conversationHistory,
          clinicalView,
          language,
          forcedCategory: category, // Signal to the AI which category to focus on
        },
      });

      if (error) throw error;

      const assistantMessage: Message = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: data.assistantMessage || data.response || (language === 'de' 
          ? `Lassen Sie uns über ${label} sprechen.`
          : `Let's discuss ${label}.`),
        timestamp: new Date(),
        isRedFlag: data.redFlags?.length > 0,
      };

      setMessages(prev => [...prev, assistantMessage]);
      await saveMessage(assistantMessage);
      setCurrentCategory(category);

      // Update completed categories
      if (data.completedCategories) {
        setCompletedCategories(data.completedCategories.map(mapCategory));
      }

      // Refresh observations
      setObservationsRefresh(prev => prev + 1);
    } catch (error) {
      console.error('Category switch error:', error);
      // Fallback to simple message on error
      const fallbackMessage: Message = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: language === 'de' 
          ? 'Lassen Sie uns mit dem nächsten Thema fortfahren.'
          : 'Let\'s continue with the next topic.',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, fallbackMessage]);
      await saveMessage(fallbackMessage);
      setCurrentCategory(category);
    } finally {
      setIsLoading(false);
    }
  };

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Update input with voice transcript
  useEffect(() => {
    if (transcript) {
      setInput(transcript);
    }
  }, [transcript]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput('');
    setIsLoading(true);

    // Save user message to database (without ontology codes initially)
    await saveMessage(userMessage);

    // Build conversation history for context
    const conversationHistory = updatedMessages
      .filter(m => m.id !== 'greeting')
      .map(m => ({
        role: m.role,
        content: m.content,
      }));
    
    // Build conversation history string for pipeline
    const conversationHistoryString = conversationHistory
      .map(m => `${m.role}: ${m.content}`)
      .join('\n');

    // Run pipeline orchestration and extract ontology codes
    runPipeline(userMessage.content, conversationHistoryString)
      .then((pipelineRes) => {
        if (pipelineRes && pipelineRes.results) {
          const ontologyCodes: OntologyCodesPayload = {};
          
          // Extract HPO codes from phase 2
          const hpoPhase = pipelineRes.results.find(r => r.phase === '2');
          if (hpoPhase?.output) {
            const hpoOutput = hpoPhase.output as { phenotypes?: Array<{ hpo_code: string; label?: string; confidence?: number }> };
            if (hpoOutput.phenotypes && hpoOutput.phenotypes.length > 0) {
              ontologyCodes.hpo = hpoOutput.phenotypes.map(p => ({
                code: p.hpo_code,
                label: p.label,
                confidence: p.confidence,
              }));
            }
          }
          
          // Extract SNOMED codes from phase 2b
          const snomedPhase = pipelineRes.results.find(r => r.phase === '2b');
          if (snomedPhase?.output) {
            const snomedOutput = snomedPhase.output as { findings?: Array<{ sctid: string; term?: string; confidence?: number }> };
            if (snomedOutput.findings && snomedOutput.findings.length > 0) {
              ontologyCodes.snomed = snomedOutput.findings.map(f => ({
                code: f.sctid,
                label: f.term,
                confidence: f.confidence,
              }));
            }
          }
          
          // Extract ICD-10 from phase 4 (differential diagnoses)
          const diagPhase = pipelineRes.results.find(r => r.phase === '4');
          if (diagPhase?.output) {
            const diagOutput = diagPhase.output as { differentials?: Array<{ icd10_code?: string; name?: string; probability?: number }> };
            if (diagOutput.differentials && diagOutput.differentials.length > 0) {
              ontologyCodes.icd10 = diagOutput.differentials
                .filter(d => d.icd10_code)
                .map(d => ({
                  code: d.icd10_code!,
                  label: d.name,
                  confidence: d.probability,
                }));
            }
          }
          
          // Update message with ontology codes if any were extracted
          if (Object.keys(ontologyCodes).length > 0) {
            updateMessageOntologyCodes(userMessage.id, ontologyCodes);
          }
        }
      })
      .catch(console.error);

    try {
      const { data, error } = await supabase.functions.invoke('ai-anamnesis', {
        body: {
          sessionId,
          userMessage: userMessage.content,
          conversationHistory,
          clinicalView,
          language,
        },
      });

      if (error) throw error;

      const hasRedFlags = (data.redFlags && data.redFlags.length > 0) || false;

      const assistantMessage: Message = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: data.assistantMessage || data.response || data.message || 'Entschuldigung, es gab einen Fehler.',
        timestamp: new Date(),
        isRedFlag: hasRedFlags,
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Save assistant message to database
      await saveMessage(assistantMessage);

      // Update progress
      if (data.nextQuestionCategory) {
        const newCategory = mapCategory(data.nextQuestionCategory);
        if (newCategory !== currentCategory) {
          setCompletedCategories(prev => 
            prev.includes(currentCategory) ? prev : [...prev, currentCategory]
          );
          setCurrentCategory(newCategory);
        }
      }

      // Update completed categories from AI response
      if (data.completedCategories && Array.isArray(data.completedCategories)) {
        setCompletedCategories(data.completedCategories.map(mapCategory));
      }

      // Update current category from AI response  
      if (data.currentCategory) {
        setCurrentCategory(mapCategory(data.currentCategory));
      }

      // Track question count
      setQuestionCount(prev => prev + 1);

      // Track red flags
      if (hasRedFlags) {
        setRedFlagCount(prev => prev + data.redFlags.length);
      }

      // Trigger observations refresh after each AI response
      setObservationsRefresh(prev => prev + 1);

      // Generate/update anamnesis path if observations were extracted
      if (data.observations && data.observations.length > 0) {
        const hpoCodes: string[] = [];
        const observations: { raw_input: string; hpo_codes: string[]; onset?: string; severity?: string }[] = [];
        
        data.observations.forEach((obs: { hpoCodes?: string[]; hpo_codes?: string[]; rawInput?: string; raw_input?: string; onset?: string; severity?: string }) => {
          // Handle both camelCase (from AI) and snake_case (from DB)
          const codes = obs.hpoCodes || obs.hpo_codes;
          const rawInput = obs.rawInput || obs.raw_input;
          
          if (codes && codes.length > 0 && rawInput) {
            hpoCodes.push(...codes);
            observations.push({
              raw_input: rawInput,
              hpo_codes: codes,
              onset: obs.onset,
              severity: obs.severity,
            });
          }
        });
        
        if (hpoCodes.length > 0) {
          // Fetch HPO labels from hpo_codes table (JSONB labels column)
          const uniqueCodes = [...new Set(hpoCodes)];
          const { data: hpoData } = await supabase
            .from('hpo_codes')
            .select('hpo_code, label, labels')
            .in('hpo_code', uniqueCodes);
          
          const labels = hpoData?.map(h => ({
            code: h.hpo_code,
            label_de: (h.labels as Record<string, string>)?.de || h.label,
            label_en: (h.labels as Record<string, string>)?.en || h.label,
          })) || uniqueCodes.map(code => ({ code, label_de: code, label_en: code }));
          
          // Generate path in background (don't await - don't block the chat)
          generatePath({
            sessionId,
            hpoCodes: uniqueCodes,
            hpoLabels: labels,
            observations,
          }, {
            onSuccess: () => {
              // Refresh the paths panel after successful generation
              setPathGenerationCount(prev => prev + 1);
            },
          });
          
          // Track HPO codes for guideline search
          setCollectedHpoCodes(prev => {
            const newCodes = [...new Set([...prev, ...uniqueCodes])];
            return newCodes;
          });
        }
      }

      // Check if session is complete
      if (data.isComplete) {
        setCompletedCategories(prev => [...prev, currentCategory, 'summary']);
        setCurrentCategory('summary');
        onComplete?.();
      }
    } catch (error) {
      console.error('Chat error:', error);
      const errorMessage: Message = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: language === 'de' 
          ? 'Entschuldigung, es gab einen Fehler. Bitte versuchen Sie es erneut.'
          : 'Sorry, there was an error. Please try again.',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  const handleManualEnd = async () => {
    setIsEnding(true);
    try {
      // Update session status to completed
      await supabase
        .from('anamnesis_sessions')
        .update({ 
          status: 'completed',
          completed_at: new Date().toISOString()
        })
        .eq('id', sessionId);

      // Add a final message
      const endMessage: Message = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: language === 'de' 
          ? 'Die Anamnese wurde manuell beendet. Sie werden nun zur Evidenzsuche weitergeleitet.'
          : 'The anamnesis has been manually ended. You will now be redirected to the evidence search.',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, endMessage]);
      await saveMessage(endMessage);

      setCompletedCategories(prev => [...prev, currentCategory, 'summary']);
      setCurrentCategory('summary');
      
      // Small delay before navigating
      setTimeout(() => {
        onComplete?.();
      }, 1500);
    } catch (error) {
      console.error('Error ending session:', error);
    } finally {
      setIsEnding(false);
    }
  };

  return (
    <div className="flex h-full bg-background rounded-lg border overflow-hidden">
      {/* Main Chat Area */}
      <div className={cn(
        "flex flex-col flex-1 min-w-0 transition-all duration-300",
        showSidebar && !isMobile && "mr-0"
      )}>
        {/* Progress */}
        <div className="p-4 pb-0 flex items-start gap-2">
          <div className="flex-1">
            <AnamnesisProgress
              currentCategory={currentCategory}
              completedCategories={completedCategories}
              redFlagCount={redFlagCount}
              questionCount={questionCount}
              maxQuestions={15}
              onCategorySelect={handleCategorySelect}
              isLoading={isLoading}
            />
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              className="shrink-0"
              onClick={() => setShowSidebar(!showSidebar)}
              title={language === 'de' ? 'Symptome ein-/ausblenden' : 'Toggle symptoms panel'}
            >
              {showSidebar ? (
                <PanelRightClose className="h-4 w-4" />
              ) : (
                <PanelRightOpen className="h-4 w-4" />
              )}
            </Button>
            {pathGenerationCount > 0 && (
              <Badge variant="outline" className="gap-1 text-xs">
                <GitBranch className="h-3 w-3" />
                {pathGenerationCount}
              </Badge>
            )}
            {isGeneratingPath && (
              <Badge variant="secondary" className="gap-1 text-xs animate-pulse">
                <Loader2 className="h-3 w-3 animate-spin" />
                {language === 'de' ? 'Pfad...' : 'Path...'}
              </Badge>
            )}
            {isPipelineRunning && (
              <Badge variant="outline" className="gap-1 text-xs animate-pulse">
                <Zap className="h-3 w-3" />
                {language === 'de' ? 'Analyse...' : 'Analysis...'}
              </Badge>
            )}
            
            {/* Guideline Search */}
            <GuidelineSearch 
              hpoCodes={collectedHpoCodes}
              sessionContext={messages.slice(-5).map(m => m.content).join(' ')}
            />
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="shrink-0 gap-1.5"
                  disabled={isEnding || messages.length < 3}
                >
                  <CheckCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">
                    {language === 'de' ? 'Beenden' : 'End'}
                  </span>
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>
                    {language === 'de' ? 'Anamnese beenden?' : 'End Anamnesis?'}
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    {language === 'de' 
                      ? 'Möchten Sie die Anamnese jetzt beenden und zur Evidenzsuche übergehen? Die bisherigen Angaben werden gespeichert.'
                      : 'Do you want to end the anamnesis now and proceed to the evidence search? Your current responses will be saved.'}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>
                    {language === 'de' ? 'Abbrechen' : 'Cancel'}
                  </AlertDialogCancel>
                  <AlertDialogAction onClick={handleManualEnd} disabled={isEnding}>
                    {isEnding ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <CheckCircle className="h-4 w-4 mr-2" />
                    )}
                    {language === 'de' ? 'Ja, beenden' : 'Yes, end'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-2">
            {isLoadingHistory ? (
              <div className="flex justify-center py-8">
                <div className="text-center">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">
                    {language === 'de' ? 'Lade Gesprächsverlauf...' : 'Loading conversation...'}
                  </p>
                </div>
              </div>
            ) : (
              <>
                {messages.map((message) => (
                  <MessageBubble 
                    key={message.id} 
                    message={message} 
                    language={language === 'de' ? 'de-DE' : 'en-US'}
                  />
                ))}
                {isLoading && (
                  <div className="flex justify-start my-3">
                    <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3">
                      <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                    </div>
                  </div>
                )}
                
                {/* Show observations summary in chat when on mobile or sidebar hidden */}
                {currentCategory === 'summary' && (isMobile || !showSidebar) && (
                  <div className="my-4">
                    <ObservationsSummary 
                      sessionId={sessionId} 
                      language={language}
                      isExpanded={true}
                      refreshTrigger={observationsRefresh}
                    />
                  </div>
                )}
              </>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="p-4 border-t">
          <div className="flex gap-2">
            {voiceSupported && (
              <Button
                variant={isListening ? 'destructive' : 'outline'}
                size="icon"
                onClick={toggleListening}
                title={t('anamnesis.voiceInput')}
                disabled={isLoadingHistory}
              >
                {isListening ? (
                  <MicOff className="h-4 w-4" />
                ) : (
                  <Mic className="h-4 w-4" />
                )}
              </Button>
            )}
            
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={t('anamnesis.typeMessage')}
              disabled={isLoading || isLoadingHistory}
              className="flex-1"
            />
            
            <Button
              onClick={sendMessage}
              disabled={!input.trim() || isLoading || isLoadingHistory}
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Observations Sidebar */}
      {showSidebar && !isMobile && (
        <div className="w-80 border-l bg-muted/30 flex flex-col overflow-hidden">
          <div className="p-3 border-b bg-background/50">
            <h3 className="font-medium text-sm flex items-center justify-between">
              {language === 'de' ? 'Erfasste Symptome' : 'Recorded Symptoms'}
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => setShowSidebar(false)}
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </h3>
          </div>
          
          {/* Lab Value Input Section */}
          <Collapsible open={showLabInput} onOpenChange={setShowLabInput} className="border-b">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className="w-full justify-between px-3 py-2 h-auto">
                <span className="flex items-center gap-2 text-sm font-medium">
                  <FlaskConical className="h-4 w-4" />
                  {language === 'de' ? 'Laborwert hinzufügen' : 'Add Lab Value'}
                </span>
                {showLabInput ? (
                  <ChevronUp className="h-4 w-4" />
                ) : (
                  <ChevronDown className="h-4 w-4" />
                )}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="px-3 pb-3">
              <LabValueInput
                onSubmit={(value, unit, ucumCode) => {
                  // Add lab value as chat input
                  const labMessage = `${language === 'de' ? 'Laborwert' : 'Lab value'}: ${value} ${unit} (UCUM: ${ucumCode})`;
                  setInput(labMessage);
                }}
                placeholder={language === 'de' ? 'z.B. 120' : 'e.g. 120'}
                disabled={isLoading}
              />
            </CollapsibleContent>
          </Collapsible>
          
          <ScrollArea className="flex-1 p-3">
            <ObservationsSummary 
              sessionId={sessionId} 
              language={language}
              isExpanded={true}
              showExport={true}
              refreshTrigger={observationsRefresh}
            />
            
            {/* Pipeline Analysis Results */}
            {(pipelineResult || isPipelineRunning) && (
              <div className="mt-4 pt-4 border-t">
                <PipelineResultsPanel
                  result={pipelineResult}
                  isRunning={isPipelineRunning}
                  language={language}
                />
              </div>
            )}
            
            {/* Differential Diagnoses and Paths */}
            <div className="mt-4 pt-4 border-t">
              <SidebarPathsPanel
                sessionId={sessionId}
                language={language}
                refreshTrigger={pathGenerationCount}
              />
            </div>
          </ScrollArea>
        </div>
      )}

      {/* Mobile Sidebar Overlay */}
      {showSidebar && isMobile && (
        <div 
          className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm"
          onClick={() => setShowSidebar(false)}
        >
          <div 
            className="absolute right-0 top-0 h-full w-80 max-w-[85vw] bg-background border-l shadow-xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b flex items-center justify-between">
              <h3 className="font-medium">
                {language === 'de' ? 'Erfasste Symptome' : 'Recorded Symptoms'}
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSidebar(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Lab Value Input for Mobile */}
            <Collapsible className="border-b">
              <CollapsibleTrigger asChild>
                <Button variant="ghost" className="w-full justify-between px-4 py-2 h-auto rounded-none">
                  <span className="flex items-center gap-2 text-sm font-medium">
                    <FlaskConical className="h-4 w-4" />
                    {language === 'de' ? 'Laborwert hinzufügen' : 'Add Lab Value'}
                  </span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="px-4 pb-3">
                <LabValueInput
                  onSubmit={(value, unit, ucumCode) => {
                    const labMessage = `${language === 'de' ? 'Laborwert' : 'Lab value'}: ${value} ${unit} (UCUM: ${ucumCode})`;
                    setInput(labMessage);
                    setShowSidebar(false);
                  }}
                  disabled={isLoading}
                />
              </CollapsibleContent>
            </Collapsible>
            
            <ScrollArea className="flex-1 p-4">
              <ObservationsSummary 
                sessionId={sessionId} 
                language={language}
                isExpanded={true}
                showExport={true}
                refreshTrigger={observationsRefresh}
              />
              
              {/* Pipeline Analysis Results */}
              {(pipelineResult || isPipelineRunning) && (
                <div className="mt-4 pt-4 border-t">
                  <PipelineResultsPanel
                    result={pipelineResult}
                    isRunning={isPipelineRunning}
                    language={language}
                  />
                </div>
              )}
              
              {/* Differential Diagnoses and Paths */}
              <div className="mt-4 pt-4 border-t">
                <SidebarPathsPanel
                  sessionId={sessionId}
                  language={language}
                  refreshTrigger={pathGenerationCount}
                />
              </div>
            </ScrollArea>
          </div>
        </div>
      )}
    </div>
  );
}
