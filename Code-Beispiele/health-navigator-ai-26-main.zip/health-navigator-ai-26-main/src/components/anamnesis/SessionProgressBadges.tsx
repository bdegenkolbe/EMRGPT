 import { cn } from '@/lib/utils';
 import { 
   AlertCircle, 
   Heart, 
   Stethoscope, 
   Pill, 
   Users, 
   ClipboardCheck,
   CheckCircle2,
   Activity
 } from 'lucide-react';
 import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
 
 export type AnamnesisCategory = 
   | 'chief_complaint' 
   | 'hpi' 
   | 'ros' 
   | 'pmh' 
   | 'medications'
   | 'social' 
   | 'family' 
   | 'summary';
 
 interface CategoryInfo {
   id: AnamnesisCategory;
   labelDe: string;
   labelEn: string;
   icon: React.ElementType;
 }
 
 const CATEGORIES: CategoryInfo[] = [
   { id: 'chief_complaint', labelDe: 'Hauptbeschwerde', labelEn: 'Chief Complaint', icon: AlertCircle },
   { id: 'hpi', labelDe: 'Aktuelle Beschwerden', labelEn: 'History of Present Illness', icon: Activity },
   { id: 'ros', labelDe: 'Systemübersicht', labelEn: 'Review of Systems', icon: Stethoscope },
   { id: 'pmh', labelDe: 'Vorerkrankungen', labelEn: 'Past Medical History', icon: ClipboardCheck },
   { id: 'medications', labelDe: 'Medikamente', labelEn: 'Medications', icon: Pill },
   { id: 'social', labelDe: 'Sozialanamnese', labelEn: 'Social History', icon: Users },
   { id: 'family', labelDe: 'Familienanamnese', labelEn: 'Family History', icon: Heart },
   { id: 'summary', labelDe: 'Zusammenfassung', labelEn: 'Summary', icon: CheckCircle2 },
 ];
 
 interface SessionProgressBadgesProps {
   completedCategories: AnamnesisCategory[];
   currentCategory?: AnamnesisCategory;
   compact?: boolean;
   language?: string;
 }
 
 export function SessionProgressBadges({ 
   completedCategories, 
   currentCategory,
   compact = false,
   language = 'de'
 }: SessionProgressBadgesProps) {
   const isGerman = language === 'de';
   const currentIndex = currentCategory 
     ? CATEGORIES.findIndex(c => c.id === currentCategory) 
     : -1;
 
   if (compact) {
     // Just show icons in a row
     return (
       <TooltipProvider delayDuration={200}>
         <div className="flex items-center gap-0.5">
           {CATEGORIES.map((category, index) => {
             const isCompleted = completedCategories.includes(category.id);
             const isCurrent = category.id === currentCategory;
             const Icon = category.icon;
             const label = isGerman ? category.labelDe : category.labelEn;
 
             return (
               <Tooltip key={category.id}>
                 <TooltipTrigger asChild>
                   <div
                     className={cn(
                       "w-5 h-5 rounded-full flex items-center justify-center transition-colors",
                       isCompleted && "bg-primary/20 text-primary",
                       isCurrent && "bg-primary text-primary-foreground",
                       !isCompleted && !isCurrent && "bg-muted text-muted-foreground/50"
                     )}
                   >
                     <Icon className="h-2.5 w-2.5" />
                   </div>
                 </TooltipTrigger>
                 <TooltipContent side="top" className="text-xs">
                   <span>{label}</span>
                   {isCompleted && <span className="text-primary ml-1">✓</span>}
                 </TooltipContent>
               </Tooltip>
             );
           })}
         </div>
       </TooltipProvider>
     );
   }
 
   // Full badges view
   return (
     <TooltipProvider delayDuration={200}>
       <div className="flex flex-wrap gap-1">
         {CATEGORIES.map((category, index) => {
           const isCompleted = completedCategories.includes(category.id);
           const isCurrent = category.id === currentCategory;
           const isPending = currentIndex >= 0 && index > currentIndex;
           const Icon = category.icon;
           const label = isGerman ? category.labelDe : category.labelEn;
 
           return (
             <Tooltip key={category.id}>
               <TooltipTrigger asChild>
                 <div
                   className={cn(
                     "flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-medium transition-colors",
                     isCompleted && "bg-primary/15 text-primary border border-primary/20",
                     isCurrent && "bg-primary text-primary-foreground",
                     !isCompleted && !isCurrent && "bg-muted text-muted-foreground opacity-60"
                   )}
                 >
                   <Icon className="h-3 w-3" />
                   <span className="hidden sm:inline">{label}</span>
                 </div>
               </TooltipTrigger>
               <TooltipContent side="top" className="text-xs">
                 <span>{label}</span>
                 {isCompleted && <span className="text-primary ml-1">✓</span>}
                 {isCurrent && <span className="text-primary ml-1">→</span>}
               </TooltipContent>
             </Tooltip>
           );
         })}
       </div>
     </TooltipProvider>
   );
 }