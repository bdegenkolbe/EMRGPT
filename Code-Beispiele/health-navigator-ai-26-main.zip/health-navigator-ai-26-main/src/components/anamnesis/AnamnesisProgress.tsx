import { useTranslation } from 'react-i18next';
import { cn } from '@/lib/utils';
import { 
  AlertCircle, 
  Heart, 
  Stethoscope, 
  Pill, 
  Users, 
  ClipboardCheck,
  CheckCircle2,
  Activity
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export type AnamnesisCategory = 
  | 'chief_complaint' 
  | 'hpi' 
  | 'ros' 
  | 'pmh' 
  | 'medications'
  | 'social' 
  | 'family' 
  | 'summary';

interface CategoryInfo {
  id: AnamnesisCategory;
  labelKey: string;
  labelDe: string;
  labelEn: string;
  icon: React.ElementType;
  description: string;
}

const CATEGORIES: CategoryInfo[] = [
  { id: 'chief_complaint', labelKey: 'anamnesis.categories.chiefComplaint', labelDe: 'Hauptbeschwerde', labelEn: 'Chief Complaint', icon: AlertCircle, description: 'Warum sind Sie hier?' },
  { id: 'hpi', labelKey: 'anamnesis.categories.hpi', labelDe: 'Aktuelle Beschwerden', labelEn: 'History of Present Illness', icon: Activity, description: 'Details zu Ihren Symptomen' },
  { id: 'ros', labelKey: 'anamnesis.categories.ros', labelDe: 'Systemübersicht', labelEn: 'Review of Systems', icon: Stethoscope, description: 'Weitere Symptome' },
  { id: 'pmh', labelKey: 'anamnesis.categories.pmh', labelDe: 'Vorerkrankungen', labelEn: 'Past Medical History', icon: ClipboardCheck, description: 'Frühere Erkrankungen' },
  { id: 'medications', labelKey: 'anamnesis.categories.medications', labelDe: 'Medikamente', labelEn: 'Medications', icon: Pill, description: 'Aktuelle Medikation' },
  { id: 'social', labelKey: 'anamnesis.categories.social', labelDe: 'Sozialanamnese', labelEn: 'Social History', icon: Users, description: 'Lebensstil & Gewohnheiten' },
  { id: 'family', labelKey: 'anamnesis.categories.family', labelDe: 'Familienanamnese', labelEn: 'Family History', icon: Heart, description: 'Erkrankungen in der Familie' },
  { id: 'summary', labelKey: 'anamnesis.categories.summary', labelDe: 'Zusammenfassung', labelEn: 'Summary', icon: CheckCircle2, description: 'Abschluss der Anamnese' },
];

interface AnamnesisProgressProps {
  currentCategory: AnamnesisCategory;
  completedCategories: AnamnesisCategory[];
  redFlagCount?: number;
  questionCount?: number;
  maxQuestions?: number;
  onCategorySelect?: (category: AnamnesisCategory) => void;
  isLoading?: boolean;
}

export function AnamnesisProgress({ 
  currentCategory, 
  completedCategories,
  redFlagCount = 0,
  questionCount = 0,
  maxQuestions = 15,
  onCategorySelect,
  isLoading = false
}: AnamnesisProgressProps) {
  const { t, i18n } = useTranslation();
  const isGerman = i18n.language === 'de';
  
  const currentIndex = CATEGORIES.findIndex(c => c.id === currentCategory);
  const progressPercent = Math.min((completedCategories.length / (CATEGORIES.length - 1)) * 100, 100);

  return (
    <div className="bg-card border rounded-lg p-4 mb-4 space-y-4">
      {/* Header with stats */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-sm font-medium">
            {isGerman ? 'Anamnese-Fortschritt' : 'Anamnesis Progress'}
          </h3>
          <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
            {completedCategories.length}/{CATEGORIES.length - 1} {isGerman ? 'Abschnitte' : 'sections'}
          </span>
        </div>
        <div className="flex items-center gap-3">
          {questionCount > 0 && (
            <span className="text-xs text-muted-foreground">
              {questionCount}/{maxQuestions} {isGerman ? 'Fragen' : 'questions'}
            </span>
          )}
        {redFlagCount > 0 && (
          <div className="flex items-center gap-1 text-destructive text-sm font-medium">
            <AlertCircle className="h-4 w-4" />
              {redFlagCount} Red Flags
          </div>
        )}
        </div>
      </div>
      
      {/* Progress Bar with gradient */}
      <Progress value={progressPercent} className="h-2" />
      
      {/* Category Steps */}
      <TooltipProvider delayDuration={300}>
        <div className="flex flex-wrap gap-2">
        {CATEGORIES.map((category, index) => {
          const isCompleted = completedCategories.includes(category.id);
          const isCurrent = category.id === currentCategory;
          const isPending = index > currentIndex;
          const Icon = category.icon;
            const label = isGerman ? category.labelDe : category.labelEn;
            const canNavigate = onCategorySelect && !isLoading && category.id !== 'summary';
          
          return (
              <Tooltip key={category.id}>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    onClick={() => canNavigate && onCategorySelect(category.id)}
                    disabled={isLoading || category.id === 'summary'}
              className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium transition-all",
                      canNavigate && "cursor-pointer hover:ring-2 hover:ring-primary/30",
                      !canNavigate && "cursor-default",
                    isCompleted && "bg-primary/15 text-primary border border-primary/20",
                    isCurrent && "bg-primary text-primary-foreground shadow-sm ring-2 ring-primary/20",
                      isPending && "bg-muted text-muted-foreground opacity-60",
                      isLoading && "opacity-50"
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">
                    {label}
              </span>
                  {isCompleted && <CheckCircle2 className="h-3 w-3 ml-0.5" />}
                  </button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-[200px]">
                  <p className="font-medium">{label}</p>
                  <p className="text-xs text-muted-foreground">{category.description}</p>
                  {isCompleted && (
                    <p className="text-xs text-primary mt-1">✓ {isGerman ? 'Abgeschlossen' : 'Completed'}</p>
                  )}
                  {isCurrent && (
                    <p className="text-xs text-primary mt-1">→ {isGerman ? 'Aktuell' : 'Current'}</p>
                  )}
                  {canNavigate && !isCurrent && (
                    <p className="text-xs text-muted-foreground mt-1 italic">
                      {isGerman ? 'Klicken zum Wechseln' : 'Click to switch'}
                    </p>
                  )}
                </TooltipContent>
              </Tooltip>
          );
        })}
        </div>
      </TooltipProvider>
      </div>
  );
}
