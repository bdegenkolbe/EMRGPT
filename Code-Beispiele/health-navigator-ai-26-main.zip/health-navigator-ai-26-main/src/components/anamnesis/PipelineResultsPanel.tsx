import { useState } from 'react';
import { 
  ChevronDown, 
  ChevronRight, 
  Zap, 
  Clock, 
  Hash, 
  AlertTriangle, 
  Stethoscope, 
  Brain,
  CheckCircle2,
  Loader2,
  Activity,
  Sparkles
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { PipelineResult, PhaseResult } from '@/hooks/usePipelineOrchestration';

interface PipelineResultsPanelProps {
  result: PipelineResult | null;
  isRunning: boolean;
  language: string;
}

// Phase labels for display
const phaseLabels: Record<string, { de: string; en: string; icon: React.ElementType; color: string }> = {
  '-1': { de: 'Domänen-Klassifizierung', en: 'Domain Classification', icon: Brain, color: 'text-violet-500' },
  '1': { de: 'Intent & Sicherheit', en: 'Intent & Safety', icon: AlertTriangle, color: 'text-amber-500' },
  '2': { de: 'HPO-Mapping', en: 'HPO Mapping', icon: Hash, color: 'text-emerald-500' },
  '2b': { de: 'SNOMED-CT Mapping', en: 'SNOMED-CT Mapping', icon: Stethoscope, color: 'text-sky-500' },
  '3': { de: 'Symptom-Extraktion', en: 'Symptom Extraction', icon: Activity, color: 'text-rose-500' },
  '4': { de: 'Differentialdiagnosen', en: 'Differential Diagnoses', icon: Sparkles, color: 'text-purple-500' },
  '5': { de: 'Follow-up Fragen', en: 'Follow-up Questions', icon: Brain, color: 'text-cyan-500' },
};

// Format output for display
function formatOutput(output: Record<string, unknown>, phase: string): React.ReactNode {
  // Handle differential diagnoses specially
  if (phase === '4' && output?.differential_diagnoses) {
    const diagnoses = output.differential_diagnoses as Array<{
      rank?: number;
      diagnosis_name?: string;
      diagnosis_name_en?: string;
      probability?: string;
      icd10_code?: string;
      is_red_flag?: boolean;
    }>;
    
    return (
      <div className="space-y-2">
        {diagnoses.map((d, idx) => (
          <div 
            key={idx} 
            className={cn(
              "p-2 rounded-md border",
              d.is_red_flag ? "bg-destructive/10 border-destructive/30" : "bg-muted/30 border-transparent"
            )}
          >
            <div className="flex items-start gap-2">
              <span className="text-xs font-bold text-primary min-w-[18px]">
                #{d.rank || idx + 1}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium leading-tight">
                  {d.diagnosis_name}
                </p>
                {d.diagnosis_name_en && d.diagnosis_name !== d.diagnosis_name_en && (
                  <p className="text-[10px] text-muted-foreground italic">
                    {d.diagnosis_name_en}
                  </p>
                )}
                <div className="flex items-center gap-2 mt-1">
                  {d.icd10_code && (
                    <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 font-mono">
                      {d.icd10_code}
                    </Badge>
                  )}
                  {d.probability && (
                    <span className="text-[10px] text-muted-foreground">
                      {d.probability}
                    </span>
                  )}
                  {d.is_red_flag && (
                    <Badge variant="destructive" className="text-[9px] px-1 py-0 h-4">
                      Red Flag
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Handle HPO codes
  if (phase === '2' && output?.hpo_codes) {
    const codes = output.hpo_codes as Array<{
      code?: string;
      label?: string;
      confidence?: number;
    }>;
    
    return (
      <div className="flex flex-wrap gap-1">
        {codes.map((c, idx) => (
          <Badge 
            key={idx} 
            variant="secondary" 
            className="text-[10px] px-1.5 py-0.5"
          >
            <span className="font-mono mr-1">{c.code}</span>
            <span className="text-muted-foreground truncate max-w-[100px]">{c.label}</span>
          </Badge>
        ))}
      </div>
    );
  }

  // Handle symptoms
  if (phase === '3' && output?.symptoms) {
    const symptoms = output.symptoms as Array<{
      symptom?: string;
      negated?: boolean;
      severity?: string;
    }>;
    
    return (
      <div className="flex flex-wrap gap-1">
        {symptoms.map((s, idx) => (
          <Badge 
            key={idx} 
            variant={s.negated ? "outline" : "default"}
            className={cn(
              "text-[10px] px-1.5 py-0.5",
              s.negated && "line-through opacity-60"
            )}
          >
            {s.symptom}
            {s.severity && <span className="ml-1 opacity-70">({s.severity})</span>}
          </Badge>
        ))}
      </div>
    );
  }

  // Handle domain classification
  if (phase === '-1' && output?.domain) {
    return (
      <div className="flex items-center gap-2">
        <Badge className="text-xs">{output.domain as string}</Badge>
        {output.confidence && (
          <span className="text-[10px] text-muted-foreground">
            {Math.round((output.confidence as number) * 100)}% Konfidenz
          </span>
        )}
      </div>
    );
  }

  // Default JSON view
  return (
    <pre className="whitespace-pre-wrap break-words text-[10px] text-muted-foreground font-mono">
      {JSON.stringify(output, null, 2)}
    </pre>
  );
}

function PhaseCard({ phase, language, maxLatency }: { phase: PhaseResult; language: string; maxLatency: number }) {
  const [isOpen, setIsOpen] = useState(false);
  const isGerman = language === 'de';
  
  const phaseInfo = phaseLabels[phase.phase] || { 
    de: `Phase ${phase.phase}`, 
    en: `Phase ${phase.phase}`,
    icon: Zap,
    color: 'text-primary'
  };
  const Icon = phaseInfo.icon;
  const label = isGerman ? phaseInfo.de : phaseInfo.en;
  const output = phase.output as Record<string, unknown>;
  
  const latencyPercent = maxLatency > 0 ? (phase.latency_ms / maxLatency) * 100 : 0;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger className="w-full group">
        <div className={cn(
          "flex items-center gap-3 p-2.5 rounded-lg transition-all",
          "hover:bg-muted/50",
          isOpen && "bg-muted/30"
        )}>
          <div className={cn(
            "p-1.5 rounded-md transition-colors",
            isOpen ? "bg-primary/10" : "bg-muted/50 group-hover:bg-muted"
          )}>
            <Icon className={cn("h-4 w-4", phaseInfo.color)} />
          </div>
          
          <div className="flex-1 min-w-0 text-left">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium truncate">{label}</span>
              <CheckCircle2 className="h-3 w-3 text-emerald-500 shrink-0" />
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden max-w-[80px]">
                <div 
                  className="h-full bg-primary/40 rounded-full transition-all"
                  style={{ width: `${latencyPercent}%` }}
                />
              </div>
              <span className="text-[10px] text-muted-foreground tabular-nums">
                {phase.latency_ms.toLocaleString()}ms
              </span>
            </div>
          </div>

          <ChevronDown className={cn(
            "h-4 w-4 text-muted-foreground transition-transform shrink-0",
            isOpen && "rotate-180"
          )} />
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="ml-11 mr-2 mb-2 p-3 rounded-lg bg-muted/20 border">
          {formatOutput(output, phase.phase)}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

export function PipelineResultsPanel({ result, isRunning, language }: PipelineResultsPanelProps) {
  const isGerman = language === 'de';
  
  if (isRunning) {
    return (
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">
                {isGerman ? 'Pipeline wird ausgeführt...' : 'Running pipeline...'}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isGerman ? 'Analyse läuft' : 'Analysis in progress'}
              </p>
            </div>
          </div>
          <Progress value={33} className="mt-3 h-1" />
        </CardContent>
      </Card>
    );
  }
  
  if (!result) {
    return null;
  }

  const maxLatency = Math.max(...result.results.map(r => r.latency_ms));

  return (
    <Card className="overflow-hidden">
      <CardHeader className="p-4 pb-3 bg-gradient-to-r from-primary/5 to-transparent border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-primary/10">
              <Zap className="h-4 w-4 text-primary" />
            </div>
            {isGerman ? 'Pipeline-Analyse' : 'Pipeline Analysis'}
          </CardTitle>
          <Badge className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
            {result.domain}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="p-2">
        <div className="space-y-0.5">
          {result.results.map((phase, idx) => (
            <PhaseCard 
              key={`${phase.phase}-${idx}`} 
              phase={phase} 
              language={language}
              maxLatency={maxLatency}
            />
          ))}
        </div>
        
        {/* Summary Footer */}
        <div className="mt-3 mx-2 p-3 rounded-lg bg-muted/30 border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="text-center">
                <p className="text-lg font-bold text-primary">{result.phases_executed}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  {isGerman ? 'Phasen' : 'Phases'}
                </p>
              </div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center">
                <p className="text-lg font-bold">{(result.total_latency_ms / 1000).toFixed(1)}s</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  {isGerman ? 'Gesamt' : 'Total'}
                </p>
              </div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center">
                <p className="text-lg font-bold">{result.total_tokens.toLocaleString()}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  Tokens
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
