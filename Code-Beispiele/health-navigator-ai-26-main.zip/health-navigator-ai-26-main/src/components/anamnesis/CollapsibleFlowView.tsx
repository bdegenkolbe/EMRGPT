import { useState, useMemo } from 'react';
import { ChevronDown, ChevronRight, Circle, ArrowRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface CollapsibleFlowViewProps {
  diagram: string;
  className?: string;
}

interface SubgraphData {
  id: string;
  label: string;
  nodes: Array<{ id: string; label: string }>;
  connections: Array<{ from: string; to: string; label?: string }>;
}

// Category colors matching QuestionTreeView
const CATEGORY_COLORS: Record<string, string> = {
  'Chief_Complaint': 'border-l-destructive bg-destructive/5',
  'ChiefComplaint': 'border-l-destructive bg-destructive/5',
  'chief_complaint': 'border-l-destructive bg-destructive/5',
  'HPI': 'border-l-primary bg-primary/5',
  'hpi': 'border-l-primary bg-primary/5',
  'ROS': 'border-l-blue-500 bg-blue-500/5',
  'ros': 'border-l-blue-500 bg-blue-500/5',
  'PMH': 'border-l-orange-500 bg-orange-500/5',
  'pmh': 'border-l-orange-500 bg-orange-500/5',
  'Medications': 'border-l-purple-500 bg-purple-500/5',
  'medications': 'border-l-purple-500 bg-purple-500/5',
  'Social': 'border-l-green-500 bg-green-500/5',
  'social': 'border-l-green-500 bg-green-500/5',
  'Family': 'border-l-pink-500 bg-pink-500/5',
  'family': 'border-l-pink-500 bg-pink-500/5',
  'Assessment': 'border-l-amber-500 bg-amber-500/5',
  'assessment': 'border-l-amber-500 bg-amber-500/5',
  'RedFlags': 'border-l-red-600 bg-red-600/5',
  'red_flags': 'border-l-red-600 bg-red-600/5',
  'Differential': 'border-l-indigo-500 bg-indigo-500/5',
  'differential': 'border-l-indigo-500 bg-indigo-500/5',
};

// German labels for categories
const CATEGORY_LABELS: Record<string, string> = {
  'Chief_Complaint': 'Hauptbeschwerde',
  'ChiefComplaint': 'Hauptbeschwerde',
  'chief_complaint': 'Hauptbeschwerde',
  'HPI': 'Aktuelle Beschwerden',
  'hpi': 'Aktuelle Beschwerden',
  'ROS': 'Systemübersicht',
  'ros': 'Systemübersicht',
  'PMH': 'Vorerkrankungen',
  'pmh': 'Vorerkrankungen',
  'Medications': 'Medikamente',
  'medications': 'Medikamente',
  'Social': 'Sozialanamnese',
  'social': 'Sozialanamnese',
  'Family': 'Familienanamnese',
  'family': 'Familienanamnese',
  'Assessment': 'Beurteilung',
  'assessment': 'Beurteilung',
  'RedFlags': 'Red Flags',
  'red_flags': 'Red Flags',
  'Differential': 'Differentialdiagnosen',
  'differential': 'Differentialdiagnosen',
};

export function CollapsibleFlowView({ diagram, className }: CollapsibleFlowViewProps) {
  const [openSubgraphs, setOpenSubgraphs] = useState<Set<string>>(new Set());
  const [expandAll, setExpandAll] = useState(false);

  // Parse Mermaid diagram to extract subgraphs and nodes
  const parsedData = useMemo(() => {
    if (!diagram?.trim()) return { subgraphs: [], standaloneNodes: [], connections: [] };

    const subgraphs: SubgraphData[] = [];
    const standaloneNodes: Array<{ id: string; label: string }> = [];
    const allConnections: Array<{ from: string; to: string; label?: string }> = [];
    const nodesInSubgraphs = new Set<string>();

    // Extract subgraphs
    const subgraphRegex = /subgraph\s+(\w+)\s*\[([^\]]+)\]([^]*?)end/gi;
    let match;

    while ((match = subgraphRegex.exec(diagram)) !== null) {
      const [, id, label, content] = match;
      const nodes: Array<{ id: string; label: string }> = [];
      const connections: Array<{ from: string; to: string; label?: string }> = [];

      // Parse nodes within subgraph (format: nodeId[Label] or nodeId["Label"])
      const nodeRegex = /(\w+)\s*\[["']?([^\]"']+)["']?\]/g;
      let nodeMatch;
      while ((nodeMatch = nodeRegex.exec(content)) !== null) {
        const [, nodeId, nodeLabel] = nodeMatch;
        if (nodeId && nodeLabel && nodeId !== 'subgraph') {
          nodes.push({ id: nodeId, label: nodeLabel.trim() });
          nodesInSubgraphs.add(nodeId);
        }
      }

      // Parse connections within subgraph
      const connRegex = /(\w+)\s*--?>?\s*(?:\|([^|]+)\|)?\s*(\w+)/g;
      let connMatch;
      while ((connMatch = connRegex.exec(content)) !== null) {
        const [, from, connLabel, to] = connMatch;
        if (from && to && !from.match(/subgraph|end/i) && !to.match(/subgraph|end/i)) {
          connections.push({ from, to, label: connLabel?.trim() });
        }
      }

      subgraphs.push({
        id,
        label: label.trim(),
        nodes,
        connections,
      });
    }

    // Parse global connections
    const globalConnRegex = /(\w+)\s*--?>?\s*(?:\|([^|]+)\|)?\s*(\w+)/g;
    while ((match = globalConnRegex.exec(diagram)) !== null) {
      const [, from, label, to] = match;
      if (from && to && !from.match(/subgraph|end|flowchart/i) && !to.match(/subgraph|end/i)) {
        allConnections.push({ from, to, label: label?.trim() });
      }
    }

    // Parse standalone nodes (not in subgraphs)
    const allNodeRegex = /(\w+)\s*\[["']?([^\]"']+)["']?\]/g;
    while ((match = allNodeRegex.exec(diagram)) !== null) {
      const [, nodeId, nodeLabel] = match;
      if (nodeId && nodeLabel && !nodesInSubgraphs.has(nodeId) && nodeId !== 'subgraph') {
        standaloneNodes.push({ id: nodeId, label: nodeLabel.trim() });
      }
    }

    return { subgraphs, standaloneNodes, connections: allConnections };
  }, [diagram]);

  const toggleSubgraph = (id: string) => {
    setOpenSubgraphs(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleExpandAll = () => {
    if (expandAll) {
      setOpenSubgraphs(new Set());
    } else {
      setOpenSubgraphs(new Set(parsedData.subgraphs.map(s => s.id)));
    }
    setExpandAll(!expandAll);
  };

  if (parsedData.subgraphs.length === 0 && parsedData.standaloneNodes.length === 0) {
    return (
      <Card className={className}>
        <CardContent className="p-4 text-center text-muted-foreground">
          <p className="text-sm">Keine Struktur im Diagramm erkannt.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={cn("space-y-2", className)}>
      {/* Header with expand/collapse all */}
      <div className="flex items-center justify-between px-1">
        <span className="text-xs text-muted-foreground">
          {parsedData.subgraphs.length} Kategorien
        </span>
        <button
          onClick={handleExpandAll}
          className="text-xs text-primary hover:underline"
        >
          {expandAll ? 'Alle zuklappen' : 'Alle aufklappen'}
        </button>
      </div>

      {/* Standalone nodes (start node, etc.) */}
      {parsedData.standaloneNodes.length > 0 && (
        <div className="flex flex-wrap gap-2 p-2 bg-muted/30 rounded-md">
          {parsedData.standaloneNodes.slice(0, 3).map(node => (
            <Badge key={node.id} variant="secondary" className="text-xs">
              {node.label}
            </Badge>
          ))}
        </div>
      )}

      {/* Subgraphs */}
      {parsedData.subgraphs.map((subgraph, idx) => {
        const isOpen = openSubgraphs.has(subgraph.id);
        const colorClass = CATEGORY_COLORS[subgraph.id] || 'border-l-muted-foreground bg-muted/30';
        const displayLabel = CATEGORY_LABELS[subgraph.id] || subgraph.label;
        
        // Find connections leading to next subgraph
        const nextSubgraph = parsedData.subgraphs[idx + 1];
        const hasConnectionToNext = nextSubgraph && parsedData.connections.some(
          c => parsedData.subgraphs.some(s => s.nodes.some(n => n.id === c.from)) &&
               nextSubgraph.nodes.some(n => n.id === c.to)
        );

        return (
          <div key={subgraph.id}>
            <Collapsible open={isOpen} onOpenChange={() => toggleSubgraph(subgraph.id)}>
              <CollapsibleTrigger className="w-full">
                <Card className={cn(
                  "border-l-4 transition-all hover:shadow-md",
                  colorClass,
                  isOpen && "ring-1 ring-primary/30"
                )}>
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {isOpen ? (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="font-medium text-sm">{displayLabel}</span>
                        <Badge variant="outline" className="text-xs">
                          {subgraph.nodes.length} Schritte
                        </Badge>
                      </div>
                      {!isOpen && subgraph.nodes.length > 0 && (
                        <span className="text-xs text-muted-foreground truncate max-w-[200px]">
                          {subgraph.nodes[0].label}...
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <div className="ml-4 mt-1 space-y-1 border-l-2 border-muted pl-4 py-2">
                  {subgraph.nodes.map((node, nodeIdx) => {
                    // Find outgoing connections from this node
                    const outgoing = subgraph.connections.filter(c => c.from === node.id);
                    
                    return (
                      <div key={node.id} className="flex items-start gap-2 group">
                        <Circle className="h-2 w-2 mt-1.5 text-muted-foreground fill-current flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm leading-relaxed">{node.label}</p>
                          {outgoing.length > 0 && outgoing[0].label && (
                            <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                              <ArrowRight className="h-3 w-3" />
                              {outgoing[0].label}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Connection arrow to next category */}
            {hasConnectionToNext && (
              <div className="flex justify-center py-1">
                <ArrowRight className="h-4 w-4 text-muted-foreground rotate-90" />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
