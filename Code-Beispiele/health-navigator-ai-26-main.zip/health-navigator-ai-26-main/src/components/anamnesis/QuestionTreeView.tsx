import { useState, useCallback, useMemo } from 'react';
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragOverEvent,
  DragStartEvent,
  DragOverlay,
  pointerWithin,
  rectIntersection,
} from '@dnd-kit/core';
import {
  arrayMove,
  sortableKeyboardCoordinates,
} from '@dnd-kit/sortable';
import { 
  ChevronDown, 
  ChevronRight, 
  HelpCircle,
  AlertCircle,
  Activity,
  Stethoscope,
  ClipboardCheck,
  Pill,
  Users,
  Heart,
  Plus,
  Save,
  Loader2,
  Printer,
  Undo2,
  Redo2
} from 'lucide-react';
import { downloadChecklistPDF } from '@/lib/export/pdfGenerator';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';
import { SortableQuestionItem } from './SortableQuestionItem';
import { DroppableCategory } from './DroppableCategory';

// Category metadata
const CATEGORY_META: Record<string, { labelDe: string; labelEn: string; icon: React.ElementType; color: string }> = {
  chief_complaint: { labelDe: 'Hauptbeschwerde', labelEn: 'Chief Complaint', icon: AlertCircle, color: 'text-destructive' },
  hpi: { labelDe: 'Aktuelle Beschwerden', labelEn: 'History of Present Illness', icon: Activity, color: 'text-primary' },
  ros: { labelDe: 'Systemübersicht', labelEn: 'Review of Systems', icon: Stethoscope, color: 'text-blue-500' },
  pmh: { labelDe: 'Vorerkrankungen', labelEn: 'Past Medical History', icon: ClipboardCheck, color: 'text-orange-500' },
  medications: { labelDe: 'Medikamente', labelEn: 'Medications', icon: Pill, color: 'text-purple-500' },
  social: { labelDe: 'Sozialanamnese', labelEn: 'Social History', icon: Users, color: 'text-green-500' },
  family: { labelDe: 'Familienanamnese', labelEn: 'Family History', icon: Heart, color: 'text-pink-500' },
};

// Ordered keys
const CATEGORY_ORDER = ['chief_complaint', 'hpi', 'ros', 'pmh', 'medications', 'social', 'family'];

interface QuestionItem {
  question?: string;
  text?: string;
  followUp?: string[];
  options?: string[];
  type?: string;
}

interface QuestionTreeViewProps {
  questionTree: Record<string, unknown>;
  language?: string;
  className?: string;
  editable?: boolean;
  onSave?: (updatedTree: Record<string, unknown>) => Promise<void>;
  patientIdentifier?: string;
  sessionDate?: string;
}

export function QuestionTreeView({ 
  questionTree, 
  language = 'de', 
  className,
  editable = false,
  onSave,
  patientIdentifier,
  sessionDate
}: QuestionTreeViewProps) {
  const [openCategories, setOpenCategories] = useState<Set<string>>(new Set(['chief_complaint', 'hpi']));
  const [editingQuestion, setEditingQuestion] = useState<{ category: string; index: number } | null>(null);
  const [editValue, setEditValue] = useState('');
  const [localTree, setLocalTree] = useState<Record<string, unknown>>(questionTree);
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<{ category: string; index: number } | null>(null);
  const [addingToCategory, setAddingToCategory] = useState<string | null>(null);
  const [newQuestionValue, setNewQuestionValue] = useState('');
  const [activeId, setActiveId] = useState<string | null>(null);
  
  // Undo/Redo history
  const [history, setHistory] = useState<Record<string, unknown>[]>([questionTree]);
  const [historyIndex, setHistoryIndex] = useState(0);
  
  const isGerman = language === 'de';
  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  // Update tree with history tracking
  const updateTreeWithHistory = useCallback((newTree: Record<string, unknown>) => {
    setLocalTree(newTree);
    setHistory(prev => {
      // Remove any redo states when making a new change
      const newHistory = prev.slice(0, historyIndex + 1);
      newHistory.push(newTree);
      // Limit history to 50 states
      if (newHistory.length > 50) {
        newHistory.shift();
        return newHistory;
      }
      return newHistory;
    });
    setHistoryIndex(prev => Math.min(prev + 1, 49));
    setHasChanges(true);
  }, [historyIndex]);

  // Undo action
  const handleUndo = useCallback(() => {
    if (!canUndo) return;
    const newIndex = historyIndex - 1;
    setHistoryIndex(newIndex);
    setLocalTree(history[newIndex]);
    setHasChanges(newIndex !== 0);
  }, [canUndo, historyIndex, history]);

  // Redo action
  const handleRedo = useCallback(() => {
    if (!canRedo) return;
    const newIndex = historyIndex + 1;
    setHistoryIndex(newIndex);
    setLocalTree(history[newIndex]);
    setHasChanges(true);
  }, [canRedo, historyIndex, history]);

  // DnD sensors with activation constraints
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Parse item ID to get category and index
  const parseItemId = (id: string): { category: string; index: number } | null => {
    const parts = String(id).split('-');
    const index = parseInt(parts.pop() || '0');
    const category = parts.join('-');
    return category ? { category, index } : null;
  };

  // Handle drag start
  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(String(event.active.id));
  };

  // Handle drag end for reordering (within same category or cross-category)
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);
    
    if (!over) return;

    const activeData = parseItemId(String(active.id));
    if (!activeData) return;

    // Check if dropping on a category directly (empty category or category header)
    const overId = String(over.id);
    if (overId.startsWith('category-')) {
      const targetCategory = overId.replace('category-', '');
      if (targetCategory !== activeData.category) {
        // Move to end of target category
        moveQuestionBetweenCategories(
          activeData.category,
          activeData.index,
          targetCategory,
          extractQuestions(localTree[targetCategory]).length
        );
      }
      return;
    }

    const overData = parseItemId(overId);
    if (!overData) return;

    // Same category - reorder
    if (activeData.category === overData.category) {
      if (activeData.index !== overData.index) {
        const questions = extractQuestions(localTree[activeData.category]);
        const reorderedQuestions = arrayMove(questions, activeData.index, overData.index);
        
        updateTreeWithHistory({
          ...localTree,
          [activeData.category]: questionsToStorageFormat(reorderedQuestions)
        });
      }
    } else {
      // Different category - move item
      moveQuestionBetweenCategories(
        activeData.category,
        activeData.index,
        overData.category,
        overData.index
      );
    }
  };

  // Move question from one category to another
  const moveQuestionBetweenCategories = (
    fromCategory: string,
    fromIndex: number,
    toCategory: string,
    toIndex: number
  ) => {
    const fromQuestions = extractQuestions(localTree[fromCategory]);
    const toQuestions = extractQuestions(localTree[toCategory]);
    
    // Remove from source
    const [movedQuestion] = fromQuestions.splice(fromIndex, 1);
    
    // Insert into target
    toQuestions.splice(toIndex, 0, movedQuestion);
    
    updateTreeWithHistory({
      ...localTree,
      [fromCategory]: questionsToStorageFormat(fromQuestions),
      [toCategory]: questionsToStorageFormat(toQuestions),
    });
  };

  // Custom collision detection that prefers items but falls back to categories
  const collisionDetection = useCallback((args: Parameters<typeof closestCenter>[0]) => {
    // First check for pointer collisions with items
    const pointerCollisions = pointerWithin(args);
    if (pointerCollisions.length > 0) {
      return pointerCollisions;
    }
    
    // Fall back to rect intersection for categories
    return rectIntersection(args);
  }, []);

  const toggleCategory = (key: string) => {
    setOpenCategories(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  // Extract questions from various formats the AI might return
  const extractQuestions = useCallback((categoryData: unknown): QuestionItem[] => {
    if (!categoryData) return [];
    
    // If it's an array of strings
    if (Array.isArray(categoryData)) {
      return categoryData.map(item => {
        if (typeof item === 'string') {
          return { question: item };
        }
        if (typeof item === 'object' && item !== null) {
          const obj = item as Record<string, unknown>;
          return {
            question: (obj.question || obj.text || obj.label || obj.q) as string | undefined,
            followUp: obj.followUp as string[] | undefined,
            options: obj.options as string[] | undefined,
            type: obj.type as string | undefined,
          };
        }
        return { question: String(item) };
      });
    }
    
    // If it's an object with questions array
    if (typeof categoryData === 'object' && categoryData !== null) {
      const obj = categoryData as Record<string, unknown>;
      if (obj.questions && Array.isArray(obj.questions)) {
        return extractQuestions(obj.questions);
      }
      // If it has text/question property
      if (obj.question || obj.text) {
        return [{ question: (obj.question || obj.text) as string }];
      }
    }
    
    // If it's a string
    if (typeof categoryData === 'string') {
      return [{ question: categoryData }];
    }
    
    return [];
  }, []);

  // Convert questions back to storage format
  const questionsToStorageFormat = (questions: QuestionItem[]): unknown[] => {
    return questions.map(q => {
      if (q.followUp?.length || q.options?.length || q.type) {
        return {
          question: q.question || q.text,
          ...(q.followUp?.length && { followUp: q.followUp }),
          ...(q.options?.length && { options: q.options }),
          ...(q.type && { type: q.type }),
        };
      }
      return q.question || q.text || '';
    });
  };

  // Start editing a question
  const startEdit = (category: string, index: number, currentValue: string) => {
    setEditingQuestion({ category, index });
    setEditValue(currentValue);
  };

  // Cancel editing
  const cancelEdit = () => {
    setEditingQuestion(null);
    setEditValue('');
  };

  // Save edited question
  const saveEdit = () => {
    if (!editingQuestion || !editValue.trim()) return;
    
    const { category, index } = editingQuestion;
    const questions = extractQuestions(localTree[category]);
    
    if (questions[index]) {
      questions[index] = { ...questions[index], question: editValue.trim() };
      
      updateTreeWithHistory({
        ...localTree,
        [category]: questionsToStorageFormat(questions)
      });
    }
    
    cancelEdit();
  };

  // Delete a question
  const deleteQuestion = (category: string, index: number) => {
    const questions = extractQuestions(localTree[category]);
    questions.splice(index, 1);
    
    updateTreeWithHistory({
      ...localTree,
      [category]: questionsToStorageFormat(questions)
    });
    setDeleteConfirm(null);
  };

  // Add new question
  const addQuestion = (category: string) => {
    if (!newQuestionValue.trim()) return;
    
    const questions = extractQuestions(localTree[category]);
    questions.push({ question: newQuestionValue.trim() });
    
    updateTreeWithHistory({
      ...localTree,
      [category]: questionsToStorageFormat(questions)
    });
    setAddingToCategory(null);
    setNewQuestionValue('');
  };

  // Save all changes
  const handleSaveAll = async () => {
    if (!onSave || !hasChanges) return;
    
    setIsSaving(true);
    try {
      await onSave(localTree);
      setHasChanges(false);
    } finally {
      setIsSaving(false);
    }
  };

  // Export as printable checklist PDF
  const handleExportChecklist = () => {
    const categories = allCategories.map(categoryKey => {
      const questions = extractQuestions(localTree[categoryKey]);
      const labels = CATEGORY_META[categoryKey] || { labelDe: categoryKey, labelEn: categoryKey };
      return {
        key: categoryKey,
        labelDe: labels.labelDe,
        labelEn: labels.labelEn,
        questions: questions.map(q => ({
          question: q.question,
          text: q.text,
          followUp: q.followUp,
          options: q.options,
        })),
      };
    });

    downloadChecklistPDF({
      categories,
      patientIdentifier,
      sessionDate,
      language,
    });
  };

  // Get all categories, prioritizing the known order
  const categories = CATEGORY_ORDER.filter(key => key in localTree);
  const otherCategories = Object.keys(localTree).filter(key => !CATEGORY_ORDER.includes(key));
  const allCategories = [...categories, ...otherCategories];

  // Get the active question for drag overlay (must be before early returns)
  const activeQuestion = useMemo(() => {
    if (!activeId) return null;
    const parsed = parseItemId(activeId);
    if (!parsed) return null;
    const questions = extractQuestions(localTree[parsed.category]);
    return questions[parsed.index];
  }, [activeId, localTree, extractQuestions]);

  if (allCategories.length === 0) {
    return (
      <Card className={cn("bg-muted/30", className)}>
        <CardContent className="p-4 text-center text-muted-foreground">
          <HelpCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">
            {isGerman ? 'Keine Fragen im Fragenbaum vorhanden.' : 'No questions in the question tree.'}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={collisionDetection}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <div className={cn("space-y-2", className)}>
        {/* Header with undo/redo and export buttons */}
        <div className="flex items-center justify-between gap-2">
          {editable && (
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleUndo}
                disabled={!canUndo}
                className="gap-1 h-8 px-2"
                title={isGerman ? 'Rückgängig (Strg+Z)' : 'Undo (Ctrl+Z)'}
              >
                <Undo2 className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRedo}
                disabled={!canRedo}
                className="gap-1 h-8 px-2"
                title={isGerman ? 'Wiederherstellen (Strg+Y)' : 'Redo (Ctrl+Y)'}
              >
                <Redo2 className="h-4 w-4" />
              </Button>
              {(canUndo || canRedo) && (
                <span className="text-xs text-muted-foreground ml-1">
                  {historyIndex}/{history.length - 1}
                </span>
              )}
            </div>
          )}
          <div className="flex-1" />
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportChecklist}
            className="gap-1"
          >
            <Printer className="h-4 w-4" />
            {isGerman ? 'Checkliste drucken' : 'Print Checklist'}
          </Button>
        </div>

        {/* Save button when there are changes */}
        {editable && hasChanges && (
          <div className="flex items-center justify-end gap-2 p-2 bg-primary/5 rounded-md border border-primary/20">
            <span className="text-xs text-muted-foreground">
              {isGerman ? 'Ungespeicherte Änderungen' : 'Unsaved changes'}
            </span>
            <Button
              size="sm"
              onClick={handleSaveAll}
              disabled={isSaving}
              className="gap-1"
            >
              {isSaving ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : (
                <Save className="h-3 w-3" />
              )}
              {isGerman ? 'Speichern' : 'Save'}
            </Button>
          </div>
        )}

        {allCategories.map(categoryKey => {
          const meta = CATEGORY_META[categoryKey] || { 
            labelDe: categoryKey, 
            labelEn: categoryKey, 
            icon: HelpCircle, 
            color: 'text-muted-foreground' 
          };
          const Icon = meta.icon;
          const isOpen = openCategories.has(categoryKey);
          const questions = extractQuestions(localTree[categoryKey]);
          
          return (
            <Collapsible
              key={categoryKey}
              open={isOpen}
              onOpenChange={() => toggleCategory(categoryKey)}
            >
              <CollapsibleTrigger className="w-full">
                <Card className={cn(
                  "transition-colors hover:bg-muted/50",
                  isOpen && "ring-1 ring-primary/20"
                )}>
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon className={cn("h-4 w-4", meta.color)} />
                        <span className="font-medium text-sm">
                          {isGerman ? meta.labelDe : meta.labelEn}
                        </span>
                        <Badge variant="secondary" className="text-xs">
                          {questions.length} {isGerman ? 'Fragen' : 'questions'}
                        </Badge>
                      </div>
                      {isOpen ? (
                        <ChevronDown className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <div className="ml-4 mt-2 border-l-2 border-muted pl-4">
                  <DroppableCategory
                    categoryKey={categoryKey}
                    items={questions.map((_, idx) => `${categoryKey}-${idx}`)}
                  >
                    {questions.length === 0 ? (
                      <p className="text-xs text-muted-foreground italic py-2">
                        {isGerman ? 'Keine Fragen – hierher ziehen zum Hinzufügen' : 'No questions – drag here to add'}
                      </p>
                    ) : (
                      questions.map((q, idx) => {
                        const isEditing = editingQuestion?.category === categoryKey && editingQuestion?.index === idx;
                        const questionText = q.question || q.text || '';
                        
                        return (
                          <SortableQuestionItem
                            key={`${categoryKey}-${idx}`}
                            id={`${categoryKey}-${idx}`}
                            question={q}
                            index={idx}
                            isGerman={isGerman}
                            editable={editable}
                            isEditing={isEditing}
                            editValue={editValue}
                            onEditValueChange={setEditValue}
                            onStartEdit={() => startEdit(categoryKey, idx, questionText)}
                            onSaveEdit={saveEdit}
                            onCancelEdit={cancelEdit}
                            onDelete={() => setDeleteConfirm({ category: categoryKey, index: idx })}
                          />
                        );
                      })
                    )}
                  </DroppableCategory>
                  
                  {/* Add new question */}
                  {editable && (
                    <div className="pt-1">
                      {addingToCategory === categoryKey ? (
                        <div className="bg-background rounded-md p-3 border border-primary/50 space-y-2">
                          <Input
                            value={newQuestionValue}
                            onChange={(e) => setNewQuestionValue(e.target.value)}
                            placeholder={isGerman ? 'Neue Frage eingeben...' : 'Enter new question...'}
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') addQuestion(categoryKey);
                              if (e.key === 'Escape') {
                                setAddingToCategory(null);
                                setNewQuestionValue('');
                              }
                            }}
                          />
                          <div className="flex items-center gap-1">
                            <Button
                              size="sm"
                              onClick={() => addQuestion(categoryKey)}
                              disabled={!newQuestionValue.trim()}
                              className="gap-1 h-7"
                            >
                              <Plus className="h-3 w-3" />
                              {isGerman ? 'Hinzufügen' : 'Add'}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                setAddingToCategory(null);
                                setNewQuestionValue('');
                              }}
                              className="h-7"
                            >
                              {isGerman ? 'Abbrechen' : 'Cancel'}
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="gap-1 text-xs text-muted-foreground hover:text-foreground w-full justify-start"
                          onClick={() => setAddingToCategory(categoryKey)}
                        >
                          <Plus className="h-3 w-3" />
                          {isGerman ? 'Frage hinzufügen' : 'Add question'}
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </CollapsibleContent>
            </Collapsible>
          );
        })}

        {/* Drag Overlay for visual feedback */}
        <DragOverlay>
          {activeId && activeQuestion && (
            <div className="bg-background rounded-md p-3 border-2 border-primary shadow-lg opacity-90">
              <p className="text-sm">{activeQuestion.question || activeQuestion.text || '-'}</p>
            </div>
          )}
        </DragOverlay>

        {/* Delete confirmation dialog */}
        <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {isGerman ? 'Frage löschen?' : 'Delete question?'}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {isGerman 
                  ? 'Diese Aktion kann nicht rückgängig gemacht werden.'
                  : 'This action cannot be undone.'}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>
                {isGerman ? 'Abbrechen' : 'Cancel'}
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteConfirm && deleteQuestion(deleteConfirm.category, deleteConfirm.index)}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {isGerman ? 'Löschen' : 'Delete'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DndContext>
  );
}
