import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Check, X, ChevronDown, Loader2, FlaskConical, ArrowRightLeft } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { cn } from '@/lib/utils';
import { useUcum, type UcumSuggestion } from '@/hooks/useUcum';

interface LabValueInputProps {
  onSubmit: (value: string, unit: string, ucumCode: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

export function LabValueInput({ 
  onSubmit, 
  placeholder,
  disabled = false,
  className 
}: LabValueInputProps) {
  const { t, i18n } = useTranslation();
  const isGerman = i18n.language === 'de';
  
  const [value, setValue] = useState('');
  const [unit, setUnit] = useState('');
  const [unitOpen, setUnitOpen] = useState(false);
  const [showConverter, setShowConverter] = useState(false);
  const [convertTo, setConvertTo] = useState('');
  const [convertedValue, setConvertedValue] = useState<number | null>(null);
  
  const {
    validateUnitDebounced,
    isValidating,
    validationResult,
    getSuggestionsDebounced,
    suggestions,
    isLoadingSuggestions,
    convertUnits,
    clearValidation,
  } = useUcum({ debounceMs: 300 });

  // Validate unit on change
  useEffect(() => {
    if (unit.trim()) {
      validateUnitDebounced(unit);
    } else {
      clearValidation();
    }
  }, [unit, validateUnitDebounced, clearValidation]);

  // Load initial suggestions
  useEffect(() => {
    getSuggestionsDebounced('');
  }, []);

  const handleUnitSearch = (search: string) => {
    setUnit(search);
    getSuggestionsDebounced(search);
  };

  const handleSelectUnit = (selectedUnit: string) => {
    setUnit(selectedUnit);
    setUnitOpen(false);
    validateUnitDebounced(selectedUnit);
  };

  const handleConvert = async () => {
    if (!value || !unit || !convertTo) return;
    
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return;
    
    const result = await convertUnits(numValue, unit, convertTo);
    if (result.success && result.toValue !== undefined) {
      setConvertedValue(result.toValue);
    } else {
      setConvertedValue(null);
    }
  };

  const handleSubmit = () => {
    if (!value.trim() || !unit.trim() || !validationResult?.valid) return;
    
    onSubmit(value.trim(), unit.trim(), validationResult.ucumCode || unit.trim());
    setValue('');
    setUnit('');
    clearValidation();
    setShowConverter(false);
    setConvertedValue(null);
  };

  const canSubmit = value.trim() && unit.trim() && validationResult?.valid && !disabled;

  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex gap-2 items-end">
        {/* Value input */}
        <div className="flex-1 space-y-1.5">
          <Label className="text-xs text-muted-foreground">
            {isGerman ? 'Wert' : 'Value'}
          </Label>
          <Input
            type="number"
            step="any"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder || (isGerman ? 'z.B. 120' : 'e.g. 120')}
            disabled={disabled}
            className="h-9"
          />
        </div>

        {/* Unit selector with UCUM validation */}
        <div className="flex-1 space-y-1.5">
          <Label className="text-xs text-muted-foreground flex items-center gap-1">
            <FlaskConical className="h-3 w-3" />
            {isGerman ? 'Einheit (UCUM)' : 'Unit (UCUM)'}
          </Label>
          <Popover open={unitOpen} onOpenChange={setUnitOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                role="combobox"
                aria-expanded={unitOpen}
                disabled={disabled}
                className={cn(
                  "h-9 w-full justify-between font-normal",
                  validationResult && !validationResult.valid && unit && "border-destructive",
                  validationResult?.valid && unit && "border-primary"
                )}
              >
                <span className="truncate">
                  {unit || (isGerman ? 'Einheit wählen...' : 'Select unit...')}
                </span>
                <div className="flex items-center gap-1">
                  {isValidating && <Loader2 className="h-3 w-3 animate-spin" />}
                  {!isValidating && validationResult?.valid && unit && (
                    <Check className="h-3 w-3 text-primary" />
                  )}
                  {!isValidating && validationResult && !validationResult.valid && unit && (
                    <X className="h-3 w-3 text-destructive" />
                  )}
                  <ChevronDown className="h-3 w-3 opacity-50" />
                </div>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-0" align="start">
              <Command>
                <CommandInput 
                  placeholder={isGerman ? "Einheit suchen..." : "Search unit..."} 
                  value={unit}
                  onValueChange={handleUnitSearch}
                />
                <CommandList>
                  <CommandEmpty>
                    {isLoadingSuggestions ? (
                      <div className="flex items-center justify-center py-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">
                        {isGerman ? 'Keine Einheiten gefunden' : 'No units found'}
                      </span>
                    )}
                  </CommandEmpty>
                  <CommandGroup heading={isGerman ? "Häufige Einheiten" : "Common units"}>
                    {suggestions.map((suggestion) => (
                      <CommandItem
                        key={suggestion.unit}
                        value={suggestion.unit}
                        onSelect={() => handleSelectUnit(suggestion.unit)}
                        className="flex flex-col items-start"
                      >
                        <div className="flex items-center gap-2 w-full">
                          <span className="font-mono text-sm">{suggestion.unit}</span>
                          <Badge variant="outline" className="text-[10px] px-1 py-0">
                            {suggestion.category}
                          </Badge>
                        </div>
                        <span className="text-xs text-muted-foreground truncate w-full">
                          {suggestion.display}
                        </span>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>

        {/* Submit button */}
        <Button
          size="sm"
          onClick={handleSubmit}
          disabled={!canSubmit}
          className="h-9"
        >
          <Check className="h-4 w-4" />
        </Button>
      </div>

      {/* Validation message */}
      {validationResult && unit && (
        <div className={cn(
          "text-xs flex items-center gap-1",
          validationResult.valid ? "text-primary" : "text-destructive"
        )}>
          {validationResult.valid ? (
            <>
              <Check className="h-3 w-3" />
              UCUM: <code className="bg-muted px-1 rounded">{validationResult.ucumCode}</code>
            </>
          ) : (
            <>
              <X className="h-3 w-3" />
              {validationResult.message || (isGerman ? 'Ungültige Einheit' : 'Invalid unit')}
            </>
          )}
        </div>
      )}

      {/* Unit converter toggle */}
      {validationResult?.valid && value && (
        <div className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowConverter(!showConverter)}
            className="h-6 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowRightLeft className="h-3 w-3 mr-1" />
            {isGerman ? 'Umrechnen' : 'Convert'}
          </Button>

          {showConverter && (
            <div className="flex gap-2 items-center p-2 bg-muted/50 rounded-md">
              <span className="text-sm">
                {value} {unit} →
              </span>
              <Input
                value={convertTo}
                onChange={(e) => {
                  setConvertTo(e.target.value);
                  setConvertedValue(null);
                }}
                placeholder={isGerman ? "Zieleinheit" : "Target unit"}
                className="h-7 w-24 text-sm"
              />
              <Button size="sm" variant="outline" onClick={handleConvert} className="h-7">
                {isGerman ? 'Rechnen' : 'Calculate'}
              </Button>
              {convertedValue !== null && (
                <Badge variant="secondary" className="font-mono">
                  {convertedValue.toFixed(4)} {convertTo}
                </Badge>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
