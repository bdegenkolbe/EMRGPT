 import { useState, useEffect } from 'react';
 import { useTranslation } from 'react-i18next';
 import { 
   GitBranch, 
   Stethoscope, 
   ChevronDown, 
   ChevronUp, 
   Loader2, 
   AlertTriangle,
   Sparkles,
   ExternalLink
 } from 'lucide-react';
 import { Badge } from '@/components/ui/badge';
 import { Button } from '@/components/ui/button';
 import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
 import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
 import { ScrollArea } from '@/components/ui/scroll-area';
 import { MermaidDiagram } from './MermaidDiagram';
 import { CodeDetailTooltip } from '@/components/ontology/CodeDetailTooltip';
 import { supabase } from '@/integrations/supabase/client';
 import { cn } from '@/lib/utils';
 import { Link } from 'react-router-dom';
 
 interface DifferentialDiagnosis {
   name: string;
   probability: number;
   icd10?: string;
   reasoning: string;
 }
 
 interface AnamnesisPath {
   id: string;
   hpo_codes: string[];
   differential_diagnoses: DifferentialDiagnosis[];
   mermaid_diagram: string | null;
   ai_reasoning: string | null;
   version: number;
   is_combined: boolean;
   created_at: string;
   updated_at: string;
 }
 
 interface HpoLabel {
   hpo_code: string;
   label_de: string;
   label_en: string;
 }
 
 interface SidebarPathsPanelProps {
   sessionId: string;
   language?: string;
   refreshTrigger?: number;
 }
 
 export function SidebarPathsPanel({ 
   sessionId, 
   language = 'de',
   refreshTrigger = 0
 }: SidebarPathsPanelProps) {
   const { t } = useTranslation();
   const [paths, setPaths] = useState<AnamnesisPath[]>([]);
   const [hpoLabels, setHpoLabels] = useState<Record<string, HpoLabel>>({});
   const [isLoading, setIsLoading] = useState(true);
   const [diagnosesOpen, setDiagnosesOpen] = useState(true);
   const [pathOpen, setPathOpen] = useState(false);
   
   const isGerman = language === 'de';
 
   useEffect(() => {
     loadPaths();
   }, [sessionId, refreshTrigger]);
 
   const loadPaths = async () => {
     setIsLoading(true);
     try {
       const { data, error } = await supabase
         .from('anamnesis_paths')
         .select('*')
         .eq('session_id', sessionId)
         .order('updated_at', { ascending: false });
 
       if (error) throw error;
 
       const pathsData = (data || []).map(p => ({
         ...p,
         differential_diagnoses: (p.differential_diagnoses as unknown as DifferentialDiagnosis[]) || [],
       })) as AnamnesisPath[];
       
       setPaths(pathsData);
 
        // Load HPO labels from hpo_codes table (JSONB labels column)
        const allCodes = [...new Set(pathsData.flatMap(p => p.hpo_codes))];
        if (allCodes.length > 0) {
          const { data: hpoData } = await supabase
            .from('hpo_codes')
            .select('hpo_code, label, labels')
            .in('hpo_code', allCodes);

          if (hpoData) {
            const labelsMap: Record<string, HpoLabel> = {};
            hpoData.forEach(h => {
              const labels = h.labels as Record<string, string> | null;
              labelsMap[h.hpo_code] = {
                hpo_code: h.hpo_code,
                label_de: labels?.de || h.label,
                label_en: labels?.en || h.label,
              };
            });
            setHpoLabels(labelsMap);
          }
        }
     } catch (error) {
       console.error('Error loading paths:', error);
     } finally {
       setIsLoading(false);
     }
   };
 
   const getHpoLabel = (code: string): string => {
     const label = hpoLabels[code];
     return isGerman ? (label?.label_de || code) : (label?.label_en || code);
   };
 
   // Get latest path with diagram
   const latestPath = paths[0];
   
   // Aggregate all differential diagnoses from all paths, deduplicated by name
   const allDiagnoses = paths.flatMap(p => p.differential_diagnoses);
   const uniqueDiagnoses = allDiagnoses.reduce((acc, d) => {
     const existing = acc.find(x => x.name === d.name);
     if (!existing || d.probability > existing.probability) {
       return [...acc.filter(x => x.name !== d.name), d];
     }
     return acc;
   }, [] as DifferentialDiagnosis[]);
   
   // Sort by probability
   const sortedDiagnoses = uniqueDiagnoses.sort((a, b) => b.probability - a.probability);
   
   const getProbabilityColor = (probability: number) => {
     if (probability >= 0.7) return 'bg-destructive/15 text-destructive border-destructive/20';
     if (probability >= 0.4) return 'bg-warning/15 text-warning border-warning/20';
     return 'bg-muted text-muted-foreground';
   };
 
   if (isLoading) {
     return (
       <div className="py-4 flex items-center justify-center">
         <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
       </div>
     );
   }
 
   if (paths.length === 0) {
     return (
       <div className="py-4 text-center text-sm text-muted-foreground">
         <GitBranch className="h-8 w-8 mx-auto mb-2 opacity-50" />
         <p>
           {isGerman 
             ? 'Anamnesepfade werden erstellt, sobald Symptome erkannt werden.'
             : 'Anamnesis paths will be created when symptoms are detected.'}
         </p>
       </div>
     );
   }
 
   return (
     <div className="space-y-3">
       {/* Differential Diagnoses */}
       {sortedDiagnoses.length > 0 && (
         <Collapsible open={diagnosesOpen} onOpenChange={setDiagnosesOpen}>
           <CollapsibleTrigger className="w-full">
             <div className="flex items-center justify-between py-2 px-1 hover:bg-muted/50 rounded-md transition-colors">
               <div className="flex items-center gap-2">
                 <Stethoscope className="h-4 w-4 text-primary" />
                 <span className="font-medium text-sm">
                   {isGerman ? 'Differentialdiagnosen' : 'Differential Diagnoses'}
                 </span>
                 <Badge variant="secondary" className="text-xs">
                   {sortedDiagnoses.length}
                 </Badge>
               </div>
               {diagnosesOpen ? (
                 <ChevronUp className="h-4 w-4 text-muted-foreground" />
               ) : (
                 <ChevronDown className="h-4 w-4 text-muted-foreground" />
               )}
             </div>
           </CollapsibleTrigger>
           <CollapsibleContent>
              <div className="space-y-2 pt-1">
                {sortedDiagnoses.slice(0, 5).map((diagnosis, idx) => (
                  <Card key={`${diagnosis.name}-${idx}`} className="border-border/50">
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="font-medium text-sm">
                              {diagnosis.name}
                            </span>
                            {diagnosis.icd10 && (
                              <CodeDetailTooltip code={diagnosis.icd10} system="icd10gm">
                                <Badge 
                                  variant="outline" 
                                  className="text-[10px] shrink-0 cursor-help hover:bg-accent transition-colors"
                                >
                                  {diagnosis.icd10}
                                </Badge>
                              </CodeDetailTooltip>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {diagnosis.reasoning}
                          </p>
                        </div>
                        <Badge 
                          variant="outline" 
                          className={cn("text-[10px] shrink-0", getProbabilityColor(diagnosis.probability))}
                        >
                          {Math.round(diagnosis.probability * 100)}%
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
               {sortedDiagnoses.length > 5 && (
                 <p className="text-xs text-muted-foreground text-center py-1">
                   +{sortedDiagnoses.length - 5} {isGerman ? 'weitere' : 'more'}
                 </p>
               )}
             </div>
           </CollapsibleContent>
         </Collapsible>
       )}
 
       {/* Anamnesis Path Diagram */}
       {latestPath?.mermaid_diagram && (
         <Collapsible open={pathOpen} onOpenChange={setPathOpen}>
           <CollapsibleTrigger className="w-full">
             <div className="flex items-center justify-between py-2 px-1 hover:bg-muted/50 rounded-md transition-colors">
               <div className="flex items-center gap-2">
                 <GitBranch className="h-4 w-4 text-primary" />
                 <span className="font-medium text-sm">
                   {isGerman ? 'Anamnesepfad' : 'Anamnesis Path'}
                 </span>
               </div>
               {pathOpen ? (
                 <ChevronUp className="h-4 w-4 text-muted-foreground" />
               ) : (
                 <ChevronDown className="h-4 w-4 text-muted-foreground" />
               )}
             </div>
           </CollapsibleTrigger>
           <CollapsibleContent>
             <div className="pt-1 space-y-2">
                {/* HPO Codes */}
                <div className="flex flex-wrap gap-1">
                  {latestPath.hpo_codes.slice(0, 4).map((code) => (
                    <CodeDetailTooltip key={code} code={code} system="hpo">
                      <Badge 
                        variant="outline" 
                        className="text-[10px] cursor-help hover:bg-accent transition-colors"
                      >
                        {getHpoLabel(code)}
                      </Badge>
                    </CodeDetailTooltip>
                  ))}
                  {latestPath.hpo_codes.length > 4 && (
                    <Badge variant="secondary" className="text-[10px]">
                      +{latestPath.hpo_codes.length - 4}
                    </Badge>
                  )}
                </div>
               
               {/* Diagram */}
               <Card className="overflow-hidden border-border/50">
                 <CardContent className="p-2">
                   <div className="max-h-[200px] overflow-auto">
                     <MermaidDiagram 
                       diagram={latestPath.mermaid_diagram} 
                       title={`anamnesis-path-${sessionId.slice(0, 8)}`}
                       className="text-xs"
                     />
                   </div>
                 </CardContent>
               </Card>
               
               {/* AI Reasoning excerpt */}
               {latestPath.ai_reasoning && (
                 <div className="text-xs text-muted-foreground p-2 bg-muted/30 rounded-md">
                   <div className="flex items-center gap-1 mb-1">
                     <Sparkles className="h-3 w-3" />
                     <span className="font-medium">KI-Analyse</span>
                   </div>
                   <p className="line-clamp-3">{latestPath.ai_reasoning}</p>
                 </div>
               )}
               
               {/* Link to full paths page */}
               <Button 
                 variant="ghost" 
                 size="sm" 
                 className="w-full text-xs gap-1"
                 asChild
               >
                 <Link to="/anamnesis/paths">
                   <ExternalLink className="h-3 w-3" />
                   {isGerman ? 'Alle Pfade anzeigen' : 'View all paths'}
                 </Link>
               </Button>
             </div>
           </CollapsibleContent>
         </Collapsible>
       )}
     </div>
   );
 }