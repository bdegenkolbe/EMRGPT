import * as React from "react";
import { Database, Cloud, HelpCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

export type DataSource = 'local' | 'api' | 'unknown';

interface DataSourceBadgeProps {
  source: DataSource;
  className?: string;
  showLabel?: boolean;
}

const sourceConfig: Record<DataSource, {
  label: string;
  shortLabel: string;
  icon: typeof Database;
  description: string;
  className: string;
}> = {
  local: {
    label: 'Lokale Datenbank',
    shortLabel: 'DB',
    icon: Database,
    description: 'Daten wurden aus der lokalen Datenbank geladen (schneller, offline verfügbar)',
    className: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-800',
  },
  api: {
    label: 'Externe API',
    shortLabel: 'API',
    icon: Cloud,
    description: 'Daten wurden von einer externen API abgerufen (aktuellste Version)',
    className: 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800',
  },
  unknown: {
    label: 'Unbekannt',
    shortLabel: '?',
    icon: HelpCircle,
    description: 'Datenquelle konnte nicht ermittelt werden',
    className: 'bg-muted text-muted-foreground border-border',
  },
};

export function DataSourceBadge({ source, className, showLabel = false }: DataSourceBadgeProps) {
  const config = sourceConfig[source];
  const Icon = config.icon;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge
          variant="outline"
          className={cn(
            'text-[10px] font-medium gap-1 cursor-help transition-all hover:scale-105',
            config.className,
            className
          )}
        >
          <Icon className="h-2.5 w-2.5" />
          {showLabel ? config.label : config.shortLabel}
        </Badge>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs">
        <div className="space-y-1">
          <div className="font-semibold text-xs flex items-center gap-1.5">
            <Icon className="h-3 w-3" />
            {config.label}
          </div>
          <p className="text-xs text-muted-foreground">{config.description}</p>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}
