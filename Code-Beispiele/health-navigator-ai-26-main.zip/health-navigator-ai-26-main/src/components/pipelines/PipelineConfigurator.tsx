import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useDomains, usePipelines, useUpdatePipeline, type Pipeline, type PipelineDomain } from '@/hooks/usePipelines';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { GripVertical, Pencil, Plus, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface SortablePhaseProps {
  phase: string;
  onRemove: (phase: string) => void;
}

function SortablePhase({ phase, onRemove }: SortablePhaseProps) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: phase });
  
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const getPhaseLabel = (p: string) => {
    const labels: Record<string, string> = {
      '-1': 'Domain-Klassifikation',
      '1': 'Intent & Safety Triage',
      '2': 'Kontext-Erhebung',
      '3': 'Normalisierung',
      '4': 'Kategorisierung',
      '5': 'Wissens-Retrieval',
      '6': 'Reranking',
      '7': 'Validierung',
      '8': 'Synthese',
      'H1': 'HR-Validierung',
      'H2': 'HR-Antwort',
      'G1': 'Allgemeine Antwort',
    };
    return labels[p] || `Phase ${p}`;
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center gap-2 p-2 bg-card border rounded-lg"
    >
      <button {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing">
        <GripVertical className="h-4 w-4 text-muted-foreground" />
      </button>
      <Badge variant="outline" className="font-mono">
        {phase}
      </Badge>
      <span className="flex-1 text-sm">{getPhaseLabel(phase)}</span>
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6"
        onClick={() => onRemove(phase)}
      >
        <Trash2 className="h-3 w-3" />
      </Button>
    </div>
  );
}

export function PipelineConfigurator() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { data: domains, isLoading: domainsLoading } = useDomains();
  const [selectedDomainId, setSelectedDomainId] = useState<string>('');
  const { data: pipelines, isLoading: pipelinesLoading } = usePipelines(selectedDomainId || undefined);
  const updatePipeline = useUpdatePipeline();
  
  const [editingPipeline, setEditingPipeline] = useState<Pipeline | null>(null);
  const [phases, setPhases] = useState<string[]>([]);
  const [newPhase, setNewPhase] = useState('');

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleEdit = (pipeline: Pipeline) => {
    setEditingPipeline(pipeline);
    setPhases(pipeline.phase_order || []);
    setNewPhase('');
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      setPhases((items) => {
        const oldIndex = items.indexOf(active.id as string);
        const newIndex = items.indexOf(over.id as string);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const handleAddPhase = () => {
    if (newPhase.trim() && !phases.includes(newPhase.trim())) {
      setPhases([...phases, newPhase.trim()]);
      setNewPhase('');
    }
  };

  const handleRemovePhase = (phase: string) => {
    setPhases(phases.filter(p => p !== phase));
  };

  const handleToggleActive = async (pipeline: Pipeline) => {
    try {
      await updatePipeline.mutateAsync({
        id: pipeline.id,
        is_active: !pipeline.is_active,
      });
      toast({
        title: t('common.success'),
        description: pipeline.is_active 
          ? t('admin.pipelines.pipelineDeactivated', { defaultValue: 'Pipeline deaktiviert' })
          : t('admin.pipelines.pipelineActivated', { defaultValue: 'Pipeline aktiviert' }),
      });
    } catch (error) {
      toast({
        title: t('common.error'),
        description: String(error),
        variant: 'destructive',
      });
    }
  };

  const handleSave = async () => {
    if (!editingPipeline) return;
    
    try {
      await updatePipeline.mutateAsync({
        id: editingPipeline.id,
        phase_order: phases,
        description: editingPipeline.description,
      });
      toast({
        title: t('common.success'),
        description: t('admin.pipelines.pipelineUpdated', { defaultValue: 'Pipeline aktualisiert' }),
      });
      setEditingPipeline(null);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: String(error),
        variant: 'destructive',
      });
    }
  };

  const selectedDomain = domains?.find(d => d.id === selectedDomainId);

  if (domainsLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-10 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>
            {t('admin.pipelines.configurator.title', { defaultValue: 'Pipeline-Konfiguration' })}
          </CardTitle>
          <CardDescription>
            {t('admin.pipelines.configurator.description', {
              defaultValue: 'Phasen-Reihenfolge und Pipeline-Einstellungen verwalten'
            })}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>{t('admin.pipelines.selectDomain', { defaultValue: 'Domäne auswählen' })}</Label>
            <Select value={selectedDomainId} onValueChange={setSelectedDomainId}>
              <SelectTrigger>
                <SelectValue placeholder={t('admin.pipelines.selectDomainPlaceholder', {
                  defaultValue: 'Domäne wählen...'
                })} />
              </SelectTrigger>
              <SelectContent>
                {domains?.filter(d => d.is_active).map((domain) => (
                  <SelectItem key={domain.id} value={domain.id}>
                    {domain.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedDomainId && (
            <div className="space-y-4">
              {pipelinesLoading ? (
                <div className="space-y-2">
                  {[1, 2].map(i => (
                    <Skeleton key={i} className="h-20 w-full" />
                  ))}
                </div>
              ) : pipelines?.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {t('admin.pipelines.noPipelines', {
                    defaultValue: 'Keine Pipelines für diese Domäne gefunden'
                  })}
                </div>
              ) : (
                pipelines?.map((pipeline) => (
                  <Card key={pipeline.id} className="border-l-4 border-l-primary">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{pipeline.name}</h4>
                            <Badge variant="outline" className="font-mono text-xs">
                              {pipeline.slug}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {pipeline.description}
                          </p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {pipeline.phase_order?.map((phase, idx) => (
                              <Badge key={idx} variant="secondary" className="font-mono text-xs">
                                {phase}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={pipeline.is_active}
                            onCheckedChange={() => handleToggleActive(pipeline)}
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(pipeline)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!editingPipeline} onOpenChange={(open) => !open && setEditingPipeline(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {t('admin.pipelines.configurator.edit', { defaultValue: 'Pipeline bearbeiten' })}
            </DialogTitle>
            <DialogDescription>
              {editingPipeline?.name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t('common.description')}</Label>
              <Textarea
                value={editingPipeline?.description || ''}
                onChange={(e) => setEditingPipeline(prev => 
                  prev ? { ...prev, description: e.target.value } : null
                )}
              />
            </div>

            <div className="space-y-2">
              <Label>
                {t('admin.pipelines.configurator.phaseOrder', { defaultValue: 'Phasen-Reihenfolge' })}
              </Label>
              <p className="text-xs text-muted-foreground">
                {t('admin.pipelines.configurator.dragHint', {
                  defaultValue: 'Ziehen Sie die Phasen, um die Reihenfolge zu ändern'
                })}
              </p>
              
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext items={phases} strategy={verticalListSortingStrategy}>
                  <div className="space-y-2">
                    {phases.map((phase) => (
                      <SortablePhase
                        key={phase}
                        phase={phase}
                        onRemove={handleRemovePhase}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>

              <div className="flex gap-2 mt-4">
                <Input
                  value={newPhase}
                  onChange={(e) => setNewPhase(e.target.value)}
                  placeholder={t('admin.pipelines.configurator.addPhase', {
                    defaultValue: 'Phase hinzufügen (z.B. "9")'
                  })}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddPhase()}
                />
                <Button onClick={handleAddPhase} size="icon" variant="outline">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingPipeline(null)}>
              {t('common.cancel')}
            </Button>
            <Button onClick={handleSave} disabled={updatePipeline.isPending}>
              {t('common.save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
