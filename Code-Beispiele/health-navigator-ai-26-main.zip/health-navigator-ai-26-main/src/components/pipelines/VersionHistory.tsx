import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';
import { History, GitCompare, Check, ChevronRight, ArrowLeft } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import type { PromptTemplate } from '@/hooks/usePipelines';

interface VersionHistoryProps {
  template: PromptTemplate;
  onSelectVersion?: (version: PromptTemplate) => void;
  onClose?: () => void;
}

interface DiffLine {
  type: 'added' | 'removed' | 'unchanged';
  content: string;
}

// Simple line-by-line diff
function computeDiff(oldText: string, newText: string): DiffLine[] {
  const oldLines = oldText.split('\n');
  const newLines = newText.split('\n');
  const result: DiffLine[] = [];

  let i = 0, j = 0;
  
  while (i < oldLines.length || j < newLines.length) {
    if (i >= oldLines.length) {
      result.push({ type: 'added', content: newLines[j] });
      j++;
    } else if (j >= newLines.length) {
      result.push({ type: 'removed', content: oldLines[i] });
      i++;
    } else if (oldLines[i] === newLines[j]) {
      result.push({ type: 'unchanged', content: oldLines[i] });
      i++;
      j++;
    } else {
      // Check if line was removed or added
      const oldInNew = newLines.indexOf(oldLines[i], j);
      const newInOld = oldLines.indexOf(newLines[j], i);
      
      if (oldInNew === -1 && newInOld === -1) {
        // Line changed - show as remove then add
        result.push({ type: 'removed', content: oldLines[i] });
        result.push({ type: 'added', content: newLines[j] });
        i++;
        j++;
      } else if (oldInNew === -1 || (newInOld !== -1 && newInOld < oldInNew)) {
        result.push({ type: 'removed', content: oldLines[i] });
        i++;
      } else {
        result.push({ type: 'added', content: newLines[j] });
        j++;
      }
    }
  }
  
  return result;
}

export function VersionHistory({ template, onSelectVersion, onClose }: VersionHistoryProps) {
  const { t } = useTranslation();
  const [selectedVersions, setSelectedVersions] = useState<string[]>([]);
  const [compareMode, setCompareMode] = useState(false);

  // Fetch all versions of this template (by parent_template_id chain)
  const { data: versions, isLoading } = useQuery({
    queryKey: ['template-versions', template.id],
    queryFn: async () => {
      // Get the root template ID
      let rootId = template.id;
      let current = template;
      
      // Walk up the parent chain to find root
      while (current.parent_template_id) {
        const { data: parent } = await supabase
          .from('prompt_templates')
          .select('*')
          .eq('id', current.parent_template_id)
          .single();
        
        if (parent) {
          rootId = parent.id;
          current = parent as PromptTemplate;
        } else {
          break;
        }
      }

      // Get all versions: root + all children that reference it
      const { data: allVersions, error } = await supabase
        .from('prompt_templates')
        .select('*')
        .or(`id.eq.${rootId},parent_template_id.eq.${rootId}`)
        .order('version', { ascending: false });

      if (error) throw error;

      // Also include the current template if not in list
      const ids = new Set(allVersions?.map(v => v.id) || []);
      if (!ids.has(template.id)) {
        return [template, ...(allVersions as PromptTemplate[] || [])];
      }

      return allVersions as PromptTemplate[];
    },
  });

  const toggleVersionSelection = (versionId: string) => {
    if (selectedVersions.includes(versionId)) {
      setSelectedVersions(prev => prev.filter(id => id !== versionId));
    } else if (selectedVersions.length < 2) {
      setSelectedVersions(prev => [...prev, versionId]);
    } else {
      // Replace oldest selection
      setSelectedVersions(prev => [prev[1], versionId]);
    }
  };

  const getSelectedTemplates = () => {
    if (!versions || selectedVersions.length !== 2) return null;
    const v1 = versions.find(v => v.id === selectedVersions[0]);
    const v2 = versions.find(v => v.id === selectedVersions[1]);
    if (!v1 || !v2) return null;
    
    // Order by version number
    return v1.version < v2.version ? [v1, v2] : [v2, v1];
  };

  const selectedPair = getSelectedTemplates();

  if (compareMode && selectedPair) {
    const [older, newer] = selectedPair;
    const systemDiff = computeDiff(older.system_prompt, newer.system_prompt);
    const userDiff = computeDiff(
      older.user_prompt_template || '', 
      newer.user_prompt_template || ''
    );

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => setCompareMode(false)} className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Zurück zur Liste
          </Button>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Badge variant="outline">v{older.version}</Badge>
            <ChevronRight className="h-4 w-4" />
            <Badge variant="secondary">v{newer.version}</Badge>
          </div>
        </div>

        <ScrollArea className="h-[400px]">
          <div className="space-y-4 pr-4">
            <div>
              <h4 className="text-sm font-medium mb-2">System-Prompt Änderungen</h4>
              <div className="bg-muted rounded-lg p-3 font-mono text-xs space-y-0.5 overflow-x-auto">
                {systemDiff.map((line, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "px-2 py-0.5 rounded-sm whitespace-pre-wrap",
                      line.type === 'added' && "bg-green-500/20 text-green-700 dark:text-green-400",
                      line.type === 'removed' && "bg-red-500/20 text-red-700 dark:text-red-400 line-through",
                      line.type === 'unchanged' && "text-muted-foreground"
                    )}
                  >
                    <span className="select-none mr-2 opacity-50">
                      {line.type === 'added' ? '+' : line.type === 'removed' ? '-' : ' '}
                    </span>
                    {line.content || ' '}
                  </div>
                ))}
              </div>
            </div>

            {(older.user_prompt_template || newer.user_prompt_template) && (
              <div>
                <h4 className="text-sm font-medium mb-2">User-Prompt Template Änderungen</h4>
                <div className="bg-muted rounded-lg p-3 font-mono text-xs space-y-0.5 overflow-x-auto">
                  {userDiff.map((line, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        "px-2 py-0.5 rounded-sm whitespace-pre-wrap",
                        line.type === 'added' && "bg-green-500/20 text-green-700 dark:text-green-400",
                        line.type === 'removed' && "bg-red-500/20 text-red-700 dark:text-red-400 line-through",
                        line.type === 'unchanged' && "text-muted-foreground"
                      )}
                    >
                      <span className="select-none mr-2 opacity-50">
                        {line.type === 'added' ? '+' : line.type === 'removed' ? '-' : ' '}
                      </span>
                      {line.content || ' '}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <h4 className="text-sm font-medium mb-2">Modell-Konfiguration</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-1">
                  <p className="text-muted-foreground">v{older.version}</p>
                  <div className="bg-muted p-2 rounded text-xs font-mono">
                    {JSON.stringify(older.model_config, null, 2)}
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-muted-foreground">v{newer.version}</p>
                  <div className="bg-muted p-2 rounded text-xs font-mono">
                    {JSON.stringify(newer.model_config, null, 2)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </ScrollArea>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">
            {t('admin.pipelines.templates.versionHistory', { defaultValue: 'Versionshistorie' })}
          </span>
        </div>
        {selectedVersions.length === 2 && (
          <Button size="sm" variant="outline" onClick={() => setCompareMode(true)} className="gap-2">
            <GitCompare className="h-4 w-4" />
            Vergleichen
          </Button>
        )}
      </div>

      {selectedVersions.length > 0 && selectedVersions.length < 2 && (
        <p className="text-xs text-muted-foreground">
          Wähle eine weitere Version zum Vergleichen
        </p>
      )}

      <ScrollArea className="h-[300px]">
        <div className="space-y-2 pr-4">
          {isLoading ? (
            <div className="text-sm text-muted-foreground py-4 text-center">
              Lade Versionen...
            </div>
          ) : versions?.length === 0 ? (
            <div className="text-sm text-muted-foreground py-4 text-center">
              Keine Versionen gefunden
            </div>
          ) : (
            versions?.map((version) => (
              <div
                key={version.id}
                className={cn(
                  "flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors",
                  selectedVersions.includes(version.id)
                    ? "border-primary bg-primary/5"
                    : "hover:bg-muted/50",
                  version.is_active && "ring-1 ring-primary/30"
                )}
                onClick={() => toggleVersionSelection(version.id)}
              >
                <div className={cn(
                  "w-5 h-5 rounded border flex items-center justify-center flex-shrink-0",
                  selectedVersions.includes(version.id) 
                    ? "bg-primary border-primary text-primary-foreground" 
                    : "border-muted-foreground/30"
                )}>
                  {selectedVersions.includes(version.id) && <Check className="h-3 w-3" />}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Badge variant={version.is_active ? "default" : "secondary"} className="text-xs">
                      v{version.version}
                    </Badge>
                    {version.is_active && (
                      <Badge variant="outline" className="text-xs">Aktiv</Badge>
                    )}
                    {version.id === template.id && (
                      <Badge variant="outline" className="text-xs bg-muted">Aktuell</Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {format(new Date(version.created_at), 'dd.MM.yyyy HH:mm', { locale: de })}
                  </p>
                </div>

                <div className="text-right text-xs text-muted-foreground">
                  <p>{version.model_config?.model || 'gpt-4o-mini'}</p>
                  <p>T: {version.model_config?.temperature || 0.3}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>

      {onSelectVersion && selectedVersions.length === 1 && (
        <>
          <Separator />
          <div className="flex justify-end">
            <Button
              size="sm"
              onClick={() => {
                const selected = versions?.find(v => v.id === selectedVersions[0]);
                if (selected) onSelectVersion(selected);
              }}
            >
              Diese Version laden
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
