import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import {
  Zap,
  TrendingUp,
  Activity,
  Database,
  Sparkles,
  FileText,
  Languages,
  Search,
  GitBranch,
  Brain,
  PieChart,
  BarChart3,
  DollarSign,
  Info,
  AlertTriangle,
  AlertCircle,
  X,
  Bell,
  Download,
  FileSpreadsheet,
  Workflow,
} from 'lucide-react';
import { format, subDays } from 'date-fns';
import { de } from 'date-fns/locale';
import { jsPDF } from 'jspdf';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

// Alert thresholds configuration
interface AlertThresholds {
  dailySpikeMultiplier: number; // Alert if day exceeds X times the average
  phaseTokenThreshold: number; // Alert if single phase uses more than X tokens
  monthlyCostThreshold: number; // Alert if estimated monthly cost exceeds $X
  executionSpikeThreshold: number; // Alert if single execution uses X times avg tokens
}

const DEFAULT_THRESHOLDS: AlertThresholds = {
  dailySpikeMultiplier: 2.5,
  phaseTokenThreshold: 100000,
  monthlyCostThreshold: 50,
  executionSpikeThreshold: 3,
};

interface UsageAlert {
  id: string;
  type: 'warning' | 'error' | 'info';
  title: string;
  description: string;
  metric?: string;
  timestamp?: string;
}

interface PhaseStatistic {
  phase: string;
  templateName: string | null;
  totalTokens: number;
  promptTokens: number;
  completionTokens: number;
  executionCount: number;
  avgLatencyMs: number;
}

interface DomainStatistic {
  domain: string;
  totalTokens: number;
  executionCount: number;
  avgTokensPerExecution: number;
}

interface DailyStatistic {
  date: string;
  totalTokens: number;
  executionCount: number;
}

interface SourceTypeStatistic {
  source_type: string;
  totalTokens: number;
  promptTokens: number;
  completionTokens: number;
  requestCount: number;
  avgLatencyMs: number;
}

// LLM Provider pricing per 1M tokens (as of Feb 2026)
interface LLMPricing {
  name: string;
  provider: string;
  inputPer1M: number;
  outputPer1M: number;
  notes?: string;
}

const LLM_PRICING: LLMPricing[] = [
  { name: 'GPT-5', provider: 'OpenAI', inputPer1M: 5.00, outputPer1M: 15.00 },
  { name: 'GPT-5-mini', provider: 'OpenAI', inputPer1M: 0.60, outputPer1M: 2.40 },
  { name: 'GPT-5-nano', provider: 'OpenAI', inputPer1M: 0.15, outputPer1M: 0.60 },
  { name: 'GPT-4o', provider: 'OpenAI', inputPer1M: 2.50, outputPer1M: 10.00, notes: 'Legacy' },
  { name: 'GPT-4o-mini', provider: 'OpenAI', inputPer1M: 0.15, outputPer1M: 0.60, notes: 'Legacy' },
  { name: 'Gemini 2.5 Pro', provider: 'Google', inputPer1M: 1.25, outputPer1M: 5.00, notes: '>128k: 2.5/10' },
  { name: 'Gemini 2.5 Flash', provider: 'Google', inputPer1M: 0.075, outputPer1M: 0.30, notes: 'Thinking: 0.4/1.6' },
  { name: 'Gemini 3 Flash', provider: 'Google', inputPer1M: 0.10, outputPer1M: 0.40, notes: 'Preview' },
  { name: 'Claude 3.5 Sonnet', provider: 'Anthropic', inputPer1M: 3.00, outputPer1M: 15.00 },
  { name: 'Claude 3 Haiku', provider: 'Anthropic', inputPer1M: 0.25, outputPer1M: 1.25 },
  { name: 'Llama 3.1 405B', provider: 'Meta (Hosted)', inputPer1M: 3.00, outputPer1M: 3.00, notes: 'via Together/Fireworks' },
  { name: 'Llama 3.1 70B', provider: 'Meta (Hosted)', inputPer1M: 0.88, outputPer1M: 0.88, notes: 'via Together' },
  { name: 'Mistral Large', provider: 'Mistral', inputPer1M: 2.00, outputPer1M: 6.00 },
  { name: 'Mistral Small', provider: 'Mistral', inputPer1M: 0.20, outputPer1M: 0.60 },
];

const PHASE_ICONS: Record<string, React.ReactNode> = {
  '-1': <Brain className="h-4 w-4" />,
  '0': <Search className="h-4 w-4" />,
  '1': <FileText className="h-4 w-4" />,
  '2': <Activity className="h-4 w-4" />,
  '3': <GitBranch className="h-4 w-4" />,
  'translation': <Languages className="h-4 w-4" />,
  'analysis': <Sparkles className="h-4 w-4" />,
};

const DOMAIN_COLORS: Record<string, string> = {
  MEDICAL: 'bg-red-500',
  HR_LAW: 'bg-purple-500',
  TECHNICAL: 'bg-blue-500',
  GENERAL_INFO: 'bg-gray-500',
};

function formatTokens(tokens: number): string {
  if (tokens >= 1_000_000) {
    return `${(tokens / 1_000_000).toFixed(2)}M`;
  }
  if (tokens >= 1_000) {
    return `${(tokens / 1_000).toFixed(1)}k`;
  }
  return tokens.toString();
}

function formatCurrency(amount: number): string {
  if (amount < 0.01) {
    return `$${amount.toFixed(4)}`;
  }
  if (amount < 1) {
    return `$${amount.toFixed(3)}`;
  }
  return `$${amount.toFixed(2)}`;
}

function calculateCost(promptTokens: number, completionTokens: number, pricing: LLMPricing): number {
  return (promptTokens / 1_000_000 * pricing.inputPer1M) + (completionTokens / 1_000_000 * pricing.outputPer1M);
}

// CSV Export Functions
function generateStatisticsCSV(
  statistics: {
    phaseStats: PhaseStatistic[];
    domainStats: DomainStatistic[];
    dailyStats: DailyStatistic[];
    totalTokens: number;
    totalExecutions: number;
    avgTokensPerExecution: number;
  },
  analysisStats: { hpoAnalyses: number; snomedAnalyses: number; icd10Analyses: number; cachedMappings: number } | undefined
): string {
  const lines: string[] = [];
  
  // Summary section
  lines.push('ZUSAMMENFASSUNG');
  lines.push('Metrik,Wert');
  lines.push(`Gesamt-Tokens (30 Tage),${statistics.totalTokens}`);
  lines.push(`Anzahl Ausführungen,${statistics.totalExecutions}`);
  lines.push(`Ø Tokens/Ausführung,${Math.round(statistics.avgTokensPerExecution)}`);
  lines.push(`HPO-Analysen gecacht,${analysisStats?.hpoAnalyses || 0}`);
  lines.push(`SNOMED-Analysen gecacht,${analysisStats?.snomedAnalyses || 0}`);
  lines.push(`ICD-10-Analysen gecacht,${analysisStats?.icd10Analyses || 0}`);
  lines.push(`Mappings im Cache,${analysisStats?.cachedMappings || 0}`);
  lines.push('');
  
  // Phase statistics
  lines.push('TOKEN-VERBRAUCH NACH PHASE');
  lines.push('Phase,Template,Gesamt-Tokens,Prompt-Tokens,Completion-Tokens,Ausführungen,Ø Latenz (ms)');
  statistics.phaseStats.forEach(phase => {
    lines.push(`${phase.phase},"${phase.templateName || ''}",${phase.totalTokens},${phase.promptTokens},${phase.completionTokens},${phase.executionCount},${Math.round(phase.avgLatencyMs)}`);
  });
  lines.push('');
  
  // Domain statistics
  lines.push('TOKEN-VERBRAUCH NACH DOMÄNE');
  lines.push('Domäne,Gesamt-Tokens,Ausführungen,Ø Tokens/Ausführung');
  statistics.domainStats.forEach(domain => {
    lines.push(`${domain.domain},${domain.totalTokens},${domain.executionCount},${Math.round(domain.avgTokensPerExecution)}`);
  });
  lines.push('');
  
  // Daily statistics
  lines.push('TÄGLICHER VERLAUF');
  lines.push('Datum,Tokens,Ausführungen');
  statistics.dailyStats.forEach(day => {
    lines.push(`${day.date},${day.totalTokens},${day.executionCount}`);
  });
  lines.push('');
  
  // Cost estimates
  lines.push('KOSTEN-SCHÄTZUNGEN');
  lines.push('Modell,Anbieter,Input $/1M,Output $/1M,Geschätzte Kosten');
  const totalPromptTokens = statistics.phaseStats.reduce((sum, p) => sum + p.promptTokens, 0);
  const totalCompletionTokens = statistics.phaseStats.reduce((sum, p) => sum + p.completionTokens, 0);
  LLM_PRICING.forEach(pricing => {
    const cost = calculateCost(totalPromptTokens, totalCompletionTokens, pricing);
    lines.push(`${pricing.name},${pricing.provider},${pricing.inputPer1M},${pricing.outputPer1M},${cost.toFixed(4)}`);
  });
  
  return lines.join('\n');
}

function downloadCSV(content: string, filename: string) {
  const blob = new Blob(['\uFEFF' + content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// PDF Export Function
function generateStatisticsPDF(
  statistics: {
    phaseStats: PhaseStatistic[];
    domainStats: DomainStatistic[];
    dailyStats: DailyStatistic[];
    totalTokens: number;
    totalExecutions: number;
    avgTokensPerExecution: number;
  },
  analysisStats: { hpoAnalyses: number; snomedAnalyses: number; icd10Analyses: number; cachedMappings: number } | undefined
): jsPDF {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin;
  let y = margin;

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > 280) {
      doc.addPage();
      y = margin;
    }
  };

  // Header
  doc.setFillColor(59, 130, 246);
  doc.rect(0, 0, pageWidth, 30, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Token-Statistiken Report', margin, 18);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generiert: ${format(new Date(), 'dd.MM.yyyy HH:mm', { locale: de })}`, pageWidth - margin - 45, 18);
  
  y = 40;
  doc.setTextColor(0, 0, 0);

  // Summary section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Zusammenfassung (30 Tage)', margin, y);
  y += 8;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const summaryData = [
    ['Gesamt-Tokens', formatTokens(statistics.totalTokens)],
    ['Ausführungen', statistics.totalExecutions.toString()],
    ['Ø Tokens/Ausführung', formatTokens(Math.round(statistics.avgTokensPerExecution))],
    ['Gecachte Analysen', `${(analysisStats?.hpoAnalyses || 0) + (analysisStats?.snomedAnalyses || 0) + (analysisStats?.icd10Analyses || 0)}`],
    ['Mappings im Cache', (analysisStats?.cachedMappings || 0).toString()],
  ];

  summaryData.forEach(([label, value]) => {
    doc.text(label, margin, y);
    doc.text(value, margin + 60, y);
    y += 6;
  });

  y += 5;
  doc.setDrawColor(200, 200, 200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 10;

  // Phase statistics
  checkPageBreak(40);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Token-Verbrauch nach Phase', margin, y);
  y += 8;

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('Phase', margin, y);
  doc.text('Tokens', margin + 50, y);
  doc.text('Prompt', margin + 80, y);
  doc.text('Completion', margin + 105, y);
  doc.text('Anzahl', margin + 135, y);
  doc.text('Ø Latenz', margin + 160, y);
  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 4;

  doc.setFont('helvetica', 'normal');
  statistics.phaseStats.forEach(phase => {
    checkPageBreak(8);
    const phaseName = phase.templateName || `Phase ${phase.phase}`;
    doc.text(phaseName.slice(0, 20), margin, y);
    doc.text(formatTokens(phase.totalTokens), margin + 50, y);
    doc.text(formatTokens(phase.promptTokens), margin + 80, y);
    doc.text(formatTokens(phase.completionTokens), margin + 105, y);
    doc.text(phase.executionCount.toString(), margin + 135, y);
    doc.text(`${(phase.avgLatencyMs / 1000).toFixed(1)}s`, margin + 160, y);
    y += 5;
  });

  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 10;

  // Domain statistics
  checkPageBreak(40);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Token-Verbrauch nach Domäne', margin, y);
  y += 8;

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('Domäne', margin, y);
  doc.text('Tokens', margin + 60, y);
  doc.text('Ausführungen', margin + 100, y);
  doc.text('Ø pro Ausführung', margin + 140, y);
  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 4;

  doc.setFont('helvetica', 'normal');
  statistics.domainStats.forEach(domain => {
    checkPageBreak(8);
    doc.text(domain.domain, margin, y);
    doc.text(formatTokens(domain.totalTokens), margin + 60, y);
    doc.text(domain.executionCount.toString(), margin + 100, y);
    doc.text(formatTokens(Math.round(domain.avgTokensPerExecution)), margin + 140, y);
    y += 5;
  });

  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 10;

  // Cost estimation table
  checkPageBreak(60);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Kosten-Schätzungen', margin, y);
  y += 8;

  const totalPromptTokens = statistics.phaseStats.reduce((sum, p) => sum + p.promptTokens, 0);
  const totalCompletionTokens = statistics.phaseStats.reduce((sum, p) => sum + p.completionTokens, 0);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('Modell', margin, y);
  doc.text('Anbieter', margin + 45, y);
  doc.text('Input $/1M', margin + 85, y);
  doc.text('Output $/1M', margin + 115, y);
  doc.text('Geschätzt', margin + 150, y);
  y += 5;
  doc.line(margin, y, pageWidth - margin, y);
  y += 4;

  doc.setFont('helvetica', 'normal');
  const sortedPricing = [...LLM_PRICING].sort((a, b) => {
    return calculateCost(totalPromptTokens, totalCompletionTokens, a) - 
           calculateCost(totalPromptTokens, totalCompletionTokens, b);
  });

  sortedPricing.forEach((pricing, idx) => {
    checkPageBreak(8);
    const cost = calculateCost(totalPromptTokens, totalCompletionTokens, pricing);
    if (idx === 0) {
      doc.setFillColor(220, 252, 231);
      doc.rect(margin - 2, y - 3, contentWidth + 4, 5, 'F');
    }
    doc.text(pricing.name, margin, y);
    doc.text(pricing.provider, margin + 45, y);
    doc.text(`$${pricing.inputPer1M.toFixed(2)}`, margin + 85, y);
    doc.text(`$${pricing.outputPer1M.toFixed(2)}`, margin + 115, y);
    doc.text(formatCurrency(cost), margin + 150, y);
    y += 5;
  });

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setTextColor(128, 128, 128);
    doc.text(`Seite ${i} von ${pageCount}`, pageWidth - margin - 20, 290);
    doc.text('Token-Statistiken Export - KI-Anamnese System', margin, 290);
  }

  return doc;
}

function downloadStatisticsPDF(
  statistics: {
    phaseStats: PhaseStatistic[];
    domainStats: DomainStatistic[];
    dailyStats: DailyStatistic[];
    totalTokens: number;
    totalExecutions: number;
    avgTokensPerExecution: number;
  },
  analysisStats: { hpoAnalyses: number; snomedAnalyses: number; icd10Analyses: number; cachedMappings: number } | undefined
) {
  const doc = generateStatisticsPDF(statistics, analysisStats);
  const dateStr = format(new Date(), 'yyyy-MM-dd');
  doc.save(`token-statistiken-${dateStr}.pdf`);
}

function StatCard({ 
  title, 
  value, 
  description, 
  icon,
  trend,
}: { 
  title: string; 
  value: string | number; 
  description?: string;
  icon: React.ReactNode;
  trend?: { value: number; positive: boolean };
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground">
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
        {trend && (
          <div className={`flex items-center gap-1 text-xs mt-1 ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
            <TrendingUp className={`h-3 w-3 ${!trend.positive && 'rotate-180'}`} />
            {trend.value}% vs. letzte Woche
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function TokenStatistics() {
  const [dismissedAlerts, setDismissedAlerts] = useState<Set<string>>(new Set());
  // Fetch pipeline phase logs for statistics
  const { data: phaseLogs, isLoading: isLoadingPhases } = useQuery({
    queryKey: ['token-statistics-phases'],
    queryFn: async () => {
      const thirtyDaysAgo = subDays(new Date(), 30).toISOString();
      
      const { data, error } = await supabase
        .from('pipeline_phase_logs')
        .select(`
          phase,
          prompt_tokens,
          completion_tokens,
          latency_ms,
          template:prompt_templates(name)
        `)
        .gte('created_at', thirtyDaysAgo);
      
      if (error) throw error;
      return data;
    },
  });

  // Fetch pipeline executions for domain statistics
  const { data: executions, isLoading: isLoadingExecutions } = useQuery({
    queryKey: ['token-statistics-executions'],
    queryFn: async () => {
      const thirtyDaysAgo = subDays(new Date(), 30).toISOString();
      
      const { data, error } = await supabase
        .from('pipeline_executions')
        .select('domain, total_tokens, created_at')
        .gte('created_at', thirtyDaysAgo);
      
      if (error) throw error;
      return data;
    },
  });

  // Fetch ontology analyses token estimates
  const { data: analysisStats, isLoading: isLoadingAnalyses } = useQuery({
    queryKey: ['token-statistics-analyses'],
    queryFn: async () => {
      const [hpoCount, snomedCount, icd10Count, mappingsCount] = await Promise.all([
        supabase.from('hpo_analyses').select('id', { count: 'exact', head: true }),
        supabase.from('snomed_analyses').select('id', { count: 'exact', head: true }),
        supabase.from('icd10gm_analyses').select('id', { count: 'exact', head: true }),
        supabase.from('ontology_mappings').select('id', { count: 'exact', head: true }),
      ]);
      
      return {
        hpoAnalyses: hpoCount.count || 0,
        snomedAnalyses: snomedCount.count || 0,
        icd10Analyses: icd10Count.count || 0,
        cachedMappings: mappingsCount.count || 0,
      };
    },
  });

  // Fetch ai_usage_logs for comprehensive statistics
  const { data: aiUsageLogs, isLoading: isLoadingAiUsage } = useQuery({
    queryKey: ['token-statistics-ai-usage'],
    queryFn: async () => {
      const thirtyDaysAgo = subDays(new Date(), 30).toISOString();
      
      const { data, error } = await supabase
        .from('ai_usage_logs')
        .select('source_type, source_detail, provider, model, prompt_tokens, completion_tokens, latency_ms, created_at, status')
        .gte('created_at', thirtyDaysAgo)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
  });

  // Calculate statistics
  const statistics = useMemo(() => {
    if (!phaseLogs || !executions) return null;

    // Phase statistics
    const phaseMap = new Map<string, PhaseStatistic>();
    for (const log of phaseLogs) {
      const key = log.phase;
      const existing = phaseMap.get(key) || {
        phase: log.phase,
        templateName: (log.template as { name: string } | null)?.name || null,
        totalTokens: 0,
        promptTokens: 0,
        completionTokens: 0,
        executionCount: 0,
        avgLatencyMs: 0,
      };
      
      existing.totalTokens += (log.prompt_tokens || 0) + (log.completion_tokens || 0);
      existing.promptTokens += log.prompt_tokens || 0;
      existing.completionTokens += log.completion_tokens || 0;
      existing.executionCount += 1;
      existing.avgLatencyMs = ((existing.avgLatencyMs * (existing.executionCount - 1)) + (log.latency_ms || 0)) / existing.executionCount;
      
      phaseMap.set(key, existing);
    }
    
    const phaseStats = Array.from(phaseMap.values())
      .sort((a, b) => b.totalTokens - a.totalTokens);

    // Domain statistics
    const domainMap = new Map<string, DomainStatistic>();
    for (const exec of executions) {
      const existing = domainMap.get(exec.domain) || {
        domain: exec.domain,
        totalTokens: 0,
        executionCount: 0,
        avgTokensPerExecution: 0,
      };
      
      existing.totalTokens += exec.total_tokens || 0;
      existing.executionCount += 1;
      existing.avgTokensPerExecution = existing.totalTokens / existing.executionCount;
      
      domainMap.set(exec.domain, existing);
    }
    
    const domainStats = Array.from(domainMap.values())
      .sort((a, b) => b.totalTokens - a.totalTokens);

    // Daily statistics (last 7 days)
    const dailyMap = new Map<string, DailyStatistic>();
    for (let i = 6; i >= 0; i--) {
      const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
      dailyMap.set(date, { date, totalTokens: 0, executionCount: 0 });
    }
    
    for (const exec of executions) {
      const date = format(new Date(exec.created_at), 'yyyy-MM-dd');
      const existing = dailyMap.get(date);
      if (existing) {
        existing.totalTokens += exec.total_tokens || 0;
        existing.executionCount += 1;
      }
    }
    
    const dailyStats = Array.from(dailyMap.values());

    // Totals
    const totalTokens = executions.reduce((sum, e) => sum + (e.total_tokens || 0), 0);
    const totalExecutions = executions.length;
    const avgTokensPerExecution = totalExecutions > 0 ? totalTokens / totalExecutions : 0;

    return {
      phaseStats,
      domainStats,
      dailyStats,
      totalTokens,
      totalExecutions,
      avgTokensPerExecution,
    };
  }, [phaseLogs, executions]);

  // Generate alerts based on usage patterns - must be before any early returns
  const alerts = useMemo((): UsageAlert[] => {
    if (!statistics) return [];

    const generatedAlerts: UsageAlert[] = [];
    const thresholds = DEFAULT_THRESHOLDS;

    // Calculate average daily tokens
    const avgDailyTokens = statistics.dailyStats.reduce((sum, d) => sum + d.totalTokens, 0) / 
      Math.max(statistics.dailyStats.filter(d => d.totalTokens > 0).length, 1);

    // Check for daily spikes
    for (const day of statistics.dailyStats) {
      if (day.totalTokens > avgDailyTokens * thresholds.dailySpikeMultiplier && avgDailyTokens > 0) {
        generatedAlerts.push({
          id: `daily-spike-${day.date}`,
          type: 'warning',
          title: 'Tägliche Nutzungsspitze erkannt',
          description: `Am ${format(new Date(day.date), 'dd.MM.yyyy', { locale: de })} wurden ${formatTokens(day.totalTokens)} Tokens verbraucht – ${((day.totalTokens / avgDailyTokens) * 100 - 100).toFixed(0)}% über dem Durchschnitt.`,
          metric: formatTokens(day.totalTokens),
          timestamp: day.date,
        });
      }
    }

    // Check for high-consumption phases
    for (const phase of statistics.phaseStats) {
      if (phase.totalTokens > thresholds.phaseTokenThreshold) {
        generatedAlerts.push({
          id: `phase-high-${phase.phase}`,
          type: 'warning',
          title: `Hoher Token-Verbrauch in Phase ${phase.templateName || phase.phase}`,
          description: `Diese Phase hat ${formatTokens(phase.totalTokens)} Tokens verbraucht (${((phase.totalTokens / statistics.totalTokens) * 100).toFixed(1)}% des Gesamtverbrauchs). Prompt-Optimierung empfohlen.`,
          metric: formatTokens(phase.totalTokens),
        });
      }

      // Check for inefficient prompt/completion ratio (>80% prompts)
      const promptRatio = phase.promptTokens / (phase.totalTokens || 1);
      if (promptRatio > 0.8 && phase.totalTokens > 10000) {
        generatedAlerts.push({
          id: `ratio-${phase.phase}`,
          type: 'info',
          title: `Ineffizientes Prompt/Completion-Verhältnis`,
          description: `Phase "${phase.templateName || phase.phase}" verwendet ${(promptRatio * 100).toFixed(0)}% für Prompts. Kürzere System-Prompts könnten Kosten senken.`,
          metric: `${(promptRatio * 100).toFixed(0)}% Prompt`,
        });
      }
    }

    // Check monthly cost threshold (using Gemini 2.5 Flash as baseline)
    const geminiFlash = LLM_PRICING.find(p => p.name === 'Gemini 2.5 Flash')!;
    const totalPromptTokens = statistics.phaseStats.reduce((sum, p) => sum + p.promptTokens, 0);
    const totalCompletionTokens = statistics.phaseStats.reduce((sum, p) => sum + p.completionTokens, 0);
    const estimatedMonthlyCost = calculateCost(totalPromptTokens, totalCompletionTokens, geminiFlash);
    
    if (estimatedMonthlyCost > thresholds.monthlyCostThreshold) {
      generatedAlerts.push({
        id: 'cost-threshold',
        type: 'error',
        title: 'Monatliches Kostenbudget überschritten',
        description: `Die geschätzten Kosten (${formatCurrency(estimatedMonthlyCost)}/Monat mit Gemini Flash) übersteigen das Budget von ${formatCurrency(thresholds.monthlyCostThreshold)}. Überprüfen Sie die Pipeline-Konfiguration.`,
        metric: formatCurrency(estimatedMonthlyCost),
      });
    } else if (estimatedMonthlyCost > thresholds.monthlyCostThreshold * 0.8) {
      generatedAlerts.push({
        id: 'cost-warning',
        type: 'warning',
        title: 'Kostenbudget bei 80%',
        description: `Die geschätzten Kosten (${formatCurrency(estimatedMonthlyCost)}/Monat) nähern sich dem Budget von ${formatCurrency(thresholds.monthlyCostThreshold)}.`,
        metric: formatCurrency(estimatedMonthlyCost),
      });
    }

    // Check for high average tokens per execution
    if (statistics.avgTokensPerExecution > 5000) {
      generatedAlerts.push({
        id: 'avg-high',
        type: 'info',
        title: 'Hoher durchschnittlicher Token-Verbrauch',
        description: `Durchschnittlich werden ${formatTokens(Math.round(statistics.avgTokensPerExecution))} Tokens pro Ausführung verwendet. Prüfen Sie, ob alle Phasen notwendig sind.`,
        metric: formatTokens(Math.round(statistics.avgTokensPerExecution)),
      });
    }

    // Check for unusual domain distribution
    if (statistics.domainStats.length > 1) {
      const topDomain = statistics.domainStats[0];
      const domainShare = topDomain.totalTokens / statistics.totalTokens;
      if (domainShare > 0.9) {
        generatedAlerts.push({
          id: 'domain-concentration',
          type: 'info',
          title: 'Hohe Domänen-Konzentration',
          description: `${(domainShare * 100).toFixed(0)}% der Tokens werden von "${topDomain.domain}" verbraucht. Falls unerwartet, überprüfen Sie die Domänen-Klassifikation.`,
          metric: `${(domainShare * 100).toFixed(0)}%`,
        });
      }
    }

    return generatedAlerts.filter(alert => !dismissedAlerts.has(alert.id));
  }, [statistics, dismissedAlerts]);

  const alertCounts = useMemo(() => ({
    error: alerts.filter(a => a.type === 'error').length,
    warning: alerts.filter(a => a.type === 'warning').length,
    info: alerts.filter(a => a.type === 'info').length,
  }), [alerts]);

  const dismissAlert = (alertId: string) => {
    setDismissedAlerts(prev => new Set([...prev, alertId]));
  };

  const isLoading = isLoadingPhases || isLoadingExecutions || isLoadingAnalyses || isLoadingAiUsage;

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
      </div>
    );
  }

  if (!statistics) return null;

  const maxPhaseTokens = Math.max(...statistics.phaseStats.map(p => p.totalTokens), 1);
  const maxDomainTokens = Math.max(...statistics.domainStats.map(d => d.totalTokens), 1);
  const maxDailyTokens = Math.max(...statistics.dailyStats.map(d => d.totalTokens), 1);

  // Estimate tokens saved by caching (rough estimate: ~500 tokens per analysis avoided)
  const estimatedTokensSaved = (analysisStats?.cachedMappings || 0) * 500;

  return (
    <div className="space-y-6">
      {/* Usage Alerts */}
      {alerts.length > 0 && (
        <Card className="border-warning/50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Bell className="h-5 w-5" />
                Nutzungswarnungen
                <div className="flex gap-1.5 ml-2">
                  {alertCounts.error > 0 && (
                    <Badge variant="destructive" className="text-xs">
                      {alertCounts.error} kritisch
                    </Badge>
                  )}
                  {alertCounts.warning > 0 && (
                    <Badge className="bg-amber-500 text-xs">
                      {alertCounts.warning} Warnung
                    </Badge>
                  )}
                  {alertCounts.info > 0 && (
                    <Badge variant="secondary" className="text-xs">
                      {alertCounts.info} Info
                    </Badge>
                  )}
                </div>
              </CardTitle>
              {dismissedAlerts.size > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setDismissedAlerts(new Set())}
                  className="text-xs"
                >
                  Alle zurücksetzen
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {alerts.map((alert) => (
              <Alert 
                key={alert.id} 
                variant={alert.type === 'error' ? 'destructive' : 'default'}
                className={
                  alert.type === 'warning' 
                    ? 'border-amber-500/50 bg-amber-500/5' 
                    : alert.type === 'info' 
                      ? 'border-blue-500/50 bg-blue-500/5'
                      : ''
                }
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    {alert.type === 'error' ? (
                      <AlertCircle className="h-5 w-5 text-destructive mt-0.5" />
                    ) : alert.type === 'warning' ? (
                      <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                    ) : (
                      <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                    )}
                    <div className="space-y-1">
                      <AlertTitle className="text-sm font-medium flex items-center gap-2">
                        {alert.title}
                        {alert.metric && (
                          <Badge variant="outline" className="font-mono text-xs">
                            {alert.metric}
                          </Badge>
                        )}
                      </AlertTitle>
                      <AlertDescription className="text-xs text-muted-foreground">
                        {alert.description}
                      </AlertDescription>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 shrink-0"
                    onClick={() => dismissAlert(alert.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </Alert>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Export Actions */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Token-Statistiken</h2>
          <p className="text-sm text-muted-foreground">Letzte 30 Tage Übersicht</p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem 
              onClick={() => {
                const csv = generateStatisticsCSV(statistics, analysisStats);
                downloadCSV(csv, `token-statistiken-${format(new Date(), 'yyyy-MM-dd')}.csv`);
              }}
              className="gap-2"
            >
              <FileSpreadsheet className="h-4 w-4" />
              Als CSV exportieren
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => downloadStatisticsPDF(statistics, analysisStats)}
              className="gap-2"
            >
              <FileText className="h-4 w-4" />
              Als PDF exportieren
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Gesamt-Tokens (30 Tage)"
          value={formatTokens(statistics.totalTokens)}
          description={`${statistics.totalExecutions} Ausführungen`}
          icon={<Zap className="h-4 w-4" />}
        />
        <StatCard
          title="Ø Tokens/Ausführung"
          value={formatTokens(Math.round(statistics.avgTokensPerExecution))}
          description="Durchschnittlicher Verbrauch"
          icon={<BarChart3 className="h-4 w-4" />}
        />
        <StatCard
          title="KI-Analysen gecacht"
          value={(analysisStats?.hpoAnalyses || 0) + (analysisStats?.snomedAnalyses || 0) + (analysisStats?.icd10Analyses || 0)}
          description={`${analysisStats?.cachedMappings || 0} Mappings im Cache`}
          icon={<Database className="h-4 w-4" />}
        />
        <StatCard
          title="Geschätzt gespart"
          value={formatTokens(estimatedTokensSaved)}
          description="Durch Mapping-Cache"
          icon={<Sparkles className="h-4 w-4" />}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {/* Token-Verbrauch nach Phase */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Token-Verbrauch nach Phase
            </CardTitle>
            <CardDescription>
              Letzte 30 Tage, sortiert nach Verbrauch
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-4">
                {statistics.phaseStats.map((phase) => (
                  <div key={phase.phase} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        {PHASE_ICONS[phase.phase] || <Activity className="h-4 w-4" />}
                        <span className="font-medium">
                          {phase.templateName || `Phase ${phase.phase === '-1' ? 'D (Domäne)' : phase.phase}`}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {phase.executionCount}x
                        </Badge>
                      </div>
                      <div className="text-right">
                        <span className="font-mono">{formatTokens(phase.totalTokens)}</span>
                        <span className="text-muted-foreground text-xs ml-2">
                          ({((phase.totalTokens / statistics.totalTokens) * 100).toFixed(1)}%)
                        </span>
                      </div>
                    </div>
                    <Progress 
                      value={(phase.totalTokens / maxPhaseTokens) * 100} 
                      className="h-2"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Prompt: {formatTokens(phase.promptTokens)}</span>
                      <span>Completion: {formatTokens(phase.completionTokens)}</span>
                      <span>Ø {(phase.avgLatencyMs / 1000).toFixed(1)}s</span>
                    </div>
                  </div>
                ))}
                {statistics.phaseStats.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    Keine Phasen-Daten vorhanden
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Token-Verbrauch nach Domäne */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Token-Verbrauch nach Domäne
            </CardTitle>
            <CardDescription>
              Letzte 30 Tage, nach Fachbereich
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {statistics.domainStats.map((domain) => (
                <div key={domain.domain} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className={`h-3 w-3 rounded-full ${DOMAIN_COLORS[domain.domain] || 'bg-gray-500'}`} />
                      <span className="font-medium">{domain.domain}</span>
                      <Badge variant="outline" className="text-xs">
                        {domain.executionCount} Ausführungen
                      </Badge>
                    </div>
                    <span className="font-mono">{formatTokens(domain.totalTokens)}</span>
                  </div>
                  <Progress 
                    value={(domain.totalTokens / maxDomainTokens) * 100} 
                    className="h-3"
                  />
                  <p className="text-xs text-muted-foreground">
                    Ø {formatTokens(Math.round(domain.avgTokensPerExecution))} Tokens pro Ausführung
                  </p>
                </div>
              ))}
              {statistics.domainStats.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-8">
                  Keine Domänen-Daten vorhanden
                </p>
              )}
            </div>

            {/* Daily trend mini chart */}
            <div className="mt-8 pt-6 border-t">
              <h4 className="text-sm font-medium mb-4">Täglicher Verlauf (7 Tage)</h4>
              <div className="flex items-end gap-1 h-20">
                {statistics.dailyStats.map((day) => (
                  <div 
                    key={day.date}
                    className="flex-1 flex flex-col items-center gap-1"
                  >
                    <div 
                      className="w-full bg-primary/80 rounded-t transition-all hover:bg-primary"
                      style={{ 
                        height: `${maxDailyTokens > 0 ? (day.totalTokens / maxDailyTokens) * 100 : 0}%`,
                        minHeight: day.totalTokens > 0 ? '4px' : '0'
                      }}
                      title={`${formatTokens(day.totalTokens)} Tokens`}
                    />
                    <span className="text-[10px] text-muted-foreground">
                      {format(new Date(day.date), 'E', { locale: de })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Usage by Source Type */}
      {aiUsageLogs && aiUsageLogs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              KI-Anfragen nach Quelltyp
            </CardTitle>
            <CardDescription>
              Alle KI-Anfragen aus der Anwendung (letzte 30 Tage)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {(() => {
                // Calculate source type statistics
                const sourceTypeMap = new Map<string, SourceTypeStatistic>();
                for (const log of aiUsageLogs) {
                  const key = log.source_type;
                  const existing = sourceTypeMap.get(key) || {
                    source_type: key,
                    totalTokens: 0,
                    promptTokens: 0,
                    completionTokens: 0,
                    requestCount: 0,
                    avgLatencyMs: 0,
                  };
                  
                  existing.totalTokens += (log.prompt_tokens || 0) + (log.completion_tokens || 0);
                  existing.promptTokens += log.prompt_tokens || 0;
                  existing.completionTokens += log.completion_tokens || 0;
                  existing.requestCount += 1;
                  existing.avgLatencyMs = ((existing.avgLatencyMs * (existing.requestCount - 1)) + (log.latency_ms || 0)) / existing.requestCount;
                  
                  sourceTypeMap.set(key, existing);
                }
                
                const sourceTypeStats = Array.from(sourceTypeMap.values())
                  .sort((a, b) => b.totalTokens - a.totalTokens);
                const maxSourceTokens = Math.max(...sourceTypeStats.map(s => s.totalTokens), 1);
                const totalAllTokens = sourceTypeStats.reduce((sum, s) => sum + s.totalTokens, 0);
                
                const sourceTypeLabels: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
                  pipeline: { label: 'Pipelines', icon: <Workflow className="h-4 w-4" />, color: 'bg-primary' },
                  chat: { label: 'Chat', icon: <Brain className="h-4 w-4" />, color: 'bg-emerald-500' },
                  analysis: { label: 'Analysen', icon: <Sparkles className="h-4 w-4" />, color: 'bg-violet-500' },
                  translation: { label: 'Übersetzungen', icon: <Languages className="h-4 w-4" />, color: 'bg-sky-500' },
                  lookup: { label: 'Lookups', icon: <Search className="h-4 w-4" />, color: 'bg-amber-500' },
                  other: { label: 'Sonstige', icon: <Activity className="h-4 w-4" />, color: 'bg-muted' },
                };
                
                return (
                  <>
                    <div className="grid gap-3 md:grid-cols-3 mb-6">
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-xs text-muted-foreground">Gesamt-Tokens (alle Quellen)</p>
                        <p className="text-xl font-bold">{formatTokens(totalAllTokens)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-xs text-muted-foreground">Anfragen</p>
                        <p className="text-xl font-bold">{aiUsageLogs.length}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-xs text-muted-foreground">Quelltypen</p>
                        <p className="text-xl font-bold">{sourceTypeStats.length}</p>
                      </div>
                    </div>
                    
                    {sourceTypeStats.map((stat) => {
                      const info = sourceTypeLabels[stat.source_type] || sourceTypeLabels.other;
                      return (
                        <div key={stat.source_type} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              {info.icon}
                              <span className="font-medium">{info.label}</span>
                              <Badge variant="outline" className="text-xs">
                                {stat.requestCount} Anfragen
                              </Badge>
                            </div>
                            <div className="text-right">
                              <span className="font-mono">{formatTokens(stat.totalTokens)}</span>
                              <span className="text-muted-foreground text-xs ml-2">
                                ({totalAllTokens > 0 ? ((stat.totalTokens / totalAllTokens) * 100).toFixed(1) : 0}%)
                              </span>
                            </div>
                          </div>
                          <Progress 
                            value={(stat.totalTokens / maxSourceTokens) * 100} 
                            className="h-2"
                          />
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Prompt: {formatTokens(stat.promptTokens)}</span>
                            <span>Completion: {formatTokens(stat.completionTokens)}</span>
                            <span>Ø {(stat.avgLatencyMs / 1000).toFixed(1)}s</span>
                          </div>
                        </div>
                      );
                    })}
                  </>
                );
              })()}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cost Estimation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Kosten-Schätzung nach LLM-Anbieter
          </CardTitle>
          <CardDescription className="flex items-center gap-2">
            Basierend auf {formatTokens(statistics.totalTokens)} Tokens (30 Tage)
            <Tooltip>
              <TooltipTrigger>
                <Info className="h-4 w-4 text-muted-foreground" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>Geschätzte Kosten basierend auf aktuellen API-Preisen. 
                Tatsächliche Kosten können je nach Nutzungsmuster und Rabattvereinbarungen abweichen.</p>
              </TooltipContent>
            </Tooltip>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="comparison">
            <TabsList className="mb-4">
              <TabsTrigger value="comparison">Anbieter-Vergleich</TabsTrigger>
              <TabsTrigger value="details">Preisdetails</TabsTrigger>
            </TabsList>
            
            <TabsContent value="comparison">
              <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                {LLM_PRICING.map((pricing) => {
                  const totalPromptTokens = statistics.phaseStats.reduce((sum, p) => sum + p.promptTokens, 0);
                  const totalCompletionTokens = statistics.phaseStats.reduce((sum, p) => sum + p.completionTokens, 0);
                  const cost = calculateCost(totalPromptTokens, totalCompletionTokens, pricing);
                  const savedCost = calculateCost(estimatedTokensSaved * 0.4, estimatedTokensSaved * 0.6, pricing);
                  
                  return (
                    <div 
                      key={pricing.name} 
                      className="p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-medium text-sm">{pricing.name}</h4>
                          <p className="text-xs text-muted-foreground">{pricing.provider}</p>
                        </div>
                        {pricing.notes && (
                          <Badge variant="outline" className="text-[10px]">
                            {pricing.notes}
                          </Badge>
                        )}
                      </div>
                      <div className="mt-3">
                        <div className="text-2xl font-bold text-primary">
                          {formatCurrency(cost)}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Geschätzte Kosten / 30 Tage
                        </p>
                        {savedCost > 0.001 && (
                          <p className="text-xs text-green-600 mt-1">
                            ~ {formatCurrency(savedCost)} durch Cache gespart
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </TabsContent>
            
            <TabsContent value="details">
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Modell</TableHead>
                      <TableHead>Anbieter</TableHead>
                      <TableHead className="text-right">Input $/1M</TableHead>
                      <TableHead className="text-right">Output $/1M</TableHead>
                      <TableHead className="text-right">Geschätzt</TableHead>
                      <TableHead>Hinweise</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {LLM_PRICING.sort((a, b) => {
                      const totalPromptTokens = statistics.phaseStats.reduce((sum, p) => sum + p.promptTokens, 0);
                      const totalCompletionTokens = statistics.phaseStats.reduce((sum, p) => sum + p.completionTokens, 0);
                      return calculateCost(totalPromptTokens, totalCompletionTokens, a) - 
                             calculateCost(totalPromptTokens, totalCompletionTokens, b);
                    }).map((pricing, idx) => {
                      const totalPromptTokens = statistics.phaseStats.reduce((sum, p) => sum + p.promptTokens, 0);
                      const totalCompletionTokens = statistics.phaseStats.reduce((sum, p) => sum + p.completionTokens, 0);
                      const cost = calculateCost(totalPromptTokens, totalCompletionTokens, pricing);
                      
                      return (
                        <TableRow key={pricing.name}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {idx === 0 && (
                                <Badge className="bg-green-600 text-[10px]">Günstigst</Badge>
                              )}
                              {pricing.name}
                            </div>
                          </TableCell>
                          <TableCell>{pricing.provider}</TableCell>
                          <TableCell className="text-right font-mono text-sm">
                            ${pricing.inputPer1M.toFixed(2)}
                          </TableCell>
                          <TableCell className="text-right font-mono text-sm">
                            ${pricing.outputPer1M.toFixed(2)}
                          </TableCell>
                          <TableCell className="text-right font-mono text-sm font-bold">
                            {formatCurrency(cost)}
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {pricing.notes || '—'}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>
              <p className="text-xs text-muted-foreground mt-4">
                * Preise basieren auf öffentlichen API-Tarifen (Stand: Feb 2026). 
                Bei Prompt: {formatTokens(statistics.phaseStats.reduce((sum, p) => sum + p.promptTokens, 0))} / 
                Completion: {formatTokens(statistics.phaseStats.reduce((sum, p) => sum + p.completionTokens, 0))}
              </p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Cache Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Ontologie-Cache-Statistiken
          </CardTitle>
          <CardDescription>
            Gecachte Analysen und Mappings zur Token-Einsparung
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-3xl font-bold text-primary">{analysisStats?.hpoAnalyses || 0}</div>
              <p className="text-sm text-muted-foreground mt-1">HPO-Analysen</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-3xl font-bold text-primary">{analysisStats?.snomedAnalyses || 0}</div>
              <p className="text-sm text-muted-foreground mt-1">SNOMED-Analysen</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-3xl font-bold text-primary">{analysisStats?.icd10Analyses || 0}</div>
              <p className="text-sm text-muted-foreground mt-1">ICD-10-Analysen</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-3xl font-bold text-green-600">{analysisStats?.cachedMappings || 0}</div>
              <p className="text-sm text-muted-foreground mt-1">Mappings im Cache</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
