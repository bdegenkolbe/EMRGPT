import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  ChevronDown, 
  ChevronRight, 
  Clock, 
  Zap, 
  AlertCircle, 
  CheckCircle2,
  XCircle,
  Eye,
  RefreshCw
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { de } from 'date-fns/locale';

interface PipelineExecution {
  id: string;
  created_at: string;
  completed_at: string | null;
  status: string;
  domain: string;
  pipeline_id: string | null;
  session_id: string | null;
  input_data: Record<string, unknown>;
  output_data: Record<string, unknown> | null;
  total_latency_ms: number | null;
  total_tokens: number | null;
  error_message: string | null;
  pipeline?: { name: string } | null;
}

interface PhaseLog {
  id: string;
  execution_id: string;
  phase: string;
  template_id: string | null;
  status: string;
  input_data: Record<string, unknown>;
  output_data: Record<string, unknown> | null;
  latency_ms: number | null;
  prompt_tokens: number | null;
  completion_tokens: number | null;
  error_message: string | null;
  created_at: string;
  completed_at: string | null;
  template?: { name: string } | null;
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'completed':
      return (
        <Badge variant="default" className="bg-green-500/20 text-green-700 border-green-500/30">
          <CheckCircle2 className="h-3 w-3 mr-1" />
          Abgeschlossen
        </Badge>
      );
    case 'running':
      return (
        <Badge variant="default" className="bg-blue-500/20 text-blue-700 border-blue-500/30">
          <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
          Läuft
        </Badge>
      );
    case 'failed':
      return (
        <Badge variant="destructive">
          <XCircle className="h-3 w-3 mr-1" />
          Fehlgeschlagen
        </Badge>
      );
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

function DomainBadge({ domain }: { domain: string }) {
  const colors: Record<string, string> = {
    MEDICAL: 'bg-red-500/20 text-red-700 border-red-500/30',
    HR_LAW: 'bg-purple-500/20 text-purple-700 border-purple-500/30',
    TECHNICAL: 'bg-blue-500/20 text-blue-700 border-blue-500/30',
    GENERAL_INFO: 'bg-gray-500/20 text-gray-700 border-gray-500/30',
  };
  return (
    <Badge variant="outline" className={colors[domain] || colors.GENERAL_INFO}>
      {domain}
    </Badge>
  );
}

function PhaseRow({ phase, isLast }: { phase: PhaseLog; isLast: boolean }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className={`relative pl-6 ${!isLast ? 'pb-4' : ''}`}>
      {/* Timeline line */}
      {!isLast && (
        <div className="absolute left-[11px] top-6 bottom-0 w-0.5 bg-border" />
      )}
      
      {/* Timeline dot */}
      <div className={`absolute left-0 top-1.5 h-6 w-6 rounded-full flex items-center justify-center text-xs font-medium
        ${phase.status === 'completed' ? 'bg-green-500/20 text-green-700' : 
          phase.status === 'failed' ? 'bg-red-500/20 text-red-700' : 
          'bg-blue-500/20 text-blue-700'}`}>
        {phase.phase === '-1' ? 'D' : phase.phase}
      </div>

      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <div className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 rounded-lg p-2 -ml-2">
            {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            <span className="font-medium">{phase.template?.name || `Phase ${phase.phase}`}</span>
            <StatusBadge status={phase.status} />
            {phase.latency_ms && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {(phase.latency_ms / 1000).toFixed(1)}s
              </span>
            )}
            {(phase.prompt_tokens || phase.completion_tokens) && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Zap className="h-3 w-3" />
                {(phase.prompt_tokens || 0) + (phase.completion_tokens || 0)} tokens
              </span>
            )}
          </div>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="mt-2 space-y-3 text-sm">
            {phase.error_message && (
              <div className="bg-destructive/10 text-destructive rounded-lg p-3">
                <div className="flex items-center gap-2 font-medium">
                  <AlertCircle className="h-4 w-4" />
                  Fehler
                </div>
                <pre className="mt-1 whitespace-pre-wrap text-xs">{phase.error_message}</pre>
              </div>
            )}
            
            {phase.output_data && (
              <div className="bg-muted rounded-lg p-3">
                <div className="font-medium mb-2">Ausgabe:</div>
                <ScrollArea className="max-h-[300px]">
                  <pre className="text-xs whitespace-pre-wrap">
                    {JSON.stringify(phase.output_data, null, 2)}
                  </pre>
                </ScrollArea>
              </div>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

function ExecutionDetailDialog({ 
  execution, 
  open, 
  onOpenChange 
}: { 
  execution: PipelineExecution | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { data: phases, isLoading } = useQuery({
    queryKey: ['pipeline-phases', execution?.id],
    queryFn: async () => {
      if (!execution) return [];
      const { data, error } = await supabase
        .from('pipeline_phase_logs')
        .select('*, template:prompt_templates(name)')
        .eq('execution_id', execution.id)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data as PhaseLog[];
    },
    enabled: !!execution && open,
  });

  if (!execution) return null;

  const userInput = execution.input_data?.user_input as string || '';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            Pipeline-Ausführung
            <StatusBadge status={execution.status} />
            <DomainBadge domain={execution.domain} />
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm">Übersicht</CardTitle>
            </CardHeader>
            <CardContent className="py-2 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Pipeline:</span>
                <span>{execution.pipeline?.name || 'Keine'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Latenz:</span>
                <span>{execution.total_latency_ms ? `${(execution.total_latency_ms / 1000).toFixed(1)}s` : '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tokens:</span>
                <span>{execution.total_tokens?.toLocaleString() || '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Erstellt:</span>
                <span>{formatDistanceToNow(new Date(execution.created_at), { addSuffix: true, locale: de })}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm">Eingabe</CardTitle>
            </CardHeader>
            <CardContent className="py-2">
              <p className="text-xs text-muted-foreground line-clamp-4">
                {userInput || 'Keine Eingabe'}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="flex-1 overflow-hidden">
          <h4 className="font-medium mb-3">Phasen-Verlauf</h4>
          <ScrollArea className="h-[400px] pr-4">
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : phases && phases.length > 0 ? (
              <div className="space-y-1">
                {phases.map((phase, idx) => (
                  <PhaseRow 
                    key={phase.id} 
                    phase={phase} 
                    isLast={idx === phases.length - 1} 
                  />
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                Keine Phasen-Logs gefunden
              </div>
            )}
          </ScrollArea>
        </div>

        {execution.error_message && (
          <div className="bg-destructive/10 text-destructive rounded-lg p-3 text-sm">
            <div className="flex items-center gap-2 font-medium">
              <AlertCircle className="h-4 w-4" />
              Ausführungsfehler
            </div>
            <pre className="mt-1 whitespace-pre-wrap text-xs">{execution.error_message}</pre>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function ExecutionHistory() {
  const { t } = useTranslation();
  const [selectedExecution, setSelectedExecution] = useState<PipelineExecution | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const { data: executions, isLoading, refetch } = useQuery({
    queryKey: ['pipeline-executions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('pipeline_executions')
        .select('*, pipeline:pipelines(name)')
        .order('created_at', { ascending: false })
        .limit(50);
      
      if (error) throw error;
      return data as PipelineExecution[];
    },
    refetchInterval: 10000, // Auto-refresh every 10s
  });

  const handleViewDetails = (execution: PipelineExecution) => {
    setSelectedExecution(execution);
    setDetailOpen(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Ausführungshistorie</h3>
          <p className="text-sm text-muted-foreground">
            Übersicht aller Pipeline-Ausführungen mit Phase-Details
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Aktualisieren
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : executions && executions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Zeit</TableHead>
                  <TableHead>Domäne</TableHead>
                  <TableHead>Pipeline</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Latenz</TableHead>
                  <TableHead className="text-right">Tokens</TableHead>
                  <TableHead className="text-right">Phasen</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {executions.map((exec) => {
                  const phasesExecuted = (exec.output_data as Record<string, unknown>)?.phases_executed as number;
                  return (
                    <TableRow key={exec.id}>
                      <TableCell className="text-sm">
                        {formatDistanceToNow(new Date(exec.created_at), { addSuffix: true, locale: de })}
                      </TableCell>
                      <TableCell>
                        <DomainBadge domain={exec.domain} />
                      </TableCell>
                      <TableCell className="text-sm">
                        {exec.pipeline?.name || '-'}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={exec.status} />
                      </TableCell>
                      <TableCell className="text-right text-sm text-muted-foreground">
                        {exec.total_latency_ms ? `${(exec.total_latency_ms / 1000).toFixed(1)}s` : '-'}
                      </TableCell>
                      <TableCell className="text-right text-sm text-muted-foreground">
                        {exec.total_tokens?.toLocaleString() || '-'}
                      </TableCell>
                      <TableCell className="text-right text-sm">
                        {phasesExecuted || '-'}
                      </TableCell>
                      <TableCell>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleViewDetails(exec)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center text-muted-foreground py-12">
              Noch keine Pipeline-Ausführungen vorhanden
            </div>
          )}
        </CardContent>
      </Card>

      <ExecutionDetailDialog
        execution={selectedExecution}
        open={detailOpen}
        onOpenChange={setDetailOpen}
      />
    </div>
  );
}
