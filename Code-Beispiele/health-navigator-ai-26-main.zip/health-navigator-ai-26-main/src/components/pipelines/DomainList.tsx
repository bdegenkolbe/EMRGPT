import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useDomains, useUpdateDomain, type PipelineDomain } from '@/hooks/usePipelines';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Pencil, X, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function DomainList() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { data: domains, isLoading } = useDomains();
  const updateDomain = useUpdateDomain();
  
  const [editingDomain, setEditingDomain] = useState<PipelineDomain | null>(null);
  const [keywords, setKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState('');

  const handleEdit = (domain: PipelineDomain) => {
    setEditingDomain(domain);
    setKeywords(domain.classification_keywords || []);
    setNewKeyword('');
  };

  const handleToggleActive = async (domain: PipelineDomain) => {
    try {
      await updateDomain.mutateAsync({
        id: domain.id,
        is_active: !domain.is_active,
      });
      toast({
        title: t('common.success'),
        description: domain.is_active 
          ? t('admin.pipelines.domainDeactivated', { defaultValue: 'Domäne deaktiviert' })
          : t('admin.pipelines.domainActivated', { defaultValue: 'Domäne aktiviert' }),
      });
    } catch (error) {
      toast({
        title: t('common.error'),
        description: String(error),
        variant: 'destructive',
      });
    }
  };

  const handleAddKeyword = () => {
    if (newKeyword.trim() && !keywords.includes(newKeyword.trim())) {
      setKeywords([...keywords, newKeyword.trim()]);
      setNewKeyword('');
    }
  };

  const handleRemoveKeyword = (keyword: string) => {
    setKeywords(keywords.filter(k => k !== keyword));
  };

  const handleSave = async () => {
    if (!editingDomain) return;
    
    try {
      await updateDomain.mutateAsync({
        id: editingDomain.id,
        classification_keywords: keywords,
        description: editingDomain.description,
      });
      toast({
        title: t('common.success'),
        description: t('admin.pipelines.domainUpdated', { defaultValue: 'Domäne aktualisiert' }),
      });
      setEditingDomain(null);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: String(error),
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>
            {t('admin.pipelines.domains.title', { defaultValue: 'Fachdomänen' })}
          </CardTitle>
          <CardDescription>
            {t('admin.pipelines.domains.description', { 
              defaultValue: 'Domänen für die automatische Klassifikation von Anfragen' 
            })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('common.name')}</TableHead>
                <TableHead>{t('admin.pipelines.domains.slug', { defaultValue: 'Slug' })}</TableHead>
                <TableHead>{t('admin.pipelines.domains.keywords', { defaultValue: 'Keywords' })}</TableHead>
                <TableHead className="text-center">{t('common.active')}</TableHead>
                <TableHead className="text-right">{t('common.actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {domains?.map((domain) => (
                <TableRow key={domain.id}>
                  <TableCell className="font-medium">{domain.name}</TableCell>
                  <TableCell>
                    <code className="text-xs bg-muted px-1 py-0.5 rounded">{domain.slug}</code>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {(domain.classification_keywords || []).slice(0, 3).map((kw) => (
                        <Badge key={kw} variant="secondary" className="text-xs">
                          {kw}
                        </Badge>
                      ))}
                      {(domain.classification_keywords || []).length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{domain.classification_keywords.length - 3}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <Switch
                      checked={domain.is_active}
                      onCheckedChange={() => handleToggleActive(domain)}
                      disabled={domain.slug === 'MEDICAL'}
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(domain)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!editingDomain} onOpenChange={(open) => !open && setEditingDomain(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {t('admin.pipelines.domains.edit', { defaultValue: 'Domäne bearbeiten' })}
            </DialogTitle>
            <DialogDescription>
              {editingDomain?.name} ({editingDomain?.slug})
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t('common.description')}</Label>
              <Textarea
                value={editingDomain?.description || ''}
                onChange={(e) => setEditingDomain(prev => 
                  prev ? { ...prev, description: e.target.value } : null
                )}
                placeholder={t('admin.pipelines.domains.descriptionPlaceholder', {
                  defaultValue: 'Beschreibung der Domäne...'
                })}
              />
            </div>

            <div className="space-y-2">
              <Label>
                {t('admin.pipelines.domains.classificationKeywords', {
                  defaultValue: 'Klassifikations-Keywords'
                })}
              </Label>
              <div className="flex gap-2">
                <Input
                  value={newKeyword}
                  onChange={(e) => setNewKeyword(e.target.value)}
                  placeholder={t('admin.pipelines.domains.addKeyword', {
                    defaultValue: 'Keyword hinzufügen...'
                  })}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddKeyword()}
                />
                <Button onClick={handleAddKeyword} size="icon" variant="outline">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-1 mt-2">
                {keywords.map((kw) => (
                  <Badge key={kw} variant="secondary" className="gap-1">
                    {kw}
                    <button
                      onClick={() => handleRemoveKeyword(kw)}
                      className="ml-1 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingDomain(null)}>
              {t('common.cancel')}
            </Button>
            <Button onClick={handleSave} disabled={updateDomain.isPending}>
              {t('common.save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
