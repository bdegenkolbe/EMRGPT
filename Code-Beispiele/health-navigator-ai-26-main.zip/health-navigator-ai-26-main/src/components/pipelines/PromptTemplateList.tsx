import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  useDomains,
  usePipelines,
  usePromptTemplates,
  useDeleteTemplate,
  type PromptTemplate,
} from '@/hooks/usePipelines';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Pencil, Plus, Trash2, History, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { PromptTemplateEditor } from './PromptTemplateEditor';

export function PromptTemplateList() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { data: domains } = useDomains();
  const [selectedDomainId, setSelectedDomainId] = useState<string>('');
  const [selectedPipelineId, setSelectedPipelineId] = useState<string>('');
  const { data: pipelines } = usePipelines(selectedDomainId || undefined);
  const { data: templates, isLoading } = usePromptTemplates(
    selectedPipelineId || undefined,
    selectedDomainId || undefined
  );
  const deleteTemplate = useDeleteTemplate();
  
  const [editingTemplate, setEditingTemplate] = useState<PromptTemplate | null>(null);
  const [creatingNew, setCreatingNew] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async () => {
    if (!deletingId) return;
    
    try {
      await deleteTemplate.mutateAsync(deletingId);
      toast({
        title: t('common.success'),
        description: t('admin.pipelines.templateDeleted', { defaultValue: 'Template gelöscht' }),
      });
    } catch (error) {
      toast({
        title: t('common.error'),
        description: String(error),
        variant: 'destructive',
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleDomainChange = (value: string) => {
    setSelectedDomainId(value);
    setSelectedPipelineId('');
  };

  const getPhaseLabel = (phase: string) => {
    const labels: Record<string, string> = {
      '-1': 'Domain-Klassifikation',
      '1': 'Intent & Safety Triage',
      '2': 'Kontext-Erhebung',
      '3': 'Normalisierung',
      '4': 'Kategorisierung',
      '5': 'Wissens-Retrieval',
      '6': 'Reranking',
      '7': 'Validierung',
      '8': 'Synthese',
      'H1': 'HR-Validierung',
      'H2': 'HR-Antwort',
      'G1': 'Allgemeine Antwort',
    };
    return labels[phase] || phase;
  };

  // Group templates by phase, showing only active ones by default
  const activeTemplates = templates?.filter(t => t.is_active) || [];

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>
                {t('admin.pipelines.templates.title', { defaultValue: 'Prompt-Templates' })}
              </CardTitle>
              <CardDescription>
                {t('admin.pipelines.templates.description', {
                  defaultValue: 'System-Prompts für die Pipeline-Phasen verwalten'
                })}
              </CardDescription>
            </div>
            <Button onClick={() => setCreatingNew(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              {t('admin.pipelines.templates.create', { defaultValue: 'Neues Template' })}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 space-y-2">
              <Label>{t('admin.pipelines.selectDomain', { defaultValue: 'Domäne' })}</Label>
              <Select value={selectedDomainId} onValueChange={handleDomainChange}>
                <SelectTrigger>
                  <SelectValue placeholder={t('common.all')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('common.all')}</SelectItem>
                  {domains?.filter(d => d.is_active).map((domain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1 space-y-2">
              <Label>{t('admin.pipelines.selectPipeline', { defaultValue: 'Pipeline' })}</Label>
              <Select 
                value={selectedPipelineId} 
                onValueChange={setSelectedPipelineId}
                disabled={!selectedDomainId}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('common.all')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('common.all')}</SelectItem>
                  {pipelines?.map((pipeline) => (
                    <SelectItem key={pipeline.id} value={pipeline.id}>
                      {pipeline.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : activeTemplates.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {t('admin.pipelines.templates.empty', {
                defaultValue: 'Keine Templates gefunden. Erstellen Sie ein neues Template.'
              })}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('admin.pipelines.templates.phase', { defaultValue: 'Phase' })}</TableHead>
                  <TableHead>{t('common.name')}</TableHead>
                  <TableHead>{t('admin.pipelines.templates.model', { defaultValue: 'Modell' })}</TableHead>
                  <TableHead className="text-center">
                    {t('admin.pipelines.templates.version', { defaultValue: 'Version' })}
                  </TableHead>
                  <TableHead className="text-right">{t('common.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeTemplates.map((template) => (
                  <TableRow key={template.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="font-mono">
                          {template.phase}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {getPhaseLabel(template.phase)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{template.name}</TableCell>
                    <TableCell>
                      <code className="text-xs bg-muted px-1 py-0.5 rounded">
                        {template.model_config?.model || 'gpt-4o-mini'}
                      </code>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary">v{template.version}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setEditingTemplate(template)}
                          title={t('common.edit')}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeletingId(template.id)}
                          title={t('common.delete')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Template Editor Dialog */}
      <PromptTemplateEditor
        open={!!editingTemplate || creatingNew}
        onOpenChange={(open) => {
          if (!open) {
            setEditingTemplate(null);
            setCreatingNew(false);
          }
        }}
        template={editingTemplate}
        defaultDomainId={selectedDomainId}
        defaultPipelineId={selectedPipelineId}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingId} onOpenChange={(open) => !open && setDeletingId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {t('admin.pipelines.templates.deleteTitle', { defaultValue: 'Template löschen?' })}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {t('admin.pipelines.templates.deleteDescription', {
                defaultValue: 'Diese Aktion kann nicht rückgängig gemacht werden.'
              })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              {t('common.delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
