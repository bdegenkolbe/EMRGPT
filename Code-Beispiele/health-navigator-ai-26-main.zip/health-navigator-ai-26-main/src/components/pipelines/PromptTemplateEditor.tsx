import { useState, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
  useDomains,
  usePipelines,
  useCreateTemplate,
  useUpdateTemplate,
  useCreateTemplateVersion,
  type PromptTemplate,
} from '@/hooks/usePipelines';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { Play, Save, GitBranch, History } from 'lucide-react';
import { VersionHistory } from './VersionHistory';

interface PromptTemplateEditorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  template: PromptTemplate | null;
  defaultDomainId?: string;
  defaultPipelineId?: string;
}

export function PromptTemplateEditor({
  open,
  onOpenChange,
  template,
  defaultDomainId,
  defaultPipelineId,
}: PromptTemplateEditorProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { data: domains } = useDomains();
  const [selectedDomainId, setSelectedDomainId] = useState(defaultDomainId || '');
  const { data: pipelines } = usePipelines(selectedDomainId || undefined);
  
  const createTemplate = useCreateTemplate();
  const updateTemplate = useUpdateTemplate();
  const createVersion = useCreateTemplateVersion();

  // Form state
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [phase, setPhase] = useState('');
  const [pipelineId, setPipelineId] = useState(defaultPipelineId || '');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [userPromptTemplate, setUserPromptTemplate] = useState('');
  const [model, setModel] = useState('gpt-4o-mini');
  const [temperature, setTemperature] = useState(0.3);
  const [maxTokens, setMaxTokens] = useState(2000);
  const [testData, setTestData] = useState('{\n  "USER_INPUT": "Ich habe seit 3 Tagen Bauchschmerzen"\n}');
  const [previewResult, setPreviewResult] = useState('');

  const isEditing = !!template;

  // Initialize form when template changes
  useEffect(() => {
    if (template) {
      setName(template.name);
      setDescription(template.description || '');
      setPhase(template.phase);
      setSelectedDomainId(template.domain_id || '');
      setPipelineId(template.pipeline_id || '');
      setSystemPrompt(template.system_prompt);
      setUserPromptTemplate(template.user_prompt_template || '');
      setModel(template.model_config?.model || 'gpt-4o-mini');
      setTemperature(template.model_config?.temperature || 0.3);
      setMaxTokens(template.model_config?.max_tokens || 2000);
    } else {
      // Reset form for new template
      setName('');
      setDescription('');
      setPhase('');
      setSelectedDomainId(defaultDomainId || '');
      setPipelineId(defaultPipelineId || '');
      setSystemPrompt('');
      setUserPromptTemplate('');
      setModel('gpt-4o-mini');
      setTemperature(0.3);
      setMaxTokens(2000);
    }
  }, [template, defaultDomainId, defaultPipelineId]);

  // Extract parameters from prompts
  const extractedParams = useMemo(() => {
    const combined = systemPrompt + (userPromptTemplate || '');
    const matches = combined.match(/\{\{([A-Z_]+)\}\}/g) || [];
    return [...new Set(matches.map(m => m.replace(/\{\{|\}\}/g, '')))];
  }, [systemPrompt, userPromptTemplate]);

  // Generate preview with test data
  const handlePreview = () => {
    try {
      const data = JSON.parse(testData);
      let result = systemPrompt;
      
      for (const [key, value] of Object.entries(data)) {
        result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), String(value));
      }
      
      if (userPromptTemplate) {
        result += '\n\n--- User Prompt ---\n\n';
        let userResult = userPromptTemplate;
        for (const [key, value] of Object.entries(data)) {
          userResult = userResult.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), String(value));
        }
        result += userResult;
      }
      
      setPreviewResult(result);
    } catch (e) {
      toast({
        title: t('common.error'),
        description: 'Ungültiges JSON in Testdaten',
        variant: 'destructive',
      });
    }
  };

  const handleSave = async () => {
    if (!name || !phase || !systemPrompt) {
      toast({
        title: t('common.error'),
        description: t('admin.pipelines.templates.requiredFields', {
          defaultValue: 'Name, Phase und System-Prompt sind erforderlich'
        }),
        variant: 'destructive',
      });
      return;
    }

    const templateData = {
      name,
      description,
      phase,
      domain_id: selectedDomainId || null,
      pipeline_id: pipelineId || null,
      system_prompt: systemPrompt,
      user_prompt_template: userPromptTemplate || null,
      model_config: { model, temperature, max_tokens: maxTokens },
      parameter_schema: {},
      is_active: true,
      version: 1,
      parent_template_id: null,
      created_by: null,
    };

    try {
      if (isEditing) {
        await updateTemplate.mutateAsync({ id: template.id, ...templateData });
        toast({
          title: t('common.success'),
          description: t('admin.pipelines.templates.updated', { defaultValue: 'Template aktualisiert' }),
        });
      } else {
        await createTemplate.mutateAsync(templateData);
        toast({
          title: t('common.success'),
          description: t('admin.pipelines.templates.created', { defaultValue: 'Template erstellt' }),
        });
      }
      onOpenChange(false);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: String(error),
        variant: 'destructive',
      });
    }
  };

  const handleCreateVersion = async () => {
    if (!template) return;
    
    try {
      await createVersion.mutateAsync({
        parentId: template.id,
        updates: {
          system_prompt: systemPrompt,
          user_prompt_template: userPromptTemplate,
          model_config: { model, temperature, max_tokens: maxTokens },
        },
      });
      toast({
        title: t('common.success'),
        description: t('admin.pipelines.templates.versionCreated', {
          defaultValue: 'Neue Version erstellt'
        }),
      });
      onOpenChange(false);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: String(error),
        variant: 'destructive',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>
            {isEditing
              ? t('admin.pipelines.templates.edit', { defaultValue: 'Template bearbeiten' })
              : t('admin.pipelines.templates.create', { defaultValue: 'Neues Template' })}
          </DialogTitle>
          <DialogDescription>
            {isEditing && (
              <span className="flex items-center gap-2">
                {template.name} <Badge variant="secondary">v{template.version}</Badge>
              </span>
            )}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="prompt" className="flex-1 overflow-hidden">
          <TabsList className={isEditing ? "grid w-full grid-cols-4" : "grid w-full grid-cols-3"}>
            <TabsTrigger value="prompt">Prompt</TabsTrigger>
            <TabsTrigger value="config">Konfiguration</TabsTrigger>
            <TabsTrigger value="preview">Live-Preview</TabsTrigger>
            {isEditing && (
              <TabsTrigger value="history" className="gap-1">
                <History className="h-3 w-3" />
                Versionen
              </TabsTrigger>
            )}
          </TabsList>

          <ScrollArea className="flex-1 mt-4">
            <TabsContent value="prompt" className="space-y-4 pr-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{t('common.name')} *</Label>
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Intent & Safety Triage"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('admin.pipelines.templates.phase', { defaultValue: 'Phase' })} *</Label>
                  <Input
                    value={phase}
                    onChange={(e) => setPhase(e.target.value)}
                    placeholder="1"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>{t('common.description')}</Label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Beschreibung des Templates..."
                />
              </div>

              <div className="space-y-2">
                <Label>System-Prompt *</Label>
                <Textarea
                  value={systemPrompt}
                  onChange={(e) => setSystemPrompt(e.target.value)}
                  placeholder="Du bist ein medizinisches Triage-Modul..."
                  className="min-h-[200px] font-mono text-sm"
                />
                {extractedParams.length > 0 && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>Parameter:</span>
                    {extractedParams.map((param) => (
                      <Badge key={param} variant="outline" className="font-mono">
                        {`{{${param}}}`}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>User-Prompt Template (optional)</Label>
                <Textarea
                  value={userPromptTemplate}
                  onChange={(e) => setUserPromptTemplate(e.target.value)}
                  placeholder="{{USER_INPUT}}"
                  className="min-h-[100px] font-mono text-sm"
                />
              </div>
            </TabsContent>

            <TabsContent value="config" className="space-y-4 pr-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{t('admin.pipelines.selectDomain', { defaultValue: 'Domäne' })}</Label>
                  <Select value={selectedDomainId} onValueChange={setSelectedDomainId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Keine Domäne" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Keine Domäne</SelectItem>
                      {domains?.filter(d => d.is_active).map((domain) => (
                        <SelectItem key={domain.id} value={domain.id}>
                          {domain.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>{t('admin.pipelines.selectPipeline', { defaultValue: 'Pipeline' })}</Label>
                  <Select value={pipelineId} onValueChange={setPipelineId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Keine Pipeline" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Keine Pipeline</SelectItem>
                      {pipelines?.map((pipeline) => (
                        <SelectItem key={pipeline.id} value={pipeline.id}>
                          {pipeline.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">
                    {t('admin.pipelines.templates.modelConfig', { defaultValue: 'Modell-Konfiguration' })}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Modell</Label>
                    <Select value={model} onValueChange={setModel}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gpt-4o-mini">GPT-4o Mini</SelectItem>
                        <SelectItem value="gpt-4o">GPT-4o</SelectItem>
                        <SelectItem value="gpt-4-turbo">GPT-4 Turbo</SelectItem>
                        <SelectItem value="google/gemini-2.0-flash">Gemini 2.0 Flash</SelectItem>
                        <SelectItem value="google/gemini-2.0-pro">Gemini 2.0 Pro</SelectItem>
                        <SelectItem value="anthropic/claude-3.5-sonnet">Claude 3.5 Sonnet</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Temperature</Label>
                      <span className="text-sm text-muted-foreground">{temperature}</span>
                    </div>
                    <Slider
                      value={[temperature]}
                      onValueChange={([v]) => setTemperature(v)}
                      min={0}
                      max={1}
                      step={0.1}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Max Tokens</Label>
                    <Input
                      type="number"
                      value={maxTokens}
                      onChange={(e) => setMaxTokens(parseInt(e.target.value) || 2000)}
                      min={100}
                      max={16000}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preview" className="space-y-4 pr-4">
              <div className="space-y-2">
                <Label>Testdaten (JSON)</Label>
                <Textarea
                  value={testData}
                  onChange={(e) => setTestData(e.target.value)}
                  className="min-h-[100px] font-mono text-sm"
                />
                <Button onClick={handlePreview} variant="outline" className="gap-2">
                  <Play className="h-4 w-4" />
                  Preview generieren
                </Button>
              </div>

              {previewResult && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Gerendeter Prompt</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <pre className="whitespace-pre-wrap text-sm bg-muted p-4 rounded-lg overflow-auto max-h-[300px]">
                      {previewResult}
                    </pre>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {isEditing && template && (
              <TabsContent value="history" className="pr-4">
                <VersionHistory 
                  template={template}
                  onSelectVersion={(selectedVersion) => {
                    // Load selected version data into form
                    setSystemPrompt(selectedVersion.system_prompt);
                    setUserPromptTemplate(selectedVersion.user_prompt_template || '');
                    setModel(selectedVersion.model_config?.model || 'gpt-4o-mini');
                    setTemperature(selectedVersion.model_config?.temperature || 0.3);
                    setMaxTokens(selectedVersion.model_config?.max_tokens || 2000);
                  }}
                />
              </TabsContent>
            )}
          </ScrollArea>
        </Tabs>

        <DialogFooter className="gap-2 sm:gap-0">
          {isEditing && (
            <Button
              variant="outline"
              onClick={handleCreateVersion}
              disabled={createVersion.isPending}
              className="gap-2"
            >
              <GitBranch className="h-4 w-4" />
              Neue Version
            </Button>
          )}
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t('common.cancel')}
          </Button>
          <Button
            onClick={handleSave}
            disabled={createTemplate.isPending || updateTemplate.isPending}
            className="gap-2"
          >
            <Save className="h-4 w-4" />
            {t('common.save')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
