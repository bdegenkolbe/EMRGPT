import { useState, useEffect, useCallback } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Stethoscope,
  Users,
  FileText,
  Activity,
  TreeDeciduous,
  GitBranch,
  Workflow,
  ChevronLeft,
  ChevronRight,
  HeartPulse,
  MessageCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const SIDEBAR_COLLAPSED_KEY = 'sidebar-collapsed';

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  collapsed: boolean;
}

function NavItem({ to, icon, label, collapsed }: NavItemProps) {
  const location = useLocation();
  const isActive = location.pathname === to || location.pathname.startsWith(to + '/');

  const linkContent = (
    <NavLink
      to={to}
      className={cn(
        'group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium',
        'transition-all duration-300 ease-out',
        collapsed && 'justify-center px-2',
        isActive
          ? 'bg-primary text-primary-foreground shadow-[0_0_12px_hsl(var(--primary)/0.4)]'
          : 'text-muted-foreground hover:bg-muted hover:text-foreground hover:translate-x-1 hover:shadow-[0_0_15px_hsl(var(--primary)/0.15)]'
      )}
    >
      <span className={cn(
        'transition-transform duration-300 flex-shrink-0',
        !isActive && 'group-hover:scale-110 group-hover:text-primary'
      )}>
        {icon}
      </span>
      <span className={cn(
        'transition-all duration-300 whitespace-nowrap',
        collapsed ? 'w-0 opacity-0 overflow-hidden' : 'w-auto opacity-100'
      )}>
        {label}
      </span>
    </NavLink>
  );

  if (collapsed) {
    return (
      <Tooltip delayDuration={0}>
        <TooltipTrigger asChild>
          {linkContent}
        </TooltipTrigger>
        <TooltipContent side="right" className="font-medium">
          {label}
        </TooltipContent>
      </Tooltip>
    );
  }

  return linkContent;
}

export function Sidebar() {
  const { t } = useTranslation();
  const { isAdmin } = useAuth();
  const { profile, updateProfile } = useProfile();
  
  // Initialize from localStorage, then sync with profile
  const [collapsed, setCollapsed] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_COLLAPSED_KEY);
    return saved === 'true';
  });

  // Sync with profile when it loads
  useEffect(() => {
    if (profile?.sidebar_collapsed !== undefined && profile.sidebar_collapsed !== collapsed) {
      setCollapsed(profile.sidebar_collapsed);
      localStorage.setItem(SIDEBAR_COLLAPSED_KEY, String(profile.sidebar_collapsed));
    }
  }, [profile?.sidebar_collapsed]);

  const handleToggle = useCallback(() => {
    const newValue = !collapsed;
    setCollapsed(newValue);
    localStorage.setItem(SIDEBAR_COLLAPSED_KEY, String(newValue));
    
    // Sync to profile in background (no toast for this)
    if (profile && profile.sidebar_collapsed !== newValue) {
      updateProfile.mutate({ sidebar_collapsed: newValue }, {
        onSuccess: () => {},
        onError: () => {},
      });
    }
  }, [collapsed, profile, updateProfile]);

  return (
    <TooltipProvider>
      <aside className={cn(
        'hidden flex-shrink-0 border-r bg-background md:block',
        'transition-all duration-300 ease-out',
        collapsed ? 'w-16' : 'w-64'
      )}>
        <nav className="flex h-full flex-col gap-2 p-4">
          <div className="flex justify-end mb-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleToggle}
              className={cn(
                'h-8 w-8 transition-all duration-300',
                'hover:bg-muted hover:shadow-[0_0_10px_hsl(var(--primary)/0.1)]'
              )}
            >
              {collapsed ? (
                <ChevronRight className="h-4 w-4 transition-transform duration-300" />
              ) : (
                <ChevronLeft className="h-4 w-4 transition-transform duration-300" />
              )}
            </Button>
          </div>

          <div className="space-y-1">
            <NavItem
              to="/dashboard"
              icon={<LayoutDashboard className="h-4 w-4" />}
              label={t('nav.dashboard')}
              collapsed={collapsed}
            />
            <NavItem
              to="/anamnesis"
              icon={<Stethoscope className="h-4 w-4" />}
              label={t('nav.anamnesis')}
              collapsed={collapsed}
            />
            <NavItem
              to="/patients"
              icon={<HeartPulse className="h-4 w-4" />}
              label={t('nav.patients', { defaultValue: 'Patienten' })}
              collapsed={collapsed}
            />
            <NavItem
              to="/chatbot"
              icon={<MessageCircle className="h-4 w-4" />}
              label={t('nav.chatbot', { defaultValue: 'Chatbot' })}
              collapsed={collapsed}
            />
          </div>

          {isAdmin && (
            <>
              <div className={cn(
                'my-4 border-t transition-all duration-300',
                collapsed && 'mx-1'
              )} />
              <div className="space-y-1">
                <p className={cn(
                  'mb-2 px-3 text-xs font-semibold uppercase text-muted-foreground',
                  'transition-all duration-300',
                  collapsed && 'text-center px-0 text-[10px]'
                )}>
                  {collapsed ? '•••' : t('nav.administration')}
                </p>
                <NavItem
                  to="/admin/users"
                  icon={<Users className="h-4 w-4" />}
                  label={t('nav.users')}
                  collapsed={collapsed}
                />
                <NavItem
                  to="/admin/integrations"
                  icon={<Activity className="h-4 w-4" />}
                  label={t('nav.integrations')}
                  collapsed={collapsed}
                />
                <NavItem
                  to="/admin/guidelines"
                  icon={<FileText className="h-4 w-4" />}
                  label={t('nav.guidelines', { defaultValue: 'Leitlinien' })}
                  collapsed={collapsed}
                />
                <NavItem
                  to="/admin/pipelines"
                  icon={<Workflow className="h-4 w-4" />}
                  label={t('nav.pipelines', { defaultValue: 'Pipelines' })}
                  collapsed={collapsed}
                />
                <NavItem
                  to="/ontology"
                  icon={<TreeDeciduous className="h-4 w-4" />}
                  label={t('nav.ontology', { defaultValue: 'Ontologie' })}
                  collapsed={collapsed}
                />
                <NavItem
                  to="/pathways"
                  icon={<GitBranch className="h-4 w-4" />}
                  label={t('nav.pathways', { defaultValue: 'Anamnesepfade' })}
                  collapsed={collapsed}
                />
              </div>
            </>
          )}
        </nav>
      </aside>
    </TooltipProvider>
  );
}
