import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useProfile } from '@/hooks/useProfile';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Sparkles,
  RefreshCw,
  Languages,
  FileText,
  Stethoscope,
  TreeDeciduous,
  Link2,
  Loader2,
  ExternalLink,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ContentBlock {
  explanation: string;
  symptoms: string;
  therapy: string;
  notes: string;
}

interface BaseMapping {
  relation: string;
}

interface HPOMappingItem extends BaseMapping {
  code: string;
  label_de: string;
  label_en: string;
}

interface SnomedMappingItem extends BaseMapping {
  sctid: string;
  pt_de: string;
  pt_en: string;
}

interface ICD10MappingItem extends BaseMapping {
  code: string;
  title_de: string;
  title_en: string;
}

interface OntologyAnalysisPanelProps {
  type: 'hpo' | 'snomed';
  code: string;
  label: string;
}

const LANGUAGES = [
  { code: 'de', label: 'Deutsch' },
  { code: 'en', label: 'English' },
  { code: 'fr', label: 'Français' },
  { code: 'es', label: 'Español' },
];

function ContentView({ content }: { content: string }) {
  const formatContent = (text: string) => {
    if (!text) return '';
    if (text.includes('* ') && !text.includes('<ul>') && !text.includes('<li>')) {
      const lines = text.split('\n').filter(l => l.trim());
      const listItems = lines
        .map(line => {
          const trimmed = line.trim();
          if (trimmed.startsWith('* ')) {
            return `<li>${trimmed.substring(2)}</li>`;
          }
          return `<p>${trimmed}</p>`;
        })
        .join('');
      return listItems.replace(/(<li>.*?<\/li>)+/g, '<ul>$&</ul>');
    }
    return text;
  };

  return (
    <div 
      className="prose prose-sm max-w-none dark:prose-invert p-3 bg-muted/20 rounded-md min-h-[80px]"
      dangerouslySetInnerHTML={{ __html: formatContent(content) || '<p class="text-muted-foreground italic">Kein Inhalt</p>' }}
    />
  );
}

export function OntologyAnalysisPanel({ type, code, label }: OntologyAnalysisPanelProps) {
  const { toast } = useToast();
  const { profile } = useProfile();
  const navigate = useNavigate();
  const [analysis, setAnalysis] = useState<any | null>(null);
  const [cachedMappings, setCachedMappings] = useState<{
    snomed_mappings?: SnomedMappingItem[];
    icd10_mappings?: ICD10MappingItem[];
    hpo_mappings?: HPOMappingItem[];
    from_cache?: boolean;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [activeTab, setActiveTab] = useState<'explanation' | 'symptoms' | 'therapy' | 'notes'>('explanation');
  const [selectedLanguage, setSelectedLanguage] = useState(profile?.language || 'de');

  const functionName = type === 'hpo' ? 'hpo-analyze' : 'snomed-analyze';
  const codeField = type === 'hpo' ? 'hpo_code' : 'sctid';
  const labelField = type === 'hpo' ? 'hpo_label' : 'snomed_label';

  const fetchAnalysis = useCallback(async () => {
    if (!code) return;
    
    setIsLoading(true);
    setCachedMappings(null);
    
    try {
      const { data, error } = await supabase.functions.invoke(functionName, {
        body: { action: 'get', [codeField]: code },
      });

      if (error) throw error;

      if (data?.analysis) {
        setAnalysis(data.analysis);
        
        // Check if translation is needed
        const content = data.analysis.content;
        if (content && !content[selectedLanguage] && content['de']) {
          setIsTranslating(true);
          const { data: translatedData } = await supabase.functions.invoke(functionName, {
            body: {
              action: 'translate',
              [codeField]: code,
              source_language: 'de',
              target_language: selectedLanguage,
            },
          });
          if (translatedData?.analysis) {
            setAnalysis(translatedData.analysis);
          }
          setIsTranslating(false);
        }
      } else if (data?.cached_mappings) {
        // No full analysis, but we have cached mappings from ontology_mappings table
        setCachedMappings(data.cached_mappings);
      }
    } catch (error) {
      console.error('Fetch analysis error:', error);
    } finally {
      setIsLoading(false);
    }
  }, [code, selectedLanguage, functionName, codeField]);

  useEffect(() => {
    fetchAnalysis();
  }, [fetchAnalysis]);

  const generateAnalysis = async () => {
    setIsGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke(functionName, {
        body: {
          action: 'generate',
          [codeField]: code,
          [labelField]: label,
          source_language: selectedLanguage,
        },
      });

      if (error) throw error;

      if (data?.analysis) {
        setAnalysis(data.analysis);
        toast({
          title: 'Analyse generiert',
          description: 'Die KI-Analyse wurde erfolgreich erstellt.',
        });
      }
    } catch (error: any) {
      console.error('Generate error:', error);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: error.message || 'Die Analyse konnte nicht generiert werden.',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleLanguageChange = async (newLang: string) => {
    setSelectedLanguage(newLang);
    
    if (analysis?.content && !analysis.content[newLang] && analysis.content['de']) {
      setIsTranslating(true);
      try {
        const { data } = await supabase.functions.invoke(functionName, {
          body: {
            action: 'translate',
            [codeField]: code,
            source_language: 'de',
            target_language: newLang,
          },
        });
        if (data?.analysis) {
          setAnalysis(data.analysis);
        }
      } catch (error) {
        console.error('Translation error:', error);
      } finally {
        setIsTranslating(false);
      }
    }
  };

  const navigateToCode = (targetType: 'hpo' | 'snomed' | 'icd10', targetCode: string) => {
    const tabMap = { hpo: 'hpo', snomed: 'snomed', icd10: 'icd10' };
    navigate(`/ontology?tab=${tabMap[targetType]}&search=${encodeURIComponent(targetCode)}&backTab=${type}&backCode=${encodeURIComponent(code)}`);
  };

  const currentContent: ContentBlock | null = analysis?.content?.[selectedLanguage] || analysis?.content?.['de'] || null;

  // Get mappings based on type
  const getMappings = () => {
    if (!analysis) return { hpo: [], snomed: [], icd10: [] };
    
    if (type === 'hpo') {
      return {
        hpo: [],
        snomed: (analysis.snomed_mappings || []) as SnomedMappingItem[],
        icd10: (analysis.icd10_mappings || []) as ICD10MappingItem[],
      };
    } else {
      return {
        hpo: (analysis.hpo_mappings || []) as HPOMappingItem[],
        snomed: [],
        icd10: (analysis.icd10_mappings || []) as ICD10MappingItem[],
      };
    }
  };

  const mappings = getMappings();

  if (isLoading) {
    return (
      <div className="space-y-4 p-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }

  // Show cached mappings even without full analysis
  if (!analysis && cachedMappings) {
    const hasMappings = 
      (cachedMappings.snomed_mappings?.length || 0) > 0 ||
      (cachedMappings.icd10_mappings?.length || 0) > 0 ||
      (cachedMappings.hpo_mappings?.length || 0) > 0;

    return (
      <div className="space-y-4 p-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-5 w-5 text-primary" />
              KI-Analyse
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Für diesen {type === 'hpo' ? 'HPO-Begriff' : 'SNOMED-Begriff'} wurde noch keine vollständige Analyse erstellt.
              {hasMappings && ' Es wurden jedoch bereits Mappings aus anderen Analysen gefunden.'}
            </p>
            <Button onClick={generateAnalysis} disabled={isGenerating}>
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generiere...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  KI-Analyse generieren
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Show cached mappings */}
        {hasMappings && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <Link2 className="h-5 w-5 text-primary" />
                Gecachte Ontologie-Mappings
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4 gap-0.5 cursor-help">
                      <Sparkles className="h-2.5 w-2.5" />
                      Cache
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Aus vorherigen Analysen gecacht – spart Token</p>
                  </TooltipContent>
                </Tooltip>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* HPO Mappings (for SNOMED) */}
              {type === 'snomed' && cachedMappings.hpo_mappings && cachedMappings.hpo_mappings.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
                    <TreeDeciduous className="h-4 w-4" />
                    HPO Codes
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {cachedMappings.hpo_mappings.map((m) => (
                      <Badge
                        key={m.code}
                        variant="outline"
                        className="cursor-pointer hover:bg-muted transition-colors"
                        onClick={() => navigateToCode('hpo', m.code)}
                      >
                        {m.code}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* SNOMED Mappings (for HPO) */}
              {type === 'hpo' && cachedMappings.snomed_mappings && cachedMappings.snomed_mappings.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
                    <Stethoscope className="h-4 w-4" />
                    SNOMED CT
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {cachedMappings.snomed_mappings.map((m) => (
                      <Badge
                        key={m.sctid}
                        variant="outline"
                        className="cursor-pointer hover:bg-muted transition-colors"
                        onClick={() => navigateToCode('snomed', m.sctid)}
                      >
                        {m.sctid}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* ICD-10 Mappings */}
              {cachedMappings.icd10_mappings && cachedMappings.icd10_mappings.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
                    <FileText className="h-4 w-4" />
                    ICD-10-GM
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {cachedMappings.icd10_mappings.map((m) => (
                      <Badge
                        key={m.code}
                        variant="outline"
                        className="cursor-pointer hover:bg-muted transition-colors"
                        onClick={() => navigateToCode('icd10', m.code)}
                      >
                        {m.code}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  if (!analysis) {
    return (
      <Card className="m-4">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Sparkles className="h-5 w-5 text-primary" />
            KI-Analyse
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Für diesen {type === 'hpo' ? 'HPO-Begriff' : 'SNOMED-Begriff'} wurde noch keine Analyse erstellt.
          </p>
          <Button onClick={generateAnalysis} disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generiere...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                KI-Analyse generieren
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4 p-4">
      {/* Analysis Card */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-5 w-5 text-primary" />
              KI-Analyse
            </CardTitle>
            <div className="flex items-center gap-2">
              <Select value={selectedLanguage} onValueChange={handleLanguageChange}>
                <SelectTrigger className="w-[120px] h-8">
                  <Languages className="h-4 w-4 mr-1" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={generateAnalysis}
                    disabled={isGenerating}
                  >
                    <RefreshCw className={cn("h-4 w-4", isGenerating && "animate-spin")} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Neu generieren</TooltipContent>
              </Tooltip>
            </div>
          </div>
          {analysis.generated_at && (
            <p className="text-xs text-muted-foreground">
              Generiert: {new Date(analysis.generated_at).toLocaleDateString('de-DE')}
            </p>
          )}
        </CardHeader>
        <CardContent>
          {isTranslating ? (
            <div className="flex items-center gap-2 py-8 justify-center text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Übersetze...</span>
            </div>
          ) : (
            <>
              <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
                <TabsList className="grid w-full grid-cols-4 mb-4">
                  <TabsTrigger value="explanation" className="text-xs">
                    <FileText className="h-3 w-3 mr-1" />
                    Erklärung
                  </TabsTrigger>
                  <TabsTrigger value="symptoms" className="text-xs">
                    <Stethoscope className="h-3 w-3 mr-1" />
                    Symptome
                  </TabsTrigger>
                  <TabsTrigger value="therapy" className="text-xs">
                    Therapie
                  </TabsTrigger>
                  <TabsTrigger value="notes" className="text-xs">
                    Hinweise
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="explanation">
                  <ContentView content={currentContent?.explanation || ''} />
                </TabsContent>
                <TabsContent value="symptoms">
                  <ContentView content={currentContent?.symptoms || ''} />
                </TabsContent>
                <TabsContent value="therapy">
                  <ContentView content={currentContent?.therapy || ''} />
                </TabsContent>
                <TabsContent value="notes">
                  <ContentView content={currentContent?.notes || ''} />
                </TabsContent>
              </Tabs>
            </>
          )}
        </CardContent>
      </Card>

      {/* Mappings Card */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Link2 className="h-5 w-5 text-primary" />
            Ontologie-Mappings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* HPO Mappings (for SNOMED) */}
          {type === 'snomed' && mappings.hpo.length > 0 && (
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
                <TreeDeciduous className="h-4 w-4" />
                HPO Codes
              </p>
              <div className="flex flex-wrap gap-2">
                {mappings.hpo.map((m) => (
                  <Badge
                    key={m.code}
                    variant="outline"
                    className="cursor-pointer hover:bg-muted transition-colors"
                    onClick={() => navigateToCode('hpo', m.code)}
                  >
                    {m.code}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* SNOMED Mappings (for HPO) */}
          {type === 'hpo' && mappings.snomed.length > 0 && (
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
                <Stethoscope className="h-4 w-4" />
                SNOMED CT
              </p>
              <div className="flex flex-wrap gap-2">
                {mappings.snomed.map((m) => (
                  <Badge
                    key={m.sctid}
                    variant="outline"
                    className="cursor-pointer hover:bg-muted transition-colors"
                    onClick={() => navigateToCode('snomed', m.sctid)}
                  >
                    {m.sctid}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* ICD-10 Mappings */}
          {mappings.icd10.length > 0 && (
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
                <FileText className="h-4 w-4" />
                ICD-10-GM
              </p>
              <div className="flex flex-wrap gap-2">
                {mappings.icd10.map((m) => (
                  <Badge
                    key={m.code}
                    variant="outline"
                    className="cursor-pointer hover:bg-muted transition-colors"
                    onClick={() => navigateToCode('icd10', m.code)}
                  >
                    {m.code}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {mappings.hpo.length === 0 && mappings.snomed.length === 0 && mappings.icd10.length === 0 && (
            <p className="text-sm text-muted-foreground italic">Keine Mappings vorhanden</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
