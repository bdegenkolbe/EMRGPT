import { useState, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Search, 
  ArrowRight,
  ArrowLeftRight,
  ExternalLink, 
  Loader2,
  TreeDeciduous,
  Stethoscope,
  Sparkles,
  Info,
  CheckCircle,
  AlertCircle,
  FileText,
  Save,
  BookmarkCheck,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface MappingResult {
  sourceCode: string;
  sourceLabel: string;
  sourceSystem: 'HPO' | 'SNOMED' | 'ICD10GM' | 'ICD10WHO' | 'ICD11';
  targetCode: string;
  targetLabel: string;
  targetSystem: 'HPO' | 'SNOMED' | 'ICD10GM' | 'ICD10WHO' | 'ICD11';
  confidence: number;
  mappingType: 'exact' | 'broad' | 'narrow' | 'related' | 'ai_suggested';
  source: 'umls' | 'ai' | 'manual' | 'snomed_map' | 'fhir_translate' | 'who_crosswalk' | 'local_db';
  notes?: string;
  isAiGenerated?: boolean;
}

interface SearchResult {
  code: string;
  label: string;
  system: 'HPO' | 'SNOMED' | 'ICD10GM' | 'ICD10WHO' | 'ICD11';
}

type MappingDirection = 
  | 'hpo-to-snomed' | 'snomed-to-hpo' 
  | 'snomed-to-icd10' | 'icd10-to-snomed' 
  | 'hpo-to-icd10' | 'icd10-to-hpo'
  | 'icd10-to-icd11' | 'icd11-to-icd10'
  | 'snomed-to-icd11' | 'icd11-to-snomed';

type OntologySystem = 'HPO' | 'SNOMED' | 'ICD10GM' | 'ICD10WHO' | 'ICD11';

export function OntologyMappingView() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchDirection, setSearchDirection] = useState<MappingDirection>('hpo-to-snomed');
  const [isSearching, setIsSearching] = useState(false);
  const [isMappingLoading, setIsMappingLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [selectedSource, setSelectedSource] = useState<SearchResult | null>(null);
  const [mappings, setMappings] = useState<MappingResult[]>([]);
  const [savedMappings, setSavedMappings] = useState<Set<string>>(new Set());
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [mappingToSave, setMappingToSave] = useState<MappingResult | null>(null);
  const [saveNotes, setSaveNotes] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Helper to get source/target systems from direction
  const getSystemsFromDirection = (dir: MappingDirection): { source: OntologySystem; target: OntologySystem } => {
    switch (dir) {
      case 'hpo-to-snomed': return { source: 'HPO', target: 'SNOMED' };
      case 'snomed-to-hpo': return { source: 'SNOMED', target: 'HPO' };
      case 'snomed-to-icd10': return { source: 'SNOMED', target: 'ICD10GM' };
      case 'icd10-to-snomed': return { source: 'ICD10GM', target: 'SNOMED' };
      case 'hpo-to-icd10': return { source: 'HPO', target: 'ICD10GM' };
      case 'icd10-to-hpo': return { source: 'ICD10GM', target: 'HPO' };
      case 'icd10-to-icd11': return { source: 'ICD10GM', target: 'ICD11' };
      case 'icd11-to-icd10': return { source: 'ICD11', target: 'ICD10GM' };
      case 'snomed-to-icd11': return { source: 'SNOMED', target: 'ICD11' };
      case 'icd11-to-snomed': return { source: 'ICD11', target: 'SNOMED' };
    }
  };

  const { source: sourceSystem, target: targetSystem } = getSystemsFromDirection(searchDirection);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setSearchResults([]);
    setSelectedSource(null);
    setMappings([]);

    try {
      if (sourceSystem === 'HPO') {
        const response = await supabase.functions.invoke('hpo-lookup', {
          body: { query: searchQuery, limit: 10 },
        });

        if (response.data?.results) {
          setSearchResults(response.data.results.map((r: any) => ({
            code: r.id || r.obo_id,
            label: r.label,
            system: 'HPO' as const,
          })));
        }
      } else if (sourceSystem === 'SNOMED') {
        const response = await supabase.functions.invoke('snomed-lookup', {
          body: { action: 'search', query: searchQuery, limit: 10, lang: 'de' },
        });

        if (response.data?.results) {
          setSearchResults(response.data.results.map((r: any) => ({
            code: r.conceptId,
            label: r.pt?.term || r.fsn?.term,
            system: 'SNOMED' as const,
          })));
        }
      } else if (sourceSystem === 'ICD10GM') {
        const searchTerm = searchQuery.trim().toUpperCase();
        const { data, error } = await supabase
          .from('icd10gm_codes')
          .select('code, title')
          .or(`code.ilike.${searchTerm}%,title.ilike.%${searchQuery}%`)
          .order('code')
          .limit(10);

        if (!error && data) {
          setSearchResults(data.map((r) => ({
            code: r.code,
            label: r.title,
            system: 'ICD10GM' as const,
          })));
        }
      }
    } catch (error) {
      console.error('Search error:', error);
      toast({
        variant: 'destructive',
        title: 'Suchfehler',
        description: 'Die Suche konnte nicht durchgeführt werden.',
      });
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery, sourceSystem, toast]);

  const findMappings = useCallback(async (source: SearchResult) => {
    setSelectedSource(source);
    setIsMappingLoading(true);
    setMappings([]);

    try {
      // Step 1: First check for existing validated mappings in the database
      const { data: existingMappings, error: dbError } = await supabase
        .from('ontology_mappings')
        .select('*')
        .eq('source_code', source.code)
        .eq('source_system', source.system)
        .eq('target_system', targetSystem);

      if (!dbError && existingMappings && existingMappings.length > 0) {
        // Found existing mappings in database - use them directly
        console.log(`Found ${existingMappings.length} existing mappings in database`);
        
        const dbResults: MappingResult[] = existingMappings.map(m => {
          const isAiGenerated = m.notes?.toLowerCase().includes('ki-generiert') || false;
          return {
            sourceCode: m.source_code,
            sourceLabel: m.source_label,
            sourceSystem: m.source_system as 'HPO' | 'SNOMED' | 'ICD10GM',
            targetCode: m.target_code,
            targetLabel: m.target_label,
            targetSystem: m.target_system as 'HPO' | 'SNOMED' | 'ICD10GM',
            confidence: m.confidence || 0.9,
            mappingType: (m.mapping_type === 'validated' ? 'exact' : m.mapping_type) as MappingResult['mappingType'],
            source: isAiGenerated ? 'ai' as const : 'manual' as const,
            notes: m.notes || undefined,
            isAiGenerated,
          };
        });

        // Mark all as already saved
        const savedKeys = new Set(dbResults.map(m => `${m.sourceCode}-${m.targetCode}`));
        setSavedMappings(prev => new Set([...prev, ...savedKeys]));
        
        setMappings(dbResults);
        setIsMappingLoading(false);
        
        toast({
          title: 'Gespeicherte Mappings geladen',
          description: `${existingMappings.length} Zuordnung(en) aus der Datenbank`,
        });
        return;
      }

      // Also check reverse direction (target -> source becomes source -> target)
      const { data: reverseMappings } = await supabase
        .from('ontology_mappings')
        .select('*')
        .eq('target_code', source.code)
        .eq('target_system', source.system)
        .eq('source_system', targetSystem);

      if (reverseMappings && reverseMappings.length > 0) {
        // Found reverse mappings - flip them
        console.log(`Found ${reverseMappings.length} reverse mappings in database`);
        
        const dbResults: MappingResult[] = reverseMappings.map(m => {
          const isAiGenerated = m.notes?.toLowerCase().includes('ki-generiert') || false;
          return {
            sourceCode: source.code,
            sourceLabel: source.label,
            sourceSystem: source.system,
            targetCode: m.source_code,
            targetLabel: m.source_label,
            targetSystem: m.source_system as 'HPO' | 'SNOMED' | 'ICD10GM',
            confidence: m.confidence || 0.9,
            mappingType: (m.mapping_type === 'validated' ? 'exact' : m.mapping_type) as MappingResult['mappingType'],
            source: isAiGenerated ? 'ai' as const : 'manual' as const,
            notes: m.notes || undefined,
            isAiGenerated,
          };
        });

        const savedKeys = new Set(dbResults.map(m => `${m.sourceCode}-${m.targetCode}`));
        setSavedMappings(prev => new Set([...prev, ...savedKeys]));
        
        setMappings(dbResults);
        setIsMappingLoading(false);
        
        toast({
          title: 'Gespeicherte Mappings geladen',
          description: `${reverseMappings.length} Zuordnung(en) aus der Datenbank (bidirektional)`,
        });
        return;
      }

      // Step 2: No existing mappings found - call the AI/API mapping service
      console.log('No existing mappings found, calling ontology-mapping service...');
      
      const response = await supabase.functions.invoke('ontology-mapping', {
        body: {
          sourceCode: source.code,
          sourceLabel: source.label,
          sourceSystem: source.system,
          targetSystem: targetSystem,
        },
      });

      if (response.data?.mappings) {
        setMappings(response.data.mappings);
      } else if (response.error) {
        console.error('Mapping error:', response.error);
        toast({
          title: 'Keine Mappings gefunden',
          description: 'Für diesen Begriff wurden keine direkten Zuordnungen gefunden.',
        });
      }
    } catch (error) {
      console.error('Mapping error:', error);
      toast({
        variant: 'destructive',
        title: 'Mapping-Fehler',
        description: 'Die Zuordnungen konnten nicht geladen werden.',
      });
    } finally {
      setIsMappingLoading(false);
    }
  }, [toast, targetSystem]);

  const openSaveDialog = (mapping: MappingResult) => {
    setMappingToSave(mapping);
    setSaveNotes('');
    setSaveDialogOpen(true);
  };

  const saveMapping = useCallback(async () => {
    if (!mappingToSave) return;
    
    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          variant: 'destructive',
          title: 'Nicht angemeldet',
          description: 'Bitte melden Sie sich an, um Mappings zu speichern.',
        });
        return;
      }

      const { error } = await supabase
        .from('ontology_mappings')
        .upsert({
          source_code: mappingToSave.sourceCode,
          source_label: mappingToSave.sourceLabel,
          source_system: mappingToSave.sourceSystem,
          target_code: mappingToSave.targetCode,
          target_label: mappingToSave.targetLabel,
          target_system: mappingToSave.targetSystem,
          confidence: mappingToSave.confidence,
          mapping_type: 'validated',
          validated_by: user.id,
          notes: saveNotes || null,
        }, {
          onConflict: 'source_code,source_system,target_code,target_system',
        });

      if (error) throw error;

      setSavedMappings(prev => new Set([...prev, `${mappingToSave.sourceCode}-${mappingToSave.targetCode}`]));
      setSaveDialogOpen(false);
      setMappingToSave(null);
      
      toast({
        title: 'Mapping gespeichert',
        description: 'Die Zuordnung wurde erfolgreich validiert und gespeichert.',
      });
    } catch (error) {
      console.error('Save error:', error);
      toast({
        variant: 'destructive',
        title: 'Speicherfehler',
        description: 'Das Mapping konnte nicht gespeichert werden.',
      });
    } finally {
      setIsSaving(false);
    }
  }, [mappingToSave, saveNotes, toast]);

  const isMappingSaved = (mapping: MappingResult) => {
    return savedMappings.has(`${mapping.sourceCode}-${mapping.targetCode}`);
  };

  const getMappingTypeBadge = (type: MappingResult['mappingType'], source?: MappingResult['source']) => {
    if (source === 'snomed_map') {
      return <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-emerald-500/40">SNOMED-Map</Badge>;
    }
    switch (type) {
      case 'exact':
        return <Badge className="bg-primary/20 text-primary border-primary/40">Exakt</Badge>;
      case 'broad':
        return <Badge className="bg-secondary text-secondary-foreground border-secondary">Breiter</Badge>;
      case 'narrow':
        return <Badge className="bg-accent text-accent-foreground border-accent">Enger</Badge>;
      case 'related':
        return <Badge variant="outline">Verwandt</Badge>;
      case 'ai_suggested':
        return (
          <Badge className="bg-primary/10 text-primary border-primary/30 gap-0.5">
            <Sparkles className="h-3 w-3" />
            KI-Vorschlag
          </Badge>
        );
    }
  };

  const getSystemIcon = (system: OntologySystem) => {
    switch (system) {
      case 'HPO': return <TreeDeciduous className="h-4 w-4" />;
      case 'SNOMED': return <Stethoscope className="h-4 w-4" />;
      case 'ICD10GM': return <FileText className="h-4 w-4" />;
      case 'ICD10WHO': return <FileText className="h-4 w-4" />;
      case 'ICD11': return <FileText className="h-4 w-4" />;
    }
  };

  const getSystemLabel = (system: OntologySystem) => {
    switch (system) {
      case 'HPO': return 'HPO-Begriffe';
      case 'SNOMED': return 'SNOMED-Begriffe';
      case 'ICD10GM': return 'ICD-10-GM Codes';
      case 'ICD10WHO': return 'ICD-10 WHO Codes';
      case 'ICD11': return 'ICD-11 Codes';
    }
  };

  const getSearchPlaceholder = (system: OntologySystem) => {
    switch (system) {
      case 'HPO': return 'HPO-Begriff oder Code suchen (z.B. Kopfschmerz, HP:0002315)...';
      case 'SNOMED': return 'SNOMED-Begriff oder Code suchen (z.B. Fieber, 386661006)...';
      case 'ICD10GM': return 'ICD-10-GM Code oder Diagnose suchen (z.B. F32.1, Depression)...';
      case 'ICD10WHO': return 'ICD-10 WHO Code suchen (z.B. E11, J06.9)...';
      case 'ICD11': return 'ICD-11 Code suchen (z.B. 5A11, BA00)...';
    }
  };

  const getConfidenceIndicator = (confidence: number) => {
    if (confidence >= 0.9) {
      return <CheckCircle className="h-4 w-4 text-primary" />;
    } else if (confidence >= 0.7) {
      return <CheckCircle className="h-4 w-4 text-muted-foreground" />;
    } else {
      return <AlertCircle className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getExternalUrl = (system: OntologySystem, code: string): string => {
    switch (system) {
      case 'SNOMED':
        return `https://browser.ihtsdotools.org/?perspective=full&conceptId1=${code}`;
      case 'HPO':
        return `https://hpo.jax.org/browse/term/${code}`;
      case 'ICD10GM':
        return `https://www.icd-code.de/icd/code/${code}.html`;
      case 'ICD10WHO':
        return `https://icd.who.int/browse10/2019/en#/${code}`;
      case 'ICD11':
        return `https://icd.who.int/browse/2024-01/mms/en#/${code}`;
      default:
        return '#';
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-primary/10">
            <ArrowLeftRight className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="font-semibold">Ontologie-Mapping</h2>
            <p className="text-sm text-muted-foreground">
              Finde Zuordnungen zwischen HPO, SNOMED CT und ICD-10-GM
            </p>
          </div>
        </div>

        {/* Direction Toggle */}
        <Tabs value={searchDirection} onValueChange={(v) => setSearchDirection(v as MappingDirection)} className="mb-4">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
            <TabsTrigger value="hpo-to-snomed" className="flex items-center gap-1 text-xs">
              <TreeDeciduous className="h-3 w-3" />
              <span className="hidden sm:inline">HPO</span>→SNOMED
            </TabsTrigger>
            <TabsTrigger value="snomed-to-hpo" className="flex items-center gap-1 text-xs">
              <Stethoscope className="h-3 w-3" />
              <span className="hidden sm:inline">SNOMED</span>→HPO
            </TabsTrigger>
            <TabsTrigger value="snomed-to-icd10" className="flex items-center gap-1 text-xs">
              <Stethoscope className="h-3 w-3" />
              <span className="hidden sm:inline">SNOMED</span>→ICD
            </TabsTrigger>
            <TabsTrigger value="icd10-to-snomed" className="flex items-center gap-1 text-xs">
              <FileText className="h-3 w-3" />
              <span className="hidden sm:inline">ICD</span>→SNOMED
            </TabsTrigger>
            <TabsTrigger value="hpo-to-icd10" className="flex items-center gap-1 text-xs">
              <TreeDeciduous className="h-3 w-3" />
              <span className="hidden sm:inline">HPO</span>→ICD
            </TabsTrigger>
            <TabsTrigger value="icd10-to-hpo" className="flex items-center gap-1 text-xs">
              <FileText className="h-3 w-3" />
              <span className="hidden sm:inline">ICD</span>→HPO
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Search */}
        <div className="flex gap-2">
          <Input
            placeholder={getSearchPlaceholder(sourceSystem)}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
          <Button onClick={handleSearch} disabled={isSearching}>
            {isSearching ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex min-h-0">
        {/* Source List */}
        <div className="w-1/3 border-r flex flex-col min-h-0">
          <div className="p-2 border-b bg-muted/30">
            <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              {getSystemIcon(sourceSystem)}
              {getSystemLabel(sourceSystem)}
            </span>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {searchResults.length === 0 && !isSearching && (
                <div className="text-center py-8 text-muted-foreground">
                  <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Suche nach einem Begriff</p>
                </div>
              )}
              {searchResults.map((result) => (
                <button
                  key={result.code}
                  className={`w-full text-left p-3 rounded-lg border transition-colors ${
                    selectedSource?.code === result.code
                      ? 'bg-primary/10 border-primary'
                      : 'bg-card hover:bg-muted border-transparent'
                  }`}
                  onClick={() => findMappings(result)}
                >
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs shrink-0">
                      {result.code}
                    </Badge>
                  </div>
                  <p className="text-sm mt-1 line-clamp-2">{result.label}</p>
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Mapping Results */}
        <div className="flex-1 flex flex-col min-h-0">
          <div className="p-2 border-b bg-muted/30">
            <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <ArrowRight className="h-4 w-4" />
              Zuordnungen
              {mappings.length > 0 && (
                <Badge variant="secondary" className="text-xs">
                  {mappings.length}
                </Badge>
              )}
            </span>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-4">
              {!selectedSource && (
                <div className="text-center py-12 text-muted-foreground">
                  <ArrowLeftRight className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p className="text-sm">Wähle einen Begriff aus der linken Liste</p>
                  <p className="text-xs mt-1">um Zuordnungen anzuzeigen</p>
                </div>
              )}

              {selectedSource && isMappingLoading && (
                <div className="text-center py-12">
                  <Loader2 className="h-8 w-8 mx-auto mb-3 animate-spin text-primary" />
                  <p className="text-sm text-muted-foreground">Suche Zuordnungen...</p>
                  <p className="text-xs text-muted-foreground mt-1 flex items-center justify-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    KI-basierte Analyse läuft
                  </p>
                </div>
              )}

              {selectedSource && !isMappingLoading && mappings.length === 0 && (
                <Card className="border-dashed">
                  <CardContent className="py-8 text-center">
                    <AlertCircle className="h-8 w-8 mx-auto mb-3 text-muted-foreground opacity-50" />
                    <p className="text-sm font-medium">Keine Zuordnungen gefunden</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Für &quot;{selectedSource.label}&quot; wurden keine passenden Mappings gefunden.
                    </p>
                  </CardContent>
                </Card>
              )}

              {selectedSource && !isMappingLoading && mappings.length > 0 && (
                <div className="space-y-3">
                  {/* Source Card */}
                  <Card className="bg-muted/30">
                    <CardHeader className="py-3">
                      <div className="flex items-center gap-2">
                        {getSystemIcon(selectedSource.system)}
                        <div className="flex-1">
                          <CardTitle className="text-base">{selectedSource.label}</CardTitle>
                          <CardDescription className="font-mono">{selectedSource.code}</CardDescription>
                        </div>
                        <Badge>{selectedSource.system === 'ICD10GM' ? 'ICD-10-GM' : selectedSource.system}</Badge>
                      </div>
                    </CardHeader>
                  </Card>

                  <div className="flex items-center justify-center py-2">
                    <ArrowRight className="h-5 w-5 text-muted-foreground" />
                  </div>

                  {/* Target Mappings */}
                  {mappings.map((mapping, idx) => (
                    <Card key={idx} className="hover:border-primary/50 transition-colors">
                      <CardHeader className="py-3">
                        <div className="flex items-start gap-3">
                          <Tooltip>
                            <TooltipTrigger>
                              {getConfidenceIndicator(mapping.confidence)}
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Konfidenz: {Math.round(mapping.confidence * 100)}%</p>
                            </TooltipContent>
                          </Tooltip>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <CardTitle className="text-base">{mapping.targetLabel}</CardTitle>
                              {getMappingTypeBadge(mapping.mappingType, mapping.source)}
                              {mapping.isAiGenerated && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Badge className="bg-primary/10 text-primary border-primary/30 gap-0.5 cursor-help">
                                      <Sparkles className="h-2.5 w-2.5" />
                                      KI
                                    </Badge>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p className="text-xs">Automatisch durch KI-Analyse generiert</p>
                                  </TooltipContent>
                                </Tooltip>
                              )}
                            </div>
                            <CardDescription className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="font-mono">
                                {mapping.targetCode}
                              </Badge>
                              <Badge variant="secondary">
                                {mapping.targetSystem === 'ICD10GM' ? 'ICD-10-GM' : mapping.targetSystem}
                              </Badge>
                            </CardDescription>
                        </div>
                          <div className="flex items-center gap-1">
                            {isMappingSaved(mapping) ? (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button variant="ghost" size="sm" disabled>
                                    <BookmarkCheck className="h-4 w-4 text-primary" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Bereits validiert</TooltipContent>
                              </Tooltip>
                            ) : (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button variant="ghost" size="sm" onClick={() => openSaveDialog(mapping)}>
                                    <Save className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Mapping validieren & speichern</TooltipContent>
                              </Tooltip>
                            )}
                            <Button variant="ghost" size="sm" asChild>
                              <a
                                href={getExternalUrl(mapping.targetSystem, mapping.targetCode)}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  ))}

                  {/* Info about AI mappings */}
                  {mappings.some(m => m.source === 'ai') && (
                    <div className="flex items-start gap-2 p-3 rounded-lg bg-primary/5 border border-primary/20 text-sm">
                      <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      <div>
                        <p className="font-medium text-primary">KI-generierte Zuordnungen</p>
                        <p className="text-muted-foreground text-xs mt-0.5">
                          Diese Mappings wurden per KI ermittelt und sollten vor klinischer Verwendung überprüft werden.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </div>

      {/* Save Dialog */}
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Save className="h-5 w-5" />
              Mapping validieren
            </DialogTitle>
            <DialogDescription>
              Speichern Sie diese Zuordnung als validiertes Mapping in der Datenbank.
            </DialogDescription>
          </DialogHeader>
          
          {mappingToSave && (
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-muted/50 space-y-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{mappingToSave.sourceSystem}</Badge>
                  <span className="font-mono text-sm">{mappingToSave.sourceCode}</span>
                </div>
                <p className="text-sm">{mappingToSave.sourceLabel}</p>
                <ArrowRight className="h-4 w-4 text-muted-foreground mx-auto" />
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{mappingToSave.targetSystem === 'ICD10GM' ? 'ICD-10-GM' : mappingToSave.targetSystem}</Badge>
                  <span className="font-mono text-sm">{mappingToSave.targetCode}</span>
                </div>
                <p className="text-sm">{mappingToSave.targetLabel}</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notizen (optional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Begründung oder Kontext für dieses Mapping..."
                  value={saveNotes}
                  onChange={(e) => setSaveNotes(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveDialogOpen(false)}>
              Abbrechen
            </Button>
            <Button onClick={saveMapping} disabled={isSaving}>
              {isSaving ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <CheckCircle className="h-4 w-4 mr-2" />
              )}
              Validieren & Speichern
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
