import { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  ArrowLeftRight,
  Loader2,
  TreeDeciduous,
  Stethoscope,
  Sparkles,
  FileText,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
  Info,
  RefreshCw,
  GitBranch,
  Heart,
  BarChart3,
  Shield,
  Download,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface MappingStats {
  total: number;
  byStatus: Record<string, number>;
  byDirection: Record<string, number>;
}

interface ConflictInfo {
  type: 'transitive_inconsistency' | 'bidirectional_asymmetry' | 'circular_reference' | 'orphan_mapping';
  severity: 'error' | 'warning' | 'info';
  description: string;
  involvedMappings: string[];
  suggestedResolution?: string;
}

interface MappingWithConflict {
  id: string;
  source_code: string;
  source_label: string;
  source_system: string;
  target_code: string;
  target_label: string;
  target_system: string;
  confidence: number;
  mapping_type: string;
  validation_status: string;
  conflict_details: {
    type?: string;
    severity?: string;
    description?: string;
    suggestedResolution?: string;
  } | null;
  notes: string | null;
  extraction_source: string | null;
}

export function MappingHubView() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');
  const [isLoading, setIsLoading] = useState(false);
  const [stats, setStats] = useState<MappingStats | null>(null);
  const [conflicts, setConflicts] = useState<MappingWithConflict[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const [isBackfilling, setIsBackfilling] = useState(false);
  const [backfillDialogOpen, setBackfillDialogOpen] = useState(false);

  const loadStats = useCallback(async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('mapping-validate', {
        body: { action: 'get-stats' },
      });

      if (error) throw error;
      setStats(data);
    } catch (error) {
      console.error('Stats error:', error);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Statistiken konnten nicht geladen werden.',
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const loadConflicts = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('mapping-validate', {
        body: { action: 'get-conflicts' },
      });

      if (error) throw error;
      setConflicts(data?.conflicts || []);
    } catch (error) {
      console.error('Conflicts error:', error);
    }
  }, []);

  useEffect(() => {
    loadStats();
    loadConflicts();
  }, [loadStats, loadConflicts]);

  const runValidation = async () => {
    setIsValidating(true);
    try {
      const { data, error } = await supabase.functions.invoke('mapping-validate', {
        body: { action: 'validate-all' },
      });

      if (error) throw error;

      toast({
        title: 'Validierung abgeschlossen',
        description: `${data?.totalConflicts || 0} Konflikte gefunden`,
      });

      await loadStats();
      await loadConflicts();
    } catch (error) {
      console.error('Validation error:', error);
      toast({
        variant: 'destructive',
        title: 'Validierungsfehler',
        description: 'Die Validierung konnte nicht durchgeführt werden.',
      });
    } finally {
      setIsValidating(false);
    }
  };

  const runBackfill = async (dryRun: boolean) => {
    setIsBackfilling(true);
    try {
      const { data, error } = await supabase.functions.invoke('mapping-backfill', {
        body: { dryRun, batchSize: 100 },
      });

      if (error) throw error;

      const stats = data?.stats;
      toast({
        title: dryRun ? 'Backfill-Vorschau' : 'Backfill abgeschlossen',
        description: `${stats?.mappingsCreated || 0} Mappings ${dryRun ? 'würden erstellt' : 'erstellt'}, ${stats?.mappingsSkipped || 0} übersprungen`,
      });

      if (!dryRun) {
        await loadStats();
        setBackfillDialogOpen(false);
      }
    } catch (error) {
      console.error('Backfill error:', error);
      toast({
        variant: 'destructive',
        title: 'Backfill-Fehler',
        description: 'Das Backfill konnte nicht durchgeführt werden.',
      });
    } finally {
      setIsBackfilling(false);
    }
  };

  const resolveConflict = async (mappingId: string, resolution: 'valid' | 'exception') => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { error } = await supabase.functions.invoke('mapping-validate', {
        body: { 
          action: 'resolve-conflict',
          mappingId,
          resolution,
          userId: user?.id,
        },
      });

      if (error) throw error;

      toast({
        title: 'Konflikt aufgelöst',
        description: resolution === 'exception' ? 'Als Ausnahme markiert' : 'Als gültig markiert',
      });

      await loadConflicts();
      await loadStats();
    } catch (error) {
      console.error('Resolve error:', error);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Der Konflikt konnte nicht aufgelöst werden.',
      });
    }
  };

  const getSystemIcon = (system: string) => {
    switch (system) {
      case 'HPO': return <TreeDeciduous className="h-4 w-4" />;
      case 'SNOMED': return <Stethoscope className="h-4 w-4" />;
      case 'ICD10GM': return <FileText className="h-4 w-4" />;
      case 'ORPHANET': return <Heart className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'valid':
        return <Badge className="bg-primary/20 text-primary border-primary/40">Gültig</Badge>;
      case 'conflict':
        return <Badge className="bg-destructive/20 text-destructive border-destructive/40">Konflikt</Badge>;
      case 'exception':
        return <Badge className="bg-warning/20 text-warning border-warning/40">Ausnahme</Badge>;
      case 'pending':
      default:
        return <Badge variant="outline">Ausstehend</Badge>;
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'error':
        return <AlertCircle className="h-4 w-4 text-destructive" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-warning" />;
      case 'info':
      default:
        return <Info className="h-4 w-4 text-muted-foreground" />;
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <GitBranch className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold">Mapping Hub</h2>
              <p className="text-sm text-muted-foreground">
                Cross-Ontology Zuordnungen verwalten und validieren
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setBackfillDialogOpen(true)}>
              <Download className="h-4 w-4 mr-2" />
              Backfill
            </Button>
            <Button variant="outline" size="sm" onClick={runValidation} disabled={isValidating}>
              {isValidating ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Shield className="h-4 w-4 mr-2" />
              )}
              Validieren
            </Button>
            <Button variant="ghost" size="sm" onClick={loadStats} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
        <div className="border-b px-4">
          <TabsList className="h-10">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Übersicht
            </TabsTrigger>
            <TabsTrigger value="conflicts" className="gap-2">
              <AlertTriangle className="h-4 w-4" />
              Konflikte
              {conflicts.length > 0 && (
                <Badge variant="destructive" className="ml-1 h-5 px-1.5 text-xs">
                  {conflicts.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="mappings" className="gap-2">
              <ArrowLeftRight className="h-4 w-4" />
              Alle Mappings
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="overview" className="flex-1 p-4 m-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : stats ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {/* Total Mappings */}
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Gesamt Mappings</CardDescription>
                  <CardTitle className="text-3xl">{stats.total}</CardTitle>
                </CardHeader>
              </Card>

              {/* By Status */}
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Nach Status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(stats.byStatus).map(([status, count]) => (
                      <div key={status} className="flex items-center justify-between">
                        {getStatusBadge(status)}
                        <span className="font-mono text-sm">{count}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* By Direction */}
              <Card className="md:col-span-2 lg:col-span-1">
                <CardHeader className="pb-2">
                  <CardDescription>Nach Richtung</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-32">
                    <div className="space-y-2">
                      {Object.entries(stats.byDirection)
                        .sort(([, a], [, b]) => b - a)
                        .map(([direction, count]) => {
                          const [source, target] = direction.split('→');
                          return (
                            <div key={direction} className="flex items-center justify-between text-sm">
                              <div className="flex items-center gap-1">
                                {getSystemIcon(source)}
                                <span className="text-muted-foreground">→</span>
                                {getSystemIcon(target)}
                                <span className="text-xs text-muted-foreground ml-1">{direction}</span>
                              </div>
                              <span className="font-mono">{count}</span>
                            </div>
                          );
                        })}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="md:col-span-2 lg:col-span-3">
                <CardHeader>
                  <CardTitle className="text-base">Aktionen</CardTitle>
                </CardHeader>
                <CardContent className="flex gap-3 flex-wrap">
                  <Button variant="outline" onClick={() => setActiveTab('conflicts')}>
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Konflikte prüfen ({conflicts.length})
                  </Button>
                  <Button variant="outline" onClick={() => setBackfillDialogOpen(true)}>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Mappings aus Analysen extrahieren
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Keine Daten</AlertTitle>
              <AlertDescription>
                Es konnten keine Mapping-Statistiken geladen werden.
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>

        <TabsContent value="conflicts" className="flex-1 m-0 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="p-4 space-y-3">
              {conflicts.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="py-12 text-center">
                    <CheckCircle className="h-12 w-12 mx-auto mb-3 text-primary opacity-50" />
                    <p className="font-medium">Keine Konflikte</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Alle Mappings sind konsistent
                    </p>
                  </CardContent>
                </Card>
              ) : (
                conflicts.map((conflict) => (
                  <Card key={conflict.id} className="border-warning/30">
                    <CardHeader className="pb-2">
                      <div className="flex items-start gap-3">
                        {getSeverityIcon((conflict.conflict_details?.severity as string) || 'warning')}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <CardTitle className="text-sm">
                              {conflict.source_label}
                            </CardTitle>
                            <span className="text-muted-foreground">→</span>
                            <CardTitle className="text-sm">
                              {conflict.target_label}
                            </CardTitle>
                          </div>
                          <CardDescription className="flex items-center gap-2 mt-1 flex-wrap">
                            <Badge variant="outline" className="font-mono text-xs">
                              {conflict.source_system}:{conflict.source_code}
                            </Badge>
                            <span className="text-muted-foreground">→</span>
                            <Badge variant="outline" className="font-mono text-xs">
                              {conflict.target_system}:{conflict.target_code}
                            </Badge>
                          </CardDescription>
                        </div>
                        {getStatusBadge(conflict.validation_status)}
                      </div>
                    </CardHeader>
                    <CardContent>
                      {conflict.conflict_details && (
                        <Alert className="mb-3">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertTitle className="text-sm">
                            {conflict.conflict_details.type.replace(/_/g, ' ')}
                          </AlertTitle>
                          <AlertDescription className="text-xs">
                            {conflict.conflict_details.description}
                            {conflict.conflict_details.suggestedResolution && (
                              <p className="mt-1 text-muted-foreground">
                                💡 {conflict.conflict_details.suggestedResolution}
                              </p>
                            )}
                          </AlertDescription>
                        </Alert>
                      )}
                      <div className="flex gap-2">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => resolveConflict(conflict.id, 'valid')}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Bestätigen
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Als gültig markieren</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => resolveConflict(conflict.id, 'exception')}
                            >
                              <AlertTriangle className="h-4 w-4 mr-1" />
                              Ausnahme
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Als bewusste Ausnahme markieren</TooltipContent>
                        </Tooltip>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="mappings" className="flex-1 m-0 overflow-hidden">
          <AllMappingsView />
        </TabsContent>
      </Tabs>

      {/* Backfill Dialog */}
      <Dialog open={backfillDialogOpen} onOpenChange={setBackfillDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" />
              Mapping Backfill
            </DialogTitle>
            <DialogDescription>
              Extrahiert Mappings aus vorhandenen Analysen (HPO, SNOMED, ICD-10) in die zentrale Mapping-Tabelle.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Datenquellen</AlertTitle>
              <AlertDescription className="text-xs space-y-1">
                <p>• <strong>hpo_analyses</strong>: SNOMED- und ICD-10-Mappings aus HPO-Analysen</p>
                <p>• <strong>snomed_analyses</strong>: HPO- und ICD-10-Mappings aus SNOMED-Analysen</p>
                <p>• <strong>icd10gm_analyses</strong>: HPO- und SNOMED-Mappings aus ICD-Analysen</p>
              </AlertDescription>
            </Alert>
          </div>
          
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => runBackfill(true)} disabled={isBackfilling}>
              {isBackfilling ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Sparkles className="h-4 w-4 mr-2" />
              )}
              Vorschau (Dry Run)
            </Button>
            <Button onClick={() => runBackfill(false)} disabled={isBackfilling}>
              {isBackfilling ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Download className="h-4 w-4 mr-2" />
              )}
              Backfill starten
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Sub-component for all mappings view
function AllMappingsView() {
  const [mappings, setMappings] = useState<MappingWithConflict[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadMappings = async () => {
      try {
        const { data, error } = await supabase
          .from('ontology_mappings')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(100);

        if (error) throw error;
        // Cast to our interface since DB returns Json type for conflict_details
        setMappings((data || []) as unknown as MappingWithConflict[]);
      } catch (error) {
        console.error('Load mappings error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadMappings();
  }, []);

  const getSystemIcon = (system: string) => {
    switch (system) {
      case 'HPO': return <TreeDeciduous className="h-3 w-3" />;
      case 'SNOMED': return <Stethoscope className="h-3 w-3" />;
      case 'ICD10GM': return <FileText className="h-3 w-3" />;
      case 'ORPHANET': return <Heart className="h-3 w-3" />;
      default: return <FileText className="h-3 w-3" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <ScrollArea className="h-full">
      <div className="p-4">
        <div className="rounded-lg border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left p-3 font-medium">Quelle</th>
                <th className="text-left p-3 font-medium">Ziel</th>
                <th className="text-left p-3 font-medium">Typ</th>
                <th className="text-left p-3 font-medium">Status</th>
                <th className="text-right p-3 font-medium">Konfidenz</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {mappings.map((m) => (
                <tr key={m.id} className="hover:bg-muted/30">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      {getSystemIcon(m.source_system)}
                      <div>
                        <p className="font-mono text-xs text-muted-foreground">{m.source_code}</p>
                        <p className="text-xs line-clamp-1">{m.source_label}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      {getSystemIcon(m.target_system)}
                      <div>
                        <p className="font-mono text-xs text-muted-foreground">{m.target_code}</p>
                        <p className="text-xs line-clamp-1">{m.target_label}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-3">
                    <Badge variant="outline" className="text-xs">
                      {m.mapping_type}
                    </Badge>
                  </td>
                  <td className="p-3">
                    <Badge 
                      variant={m.validation_status === 'conflict' ? 'destructive' : 'outline'}
                      className="text-xs"
                    >
                      {m.validation_status}
                    </Badge>
                  </td>
                  <td className="p-3 text-right font-mono text-xs">
                    {Math.round(m.confidence * 100)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </ScrollArea>
  );
}
