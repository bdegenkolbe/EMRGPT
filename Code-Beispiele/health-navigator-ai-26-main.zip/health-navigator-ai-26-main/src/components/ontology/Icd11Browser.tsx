import { useState, useEffect, useCallback } from 'react';
import { useIcd11, ICD11Code, ICD11Analysis, DataSource } from '@/hooks/useIcd11';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { 
  Search, 
  ChevronRight, 
  ChevronDown, 
  RefreshCw,
  Info,
  Copy,
  Check,
  Loader2,
  ExternalLink,
  AlertCircle,
  X,
  PanelRightClose,
  PanelRightOpen,
  Globe,
  Sparkles,
  FileCode2,
  BookOpen,
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { DataSourceBadge } from '@/components/ui/data-source-badge';
import { BulkSyncButton } from './BulkSyncButton';
import { OntologyStatsBar } from './OntologyStatsBar';

interface ICD11TreeNode extends ICD11Code {
  children?: ICD11TreeNode[];
  isLoading?: boolean;
  isExpanded?: boolean;
}

interface TreeNodeProps {
  node: ICD11TreeNode;
  level: number;
  onSelect: (node: ICD11TreeNode) => void;
  onExpand: (node: ICD11TreeNode) => void;
  selectedCode?: string;
  translations: Map<string, { title_de: string; definition_de?: string }>;
}

function TreeNode({ node, level, onSelect, onExpand, selectedCode, translations }: TreeNodeProps) {
  const hasChildren = node.children && node.children.length > 0;
  const isSelected = node.code === selectedCode;
  const canExpand = !node.is_terminal;
  
  // Get translated title if available
  const translation = translations.get(node.code);
  const displayTitle = translation?.title_de || node.labels?.de || node.title_short || node.title;

  return (
    <div className="select-none">
      <div
        className={cn(
          'group flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted active:scale-[0.98]',
          isSelected && 'bg-primary/10 text-primary font-medium ring-1 ring-primary/20'
        )}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={() => onSelect(node)}
      >
        {node.isLoading ? (
          <Loader2 className="h-3.5 w-3.5 md:h-4 md:w-4 animate-spin text-muted-foreground shrink-0" />
        ) : canExpand ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onExpand(node);
            }}
            className="p-0.5 hover:bg-muted-foreground/20 rounded transition-colors"
          >
            {node.isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground" />
            )}
          </button>
        ) : (
          <div className="w-4 md:w-5" />
        )}
        
        <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0 transition-colors group-hover:border-primary/30">
          {node.code}
        </Badge>
        <span className="text-xs md:text-sm truncate flex-1">
          {displayTitle}
        </span>
        {node.is_terminal && (
          <Badge variant="secondary" className="text-[9px] md:text-[10px] px-1 py-0 h-3.5 shrink-0 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
            <Check className="h-2 w-2" />
          </Badge>
        )}
      </div>

      {node.isExpanded && hasChildren && (
        <div className="animate-in slide-in-from-top-1 duration-200">
          {node.children!.map((child) => (
            <TreeNode
              key={child.code}
              node={child}
              level={level + 1}
              onSelect={onSelect}
              onExpand={onExpand}
              selectedCode={selectedCode}
              translations={translations}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Analysis display component
function AnalysisPanel({ 
  analysis, 
  isLoading, 
  onRegenerate 
}: { 
  analysis: ICD11Analysis | null; 
  isLoading: boolean;
  onRegenerate: () => void;
}) {
  if (isLoading) {
    return (
      <div className="space-y-4 p-4">
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">Keine Analyse vorhanden</p>
        <Button variant="outline" size="sm" className="mt-2" onClick={onRegenerate}>
          <Sparkles className="h-3 w-3 mr-1" />
          Analyse generieren
        </Button>
      </div>
    );
  }

  const content = analysis.content;

  return (
    <div className="space-y-4 p-4">
      {content.explanation && (
        <div>
          <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">Erklärung</h4>
          <p className="text-sm">{content.explanation}</p>
        </div>
      )}

      {content.symptoms && content.symptoms.length > 0 && (
        <div>
          <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">Symptome</h4>
          <div className="flex flex-wrap gap-1">
            {content.symptoms.map((symptom, i) => (
              <Badge key={i} variant="secondary" className="text-xs">{symptom}</Badge>
            ))}
          </div>
        </div>
      )}

      {content.diagnosis && (
        <div>
          <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">Diagnostik</h4>
          <p className="text-sm">{content.diagnosis}</p>
        </div>
      )}

      {content.therapy && (
        <div>
          <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">Therapie</h4>
          <p className="text-sm">{content.therapy}</p>
        </div>
      )}

      {analysis.hpo_mappings && analysis.hpo_mappings.length > 0 && (
        <div>
          <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">HPO Mappings</h4>
          <div className="space-y-1">
            {analysis.hpo_mappings.slice(0, 5).map((m, i) => (
              <div key={i} className="flex items-center gap-2 text-xs">
                <Badge variant="outline" className="font-mono">{m.code}</Badge>
                <span className="truncate flex-1">{m.label}</span>
                <span className="text-muted-foreground">{Math.round(m.confidence * 100)}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {analysis.snomed_mappings && analysis.snomed_mappings.length > 0 && (
        <div>
          <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">SNOMED Mappings</h4>
          <div className="space-y-1">
            {analysis.snomed_mappings.slice(0, 5).map((m, i) => (
              <div key={i} className="flex items-center gap-2 text-xs">
                <Badge variant="outline" className="font-mono">{m.code}</Badge>
                <span className="truncate flex-1">{m.label}</span>
                <span className="text-muted-foreground">{Math.round(m.confidence * 100)}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="pt-2 border-t">
        <Button variant="ghost" size="sm" onClick={onRegenerate}>
          <RefreshCw className="h-3 w-3 mr-1" />
          Neu generieren
        </Button>
      </div>
    </div>
  );
}

export function Icd11Browser() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const { 
    searchCodes, 
    getCode,
    getChildren,
    getChapters,
    getAnalysis,
    translateCodes,
    fetchSyncStatus, 
    isLoading, 
    searchResults,
    syncStatus,
    lastDataSource,
  } = useIcd11();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCode, setSelectedCode] = useState<ICD11TreeNode | null>(null);
  const [showDetailSheet, setShowDetailSheet] = useState(false);
  const [detailPanelCollapsed, setDetailPanelCollapsed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [chapters, setChapters] = useState<ICD11TreeNode[]>([]);
  const [isLoadingChapters, setIsLoadingChapters] = useState(false);
  const [analysis, setAnalysis] = useState<ICD11Analysis | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);
  const [activeDetailTab, setActiveDetailTab] = useState<'info' | 'analysis'>('info');
  const [apiConfigured, setApiConfigured] = useState(true);
  const [translations, setTranslations] = useState<Map<string, { title_de: string; definition_de?: string }>>(new Map());

  const handleCodeSelect = (node: ICD11TreeNode) => {
    setSelectedCode(node);
    setAnalysis(null);
    if (isMobile) {
      setShowDetailSheet(true);
    }
  };

  const handleSearchResultSelect = (code: ICD11Code) => {
    setSelectedCode({ ...code, isExpanded: false });
    setAnalysis(null);
    if (isMobile) {
      setShowDetailSheet(true);
    }
  };

  useEffect(() => {
    fetchSyncStatus();
  }, [fetchSyncStatus]);

  // Load chapters on mount and translate them
  useEffect(() => {
    let mounted = true;
    const loadChapters = async () => {
      setIsLoadingChapters(true);
      try {
        const chaptersData = await getChapters();
        if (mounted) {
          setChapters(chaptersData.map(c => ({ ...c, isExpanded: false })));
          
          // Request translations for chapters
          const translationResults = await translateCodes(chaptersData);
          if (mounted && translationResults.length > 0) {
            const newTranslations = new Map(translations);
            for (const t of translationResults) {
              newTranslations.set(t.code, { title_de: t.title_de, definition_de: t.definition_de });
            }
            setTranslations(newTranslations);
          }
        }
      } catch (err) {
        console.error('Failed to load chapters:', err);
      } finally {
        if (mounted) {
          setIsLoadingChapters(false);
        }
      }
    };
    loadChapters();
    return () => { mounted = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length >= 2) {
      const results = await searchCodes(query, 30);
      // Request translations for search results
      if (results.length > 0) {
        const translationResults = await translateCodes(results);
        if (translationResults.length > 0) {
          const newTranslations = new Map(translations);
          for (const t of translationResults) {
            newTranslations.set(t.code, { title_de: t.title_de, definition_de: t.definition_de });
          }
          setTranslations(newTranslations);
        }
      }
    }
  };

  const handleNodeExpand = useCallback(async (node: ICD11TreeNode) => {
    if (node.is_terminal) return;

    // Toggle if already has children
    if (node.children && node.children.length > 0) {
      // Deep update for nested nodes
      const updateNodeInTree = (nodes: ICD11TreeNode[], targetCode: string): ICD11TreeNode[] => {
        return nodes.map(n => {
          if (n.code === targetCode) {
            return { ...n, isExpanded: !n.isExpanded };
          }
          if (n.children) {
            return { ...n, children: updateNodeInTree(n.children, targetCode) };
          }
          return n;
        });
      };
      setChapters(prev => updateNodeInTree(prev, node.code));
      return;
    }

    // Deep update for loading state
    const setLoadingInTree = (nodes: ICD11TreeNode[], targetCode: string, loading: boolean): ICD11TreeNode[] => {
      return nodes.map(n => {
        if (n.code === targetCode) {
          return { ...n, isLoading: loading };
        }
        if (n.children) {
          return { ...n, children: setLoadingInTree(n.children, targetCode, loading) };
        }
        return n;
      });
    };
    
    setChapters(prev => setLoadingInTree(prev, node.code, true));

    // Use linearization_uri if available, otherwise fall back to code
    const parentIdentifier = node.linearization_uri || node.code;
    const children = await getChildren(parentIdentifier);
    
    // Translate the children
    if (children.length > 0) {
      const translationResults = await translateCodes(children);
      if (translationResults.length > 0) {
        const newTranslations = new Map(translations);
        for (const t of translationResults) {
          newTranslations.set(t.code, { title_de: t.title_de, definition_de: t.definition_de });
        }
        setTranslations(newTranslations);
      }
    }
    
    // Deep update for setting children
    const setChildrenInTree = (nodes: ICD11TreeNode[], targetCode: string, newChildren: ICD11TreeNode[]): ICD11TreeNode[] => {
      return nodes.map(n => {
        if (n.code === targetCode) {
          return { ...n, children: newChildren, isLoading: false, isExpanded: true };
        }
        if (n.children) {
          return { ...n, children: setChildrenInTree(n.children, targetCode, newChildren) };
        }
        return n;
      });
    };
    
    setChapters(prev => setChildrenInTree(prev, node.code, children.map(child => ({ ...child, isExpanded: false }))));
  }, [getChildren, translateCodes, translations]);

  const copyCode = async (code: string) => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    toast({ title: 'Code kopiert' });
    setTimeout(() => setCopied(false), 2000);
  };

  const loadAnalysis = async (forceRegenerate = false) => {
    if (!selectedCode) return;
    setIsLoadingAnalysis(true);
    try {
      const result = await getAnalysis(selectedCode.code, selectedCode.title, forceRegenerate);
      setAnalysis(result);
    } catch (err) {
      console.error('Analysis error:', err);
    } finally {
      setIsLoadingAnalysis(false);
    }
  };

  // Load analysis when code is selected
  useEffect(() => {
    if (selectedCode && activeDetailTab === 'analysis') {
      loadAnalysis();
    }
  }, [selectedCode, activeDetailTab]);

  const renderDetailContent = () => {
    if (!selectedCode) {
      return (
        <div className="h-full flex items-center justify-center text-muted-foreground p-4 text-center">
          <div>
            <FileCode2 className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Wählen Sie einen ICD-11 Code aus der Suche oder dem Baum</p>
          </div>
        </div>
      );
    }

    return (
      <div className="h-full flex flex-col">
        <div className="p-3 md:p-4 border-b">
          <div className="flex items-center gap-2 mb-2">
            <Badge className="font-mono text-sm">{selectedCode.code}</Badge>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => copyCode(selectedCode.code)}
            >
              {copied ? <Check className="h-3.5 w-3.5 text-primary" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
            <a
              href={`https://icd.who.int/browse/2024-01/mms/en#/${selectedCode.code}`}
              target="_blank"
              rel="noopener noreferrer"
              className="ml-auto"
            >
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <ExternalLink className="h-3.5 w-3.5" />
              </Button>
            </a>
          </div>
          <h3 className="font-semibold text-sm md:text-base">{selectedCode.title}</h3>
          {selectedCode.is_terminal && (
            <Badge variant="secondary" className="mt-2 text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
              <Check className="h-3 w-3 mr-1" />
              Terminal-Code
            </Badge>
          )}
        </div>

        <Tabs value={activeDetailTab} onValueChange={(v) => setActiveDetailTab(v as 'info' | 'analysis')} className="flex-1 flex flex-col min-h-0">
          <TabsList className="mx-3 mt-2 grid grid-cols-2">
            <TabsTrigger value="info" className="text-xs">
              <Info className="h-3 w-3 mr-1" />
              Info
            </TabsTrigger>
            <TabsTrigger value="analysis" className="text-xs">
              <Sparkles className="h-3 w-3 mr-1" />
              Analyse
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1">
            <TabsContent value="info" className="m-0 p-4">
              {selectedCode.definition && (
                <div className="mb-4">
                  <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">Definition</h4>
                  <p className="text-sm">{selectedCode.definition}</p>
                </div>
              )}
              
              {selectedCode.parent_code && (
                <div className="mb-4">
                  <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">Übergeordnet</h4>
                  <Badge variant="outline" className="font-mono">{selectedCode.parent_code}</Badge>
                </div>
              )}

              {selectedCode.class_kind && (
                <div className="mb-4">
                  <h4 className="text-xs font-medium text-muted-foreground uppercase mb-1">Klassifikationsart</h4>
                  <Badge variant="secondary">{selectedCode.class_kind}</Badge>
                </div>
              )}

              <div className="text-xs text-muted-foreground mt-4 pt-4 border-t">
                <Globe className="h-3 w-3 inline mr-1" />
                WHO ICD-11 (2024)
              </div>
            </TabsContent>

            <TabsContent value="analysis" className="m-0">
              <AnalysisPanel 
                analysis={analysis} 
                isLoading={isLoadingAnalysis} 
                onRegenerate={() => loadAnalysis(true)}
              />
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </div>
    );
  };

  return (
    <div className="h-full flex">
      {/* Left Panel - Search & Tree */}
      <div className={cn(
        "flex flex-col border-r transition-all duration-300",
        detailPanelCollapsed ? "flex-1" : "w-full md:w-1/2 lg:w-2/5"
      )}>
        {/* Search */}
        <div className="p-3 md:p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="ICD-11 Code oder Begriff suchen..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-9"
            />
            {isLoading && (
              <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
            )}
          </div>
          
          {/* API Status */}
          {!apiConfigured && (
            <Alert className="mt-3" variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>API nicht konfiguriert</AlertTitle>
              <AlertDescription className="text-xs">
                Bitte konfigurieren Sie die WHO ICD-11 API Credentials 
                (ICD11_CLIENT_ID, ICD11_CLIENT_SECRET) unter{' '}
                <a href="https://icd.who.int/icdapi" target="_blank" rel="noopener noreferrer" className="underline">
                  icd.who.int
                </a>
              </AlertDescription>
            </Alert>
          )}

          {/* Stats & Sync Button */}
          <div className="flex items-center justify-between mt-2">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <OntologyStatsBar source="icd11" showLabel={!isMobile} />
              {lastDataSource !== 'unknown' && (
                <DataSourceBadge source={lastDataSource} />
              )}
            </div>
            <BulkSyncButton source="icd11" />
          </div>
        </div>

        {/* Search Results */}
        {searchQuery.length >= 2 && searchResults.length > 0 && (
          <div className="border-b">
            <div className="p-2 bg-muted/50">
              <span className="text-xs text-muted-foreground">
                {searchResults.length} Ergebnisse
              </span>
            </div>
            <ScrollArea className="max-h-[200px]">
              {searchResults.map((result) => (
                <div
                  key={result.code}
                  className={cn(
                    "flex items-center gap-2 p-2 cursor-pointer hover:bg-muted transition-colors",
                    selectedCode?.code === result.code && "bg-primary/10"
                  )}
                  onClick={() => handleSearchResultSelect(result)}
                >
                  <Badge variant="outline" className="font-mono text-xs shrink-0">
                    {result.code}
                  </Badge>
                  <span className="text-xs md:text-sm truncate">{result.title}</span>
                  {result.is_terminal && (
                    <Check className="h-3 w-3 text-emerald-500 shrink-0" />
                  )}
                </div>
              ))}
            </ScrollArea>
          </div>
        )}

        {/* Tree View */}
        <ScrollArea className="flex-1">
          <div className="p-2">
            {isLoadingChapters ? (
              <div className="space-y-2 p-2">
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-3/4" />
                <Skeleton className="h-8 w-5/6" />
              </div>
            ) : chapters.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <BookOpen className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Keine Kapitel geladen</p>
                <p className="text-xs mt-1">Nutzen Sie die Suche oben</p>
              </div>
            ) : (
              chapters.map((chapter) => (
                <TreeNode
                  key={chapter.code}
                  node={chapter}
                  level={0}
                  onSelect={handleCodeSelect}
                  onExpand={handleNodeExpand}
                  selectedCode={selectedCode?.code}
                  translations={translations}
                />
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Right Panel - Details (Desktop) */}
      {!isMobile && (
        <div className={cn(
          "flex flex-col transition-all duration-300",
          detailPanelCollapsed ? "w-0 opacity-0 overflow-hidden" : "flex-1"
        )}>
          <div className="h-10 border-b flex items-center justify-between px-2">
            <span className="text-xs text-muted-foreground font-medium">Details</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => setDetailPanelCollapsed(!detailPanelCollapsed)}
            >
              {detailPanelCollapsed ? (
                <PanelRightOpen className="h-4 w-4" />
              ) : (
                <PanelRightClose className="h-4 w-4" />
              )}
            </Button>
          </div>
          {renderDetailContent()}
        </div>
      )}

      {/* Collapse toggle when panel is hidden */}
      {!isMobile && detailPanelCollapsed && (
        <div className="w-10 border-l flex flex-col items-center pt-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setDetailPanelCollapsed(false)}
          >
            <PanelRightOpen className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Mobile Detail Drawer */}
      {isMobile && (
        <Drawer open={showDetailSheet} onOpenChange={setShowDetailSheet}>
          <DrawerContent className="max-h-[85vh]">
            <DrawerHeader className="pb-2">
              <div className="flex items-center justify-between">
                <DrawerTitle className="text-base">Code Details</DrawerTitle>
                <DrawerClose asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <X className="h-4 w-4" />
                  </Button>
                </DrawerClose>
              </div>
            </DrawerHeader>
            <div className="flex-1 overflow-auto">
              {renderDetailContent()}
            </div>
          </DrawerContent>
        </Drawer>
      )}
    </div>
  );
}
