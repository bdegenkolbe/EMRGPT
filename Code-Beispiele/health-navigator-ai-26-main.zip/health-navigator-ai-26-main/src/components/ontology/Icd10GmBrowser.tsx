import { useState, useEffect, useCallback } from 'react';
import { useIcd10Gm, ICD10Code, DataSource } from '@/hooks/useIcd10Gm';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { 
  Search, 
  ChevronRight, 
  ChevronDown, 
  RefreshCw,
  Info,
  Copy,
  Check,
  Loader2,
  ExternalLink,
  Upload,
  FileArchive,
  AlertCircle,
  X,
  PanelRightClose,
  PanelRightOpen,
  FileCode,
  FileSpreadsheet,
  CheckCircle2,
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useDropzone } from 'react-dropzone';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { ICD10AnalysisPanel } from './ICD10AnalysisPanel';
import { DataSourceBadge } from '@/components/ui/data-source-badge';
import { OntologyStatsBar } from './OntologyStatsBar';

// ICD-10-GM chapters for navigation
const ICD10_CHAPTERS = [
  { id: 'I', range: 'A00-B99', name: 'Bestimmte infektiöse und parasitäre Krankheiten' },
  { id: 'II', range: 'C00-D48', name: 'Neubildungen' },
  { id: 'III', range: 'D50-D90', name: 'Krankheiten des Blutes und der blutbildenden Organe' },
  { id: 'IV', range: 'E00-E90', name: 'Endokrine, Ernährungs- und Stoffwechselkrankheiten' },
  { id: 'V', range: 'F00-F99', name: 'Psychische und Verhaltensstörungen' },
  { id: 'VI', range: 'G00-G99', name: 'Krankheiten des Nervensystems' },
  { id: 'VII', range: 'H00-H59', name: 'Krankheiten des Auges und der Augenanhangsgebilde' },
  { id: 'VIII', range: 'H60-H95', name: 'Krankheiten des Ohres und des Warzenfortsatzes' },
  { id: 'IX', range: 'I00-I99', name: 'Krankheiten des Kreislaufsystems' },
  { id: 'X', range: 'J00-J99', name: 'Krankheiten des Atmungssystems' },
  { id: 'XI', range: 'K00-K93', name: 'Krankheiten des Verdauungssystems' },
  { id: 'XII', range: 'L00-L99', name: 'Krankheiten der Haut und der Unterhaut' },
  { id: 'XIII', range: 'M00-M99', name: 'Krankheiten des Muskel-Skelett-Systems und des Bindegewebes' },
  { id: 'XIV', range: 'N00-N99', name: 'Krankheiten des Urogenitalsystems' },
  { id: 'XV', range: 'O00-O99', name: 'Schwangerschaft, Geburt und Wochenbett' },
  { id: 'XVI', range: 'P00-P96', name: 'Bestimmte Zustände, die ihren Ursprung in der Perinatalperiode haben' },
  { id: 'XVII', range: 'Q00-Q99', name: 'Angeborene Fehlbildungen, Deformitäten und Chromosomenanomalien' },
  { id: 'XVIII', range: 'R00-R99', name: 'Symptome und abnorme klinische und Laborbefunde' },
  { id: 'XIX', range: 'S00-T98', name: 'Verletzungen, Vergiftungen und bestimmte andere Folgen äußerer Ursachen' },
  { id: 'XX', range: 'V01-Y84', name: 'Äußere Ursachen von Morbidität und Mortalität' },
  { id: 'XXI', range: 'Z00-Z99', name: 'Faktoren, die den Gesundheitszustand beeinflussen' },
  { id: 'XXII', range: 'U00-U99', name: 'Schlüsselnummern für besondere Zwecke' },
];

interface ICD10TreeNode extends ICD10Code {
  children?: ICD10TreeNode[];
  isLoading?: boolean;
  isExpanded?: boolean;
}

interface TreeNodeProps {
  node: ICD10TreeNode;
  level: number;
  onSelect: (node: ICD10TreeNode) => void;
  onExpand: (node: ICD10TreeNode) => void;
  selectedCode?: string;
}

// Helper to determine the hierarchy level type based on code structure
function getCodeLevel(node: ICD10TreeNode): { type: 'block' | 'category' | 'subcategory' | 'code'; label: string; color: string } {
  // Block: range codes like "A00-A09"
  if (node.code.includes('-')) {
    return { type: 'block', label: 'Block', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' };
  }
  // Category: 3-char codes like "A00" (non-terminal parent)
  if (node.code.length === 3 && !node.is_terminal) {
    return { type: 'category', label: 'Kategorie', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' };
  }
  // Subcategory: 4-char codes like "A00.0" that still have children
  if (node.code.length >= 4 && !node.is_terminal) {
    return { type: 'subcategory', label: 'Subkat.', color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400' };
  }
  // Terminal code
  return { type: 'code', label: 'Code', color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' };
}

function TreeNode({ node, level, onSelect, onExpand, selectedCode }: TreeNodeProps) {
  const hasChildren = node.children && node.children.length > 0;
  const isSelected = node.code === selectedCode;
  const canExpand = !node.is_terminal;
  const codeLevel = getCodeLevel(node);

  return (
    <div className="select-none">
      <div
        className={cn(
          'group flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted active:scale-[0.98]',
          isSelected && 'bg-primary/10 text-primary font-medium ring-1 ring-primary/20'
        )}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={() => onSelect(node)}
      >
        {node.isLoading ? (
          <Loader2 className="h-3.5 w-3.5 md:h-4 md:w-4 animate-spin text-muted-foreground shrink-0" />
        ) : canExpand ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onExpand(node);
            }}
            className="p-0.5 hover:bg-muted-foreground/20 rounded transition-colors"
          >
            {node.isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground transition-transform duration-200" />
            )}
          </button>
        ) : (
          <div className="w-4 md:w-5" />
        )}
        
        {/* Level indicator badge */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge 
              variant="secondary" 
              className={cn(
                "text-[8px] md:text-[9px] px-1 py-0 h-3 md:h-3.5 shrink-0 font-medium cursor-help border-0",
                codeLevel.color
              )}
            >
              {codeLevel.label}
            </Badge>
          </TooltipTrigger>
          <TooltipContent side="top" className="max-w-xs">
            <p className="text-xs">
              {codeLevel.type === 'block' && 'Block: Gruppe verwandter Diagnosen'}
              {codeLevel.type === 'category' && 'Kategorie: Dreistelliger Schlüssel'}
              {codeLevel.type === 'subcategory' && 'Subkategorie: Weiter untergliedert'}
              {codeLevel.type === 'code' && 'Terminal-Code: Abrechnungsfähig'}
            </p>
          </TooltipContent>
        </Tooltip>

        <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0 transition-colors group-hover:border-primary/30">
          {node.code}
        </Badge>
        <div className="flex flex-col min-w-0 flex-1">
          <span className="text-xs md:text-sm truncate transition-colors">
            {node.title_short || node.title}
          </span>
          {/* Show block info for categories */}
          {node.block && codeLevel.type !== 'block' && (
            <span className="text-[9px] md:text-[10px] text-muted-foreground truncate hidden sm:block">
              Block: {node.block}
            </span>
          )}
        </div>
        {node.is_terminal && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant="secondary" className="text-[9px] md:text-[10px] px-1 py-0 h-3.5 md:h-4 shrink-0 gap-0.5 cursor-help bg-primary/10 text-primary border-primary/20">
                <Check className="h-2 w-2 md:h-2.5 md:w-2.5" />
              </Badge>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <p className="text-xs">
                Terminal-Code: Dieser Code kann für die Abrechnung verwendet werden.
              </p>
            </TooltipContent>
          </Tooltip>
        )}
      </div>

      {node.isExpanded && hasChildren && (
        <div className="animate-in slide-in-from-top-1 duration-200">
          {node.children!.map((child) => (
            <TreeNode
              key={child.code}
              node={child}
              level={level + 1}
              onSelect={onSelect}
              onExpand={onExpand}
              selectedCode={selectedCode}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Chapter node component (similar to HPO root categories)
interface ChapterNodeProps {
  chapter: typeof ICD10_CHAPTERS[0];
  children: ICD10TreeNode[];
  isLoading: boolean;
  isExpanded: boolean;
  onToggle: () => void;
  onSelect: (node: ICD10TreeNode) => void;
  onExpand: (node: ICD10TreeNode) => void;
  selectedCode?: string;
}

function ChapterNode({ 
  chapter, 
  children, 
  isLoading, 
  isExpanded, 
  onToggle,
  onSelect,
  onExpand,
  selectedCode 
}: ChapterNodeProps) {
  return (
    <div className="select-none">
      <div
        className={cn(
          'group flex items-center gap-1 py-1.5 md:py-2 px-2 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted active:scale-[0.99]',
          isExpanded && 'bg-muted/50'
        )}
        onClick={onToggle}
      >
        {isLoading ? (
          <Loader2 className="h-3.5 w-3.5 md:h-4 md:w-4 animate-spin text-muted-foreground shrink-0" />
        ) : (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggle();
            }}
            className="p-0.5 hover:bg-muted-foreground/20 rounded transition-colors"
          >
            {isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground transition-transform duration-200" />
            )}
          </button>
        )}
        
        <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0 transition-colors group-hover:border-primary/30">
          {chapter.id}
        </Badge>
        <div className="flex flex-col min-w-0 flex-1">
          <span className="text-xs md:text-sm font-medium truncate transition-colors group-hover:text-primary">
            {chapter.name}
          </span>
          <span className="text-[10px] md:text-[11px] text-muted-foreground italic hidden sm:block">
            {chapter.range}
          </span>
        </div>
      </div>

      {isExpanded && (
        <div className="ml-3 md:ml-4 animate-in slide-in-from-top-1 duration-200">
          {isLoading ? (
            <div className="py-2 space-y-2 ml-2 md:ml-4">
              <Skeleton className="h-5 md:h-6 w-full" />
              <Skeleton className="h-5 md:h-6 w-3/4" />
              <Skeleton className="h-5 md:h-6 w-5/6" />
            </div>
          ) : children.length === 0 ? (
            <div className="py-2 md:py-3 px-3 md:px-4 ml-2 text-xs md:text-sm">
              <p className="text-muted-foreground mb-2">
                Keine Codes vorhanden.
              </p>
              <p className="text-[10px] md:text-xs text-muted-foreground">
                Bitte synchronisieren Sie zuerst den ICD-10-GM Katalog.
              </p>
            </div>
          ) : (
            children.map((child) => (
              <TreeNode
                key={child.code}
                node={child}
                level={1}
                onSelect={onSelect}
                onExpand={onExpand}
                selectedCode={selectedCode}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
}

export function Icd10GmBrowser() {
  const { toast } = useToast();
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const { 
    searchCodes, 
    getChildren,
    getCode,
    getByChapter,
    fetchSyncStatus, 
    triggerSync,
    isLoading, 
    isSyncing,
    searchResults,
    syncStatus,
    lastDataSource,
  } = useIcd10Gm();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCode, setSelectedCode] = useState<ICD10TreeNode | null>(null);
  const [showDetailSheet, setShowDetailSheet] = useState(false);
  const [detailPanelCollapsed, setDetailPanelCollapsed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Upload state
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [detectedFormat, setDetectedFormat] = useState<'csv' | 'claml' | null>(null);
  const [importResult, setImportResult] = useState<{ inserted: number; format: string } | null>(null);
  
  // Filter state
  const [filterMode, setFilterMode] = useState<'all' | 'terminal' | 'blocks' | 'categories'>('all');
  
  // Chapter state
  const [chapterData, setChapterData] = useState<Record<string, {
    codes: ICD10TreeNode[];
    isLoading: boolean;
    isExpanded: boolean;
  }>>({});

  const handleCodeSelect = (node: ICD10TreeNode) => {
    setSelectedCode(node);
    if (isMobile) {
      setShowDetailSheet(true);
    }
  };

  const handleSearchResultSelect = (code: ICD10Code) => {
    setSelectedCode({ ...code, isExpanded: false });
    if (isMobile) {
      setShowDetailSheet(true);
    }
  };

  // Check admin status
  useEffect(() => {
    const checkAdmin = async () => {
      if (!user) {
        setIsAdmin(false);
        return;
      }
      const { data } = await supabase.rpc('is_admin', { _user_id: user.id });
      setIsAdmin(!!data);
    };
    checkAdmin();
  }, [user]);

  useEffect(() => {
    fetchSyncStatus();
  }, [fetchSyncStatus]);

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length >= 2) {
      await searchCodes(query, 30);
    }
  };

  const handleSync = useCallback(async () => {
    await triggerSync();
    // Clear cached chapter results so the tree can re-fetch fresh data
    setChapterData({});
    setSelectedCode(null);
  }, [triggerSync]);

  const handleChapterToggle = useCallback(async (chapterId: string) => {
    const current = chapterData[chapterId];

    // Prevent duplicate loads when users click quickly
    if (current?.isLoading) return;

    if (current?.isExpanded) {
      // Collapse
      setChapterData(prev => ({
        ...prev,
        [chapterId]: { ...prev[chapterId], isExpanded: false },
      }));
      return;
    }

    // Expand without re-fetch ONLY if we have cached items
    if (current && current.codes.length > 0) {
      setChapterData(prev => ({
        ...prev,
        [chapterId]: { ...prev[chapterId], isExpanded: true },
      }));
      return;
    }

    // Load only direct children (blocks) - lazy loading optimization
    setChapterData(prev => ({
      ...prev,
      [chapterId]: { codes: current?.codes ?? [], isLoading: true, isExpanded: true },
    }));

    // Use getChildren to fetch only direct children of the chapter (blocks like "A00-A09")
    // This is much more efficient than getByChapter which loads ALL codes in the chapter
    const blocks = await getChildren(chapterId);

    setChapterData(prev => ({
      ...prev,
      [chapterId]: {
        codes: blocks.map(c => ({ ...c, isExpanded: false })),
        isLoading: false,
        isExpanded: true,
      },
    }));
  }, [chapterData, getChildren]);

  const handleNodeExpand = useCallback(async (node: ICD10TreeNode) => {
    if (node.is_terminal) return;

    // Find which chapter this node belongs to
    const chapterId = Object.keys(chapterData).find(id => {
      const chapter = chapterData[id];
      const findNode = (nodes: ICD10TreeNode[]): boolean => {
        for (const n of nodes) {
          if (n.code === node.code) return true;
          if (n.children && findNode(n.children)) return true;
        }
        return false;
      };
      return findNode(chapter.codes);
    });

    if (!chapterId) return;

    // Toggle expansion
    const updateNodeInTree = (nodes: ICD10TreeNode[]): ICD10TreeNode[] => {
      return nodes.map(n => {
        if (n.code === node.code) {
          if (n.isExpanded) {
            return { ...n, isExpanded: false };
          } else if (n.children && n.children.length > 0) {
            return { ...n, isExpanded: true };
          } else {
            return { ...n, isLoading: true };
          }
        }
        if (n.children) {
          return { ...n, children: updateNodeInTree(n.children) };
        }
        return n;
      });
    };

    // If already has children, just toggle
    if (node.children && node.children.length > 0) {
      setChapterData(prev => ({
        ...prev,
        [chapterId]: {
          ...prev[chapterId],
          codes: updateNodeInTree(prev[chapterId].codes)
        }
      }));
      return;
    }

    // Set loading state
    setChapterData(prev => ({
      ...prev,
      [chapterId]: {
        ...prev[chapterId],
        codes: updateNodeInTree(prev[chapterId].codes)
      }
    }));

    // Fetch children
    const children = await getChildren(node.code);
    
    // Update with children
    const updateWithChildren = (nodes: ICD10TreeNode[]): ICD10TreeNode[] => {
      return nodes.map(n => {
        if (n.code === node.code) {
          return { 
            ...n, 
            isLoading: false, 
            isExpanded: true,
            children: children.map(c => ({ ...c, isExpanded: false }))
          };
        }
        if (n.children) {
          return { ...n, children: updateWithChildren(n.children) };
        }
        return n;
      });
    };

    setChapterData(prev => ({
      ...prev,
      [chapterId]: {
        ...prev[chapterId],
        codes: updateWithChildren(prev[chapterId].codes)
      }
    }));
  }, [chapterData, getChildren]);


  const copyToClipboard = () => {
    if (!selectedCode) return;
    navigator.clipboard.writeText(selectedCode.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: 'Kopiert',
      description: `${selectedCode.code} in die Zwischenablage kopiert`,
    });
  };

  // File upload handling
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      if (file.name.toLowerCase().endsWith('.zip')) {
        setUploadFile(file);
        setUploadError(null);
      } else {
        setUploadError('Bitte eine ZIP-Datei auswählen (BfArM Metadaten TXT/CSV)');
      }
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/zip': ['.zip'] },
    maxFiles: 1,
    disabled: isUploading,
  });

  const handleUpload = async () => {
    if (!uploadFile) return;

    setIsUploading(true);
    setUploadProgress(10);
    setUploadError(null);

    try {
      // Upload to storage
      const fileName = `${Date.now()}_${uploadFile.name}`;
      setUploadProgress(20);

      const { error: uploadError } = await supabase.storage
        .from('icd10gm-imports')
        .upload(fileName, uploadFile);

      if (uploadError) throw uploadError;
      setUploadProgress(50);

      // Trigger import
      const { data, error: invokeError } = await supabase.functions.invoke('icd10gm-import', {
        body: {
          file_path: fileName,
          year: new Date().getFullYear(),
          clear_existing: true,
        },
      });

      setUploadProgress(90);

      if (invokeError) throw invokeError;

      if (!data?.success && data?.errors?.length > 0) {
        throw new Error(data.errors.join(', '));
      }

      setUploadProgress(100);
      setDetectedFormat(data?.format || null);
      setImportResult({ inserted: data?.inserted || 0, format: data?.format || 'csv' });
      
      toast({
        title: 'Import erfolgreich',
        description: `${data?.inserted || 0} ICD-10-GM Codes aus ${data?.format?.toUpperCase() || 'Datei'} importiert`,
      });

      // Refresh data
      await fetchSyncStatus();
      setChapterData({});
    } catch (err: any) {
      console.error('Upload error:', err);
      setUploadError(err.message || 'Import fehlgeschlagen');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  // Reusable detail card
  const DetailCard = () => selectedCode && (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 md:gap-3 flex-wrap">
            <Badge className="font-mono text-sm md:text-lg px-2 md:px-3 py-0.5 md:py-1">
              {selectedCode.code}
            </Badge>
            {selectedCode.is_terminal && (
              <Badge variant="secondary" className="text-xs">Terminal</Badge>
            )}
          </div>
          <div className="flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={copyToClipboard}>
                  {copied ? (
                    <Check className="h-4 w-4 text-primary" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Code kopieren</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => window.open(
                    `https://www.icd-code.de/suche/icd/code/${selectedCode.code}.html`,
                    '_blank'
                  )}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Im Browser öffnen</TooltipContent>
            </Tooltip>
          </div>
        </div>
        <CardTitle className="text-base md:text-xl mt-2 md:mt-3">
          {selectedCode.title}
        </CardTitle>
        {selectedCode.title_short && selectedCode.title_short !== selectedCode.title && (
          <p className="text-sm text-muted-foreground">
            {selectedCode.title_short}
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3 md:space-y-4">
        {/* Hierarchy Breadcrumb - Clickable */}
        {(selectedCode.chapter || selectedCode.block) && (
          <div className="flex items-center gap-1 flex-wrap text-xs md:text-sm pb-2 border-b">
            {selectedCode.chapter && (
              <>
                <Badge 
                  variant="outline" 
                  className="text-[10px] md:text-xs bg-slate-100 dark:bg-slate-800 cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  onClick={() => {
                    // Toggle chapter open/closed
                    if (selectedCode.chapter) {
                      handleChapterToggle(selectedCode.chapter);
                      setSelectedCode(null);
                    }
                  }}
                >
                  Kap. {selectedCode.chapter}
                </Badge>
                <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />
              </>
            )}
            {selectedCode.block && (
              <>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-[10px] md:text-xs bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 border-blue-200 dark:border-blue-800",
                    selectedCode.code !== selectedCode.block && "cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors"
                  )}
                  onClick={async () => {
                    if (selectedCode.block && selectedCode.code !== selectedCode.block) {
                      const blockCode = await getCode(selectedCode.block);
                      if (blockCode) {
                        setSelectedCode(blockCode);
                      }
                    }
                  }}
                >
                  {selectedCode.block}
                </Badge>
                {(selectedCode.category || selectedCode.code !== selectedCode.block) && (
                  <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />
                )}
              </>
            )}
            {selectedCode.category && selectedCode.category !== selectedCode.block && (
              <>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-[10px] md:text-xs bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800",
                    selectedCode.code !== selectedCode.category && "cursor-pointer hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-colors"
                  )}
                  onClick={async () => {
                    if (selectedCode.category && selectedCode.code !== selectedCode.category) {
                      const categoryCode = await getCode(selectedCode.category);
                      if (categoryCode) {
                        setSelectedCode(categoryCode);
                      }
                    }
                  }}
                >
                  {selectedCode.category}
                </Badge>
                {selectedCode.code !== selectedCode.category && (
                  <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />
                )}
              </>
            )}
            {selectedCode.code !== selectedCode.block && selectedCode.code !== selectedCode.category && (
              <Badge variant="outline" className="text-[10px] md:text-xs font-mono bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800">
                {selectedCode.code}
              </Badge>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 md:gap-4 text-xs md:text-sm">
          {selectedCode.chapter && (
            <div>
              <span className="text-muted-foreground">Kapitel:</span>
              <p className="font-medium">{selectedCode.chapter}</p>
            </div>
          )}
          {selectedCode.block && (
            <div>
              <span className="text-muted-foreground">Gruppe:</span>
              <p className="font-medium">{selectedCode.block}</p>
            </div>
          )}
          {selectedCode.category && (
            <div>
              <span className="text-muted-foreground">Kategorie:</span>
              <p className="font-medium">{selectedCode.category}</p>
            </div>
          )}
          {selectedCode.parent_code && (
            <div>
              <span className="text-muted-foreground">Übergeordnet:</span>
              <p className="font-medium font-mono">{selectedCode.parent_code}</p>
            </div>
          )}
          {selectedCode.year && (
            <div>
              <span className="text-muted-foreground">Katalog-Jahr:</span>
              <p className="font-medium">{selectedCode.year}</p>
            </div>
          )}
        </div>

        {selectedCode.notes && (
          <div>
            <h4 className="text-xs md:text-sm font-medium flex items-center gap-2 mb-1 md:mb-2">
              <Info className="h-3.5 w-3.5 md:h-4 md:w-4" />
              Hinweise
            </h4>
            <p className="text-xs md:text-sm text-muted-foreground whitespace-pre-wrap">
              {selectedCode.notes}
            </p>
          </div>
        )}

        {selectedCode.inclusions && selectedCode.inclusions.length > 0 && (
          <div>
            <h4 className="text-xs md:text-sm font-medium text-primary mb-1 md:mb-2">
              Inklusiva
            </h4>
            <ul className="text-xs md:text-sm space-y-0.5 md:space-y-1">
              {selectedCode.inclusions.map((inc, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-primary">+</span>
                  {inc}
                </li>
              ))}
            </ul>
          </div>
        )}

        {selectedCode.exclusions && selectedCode.exclusions.length > 0 && (
          <div>
            <h4 className="text-xs md:text-sm font-medium text-destructive mb-1 md:mb-2">
              Exklusiva
            </h4>
            <ul className="text-xs md:text-sm space-y-0.5 md:space-y-1">
              {selectedCode.exclusions.map((exc, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-destructive">−</span>
                  {exc}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="h-full flex flex-col md:flex-row">
      {/* Left Panel: Tree Navigation */}
      <div className={cn(
        'flex flex-col transition-all duration-300',
        isMobile ? 'flex-1' : detailPanelCollapsed ? 'flex-1' : 'w-1/2',
        !isMobile && !detailPanelCollapsed && 'border-r'
      )}>
        {/* Search */}
        <div className="p-3 md:p-4 border-b space-y-2 md:space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={isMobile ? "Suchen..." : "ICD-10 Code oder Begriff suchen..."}
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10 text-sm"
            />
          </div>
          
          {/* Filter Toggles */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs text-muted-foreground mr-1">Filter:</span>
            <Button
              variant={filterMode === 'all' ? 'default' : 'outline'}
              size="sm"
              className="h-6 md:h-7 px-2 md:px-2.5 text-[10px] md:text-xs"
              onClick={() => setFilterMode('all')}
            >
              Alle
            </Button>
            <Button
              variant={filterMode === 'terminal' ? 'default' : 'outline'}
              size="sm"
              className="h-6 md:h-7 px-2 md:px-2.5 text-[10px] md:text-xs"
              onClick={() => setFilterMode('terminal')}
            >
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Terminal
            </Button>
            <Button
              variant={filterMode === 'blocks' ? 'default' : 'outline'}
              size="sm"
              className="h-6 md:h-7 px-2 md:px-2.5 text-[10px] md:text-xs"
              onClick={() => setFilterMode('blocks')}
            >
              <FileCode className="h-3 w-3 mr-1" />
              Blöcke
            </Button>
            <Button
              variant={filterMode === 'categories' ? 'default' : 'outline'}
              size="sm"
              className="h-6 md:h-7 px-2 md:px-2.5 text-[10px] md:text-xs"
              onClick={() => setFilterMode('categories')}
            >
              <FileSpreadsheet className="h-3 w-3 mr-1" />
              Kategorien
            </Button>
          </div>
          
          {/* Sync Status & Actions */}
          <div className="flex items-center justify-between text-xs md:text-sm">
            <div className="flex items-center gap-1.5 md:gap-2 text-muted-foreground">
              <OntologyStatsBar source="icd10gm" showLabel={!isMobile} />
              {syncStatus?.year && (
                <Badge variant="secondary" className="text-[10px] md:text-xs">{syncStatus.year}</Badge>
              )}
              <DataSourceBadge source={lastDataSource} />
            </div>
            <div className="flex items-center gap-1">
              {/* Toggle Detail Panel - Desktop only */}
              {!isMobile && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 md:h-8 md:w-8 p-0"
                  onClick={() => setDetailPanelCollapsed(!detailPanelCollapsed)}
                  title={detailPanelCollapsed ? 'Details einblenden' : 'Details ausblenden'}
                >
                  {detailPanelCollapsed ? (
                    <PanelRightOpen className="h-3.5 w-3.5 md:h-4 md:w-4" />
                  ) : (
                    <PanelRightClose className="h-3.5 w-3.5 md:h-4 md:w-4" />
                  )}
                </Button>
              )}
              
              {/* Admin: Upload Button */}
              {isAdmin && (
                <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-7 w-7 md:h-8 md:w-8 p-0">
                      <Upload className="h-3.5 w-3.5 md:h-4 md:w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-[90vw] sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>ICD-10-GM Katalog importieren</DialogTitle>
                      <DialogDescription>
                        Laden Sie die BfArM Metadaten-ZIP hoch.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 py-4">
                      <div
                        {...getRootProps()}
                        className={`border-2 border-dashed rounded-lg p-6 md:p-8 text-center cursor-pointer transition-colors ${
                          isDragActive 
                            ? 'border-primary bg-primary/5' 
                            : uploadFile 
                              ? 'border-primary/50 bg-primary/5'
                              : 'border-muted-foreground/25 hover:border-primary/50'
                        }`}
                      >
                        <input {...getInputProps()} />
                        {uploadFile ? (
                          <div className="flex items-center justify-center gap-3">
                            <FileArchive className="h-6 w-6 md:h-8 md:w-8 text-primary" />
                            <div className="text-left">
                              <p className="font-medium text-sm">{uploadFile.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {(uploadFile.size / 1024 / 1024).toFixed(2)} MB
                              </p>
                            </div>
                          </div>
                        ) : (
                          <>
                            <FileArchive className="h-8 w-8 md:h-10 md:w-10 mx-auto text-muted-foreground mb-3" />
                            <p className="text-xs md:text-sm text-muted-foreground">
                              {isDragActive 
                                ? 'Datei hier ablegen...' 
                                : 'ZIP-Datei hier ablegen'}
                            </p>
                          </>
                        )}
                      </div>
                      
                      {isUploading && (
                        <div className="space-y-2">
                          <Progress value={uploadProgress} />
                          <p className="text-xs text-center text-muted-foreground">
                            {uploadProgress < 50 ? 'Hochladen...' : 'Importieren...'}
                          </p>
                        </div>
                      )}
                      
                      {uploadError && (
                        <Alert variant="destructive">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription className="text-xs">{uploadError}</AlertDescription>
                        </Alert>
                      )}
                      
                      {importResult && !isUploading && (
                        <Alert className="bg-primary/5 border-primary/20">
                          <CheckCircle2 className="h-4 w-4 text-primary" />
                          <AlertDescription className="text-xs flex items-center gap-2">
                            <span className="font-medium">{importResult.inserted} Codes importiert</span>
                            <Badge 
                              variant="outline" 
                              className={`text-[10px] px-1.5 py-0 ${
                                importResult.format === 'claml' 
                                  ? 'bg-blue-500/10 text-blue-600 border-blue-500/30' 
                                  : 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30'
                              }`}
                            >
                              {importResult.format === 'claml' ? (
                                <><FileCode className="h-3 w-3 mr-1" />ClaML/XML</>
                              ) : (
                                <><FileSpreadsheet className="h-3 w-3 mr-1" />CSV</>
                              )}
                            </Badge>
                          </AlertDescription>
                        </Alert>
                      )}
                    </div>
                    
                    <DialogFooter className="flex-col sm:flex-row gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => { 
                          setUploadDialogOpen(false); 
                          setUploadFile(null); 
                          setUploadError(null); 
                          setImportResult(null);
                          setDetectedFormat(null);
                        }}
                        disabled={isUploading}
                      >
                        Abbrechen
                      </Button>
                      <Button 
                        size="sm"
                        onClick={handleUpload} 
                        disabled={!uploadFile || isUploading}
                      >
                        {isUploading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Importiere...
                          </>
                        ) : (
                          'Importieren'
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
              
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 w-7 md:h-8 md:w-8 p-0"
                    onClick={handleSync}
                    disabled={isSyncing}
                  >
                    <RefreshCw className={`h-3.5 w-3.5 md:h-4 md:w-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Katalog synchronisieren</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>
        </div>

        {/* Tree Content */}
        <ScrollArea className="flex-1">
          {searchQuery.length >= 2 ? (
            /* Search Results */
            <div className="p-3 md:p-4">
              {(() => {
                const filteredResults = searchResults.filter(code => {
                  if (filterMode === 'terminal') return code.is_terminal;
                  if (filterMode === 'blocks') return code.code.includes('-');
                  if (filterMode === 'categories') return code.code.length === 3 && !code.code.includes('-');
                  return true;
                });
                return (
                  <>
                    <h3 className="text-xs md:text-sm font-medium mb-2 md:mb-3">
                      Suchergebnisse ({filteredResults.length}
                      {filterMode !== 'all' && ` von ${searchResults.length}`})
                    </h3>
                    {isLoading ? (
                      <div className="space-y-2">
                        {[...Array(5)].map((_, i) => (
                          <Skeleton key={i} className="h-7 md:h-8 w-full" />
                        ))}
                      </div>
                    ) : filteredResults.length === 0 ? (
                      <p className="text-muted-foreground text-xs md:text-sm">
                        {searchResults.length > 0 
                          ? `Keine ${filterMode === 'terminal' ? 'terminalen Codes' : filterMode === 'blocks' ? 'Blöcke' : 'Kategorien'} gefunden`
                          : 'Keine Ergebnisse gefunden'}
                      </p>
                    ) : (
                      <div className="space-y-0.5">
                        {filteredResults.map((code) => (
                          <div
                            key={code.code}
                            className={`flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer transition-colors hover:bg-muted ${
                              selectedCode?.code === code.code ? 'bg-primary/10 text-primary font-medium' : ''
                            }`}
                            onClick={() => handleSearchResultSelect(code)}
                          >
                            <div className="w-4 md:w-5" />
                            <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0">
                              {code.code}
                            </Badge>
                            <span className="text-xs md:text-sm truncate flex-1">
                              {code.title_short || code.title}
                            </span>
                            {code.is_terminal && (
                              <Badge variant="secondary" className="text-[8px] md:text-[10px] px-1 py-0 h-3.5 md:h-4 shrink-0">
                                ✓
                              </Badge>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                );
              })()}
            </div>
          ) : (
            /* Chapter Tree */
            <div className="p-1.5 md:p-2">
              {filterMode === 'all' ? (
                // Normal tree view
                ICD10_CHAPTERS.map((chapter) => (
                  <ChapterNode
                    key={chapter.id}
                    chapter={chapter}
                    children={chapterData[chapter.id]?.codes || []}
                    isLoading={chapterData[chapter.id]?.isLoading || false}
                    isExpanded={chapterData[chapter.id]?.isExpanded || false}
                    onToggle={() => handleChapterToggle(chapter.id)}
                    onSelect={handleCodeSelect}
                    onExpand={handleNodeExpand}
                    selectedCode={selectedCode?.code}
                  />
                ))
              ) : (
                // Filtered view - show flat list per chapter
                ICD10_CHAPTERS.map((chapter) => {
                  const chapterCodes = chapterData[chapter.id]?.codes || [];
                  
                  // Count function for statistics
                  const countCodes = (nodes: ICD10TreeNode[]): { terminal: number; blocks: number; categories: number } => {
                    let counts = { terminal: 0, blocks: 0, categories: 0 };
                    for (const node of nodes) {
                      if (node.is_terminal) counts.terminal++;
                      if (node.code.includes('-')) counts.blocks++;
                      if (node.code.length === 3 && !node.code.includes('-')) counts.categories++;
                      if (node.children) {
                        const childCounts = countCodes(node.children);
                        counts.terminal += childCounts.terminal;
                        counts.blocks += childCounts.blocks;
                        counts.categories += childCounts.categories;
                      }
                    }
                    return counts;
                  };
                  
                  const filterCodes = (nodes: ICD10TreeNode[]): ICD10TreeNode[] => {
                    let result: ICD10TreeNode[] = [];
                    for (const node of nodes) {
                      if (filterMode === 'terminal' && node.is_terminal) {
                        result.push(node);
                      } else if (filterMode === 'blocks' && node.code.includes('-')) {
                        result.push(node);
                      } else if (filterMode === 'categories' && node.code.length === 3 && !node.code.includes('-')) {
                        result.push(node);
                      }
                      if (node.children) {
                        result = result.concat(filterCodes(node.children));
                      }
                    }
                    return result;
                  };
                  const filtered = filterCodes(chapterCodes);
                  const stats = countCodes(chapterCodes);
                  const isExpanded = chapterData[chapter.id]?.isExpanded || false;
                  const isLoading = chapterData[chapter.id]?.isLoading || false;
                  
                  return (
                    <div key={chapter.id} className="mb-1">
                      <div
                        className="flex items-center gap-2 py-2 px-2 rounded-md cursor-pointer hover:bg-muted transition-colors"
                        onClick={() => handleChapterToggle(chapter.id)}
                      >
                        {isLoading ? (
                          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                        ) : isExpanded ? (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        )}
                        <Badge variant="outline" className="font-mono text-xs">
                          {chapter.id}
                        </Badge>
                        <span className="text-xs md:text-sm truncate flex-1">
                          {chapter.name}
                        </span>
                        {/* Statistics badges when expanded */}
                        {isExpanded && chapterCodes.length > 0 && (
                          <div className="flex items-center gap-1 shrink-0">
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge variant="outline" className="text-[9px] px-1.5 py-0 h-4 gap-0.5 bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800">
                                  <FileCode className="h-2.5 w-2.5" />
                                  {stats.blocks}
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent side="top" className="text-xs">Blöcke</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge variant="outline" className="text-[9px] px-1.5 py-0 h-4 gap-0.5 bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800">
                                  <FileSpreadsheet className="h-2.5 w-2.5" />
                                  {stats.categories}
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent side="top" className="text-xs">Kategorien (3-stellig)</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge variant="outline" className="text-[9px] px-1.5 py-0 h-4 gap-0.5 bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800">
                                  <CheckCircle2 className="h-2.5 w-2.5" />
                                  {stats.terminal}
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent side="top" className="text-xs">Terminale Codes</TooltipContent>
                            </Tooltip>
                          </div>
                        )}
                      </div>
                      {isExpanded && (
                        <div className="ml-4 pl-2 border-l border-muted space-y-0.5">
                          {filtered.length === 0 ? (
                            <p className="text-xs text-muted-foreground py-2 px-2">
                              {chapterCodes.length === 0 
                                ? 'Lade Daten...'
                                : `Keine ${filterMode === 'terminal' ? 'terminalen Codes' : filterMode === 'blocks' ? 'Blöcke' : 'Kategorien'} geladen`}
                            </p>
                          ) : (
                            filtered.map((code) => (
                              <div
                                key={code.code}
                                className={cn(
                                  'flex items-center gap-1.5 py-1.5 px-2 rounded-md cursor-pointer transition-colors hover:bg-muted',
                                  selectedCode?.code === code.code && 'bg-primary/10 text-primary font-medium'
                                )}
                                onClick={() => handleCodeSelect(code)}
                              >
                                <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0">
                                  {code.code}
                                </Badge>
                                <span className="text-xs md:text-sm truncate flex-1">
                                  {code.title_short || code.title}
                                </span>
                                {filterMode === 'terminal' && (
                                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                                )}
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}
        </ScrollArea>
      </div>

      {/* Right Panel: Details - Desktop (hidden when collapsed) */}
      {!isMobile && !detailPanelCollapsed && (
        <div className="w-1/2 flex flex-col border-l animate-in slide-in-from-right-2 duration-300">
          {selectedCode ? (
            <ScrollArea className="flex-1 p-4">
              <DetailCard />
              <ICD10AnalysisPanel icdCode={selectedCode.code} icdTitle={selectedCode.title} />
            </ScrollArea>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center space-y-2">
                <Info className="h-12 w-12 mx-auto opacity-20" />
                <p>Wählen Sie einen ICD-10 Code aus</p>
                <p className="text-sm">um Details anzuzeigen</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Mobile Detail Drawer */}
      {isMobile && (
        <Drawer open={showDetailSheet} onOpenChange={setShowDetailSheet}>
          <DrawerContent className="max-h-[85vh]">
            <DrawerHeader className="pb-2">
              <div className="flex items-center justify-between">
                <DrawerTitle className="text-base">ICD-10 Details</DrawerTitle>
                <DrawerClose asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <X className="h-4 w-4" />
                  </Button>
                </DrawerClose>
              </div>
            </DrawerHeader>
            <ScrollArea className="flex-1 px-4" style={{ maxHeight: 'calc(85vh - 100px)' }}>
              {selectedCode && (
                <>
                  <DetailCard />
                  <ICD10AnalysisPanel icdCode={selectedCode.code} icdTitle={selectedCode.title} />
                </>
              )}
            </ScrollArea>
            <DrawerFooter className="pt-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => selectedCode && window.open(
                  `https://www.icd-code.de/suche/icd/code/${selectedCode.code}.html`,
                  '_blank'
                )}
              >
                <ExternalLink className="h-3.5 w-3.5 mr-2" />
                Im Browser öffnen
              </Button>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      )}
    </div>
  );
}
