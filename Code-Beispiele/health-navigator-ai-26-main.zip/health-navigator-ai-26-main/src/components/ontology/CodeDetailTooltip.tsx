import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Activity, 
  Stethoscope, 
  FileText, 
  FlaskConical, 
  Package, 
  Pill, 
  Loader2,
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';

export type CodeSystem = 'hpo' | 'snomed' | 'icd10gm' | 'loinc' | 'emdn' | 'medicine';

interface CodeDetails {
  code: string;
  system: CodeSystem;
  label?: string;
  label_de?: string;
  label_en?: string;
  definition?: string;
  definition_de?: string;
  synonyms?: string[];
  parent?: string;
  category?: string;
  url?: string;
}

interface CodeDetailTooltipProps {
  code: string;
  system: CodeSystem;
  children: React.ReactNode;
  showCopyButton?: boolean;
  className?: string;
}

const systemConfig: Record<CodeSystem, { 
  icon: React.ElementType; 
  color: string; 
  bgColor: string;
  label: string;
  urlTemplate?: string;
}> = {
  hpo: { 
    icon: Activity, 
    color: 'text-violet-600', 
    bgColor: 'bg-violet-50 dark:bg-violet-950/30',
    label: 'HPO',
    urlTemplate: 'https://hpo.jax.org/browse/term/{code}'
  },
  snomed: { 
    icon: Stethoscope, 
    color: 'text-blue-600', 
    bgColor: 'bg-blue-50 dark:bg-blue-950/30',
    label: 'SNOMED CT',
    urlTemplate: 'https://browser.ihtsdotools.org/?perspective=full&conceptId1={code}'
  },
  icd10gm: { 
    icon: FileText, 
    color: 'text-emerald-600', 
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/30',
    label: 'ICD-10-GM',
    urlTemplate: 'https://www.icd-code.de/icd/code/{code}.html'
  },
  loinc: { 
    icon: FlaskConical, 
    color: 'text-amber-600', 
    bgColor: 'bg-amber-50 dark:bg-amber-950/30',
    label: 'LOINC',
    urlTemplate: 'https://loinc.org/{code}'
  },
  emdn: { 
    icon: Package, 
    color: 'text-rose-600', 
    bgColor: 'bg-rose-50 dark:bg-rose-950/30',
    label: 'EMDN'
  },
  medicine: { 
    icon: Pill, 
    color: 'text-cyan-600', 
    bgColor: 'bg-cyan-50 dark:bg-cyan-950/30',
    label: 'Arzneimittel'
  },
};

// Cache for code details
const detailsCache = new Map<string, { details: CodeDetails; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

export function CodeDetailTooltip({ 
  code, 
  system, 
  children, 
  showCopyButton = true,
  className 
}: CodeDetailTooltipProps) {
  const { i18n } = useTranslation();
  const isGerman = i18n.language === 'de';
  
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [details, setDetails] = useState<CodeDetails | null>(null);
  const [copied, setCopied] = useState(false);

  const config = systemConfig[system];
  const Icon = config.icon;

  useEffect(() => {
    if (isOpen && !details) {
      loadDetails();
    }
  }, [isOpen]);

  const loadDetails = async () => {
    const cacheKey = `${system}:${code}`;
    const cached = detailsCache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      setDetails(cached.details);
      return;
    }

    setIsLoading(true);
    try {
      let fetchedDetails: CodeDetails = { code, system };

      switch (system) {
        case 'hpo': {
          const { data } = await supabase
            .from('hpo_codes')
            .select('hpo_code, label, labels, definitions, explanations, synonyms')
            .eq('hpo_code', code)
            .maybeSingle();
          
          if (data) {
            const labels = data.labels as Record<string, string> | null;
            const definitions = data.definitions as Record<string, string> | null;
            const explanations = data.explanations as Record<string, string> | null;
            fetchedDetails = {
              ...fetchedDetails,
              label_de: labels?.de || data.label,
              label_en: labels?.en || data.label,
              definition_de: definitions?.de || explanations?.de,
              definition: definitions?.en || explanations?.en,
              synonyms: data.synonyms as string[] | undefined,
            };
          }
          break;
        }
        
        case 'snomed': {
          const { data } = await supabase
            .from('snomed_codes')
            .select('sctid, fsn, pt, labels, definitions, explanations')
            .eq('sctid', code)
            .maybeSingle();
          
          if (data) {
            const labels = data.labels as Record<string, string> | null;
            const definitions = data.definitions as Record<string, string> | null;
            const explanations = data.explanations as Record<string, string> | null;
            fetchedDetails = {
              ...fetchedDetails,
              label_de: labels?.de || data.pt,
              label_en: labels?.en || data.pt,
              definition_de: definitions?.de || explanations?.de,
              definition: definitions?.en || explanations?.en,
            };
          }
          break;
        }
        
        case 'icd10gm': {
          const { data } = await supabase
            .from('icd10gm_codes')
            .select('*')
            .eq('code', code)
            .maybeSingle();
          
          if (data) {
            fetchedDetails = {
              ...fetchedDetails,
              label_de: data.title,
              label_en: data.title_short || data.title,
              category: data.chapter,
              parent: data.parent_code || undefined,
            };
          }
          break;
        }
        
        case 'loinc': {
          const { data } = await supabase
            .from('loinc_codes')
            .select('*')
            .eq('loinc_num', code)
            .maybeSingle();
          
          if (data) {
            fetchedDetails = {
              ...fetchedDetails,
              label_de: data.long_common_name || data.component,
              label_en: data.long_common_name || data.component,
              definition: `${data.component} - ${data.property || ''} in ${data.system || 'unspecified'}`,
              category: data.class || undefined,
              url: `https://loinc.org/${code}`,
            };
            // Add UCUM units as additional info
            if (data.example_ucum_units) {
              fetchedDetails.definition += ` (${data.example_ucum_units})`;
            }
          }
          break;
        }
        
        case 'emdn': {
          const { data } = await supabase
            .from('emdn_codes')
            .select('*')
            .eq('code', code)
            .maybeSingle();
          
          if (data) {
            fetchedDetails = {
              ...fetchedDetails,
              label_de: data.name_de || data.name_en,
              label_en: data.name_en,
              definition: data.description || undefined,
              category: data.mdr_class || undefined,
              parent: data.parent_code || undefined,
            };
          }
          break;
        }
        
        default:
          // For systems without local data, just use the code
          fetchedDetails = { code, system, label: code };
      }

      setDetails(fetchedDetails);
      detailsCache.set(cacheKey, { details: fetchedDetails, timestamp: Date.now() });
    } catch (error) {
      console.error('Error loading code details:', error);
      setDetails({ code, system });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getExternalUrl = () => {
    if (!config.urlTemplate) return null;
    return config.urlTemplate.replace('{code}', code);
  };

  const getDisplayLabel = () => {
    if (!details) return code;
    return isGerman 
      ? (details.label_de || details.label_en || details.label || code)
      : (details.label_en || details.label_de || details.label || code);
  };

  const getDisplayDefinition = () => {
    if (!details) return null;
    return isGerman 
      ? (details.definition_de || details.definition)
      : (details.definition || details.definition_de);
  };

  const externalUrl = getExternalUrl();

  return (
    <HoverCard open={isOpen} onOpenChange={setIsOpen} openDelay={300} closeDelay={100}>
      <HoverCardTrigger asChild>
        <span className={cn("cursor-help", className)}>
          {children}
        </span>
      </HoverCardTrigger>
      <HoverCardContent 
        className="w-80 p-0" 
        align="start"
        side="top"
        sideOffset={5}
      >
        {/* Header */}
        <div className={cn("flex items-center gap-2 p-3 rounded-t-md", config.bgColor)}>
          <Icon className={cn("h-4 w-4", config.color)} />
          <span className={cn("font-medium text-sm", config.color)}>
            {config.label}
          </span>
          <Badge variant="outline" className="ml-auto font-mono text-xs">
            {code}
          </Badge>
          {showCopyButton && (
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={handleCopy}
            >
              {copied ? (
                <Check className="h-3 w-3 text-primary" />
              ) : (
                <Copy className="h-3 w-3" />
              )}
            </Button>
          )}
        </div>

        {/* Content */}
        <div className="p-3 space-y-2">
          {isLoading ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              {/* Label */}
              <div>
                <p className="font-medium text-sm">{getDisplayLabel()}</p>
                {details?.label_en && isGerman && details.label_en !== details.label_de && (
                  <p className="text-xs text-muted-foreground italic">
                    {details.label_en}
                  </p>
                )}
              </div>

              {/* Definition */}
              {getDisplayDefinition() && (
                <>
                  <Separator />
                  <p className="text-xs text-muted-foreground line-clamp-4">
                    {getDisplayDefinition()}
                  </p>
                </>
              )}

              {/* Synonyms */}
              {details?.synonyms && details.synonyms.length > 0 && (
                <>
                  <Separator />
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-1">
                      {isGerman ? 'Synonyme' : 'Synonyms'}
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {details.synonyms.slice(0, 4).map((syn, idx) => (
                        <Badge key={idx} variant="secondary" className="text-[10px]">
                          {syn}
                        </Badge>
                      ))}
                      {details.synonyms.length > 4 && (
                        <Badge variant="outline" className="text-[10px]">
                          +{details.synonyms.length - 4}
                        </Badge>
                      )}
                    </div>
                  </div>
                </>
              )}

              {/* Category/Parent */}
              {(details?.category || details?.parent) && (
                <>
                  <Separator />
                  <div className="flex gap-2 text-xs text-muted-foreground">
                    {details.category && (
                      <span>
                        {isGerman ? 'Kategorie' : 'Category'}: {details.category}
                      </span>
                    )}
                    {details.parent && (
                      <span>
                        {isGerman ? 'Übergeordnet' : 'Parent'}: {details.parent}
                      </span>
                    )}
                  </div>
                </>
              )}

              {/* External link */}
              {externalUrl && (
                <a 
                  href={externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-xs text-primary hover:underline pt-1"
                >
                  <ExternalLink className="h-3 w-3" />
                  {isGerman ? 'Im Browser öffnen' : 'Open in browser'}
                </a>
              )}
            </>
          )}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
