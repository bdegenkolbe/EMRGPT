import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { supabase } from '@/integrations/supabase/client';
import { useProfile } from '@/hooks/useProfile';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Sparkles,
  RefreshCw,
  Save,
  Languages,
  FileText,
  Stethoscope,
  Pill,
  AlertCircle,
  Link2,
  Loader2,
  Check,
  Bold,
  Italic,
  List,
  ListOrdered,
  ExternalLink,
  Pencil,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ContentBlock {
  explanation: string;
  symptoms: string;
  therapy: string;
  notes: string;
}

interface HpoMapping {
  code: string;
  label_de: string;
  label_en: string;
  relation: string;
}

interface SnomedMapping {
  sctid: string;
  pt_de: string;
  pt_en: string;
  relation: string;
}

interface SymptomMapping {
  symptom: string;
  hpo_code?: string;
  snomed_code?: string;
}

interface Analysis {
  id: string;
  icd_code: string;
  content: Record<string, ContentBlock>;
  source_language: string;
  hpo_mappings: HpoMapping[];
  snomed_mappings: SnomedMapping[];
  symptom_mappings: SymptomMapping[];
  generated_at: string;
  updated_at: string;
}

interface ICD10AnalysisPanelProps {
  icdCode: string;
  icdTitle: string;
}

const LANGUAGES = [
  { code: 'de', label: 'Deutsch' },
  { code: 'en', label: 'English' },
  { code: 'fr', label: 'Français' },
  { code: 'es', label: 'Español' },
  { code: 'it', label: 'Italiano' },
];

// Content View Component - displays HTML content as read-only
function ContentView({ content }: { content: string }) {
  // Convert asterisk-based lists to proper HTML if needed
  const formatContent = (text: string) => {
    if (!text) return '';
    // If content starts with asterisks, convert to bullet list
    if (text.includes('* ') && !text.includes('<ul>') && !text.includes('<li>')) {
      const lines = text.split('\n').filter(l => l.trim());
      const listItems = lines
        .map(line => {
          const trimmed = line.trim();
          if (trimmed.startsWith('* ')) {
            return `<li>${trimmed.substring(2)}</li>`;
          }
          return `<p>${trimmed}</p>`;
        })
        .join('');
      // Wrap consecutive li elements in ul
      return listItems.replace(/(<li>.*?<\/li>)+/g, '<ul>$&</ul>');
    }
    return text;
  };

  return (
    <div 
      className="prose prose-sm max-w-none dark:prose-invert p-3 bg-muted/20 rounded-md min-h-[80px]"
      dangerouslySetInnerHTML={{ __html: formatContent(content) || '<p class="text-muted-foreground italic">Kein Inhalt</p>' }}
    />
  );
}

// Rich Text Editor Component
function RichTextEditor({
  content,
  onChange,
  placeholder,
}: {
  content: string;
  onChange: (content: string) => void;
  placeholder?: string;
}) {
  // Convert asterisk-based content to HTML for editor
  const formatForEditor = (text: string) => {
    if (!text) return '';
    if (text.includes('* ') && !text.includes('<ul>') && !text.includes('<li>')) {
      const lines = text.split('\n').filter(l => l.trim());
      const listItems = lines
        .map(line => {
          const trimmed = line.trim();
          if (trimmed.startsWith('* ')) {
            return `<li><p>${trimmed.substring(2)}</p></li>`;
          }
          return `<p>${trimmed}</p>`;
        })
        .join('');
      return listItems.replace(/(<li><p>.*?<\/p><\/li>)+/g, '<ul>$&</ul>');
    }
    return text;
  };

  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: placeholder || 'Inhalt eingeben...',
      }),
    ],
    content: formatForEditor(content),
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
  });

  useEffect(() => {
    if (editor) {
      const formatted = formatForEditor(content);
      if (formatted !== editor.getHTML()) {
        editor.commands.setContent(formatted);
      }
    }
  }, [content, editor]);

  if (!editor) return null;

  return (
    <div className="border rounded-md border-primary/30">
      <div className="flex items-center gap-1 p-2 border-b bg-muted/30">
        <Button
          variant="ghost"
          size="sm"
          className={cn("h-7 w-7 p-0", editor.isActive('bold') && "bg-primary/20")}
          onClick={() => editor.chain().focus().toggleBold().run()}
        >
          <Bold className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={cn("h-7 w-7 p-0", editor.isActive('italic') && "bg-primary/20")}
          onClick={() => editor.chain().focus().toggleItalic().run()}
        >
          <Italic className="h-4 w-4" />
        </Button>
        <Separator orientation="vertical" className="h-5 mx-1" />
        <Button
          variant="ghost"
          size="sm"
          className={cn("h-7 w-7 p-0", editor.isActive('bulletList') && "bg-primary/20")}
          onClick={() => editor.chain().focus().toggleBulletList().run()}
        >
          <List className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={cn("h-7 w-7 p-0", editor.isActive('orderedList') && "bg-primary/20")}
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
        >
          <ListOrdered className="h-4 w-4" />
        </Button>
      </div>
      <EditorContent
        editor={editor}
        className={cn(
          'prose prose-sm max-w-none p-3',
          'dark:prose-invert',
          '[&_.ProseMirror]:outline-none [&_.ProseMirror]:min-h-[100px]',
          '[&_.ProseMirror_p.is-editor-empty:first-child::before]:text-muted-foreground',
          '[&_.ProseMirror_p.is-editor-empty:first-child::before]:content-[attr(data-placeholder)]',
          '[&_.ProseMirror_p.is-editor-empty:first-child::before]:float-left',
          '[&_.ProseMirror_p.is-editor-empty:first-child::before]:h-0',
          '[&_.ProseMirror_p.is-editor-empty:first-child::before]:pointer-events-none'
        )}
      />
    </div>
  );
}

export function ICD10AnalysisPanel({ icdCode, icdTitle }: ICD10AnalysisPanelProps) {
  const { toast } = useToast();
  const { profile } = useProfile();
  const navigate = useNavigate();
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<'explanation' | 'symptoms' | 'therapy' | 'notes'>('explanation');
  const [selectedLanguage, setSelectedLanguage] = useState(profile?.language || 'de');
  const [editedContent, setEditedContent] = useState<ContentBlock | null>(null);
  const [originalContent, setOriginalContent] = useState<ContentBlock | null>(null);
  const [existingMappingsOnly, setExistingMappingsOnly] = useState(false); // True when only DB mappings exist (no full analysis)

  // Navigation helpers for ontology links
  const navigateToHpo = (code: string) => {
    // Navigate to HPO tab with search query and back reference to ICD-10
    navigate(`/ontology?tab=hpo&search=${encodeURIComponent(code)}&backTab=icd10&backCode=${encodeURIComponent(icdCode)}`);
  };

  const navigateToSnomed = (sctid: string) => {
    // Navigate to SNOMED tab with search query and back reference to ICD-10
    navigate(`/ontology?tab=snomed&search=${encodeURIComponent(sctid)}&backTab=icd10&backCode=${encodeURIComponent(icdCode)}`);
  };

  // Fetch existing analysis and auto-translate if needed
  // Token-saving optimization: Check ontology_mappings first before triggering AI
  const fetchAnalysis = useCallback(async () => {
    setIsLoading(true);
    setExistingMappingsOnly(false);
    
    try {
      // Step 1: Check if full analysis exists
      const { data, error } = await supabase.functions.invoke('icd10-analyze', {
        body: { action: 'get', icd_code: icdCode },
      });

      if (error) throw error;
      
      if (data.analysis) {
        // Full analysis exists - use it
        setAnalysis(data.analysis);
        const lang = selectedLanguage;
        
        // Check if content exists in user's language
        if (data.analysis.content[lang]) {
          setEditedContent(data.analysis.content[lang]);
          setOriginalContent(data.analysis.content[lang]);
        } else if (data.analysis.content[data.analysis.source_language]) {
          // Content exists but not in user's language - auto-translate
          console.log(`Translating from ${data.analysis.source_language} to ${lang}...`);
          setIsTranslating(true);
          
          try {
            const { data: translateData, error: translateError } = await supabase.functions.invoke('icd10-analyze', {
              body: {
                action: 'translate',
                icd_code: icdCode,
                source_language: data.analysis.source_language,
                target_language: lang,
              },
            });

            if (translateError) throw translateError;

            if (translateData.analysis) {
              setAnalysis(translateData.analysis);
              setEditedContent(translateData.analysis.content[lang]);
              setOriginalContent(translateData.analysis.content[lang]);
              toast({
                title: 'Übersetzung abgeschlossen',
                description: `Analyse wurde nach ${lang === 'de' ? 'Deutsch' : lang === 'en' ? 'Englisch' : lang} übersetzt`,
              });
            }
          } catch (translateErr) {
            console.error('Auto-translation error:', translateErr);
            setEditedContent(data.analysis.content[data.analysis.source_language]);
            setOriginalContent(data.analysis.content[data.analysis.source_language]);
            setSelectedLanguage(data.analysis.source_language);
            toast({
              title: 'Übersetzung fehlgeschlagen',
              description: 'Zeige Originalsprache an',
              variant: 'destructive',
            });
          } finally {
            setIsTranslating(false);
          }
        } else {
          setEditedContent(null);
          setOriginalContent(null);
        }
      } else {
        // No full analysis exists - check ontology_mappings for existing mappings (token-saving)
        console.log('No analysis found, checking ontology_mappings for existing mappings...');
        
        const [hpoMappings, snomedMappings] = await Promise.all([
          supabase
            .from('ontology_mappings')
            .select('target_code, target_label, mapping_type, confidence, notes')
            .eq('source_code', icdCode)
            .eq('source_system', 'ICD10GM')
            .eq('target_system', 'HPO'),
          supabase
            .from('ontology_mappings')
            .select('target_code, target_label, mapping_type, confidence, notes')
            .eq('source_code', icdCode)
            .eq('source_system', 'ICD10GM')
            .eq('target_system', 'SNOMED'),
        ]);
        
        const hasExistingMappings = 
          (hpoMappings.data && hpoMappings.data.length > 0) ||
          (snomedMappings.data && snomedMappings.data.length > 0);
        
        if (hasExistingMappings) {
          // Convert DB mappings to analysis format (partial analysis from mappings only)
          const partialAnalysis: Analysis = {
            id: '',
            icd_code: icdCode,
            content: {},
            source_language: selectedLanguage,
            hpo_mappings: (hpoMappings.data || []).map(m => ({
              code: m.target_code,
              label_de: m.target_label,
              label_en: m.target_label,
              relation: m.mapping_type || 'related',
            })),
            snomed_mappings: (snomedMappings.data || []).map(m => ({
              sctid: m.target_code,
              pt_de: m.target_label,
              pt_en: m.target_label,
              relation: m.mapping_type || 'related',
            })),
            symptom_mappings: [],
            generated_at: '',
            updated_at: '',
          };
          
          setAnalysis(partialAnalysis);
          setExistingMappingsOnly(true);
          setEditedContent(null);
          setOriginalContent(null);
          
          console.log(`Loaded ${partialAnalysis.hpo_mappings.length} HPO + ${partialAnalysis.snomed_mappings.length} SNOMED mappings from DB (no AI needed)`);
        } else {
          // No analysis and no mappings - user needs to generate
          setAnalysis(null);
          setEditedContent(null);
          setOriginalContent(null);
        }
      }
    } catch (err) {
      console.error('Fetch analysis error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [icdCode, selectedLanguage, toast]);

  useEffect(() => {
    fetchAnalysis();
  }, [fetchAnalysis]);

  // Handle language change - auto-translate if content not available
  useEffect(() => {
    const handleLanguageChange = async () => {
      if (!analysis) return;
      
      if (analysis.content[selectedLanguage]) {
        // Content available in selected language
        setEditedContent(analysis.content[selectedLanguage]);
        setOriginalContent(analysis.content[selectedLanguage]);
        setIsEditing(false);
      } else if (analysis.source_language && analysis.content[analysis.source_language]) {
        // Need to translate
        setIsTranslating(true);
        try {
          const { data, error } = await supabase.functions.invoke('icd10-analyze', {
            body: {
              action: 'translate',
              icd_code: icdCode,
              source_language: analysis.source_language,
              target_language: selectedLanguage,
            },
          });

          if (error) throw error;

          if (data.analysis) {
            setAnalysis(data.analysis);
            setEditedContent(data.analysis.content[selectedLanguage]);
            setOriginalContent(data.analysis.content[selectedLanguage]);
            toast({
              title: 'Übersetzung abgeschlossen',
              description: `Analyse nach ${selectedLanguage === 'de' ? 'Deutsch' : selectedLanguage === 'en' ? 'Englisch' : selectedLanguage} übersetzt`,
            });
          }
        } catch (err) {
          console.error('Translation error:', err);
          toast({
            title: 'Übersetzung fehlgeschlagen',
            description: 'Bitte versuchen Sie es erneut',
            variant: 'destructive',
          });
        } finally {
          setIsTranslating(false);
        }
        setIsEditing(false);
      }
    };

    handleLanguageChange();
  }, [selectedLanguage, analysis?.source_language, icdCode, toast]);

  // Generate new analysis
  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke('icd10-analyze', {
        body: {
          action: 'generate',
          icd_code: icdCode,
          icd_title: icdTitle,
          source_language: selectedLanguage,
        },
      });

      if (error) throw error;

      if (data.error) {
        toast({
          title: 'Fehler',
          description: data.error,
          variant: 'destructive',
        });
        return;
      }

      setAnalysis(data.analysis);
      setEditedContent(data.analysis.content[selectedLanguage]);
      setOriginalContent(data.analysis.content[selectedLanguage]);
      setIsEditing(false);

      toast({
        title: 'Analyse erstellt',
        description: `KI-Analyse für ${icdCode} wurde generiert`,
      });
    } catch (err: any) {
      console.error('Generate error:', err);
      toast({
        title: 'Fehler',
        description: err.message || 'Analyse konnte nicht erstellt werden',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Translate to another language
  const handleTranslate = async (targetLang: string) => {
    if (!analysis) return;

    setIsTranslating(true);
    try {
      const { data, error } = await supabase.functions.invoke('icd10-analyze', {
        body: {
          action: 'translate',
          icd_code: icdCode,
          icd_title: icdTitle,
          source_language: analysis.source_language,
          target_language: targetLang,
        },
      });

      if (error) throw error;

      setAnalysis(data.analysis);
      setSelectedLanguage(targetLang);
      setEditedContent(data.analysis.content[targetLang]);

      toast({
        title: 'Übersetzung erstellt',
        description: `Inhalt wurde nach ${LANGUAGES.find(l => l.code === targetLang)?.label} übersetzt`,
      });
    } catch (err: any) {
      console.error('Translate error:', err);
      toast({
        title: 'Fehler',
        description: err.message || 'Übersetzung fehlgeschlagen',
        variant: 'destructive',
      });
    } finally {
      setIsTranslating(false);
    }
  };

  // Save changes
  const handleSave = async () => {
    if (!analysis || !editedContent) return;

    setIsSaving(true);
    try {
      const updatedContent = {
        ...analysis.content,
        [selectedLanguage]: editedContent,
      };

      // Use type assertion to bypass strict Json typing
      const { error } = await (supabase
        .from('icd10gm_analyses') as any)
        .update({ content: updatedContent })
        .eq('icd_code', icdCode);

      if (error) throw error;

      setAnalysis({ ...analysis, content: updatedContent });
      setOriginalContent(editedContent);
      setIsEditing(false);

      toast({
        title: 'Gespeichert',
        description: 'Änderungen wurden gespeichert',
      });
    } catch (err: any) {
      console.error('Save error:', err);
      toast({
        title: 'Fehler',
        description: err.message || 'Speichern fehlgeschlagen',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Update content field
  const updateField = (field: keyof ContentBlock, value: string) => {
    if (!editedContent) return;
    setEditedContent({ ...editedContent, [field]: value });
  };

  // Start editing
  const startEditing = () => {
    setOriginalContent(editedContent);
    setIsEditing(true);
  };

  // Cancel editing
  const cancelEditing = () => {
    setEditedContent(originalContent);
    setIsEditing(false);
  };

  const availableLanguages = analysis
    ? Object.keys(analysis.content)
    : [selectedLanguage];

  const missingLanguages = LANGUAGES.filter(
    (l) => !availableLanguages.includes(l.code)
  );

  if (isLoading) {
    return (
      <Card className="mt-4">
        <CardHeader className="pb-3">
          <Skeleton className="h-6 w-40" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
        </CardContent>
      </Card>
    );
  }

  // Show "generate analysis" prompt when no analysis and no mappings exist
  if (!analysis) {
    return (
      <Card className="mt-4">
        <CardContent className="py-8 text-center">
          <Sparkles className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="font-semibold mb-2">Keine KI-Analyse vorhanden</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Erstelle eine detaillierte klinische Analyse mit HPO/SNOMED Mapping
          </p>
          <Button onClick={handleGenerate} disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generiere...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                KI-Analyse starten
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  // Show info banner when only DB mappings exist (no full AI analysis yet)
  const MappingsOnlyBanner = existingMappingsOnly ? (
    <div className="mb-4 p-3 bg-muted/50 border rounded-lg">
      <div className="flex items-start gap-3">
        <Link2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
        <div className="flex-1">
          <p className="text-sm font-medium">Nur gespeicherte Mappings</p>
          <p className="text-xs text-muted-foreground mt-1">
            Diese Zuordnungen wurden aus der Datenbank geladen. Für eine vollständige Analyse mit Erklärung, Symptomen und Therapie-Hinweisen können Sie eine KI-Analyse generieren.
          </p>
          <Button 
            size="sm" 
            variant="outline" 
            className="mt-2"
            onClick={handleGenerate} 
            disabled={isGenerating}
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                Generiere...
              </>
            ) : (
              <>
                <Sparkles className="h-3 w-3 mr-1" />
                Vollständige KI-Analyse erstellen
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  ) : null;

  return (
    <Card className="mt-4">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            KI-Analyse
          </CardTitle>
          <div className="flex items-center gap-2">
            {/* Language selector */}
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-[120px] h-8 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableLanguages.map((code) => (
                  <SelectItem key={code} value={code}>
                    {LANGUAGES.find((l) => l.code === code)?.label || code}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Translate button */}
            {missingLanguages.length > 0 && (
              <Select
                value=""
                onValueChange={handleTranslate}
                disabled={isTranslating}
              >
                <SelectTrigger className="w-8 h-8 p-0">
                  {isTranslating ? (
                    <Loader2 className="h-4 w-4 animate-spin mx-auto" />
                  ) : (
                    <Languages className="h-4 w-4 mx-auto" />
                  )}
                </SelectTrigger>
                <SelectContent>
                  {missingLanguages.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      Übersetzen: {lang.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {/* Regenerate button */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={handleGenerate}
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>KI-Analyse wiederholen</TooltipContent>
            </Tooltip>

            {/* Edit/Cancel/Save buttons */}
            {!isEditing ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={startEditing}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Bearbeiten</TooltipContent>
              </Tooltip>
            ) : (
              <div className="flex items-center gap-1.5">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8"
                  onClick={cancelEditing}
                >
                  <X className="h-4 w-4 mr-1" />
                  Abbrechen
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  className="h-8"
                  onClick={handleSave}
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-1" />
                  ) : (
                    <Save className="h-4 w-4 mr-1" />
                  )}
                  Speichern
                </Button>
              </div>
            )}
          </div>
        </div>
        {analysis.generated_at && (
          <p className="text-xs text-muted-foreground">
            Generiert: {new Date(analysis.generated_at).toLocaleDateString('de-DE')}
          </p>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Token-saving optimization: Show banner when only DB mappings exist */}
        {MappingsOnlyBanner}
        
        {/* Content Tabs - only show when full analysis exists */}
        {!existingMappingsOnly && (
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="explanation" className="text-xs">
              <FileText className="h-3.5 w-3.5 mr-1" />
              Erklärung
            </TabsTrigger>
            <TabsTrigger value="symptoms" className="text-xs">
              <Stethoscope className="h-3.5 w-3.5 mr-1" />
              Symptome
            </TabsTrigger>
            <TabsTrigger value="therapy" className="text-xs">
              <Pill className="h-3.5 w-3.5 mr-1" />
              Therapie
            </TabsTrigger>
            <TabsTrigger value="notes" className="text-xs">
              <AlertCircle className="h-3.5 w-3.5 mr-1" />
              Hinweise
            </TabsTrigger>
          </TabsList>

          {editedContent && (
            <>
              <TabsContent value="explanation" className="mt-3">
                {isEditing ? (
                  <RichTextEditor
                    content={editedContent.explanation}
                    onChange={(v) => updateField('explanation', v)}
                    placeholder="Klinische Erklärung..."
                  />
                ) : (
                  <ContentView content={editedContent.explanation} />
                )}
              </TabsContent>
              <TabsContent value="symptoms" className="mt-3">
                {isEditing ? (
                  <RichTextEditor
                    content={editedContent.symptoms}
                    onChange={(v) => updateField('symptoms', v)}
                    placeholder="Typische Symptome..."
                  />
                ) : (
                  <ContentView content={editedContent.symptoms} />
                )}
              </TabsContent>
              <TabsContent value="therapy" className="mt-3">
                {isEditing ? (
                  <RichTextEditor
                    content={editedContent.therapy}
                    onChange={(v) => updateField('therapy', v)}
                    placeholder="Therapie und Behandlung..."
                  />
                ) : (
                  <ContentView content={editedContent.therapy} />
                )}
              </TabsContent>
              <TabsContent value="notes" className="mt-3">
                {isEditing ? (
                  <RichTextEditor
                    content={editedContent.notes}
                    onChange={(v) => updateField('notes', v)}
                    placeholder="Hinweise und Anmerkungen..."
                  />
                ) : (
                  <ContentView content={editedContent.notes} />
                )}
              </TabsContent>
            </>
          )}
        </Tabs>
        )}

        {/* Mappings Section */}
        <Separator />

        <div className="space-y-3">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <Link2 className="h-4 w-4" />
            Ontologie-Mappings
          </h4>

          {/* HPO Mappings */}
          {analysis.hpo_mappings?.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-1.5">HPO Codes</p>
              <div className="flex flex-wrap gap-1.5">
                {analysis.hpo_mappings.map((m, i) => (
                  <Tooltip key={i}>
                    <TooltipTrigger asChild>
                      <Badge 
                        variant="outline" 
                        className="text-xs font-mono cursor-pointer hover:bg-primary/10 hover:border-primary/50 transition-colors group"
                        onClick={() => navigateToHpo(m.code)}
                      >
                        {m.code}
                        <ExternalLink className="h-2.5 w-2.5 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="font-medium">{m.label_de}</p>
                      <p className="text-xs text-muted-foreground">{m.label_en}</p>
                      <p className="text-xs">Relation: {m.relation}</p>
                      <p className="text-xs text-primary mt-1">Klicken zum Öffnen im HPO-Browser</p>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>
          )}

          {/* SNOMED Mappings */}
          {analysis.snomed_mappings?.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-1.5">SNOMED CT</p>
              <div className="flex flex-wrap gap-1.5">
                {analysis.snomed_mappings.map((m, i) => (
                  <Tooltip key={i}>
                    <TooltipTrigger asChild>
                      <Badge 
                        variant="secondary" 
                        className="text-xs font-mono cursor-pointer hover:bg-primary/10 hover:border-primary/50 transition-colors group"
                        onClick={() => navigateToSnomed(m.sctid)}
                      >
                        {m.sctid}
                        <ExternalLink className="h-2.5 w-2.5 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="font-medium">{m.pt_de}</p>
                      <p className="text-xs text-muted-foreground">{m.pt_en}</p>
                      <p className="text-xs">Relation: {m.relation}</p>
                      <p className="text-xs text-primary mt-1">Klicken zum Öffnen im SNOMED-Browser</p>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>
          )}

          {/* Symptom Mappings */}
          {analysis.symptom_mappings?.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-1.5">Symptome mit Codes</p>
              <ScrollArea className="max-h-32">
                <div className="space-y-1">
                  {analysis.symptom_mappings.map((m, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <span>{m.symptom}</span>
                      {m.hpo_code && (
                        <Badge 
                          variant="outline" 
                          className="text-[10px] font-mono cursor-pointer hover:bg-primary/10"
                          onClick={() => navigateToHpo(m.hpo_code!)}
                        >
                          {m.hpo_code}
                        </Badge>
                      )}
                      {m.snomed_code && (
                        <Badge 
                          variant="secondary" 
                          className="text-[10px] font-mono cursor-pointer hover:bg-primary/10"
                          onClick={() => navigateToSnomed(m.snomed_code!)}
                        >
                          {m.snomed_code}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
