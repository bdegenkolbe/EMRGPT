import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Loader2, Database, CheckCircle2 } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

export type OntologySource = 'hpo' | 'snomed' | 'icd10gm' | 'icd11' | 'orphanet' | 'loinc' | 'emdn' | 'umdns';

interface OntologyStats {
  totalCodes: number;
  syncStatus: 'pending' | 'running' | 'paused' | 'completed' | 'error' | 'unknown';
  syncedCount?: number;
  totalAvailable?: number;
  lastSync?: string;
}

interface OntologyStatsBarProps {
  source: OntologySource;
  className?: string;
  showLabel?: boolean;
}

const SOURCE_CONFIG: Record<OntologySource, { table: string; countColumn: string; label: string }> = {
  hpo: { table: 'hpo_codes', countColumn: 'hpo_code', label: 'HPO' },
  snomed: { table: 'snomed_codes', countColumn: 'sctid', label: 'SNOMED' },
  icd10gm: { table: 'icd10gm_codes', countColumn: 'code', label: 'ICD-10-GM' },
  icd11: { table: 'icd11_codes', countColumn: 'code', label: 'ICD-11' },
  orphanet: { table: 'orphanet_codes', countColumn: 'orpha_code', label: 'Orphanet' },
  loinc: { table: 'loinc_codes', countColumn: 'loinc_num', label: 'LOINC' },
  emdn: { table: 'emdn_codes', countColumn: 'code', label: 'EMDN' },
  umdns: { table: 'umdns_codes', countColumn: 'code', label: 'UMDNS' },
};

// Map source name to sync_status source_name
const SYNC_SOURCE_MAP: Partial<Record<OntologySource, string>> = {
  hpo: 'hpo',
  snomed: 'snomed',
  orphanet: 'orphanet',
  icd11: 'icd11',
  // icd10gm uses file upload mechanism, not sync_status
};

export function OntologyStatsBar({ source, className, showLabel = true }: OntologyStatsBarProps) {
  const [stats, setStats] = useState<OntologyStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const fetchStats = async () => {
      const config = SOURCE_CONFIG[source];
      if (!config) {
        setIsLoading(false);
        return;
      }

      try {
        // Fetch total count from the table using direct query based on source
        let count = 0;
        
        // Type-safe queries for each table
        if (source === 'hpo') {
          const result = await supabase.from('hpo_codes').select('hpo_code', { count: 'exact', head: true });
          count = result.count || 0;
        } else if (source === 'snomed') {
          const result = await supabase.from('snomed_codes').select('sctid', { count: 'exact', head: true });
          count = result.count || 0;
        } else if (source === 'icd10gm') {
          const result = await supabase.from('icd10gm_codes').select('code', { count: 'exact', head: true });
          count = result.count || 0;
        } else if (source === 'icd11') {
          const result = await supabase.from('icd11_codes').select('code', { count: 'exact', head: true });
          count = result.count || 0;
        } else if (source === 'orphanet') {
          const result = await supabase.from('orphanet_codes').select('orpha_code', { count: 'exact', head: true });
          count = result.count || 0;
        } else if (source === 'loinc') {
          const result = await supabase.from('loinc_codes').select('loinc_num', { count: 'exact', head: true });
          count = result.count || 0;
        } else if (source === 'emdn') {
          const result = await supabase.from('emdn_codes').select('code', { count: 'exact', head: true });
          count = result.count || 0;
        } else if (source === 'umdns') {
          const result = await supabase.from('umdns_codes').select('code', { count: 'exact', head: true });
          count = result.count || 0;
        }

        // Fetch sync status if available
        const syncSourceName = SYNC_SOURCE_MAP[source];
        let syncStatus: OntologyStats['syncStatus'] = 'unknown';
        let syncedCount: number | undefined;
        let totalAvailable: number | undefined;

        if (syncSourceName) {
          const { data: syncData } = await supabase
            .from('sync_status')
            .select('status, total_synced, total_available, completed_at')
            .eq('source_name', syncSourceName)
            .maybeSingle();

          if (syncData) {
            syncStatus = (syncData.status as OntologyStats['syncStatus']) || 'unknown';
            syncedCount = syncData.total_synced || undefined;
            totalAvailable = syncData.total_available || undefined;
          }
        } else {
          // For sources without sync_status, mark as completed if they have data
          syncStatus = (count && count > 0) ? 'completed' : 'pending';
        }

        if (mounted) {
          setStats({
            totalCodes: count || 0,
            syncStatus,
            syncedCount,
            totalAvailable,
          });
        }
      } catch (err) {
        console.error(`Error fetching stats for ${source}:`, err);
        if (mounted) {
          setStats({ totalCodes: 0, syncStatus: 'error' });
        }
      } finally {
        if (mounted) setIsLoading(false);
      }
    };

    fetchStats();

    // Refresh every 10 seconds if syncing
    const interval = setInterval(() => {
      if (stats?.syncStatus === 'running') {
        fetchStats();
      }
    }, 10000);

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [source, stats?.syncStatus]);

  const config = SOURCE_CONFIG[source];

  if (isLoading) {
    return (
      <div className={cn("flex items-center gap-1.5 text-muted-foreground", className)}>
        <Loader2 className="h-3 w-3 animate-spin" />
        <span className="text-xs">Lade...</span>
      </div>
    );
  }

  if (!stats) return null;

  const getStatusColor = () => {
    switch (stats.syncStatus) {
      case 'completed': return 'text-emerald-600 dark:text-emerald-400';
      case 'running': return 'text-blue-600 dark:text-blue-400';
      case 'paused': return 'text-amber-600 dark:text-amber-400';
      case 'error': return 'text-red-600 dark:text-red-400';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = () => {
    switch (stats.syncStatus) {
      case 'completed': return <CheckCircle2 className="h-3 w-3" />;
      case 'running': return <Loader2 className="h-3 w-3 animate-spin" />;
      default: return <Database className="h-3 w-3" />;
    }
  };

  const formatCount = (n: number) => {
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
    if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
    return n.toString();
  };

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div className={cn(
          "flex items-center gap-1.5 cursor-help",
          getStatusColor(),
          className
        )}>
          {getStatusIcon()}
          <span className="text-xs font-medium tabular-nums">
            {formatCount(stats.totalCodes)}
          </span>
          {showLabel && (
            <span className="text-xs text-muted-foreground hidden sm:inline">
              Codes
            </span>
          )}
          {stats.syncStatus === 'running' && stats.syncedCount && stats.totalAvailable && (
            <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
              {Math.round((stats.syncedCount / stats.totalAvailable) * 100)}%
            </Badge>
          )}
        </div>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="max-w-xs">
        <div className="text-xs space-y-1">
          <p className="font-medium">{config?.label || source.toUpperCase()} Statistik</p>
          <p>Gesamt: {stats.totalCodes.toLocaleString('de-DE')} Codes</p>
          {stats.syncedCount !== undefined && stats.totalAvailable && (
            <p>Synchronisiert: {stats.syncedCount.toLocaleString('de-DE')} / {stats.totalAvailable.toLocaleString('de-DE')}</p>
          )}
          <p className="capitalize">Status: {
            stats.syncStatus === 'completed' ? 'Abgeschlossen' :
            stats.syncStatus === 'running' ? 'Läuft...' :
            stats.syncStatus === 'paused' ? 'Pausiert' :
            stats.syncStatus === 'error' ? 'Fehler' :
            stats.syncStatus === 'pending' ? 'Ausstehend' :
            'Unbekannt'
          }</p>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}
