import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  ChevronRight, 
  ChevronDown, 
  ExternalLink, 
  Loader2,
  Copy,
  Check,
  Plus,
  FileText,
  X,
  Stethoscope,
  Sparkles,
  BookOpen,
  Globe,
} from 'lucide-react';
import { SnomedConcept } from '@/hooks/useSnomed';

interface AnamnesisSession {
  id: string;
  clinical_view: string;
  status: string;
  created_at: string;
  patient_identifier?: string;
}

interface SnomedDetailSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  concept: SnomedConcept | null;
  translationData: {
    pt_de?: string;
    explanation_de?: string;
    source?: 'official' | 'ai_translated';
    isLoading: boolean;
  };
  conceptDetails: {
    parents?: SnomedConcept[];
    children?: SnomedConcept[];
    icd10Mappings?: { code: string; name: string }[];
    isLoading: boolean;
  };
  sessions: AnamnesisSession[];
  selectedSessionId: string;
  onSessionChange: (sessionId: string) => void;
  onAddToSession: () => void;
  isAddingToSession: boolean;
  onCopyId: () => void;
  copied: boolean;
  showEnglishDetails: boolean;
  onShowEnglishDetailsChange: (open: boolean) => void;
  onSelectConcept: (concept: SnomedConcept) => void;
}

function getSemanticTag(fsn: string): string {
  const match = fsn.match(/\(([^)]+)\)$/);
  return match ? match[1] : '';
}

function formatSessionLabel(session: AnamnesisSession) {
  const date = new Date(session.created_at);
  const dateStr = date.toLocaleDateString('de-DE', { 
    day: '2-digit', 
    month: '2-digit', 
    hour: '2-digit', 
    minute: '2-digit' 
  });
  const viewLabel = session.clinical_view.charAt(0).toUpperCase() + session.clinical_view.slice(1);
  return `${viewLabel} - ${dateStr}${session.patient_identifier ? ` (${session.patient_identifier})` : ''}`;
}

export function SnomedDetailSheet({
  open,
  onOpenChange,
  concept,
  translationData,
  conceptDetails,
  sessions,
  selectedSessionId,
  onSessionChange,
  onAddToSession,
  isAddingToSession,
  onCopyId,
  copied,
  showEnglishDetails,
  onShowEnglishDetailsChange,
  onSelectConcept,
}: SnomedDetailSheetProps) {
  if (!concept) return null;

  const handleSelectRelatedConcept = (relatedConcept: SnomedConcept) => {
    onSelectConcept(relatedConcept);
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[85vh]">
        <DrawerHeader className="pb-2">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <DrawerTitle className="text-lg truncate">
                  {translationData.pt_de || concept.pt?.term || concept.fsn?.term}
                </DrawerTitle>
                {translationData.source === 'ai_translated' && (
                  <Badge variant="secondary" className="text-[10px] gap-0.5 shrink-0">
                    <Sparkles className="h-2.5 w-2.5" />
                    KI
                  </Badge>
                )}
                {translationData.isLoading && (
                  <Badge variant="outline" className="text-[10px] gap-1 bg-primary/5 border-primary/30 shrink-0">
                    <Sparkles className="h-2.5 w-2.5 animate-pulse text-primary" />
                    <span className="text-primary">...</span>
                  </Badge>
                )}
              </div>
              <DrawerDescription className="flex items-center gap-2 mt-1">
                <Badge variant="secondary" className="font-mono text-xs">
                  SCTID: {concept.conceptId}
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2"
                  onClick={onCopyId}
                >
                  {copied ? (
                    <Check className="h-3 w-3 text-primary" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                </Button>
                {getSemanticTag(concept.fsn?.term || '') && (
                  <Badge variant="outline" className="text-[10px]">
                    {getSemanticTag(concept.fsn?.term || '')}
                  </Badge>
                )}
              </DrawerDescription>
            </div>
            <DrawerClose asChild>
              <Button variant="ghost" size="icon" className="shrink-0 h-8 w-8">
                <X className="h-4 w-4" />
              </Button>
            </DrawerClose>
          </div>
        </DrawerHeader>

        <ScrollArea className="flex-1 px-4 overflow-auto" style={{ maxHeight: 'calc(85vh - 140px)' }}>
          <div className="space-y-4 pb-4">
            {/* Add to Session */}
            {sessions.length > 0 && (
              <Card className="border-primary/30 bg-primary/5">
                <CardHeader className="py-2 px-3">
                  <CardTitle className="text-xs flex items-center gap-2">
                    <FileText className="h-3.5 w-3.5" />
                    Zur Anamnese hinzufügen
                  </CardTitle>
                </CardHeader>
                <CardContent className="py-2 px-3">
                  <div className="flex gap-2">
                    <Select value={selectedSessionId} onValueChange={onSessionChange}>
                      <SelectTrigger className="flex-1 h-8 text-xs">
                        <SelectValue placeholder="Session wählen..." />
                      </SelectTrigger>
                      <SelectContent>
                        {sessions.map((session) => (
                          <SelectItem key={session.id} value={session.id} className="text-xs">
                            {formatSessionLabel(session)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button 
                      onClick={onAddToSession}
                      disabled={!selectedSessionId || isAddingToSession}
                      size="sm"
                      className="shrink-0 h-8"
                    >
                      {isAddingToSession ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Plus className="h-3.5 w-3.5" />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* AI Explanation */}
            {translationData.explanation_de && (
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
                <h4 className="text-xs font-medium mb-1 flex items-center gap-1">
                  <BookOpen className="h-3 w-3 text-primary" />
                  Erklärung
                  <Badge variant="secondary" className="text-[10px] ml-1 gap-0.5">
                    <Sparkles className="h-2 w-2" />
                    KI
                  </Badge>
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">{translationData.explanation_de}</p>
              </div>
            )}

            {/* English Original (collapsible) */}
            <Collapsible open={showEnglishDetails} onOpenChange={onShowEnglishDetailsChange}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground h-8 text-xs">
                  {showEnglishDetails ? (
                    <ChevronDown className="h-3.5 w-3.5" />
                  ) : (
                    <ChevronRight className="h-3.5 w-3.5" />
                  )}
                  <Globe className="h-3.5 w-3.5" />
                  Englische Originalbezeichnungen
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-2 pl-4 border-l-2 border-muted space-y-2">
                <div>
                  <h4 className="text-[10px] font-medium text-muted-foreground mb-0.5">Preferred Term (EN)</h4>
                  <p className="text-xs italic">{concept.pt?.term}</p>
                </div>
                {concept.fsn?.term && concept.fsn.term !== concept.pt?.term && (
                  <div>
                    <h4 className="text-[10px] font-medium text-muted-foreground mb-0.5">Fully Specified Name</h4>
                    <p className="text-xs italic">{concept.fsn.term}</p>
                  </div>
                )}
              </CollapsibleContent>
            </Collapsible>

            {/* Status Badges */}
            <div className="flex gap-3">
              <div>
                <h4 className="text-[10px] font-medium text-muted-foreground mb-1">Status</h4>
                <Badge variant={concept.active ? 'default' : 'destructive'} className="text-[10px]">
                  {concept.active ? 'Aktiv' : 'Inaktiv'}
                </Badge>
              </div>
              <div>
                <h4 className="text-[10px] font-medium text-muted-foreground mb-1">Definition</h4>
                <Badge variant="outline" className="text-[10px]">
                  {concept.definitionStatus === 'FULLY_DEFINED' 
                    ? 'Vollständig' 
                    : 'Primitiv'}
                </Badge>
              </div>
            </div>

            {/* Loading Details */}
            {conceptDetails.isLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground py-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-xs">Lade Details...</span>
              </div>
            ) : (
              <>
                {/* ICD-10 Mappings */}
                {conceptDetails.icd10Mappings && conceptDetails.icd10Mappings.length > 0 && (
                  <div>
                    <h4 className="text-xs font-medium text-muted-foreground mb-2">
                      ICD-10 Mappings
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {conceptDetails.icd10Mappings.map((mapping, idx) => (
                        <Tooltip key={idx}>
                          <TooltipTrigger asChild>
                            <Badge variant="outline" className="font-mono text-[10px] cursor-help">
                              {mapping.code}
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">{mapping.name || mapping.code}</p>
                          </TooltipContent>
                        </Tooltip>
                      ))}
                    </div>
                  </div>
                )}

                {/* Parents */}
                {conceptDetails.parents && conceptDetails.parents.length > 0 && (
                  <div>
                    <h4 className="text-xs font-medium text-muted-foreground mb-2">
                      Übergeordnete Konzepte
                    </h4>
                    <div className="space-y-1">
                      {conceptDetails.parents.slice(0, 3).map((parent) => (
                        <button
                          key={parent.conceptId}
                          className="flex items-center gap-2 text-xs hover:text-primary transition-colors w-full text-left py-1"
                          onClick={() => handleSelectRelatedConcept(parent)}
                        >
                          <Badge variant="outline" className="text-[10px] font-mono shrink-0">
                            {parent.conceptId}
                          </Badge>
                          <span className="truncate">{parent.pt?.term}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Children */}
                {conceptDetails.children && conceptDetails.children.length > 0 && (
                  <div>
                    <h4 className="text-xs font-medium text-muted-foreground mb-2">
                      Untergeordnete Konzepte ({conceptDetails.children.length}+)
                    </h4>
                    <div className="space-y-1">
                      {conceptDetails.children.slice(0, 3).map((child) => (
                        <button
                          key={child.conceptId}
                          className="flex items-center gap-2 text-xs hover:text-primary transition-colors w-full text-left py-1"
                          onClick={() => handleSelectRelatedConcept(child)}
                        >
                          <Badge variant="outline" className="text-[10px] font-mono shrink-0">
                            {child.conceptId}
                          </Badge>
                          <span className="truncate">{child.pt?.term}</span>
                        </button>
                      ))}
                      {conceptDetails.children.length > 3 && (
                        <p className="text-[10px] text-muted-foreground">
                          ...und {conceptDetails.children.length - 3} weitere
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </ScrollArea>

        <DrawerFooter className="pt-2">
          <Button variant="outline" size="sm" asChild className="w-full">
            <a 
              href={`https://browser.ihtsdotools.org/?perspective=full&conceptId1=${concept.conceptId}&edition=MAIN/SNOMEDCT-DE&release=&languages=de,en`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Im SNOMED Browser öffnen
            </a>
          </Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}
