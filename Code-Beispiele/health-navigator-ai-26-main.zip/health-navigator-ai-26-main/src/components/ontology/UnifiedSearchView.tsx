import { useState, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { 
  Search, 
  ExternalLink, 
  Loader2,
  TreeDeciduous,
  Stethoscope,
  Sparkles,
  ChevronDown,
  Copy,
  Check,
  SlidersHorizontal,
  Layers,
  Info,
  X,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';

interface UnifiedSearchResult {
  code: string;
  label: string;
  labelOriginal?: string;
  system: 'HPO' | 'SNOMED';
  definition?: string;
  translationSource?: 'official' | 'ai_translated';
  relevanceScore?: number;
}

interface SearchFilters {
  includeHPO: boolean;
  includeSNOMED: boolean;
  minResults: number;
}

export function UnifiedSearchView() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<UnifiedSearchResult[]>([]);
  const [selectedResult, setSelectedResult] = useState<UnifiedSearchResult | null>(null);
  const [showDetailSheet, setShowDetailSheet] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    includeHPO: true,
    includeSNOMED: true,
    minResults: 10,
  });
  const [searchStats, setSearchStats] = useState<{
    hpoCount: number;
    snomedCount: number;
    duration: number;
  } | null>(null);

  const handleSelectResult = (result: UnifiedSearchResult) => {
    setSelectedResult(result);
    if (isMobile) {
      setShowDetailSheet(true);
    }
  };

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;
    if (!filters.includeHPO && !filters.includeSNOMED) {
      toast({
        variant: 'destructive',
        title: 'Filter-Fehler',
        description: 'Mindestens eine Ontologie muss ausgewählt sein.',
      });
      return;
    }
    
    setIsSearching(true);
    setResults([]);
    setSelectedResult(null);
    setSearchStats(null);
    
    const startTime = Date.now();
    const allResults: UnifiedSearchResult[] = [];
    let hpoCount = 0;
    let snomedCount = 0;

    try {
      // Search both ontologies in parallel
      const searchPromises: Promise<void>[] = [];

      if (filters.includeHPO) {
        searchPromises.push(
          supabase.functions.invoke('hpo-lookup', {
            body: { query: searchQuery, limit: filters.minResults },
          }).then(response => {
            if (response.data?.results) {
              const hpoResults: UnifiedSearchResult[] = response.data.results.map((r: any) => ({
                code: r.id || r.obo_id,
                label: r.label,
                labelOriginal: r.labelOriginal,
                system: 'HPO' as const,
                definition: r.description?.[0],
                translationSource: r.translationSource,
              }));
              allResults.push(...hpoResults);
              hpoCount = hpoResults.length;
            }
          }).catch(err => {
            console.error('HPO search error:', err);
          })
        );
      }

      if (filters.includeSNOMED) {
        searchPromises.push(
          supabase.functions.invoke('snomed-lookup', {
            body: { action: 'search', query: searchQuery, limit: filters.minResults, lang: 'de' },
          }).then(response => {
            if (response.data?.results) {
              const snomedResults: UnifiedSearchResult[] = response.data.results.map((r: any) => ({
                code: r.conceptId,
                label: r.pt?.term || r.fsn?.term,
                labelOriginal: r.fsn?.term,
                system: 'SNOMED' as const,
                definition: r.fsn?.term,
              }));
              allResults.push(...snomedResults);
              snomedCount = snomedResults.length;
            }
          }).catch(err => {
            console.error('SNOMED search error:', err);
          })
        );
      }

      await Promise.all(searchPromises);

      // Sort results: exact matches first, then by system alternating
      const sortedResults = allResults.sort((a, b) => {
        const queryLower = searchQuery.toLowerCase();
        const aExact = a.label.toLowerCase().includes(queryLower) ? 1 : 0;
        const bExact = b.label.toLowerCase().includes(queryLower) ? 1 : 0;
        
        if (aExact !== bExact) return bExact - aExact;
        
        // Alternate between systems for variety
        return 0;
      });

      // Interleave results from both systems
      const hpoResults = sortedResults.filter(r => r.system === 'HPO');
      const snomedResults = sortedResults.filter(r => r.system === 'SNOMED');
      const interleavedResults: UnifiedSearchResult[] = [];
      
      const maxLen = Math.max(hpoResults.length, snomedResults.length);
      for (let i = 0; i < maxLen; i++) {
        if (i < hpoResults.length) interleavedResults.push(hpoResults[i]);
        if (i < snomedResults.length) interleavedResults.push(snomedResults[i]);
      }

      setResults(interleavedResults);
      setSearchStats({
        hpoCount,
        snomedCount,
        duration: Date.now() - startTime,
      });

    } catch (error) {
      console.error('Unified search error:', error);
      toast({
        variant: 'destructive',
        title: 'Suchfehler',
        description: 'Die Suche konnte nicht durchgeführt werden.',
      });
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery, filters, toast]);

  const handleCopyCode = useCallback(() => {
    if (selectedResult) {
      navigator.clipboard.writeText(selectedResult.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [selectedResult]);

  const getSystemIcon = (system: 'HPO' | 'SNOMED') => {
    return system === 'HPO' 
      ? <TreeDeciduous className="h-4 w-4" />
      : <Stethoscope className="h-4 w-4" />;
  };

  const getSystemBadgeClass = (system: 'HPO' | 'SNOMED') => {
    return system === 'HPO'
      ? 'bg-primary/10 text-primary border-primary/30'
      : 'bg-secondary text-secondary-foreground border-secondary';
  };

  const getExternalLink = (result: UnifiedSearchResult) => {
    return result.system === 'HPO'
      ? `https://hpo.jax.org/browse/term/${result.code}`
      : `https://browser.ihtsdotools.org/?perspective=full&conceptId1=${result.code}`;
  };

  // Reusable detail card content
  const DetailCard = () => selectedResult && (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={`${getSystemBadgeClass(selectedResult.system)} gap-1`}>
              {getSystemIcon(selectedResult.system)}
              {selectedResult.system}
            </Badge>
            {selectedResult.translationSource === 'ai_translated' && (
              <Badge variant="secondary" className="gap-1">
                <Sparkles className="h-3 w-3" />
                KI-übersetzt
              </Badge>
            )}
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="sm" onClick={handleCopyCode}>
              {copied ? (
                <Check className="h-4 w-4 text-primary" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <a
                href={getExternalLink(selectedResult)}
                target="_blank"
                rel="noopener noreferrer"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
        <CardTitle className="text-lg mt-2">{selectedResult.label}</CardTitle>
        <CardDescription className="font-mono">
          {selectedResult.code}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {selectedResult.labelOriginal && selectedResult.labelOriginal !== selectedResult.label && (
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">
              Originalbezeichnung (EN)
            </p>
            <p className="text-sm italic">{selectedResult.labelOriginal}</p>
          </div>
        )}
        {selectedResult.definition && (
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">
              Definition
            </p>
            <p className="text-sm">{selectedResult.definition}</p>
          </div>
        )}
        <div className="pt-2 border-t">
          <p className="text-xs text-muted-foreground">
            {selectedResult.system === 'HPO' ? (
              <>Human Phenotype Ontology - Standardisierte Kodierung von phänotypischen Merkmalen</>
            ) : (
              <>SNOMED CT - Systematisierte Nomenklatur der Medizin für Diagnosen, Prozeduren und klinische Befunde</>
            )}
          </p>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-3 md:p-4 border-b">
        <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
          <div className="p-1.5 md:p-2 rounded-lg bg-primary/10">
            <Layers className="h-4 w-4 md:h-5 md:w-5 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="font-semibold text-sm md:text-base">Kombinierte Ontologie-Suche</h2>
            <p className="text-xs md:text-sm text-muted-foreground hidden sm:block">
              Durchsuche HPO und SNOMED CT gleichzeitig
            </p>
          </div>
        </div>

        {/* Search Input */}
        <div className="flex gap-2 mb-2 md:mb-3">
          <div className="relative flex-1">
            <Input
              placeholder={isMobile ? "Suchen..." : "Symptom, Diagnose oder Code suchen (z.B. Kopfschmerz, Fieber, HP:0002315)..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="pr-10 text-sm"
            />
            {isSearching && (
              <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
            )}
          </div>
          <Button onClick={handleSearch} disabled={isSearching} size={isMobile ? "icon" : "default"}>
            <Search className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Suchen</span>}
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => setShowFilters(!showFilters)}
            className={showFilters ? 'bg-muted' : ''}
          >
            <SlidersHorizontal className="h-4 w-4" />
          </Button>
        </div>

        {/* Filters */}
        <Collapsible open={showFilters} onOpenChange={setShowFilters}>
          <CollapsibleContent>
            <div className="flex items-center gap-6 p-3 bg-muted/30 rounded-lg mt-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="filter-hpo"
                  checked={filters.includeHPO}
                  onCheckedChange={(checked) => 
                    setFilters(prev => ({ ...prev, includeHPO: checked === true }))
                  }
                />
                <Label htmlFor="filter-hpo" className="flex items-center gap-1.5 cursor-pointer">
                  <TreeDeciduous className="h-4 w-4 text-primary" />
                  HPO
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="filter-snomed"
                  checked={filters.includeSNOMED}
                  onCheckedChange={(checked) => 
                    setFilters(prev => ({ ...prev, includeSNOMED: checked === true }))
                  }
                />
                <Label htmlFor="filter-snomed" className="flex items-center gap-1.5 cursor-pointer">
                  <Stethoscope className="h-4 w-4" />
                  SNOMED CT
                </Label>
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Search Stats */}
        {searchStats && (
          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <TreeDeciduous className="h-3 w-3" />
              {searchStats.hpoCount} HPO
            </span>
            <span className="flex items-center gap-1">
              <Stethoscope className="h-3 w-3" />
              {searchStats.snomedCount} SNOMED
            </span>
            <span>• {searchStats.duration}ms</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0">
        {/* Results List */}
        <div className={`${isMobile ? 'flex-1' : 'w-1/2'} md:border-r flex flex-col min-h-0`}>
          <div className="p-2 border-b bg-muted/30">
            <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Layers className="h-4 w-4" />
              Ergebnisse
              {results.length > 0 && (
                <Badge variant="secondary" className="text-xs">
                  {results.length}
                </Badge>
              )}
            </span>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {results.length === 0 && !isSearching && (
                <div className="text-center py-8 md:py-12 text-muted-foreground">
                  <Layers className="h-8 w-8 md:h-10 md:w-10 mx-auto mb-3 opacity-30" />
                  <p className="text-sm font-medium">Kombinierte Suche</p>
                  <p className="text-xs mt-1">
                    Suche in HPO und SNOMED CT gleichzeitig
                  </p>
                </div>
              )}
              {isSearching && (
                <div className="text-center py-8 md:py-12">
                  <Loader2 className="h-6 w-6 md:h-8 md:w-8 mx-auto mb-3 animate-spin text-primary" />
                  <p className="text-sm text-muted-foreground">Durchsuche Ontologien...</p>
                </div>
              )}
              {results.map((result, idx) => (
                <button
                  key={`${result.system}-${result.code}-${idx}`}
                  className={`w-full text-left p-2 md:p-3 rounded-lg border transition-colors ${
                    selectedResult?.code === result.code && selectedResult?.system === result.system
                      ? 'bg-primary/10 border-primary'
                      : 'bg-card hover:bg-muted border-transparent'
                  }`}
                  onClick={() => handleSelectResult(result)}
                >
                  <div className="flex items-center gap-1.5 md:gap-2 mb-1 flex-wrap">
                    <Badge className={`${getSystemBadgeClass(result.system)} gap-1 text-[10px] md:text-xs`}>
                      {getSystemIcon(result.system)}
                      <span className="hidden sm:inline">{result.system}</span>
                    </Badge>
                    <Badge variant="outline" className="font-mono text-[10px] md:text-xs">
                      {result.code}
                    </Badge>
                    {result.translationSource === 'ai_translated' && (
                      <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4 gap-0.5">
                        <Sparkles className="h-2.5 w-2.5" />
                        <span className="hidden sm:inline">KI</span>
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs md:text-sm line-clamp-2">{result.label}</p>
                  {result.labelOriginal && result.labelOriginal !== result.label && (
                    <p className="text-[10px] md:text-xs text-muted-foreground italic mt-0.5 line-clamp-1">
                      {result.labelOriginal}
                    </p>
                  )}
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Detail Panel - Desktop */}
        {!isMobile && (
          <div className="flex-1 flex flex-col min-h-0">
            <div className="p-2 border-b bg-muted/30">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Info className="h-4 w-4" />
                Details
              </span>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-4">
                {!selectedResult && (
                  <div className="text-center py-12 text-muted-foreground">
                    <Search className="h-10 w-10 mx-auto mb-3 opacity-30" />
                    <p className="text-sm">Wähle ein Ergebnis aus der Liste</p>
                  </div>
                )}
                {selectedResult && <DetailCard />}
              </div>
            </ScrollArea>
          </div>
        )}
      </div>

      {/* Mobile Detail Sheet */}
      {isMobile && (
        <Sheet open={showDetailSheet} onOpenChange={setShowDetailSheet}>
          <SheetContent side="bottom" className="h-[80vh] rounded-t-xl">
            <SheetHeader className="pb-4">
              <SheetTitle className="flex items-center justify-between">
                <span>Details</span>
              </SheetTitle>
            </SheetHeader>
            <ScrollArea className="h-[calc(80vh-6rem)]">
              {selectedResult && <DetailCard />}
            </ScrollArea>
          </SheetContent>
        </Sheet>
      )}
    </div>
  );
}
