import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Check, Edit2, Loader2, Shield, ShieldCheck, Sparkles } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface TranslationEditorProps {
  hpoCode: string;
  labelEn: string;
  labelDe: string;
  definitionDe?: string;
  translationSource: 'official' | 'ai_translated' | undefined;
  isVerified?: boolean;
  onUpdate?: (newLabel: string, newDefinition?: string) => void;
}

export function TranslationEditor({
  hpoCode,
  labelEn,
  labelDe,
  definitionDe,
  translationSource,
  isVerified,
  onUpdate,
}: TranslationEditorProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [editForm, setEditForm] = useState({
    label_de: labelDe,
    definition_de: definitionDe || '',
  });

  const handleVerify = async () => {
    if (!user) {
      toast({
        variant: 'destructive',
        title: 'Nicht angemeldet',
        description: 'Bitte melden Sie sich an, um Übersetzungen zu verifizieren.',
      });
      return;
    }

    setIsVerifying(true);
    try {
      // Get current HPO code data
      const { data: hpoData, error: fetchError } = await supabase
        .from('hpo_codes')
        .select('labels, definitions, explanations')
        .eq('hpo_code', hpoCode)
        .maybeSingle();

      if (fetchError) throw fetchError;

      // Mark as verified by updating with a verified flag in labels metadata
      const currentLabels = (hpoData?.labels as Record<string, unknown>) || {};
      const { error } = await supabase
        .from('hpo_codes')
        .update({
          labels: { 
            ...currentLabels, 
            de: labelDe, 
            en: labelEn,
            _verified: true,
            _verified_at: new Date().toISOString(),
            _verified_by: user.id,
          },
        })
        .eq('hpo_code', hpoCode);

      if (error) throw error;

      toast({
        title: 'Übersetzung verifiziert',
        description: `"${labelDe}" wurde als korrekt markiert.`,
      });
      
      onUpdate?.(labelDe, definitionDe);
    } catch (error) {
      console.error('Verify error:', error);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Die Verifizierung konnte nicht gespeichert werden.',
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSave = async () => {
    if (!user) {
      toast({
        variant: 'destructive',
        title: 'Nicht angemeldet',
        description: 'Bitte melden Sie sich an, um Übersetzungen zu bearbeiten.',
      });
      return;
    }

    setIsSaving(true);
    try {
      // Get current HPO code data
      const { data: hpoData, error: fetchError } = await supabase
        .from('hpo_codes')
        .select('labels, definitions, explanations')
        .eq('hpo_code', hpoCode)
        .maybeSingle();

      if (fetchError) throw fetchError;

      const currentLabels = (hpoData?.labels as Record<string, unknown>) || {};
      const currentDefinitions = (hpoData?.definitions as Record<string, string>) || {};

      // Update the HPO code with new translation
      const { error } = await supabase
        .from('hpo_codes')
        .update({
          labels: { 
            ...currentLabels, 
            de: editForm.label_de, 
            en: labelEn,
            _verified: true,
            _verified_at: new Date().toISOString(),
            _verified_by: user.id,
            _source: 'manual',
          },
          definitions: editForm.definition_de 
            ? { ...currentDefinitions, de: editForm.definition_de }
            : currentDefinitions,
        })
        .eq('hpo_code', hpoCode);

      if (error) throw error;

      toast({
        title: 'Übersetzung gespeichert',
        description: 'Die Korrektur wurde erfolgreich gespeichert.',
      });
      
      setIsEditing(false);
      onUpdate?.(editForm.label_de, editForm.definition_de);
    } catch (error) {
      console.error('Save error:', error);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Die Übersetzung konnte nicht gespeichert werden.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const openEditor = () => {
    setEditForm({
      label_de: labelDe,
      definition_de: definitionDe || '',
    });
    setIsEditing(true);
  };

  // Only show for AI translations
  if (translationSource !== 'ai_translated') {
    return null;
  }

  return (
    <>
      <div className="flex items-center gap-1 mt-2">
        {isVerified ? (
          <Badge variant="outline" className="text-xs gap-1 text-primary border-primary/30">
            <ShieldCheck className="h-3 w-3" />
            Verifiziert
          </Badge>
        ) : (
          <>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs gap-1"
                  onClick={handleVerify}
                  disabled={isVerifying}
                >
                  {isVerifying ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <Check className="h-3 w-3" />
                  )}
                  Bestätigen
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Diese Übersetzung als korrekt markieren</p>
              </TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs gap-1"
                  onClick={openEditor}
                >
                  <Edit2 className="h-3 w-3" />
                  Korrigieren
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Die Übersetzung bearbeiten</p>
              </TooltipContent>
            </Tooltip>
          </>
        )}
      </div>

      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit2 className="h-5 w-5" />
              Übersetzung korrigieren
            </DialogTitle>
            <DialogDescription>
              Korrigieren Sie die KI-Übersetzung für <span className="font-mono">{hpoCode}</span>
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">🇬🇧 Englisches Original</Label>
              <p className="text-sm bg-muted/50 p-2 rounded-md">{labelEn}</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="label_de">🇩🇪 Deutsche Übersetzung</Label>
              <Input
                id="label_de"
                value={editForm.label_de}
                onChange={(e) => setEditForm(prev => ({ ...prev, label_de: e.target.value }))}
                placeholder="Deutsche Übersetzung eingeben..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="definition_de">🇩🇪 Definition (optional)</Label>
              <Textarea
                id="definition_de"
                value={editForm.definition_de}
                onChange={(e) => setEditForm(prev => ({ ...prev, definition_de: e.target.value }))}
                placeholder="Deutsche Definition eingeben..."
                rows={3}
              />
            </div>

            <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/30 p-2 rounded-md">
              <Shield className="h-4 w-4" />
              <span>Ihre Korrektur wird automatisch als verifiziert markiert.</span>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditing(false)}>
              Abbrechen
            </Button>
            <Button onClick={handleSave} disabled={isSaving || !editForm.label_de.trim()}>
              {isSaving ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Check className="h-4 w-4 mr-2" />
              )}
              Speichern
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
