import { useState, useCallback, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { 
  Search, 
  ChevronRight, 
  ChevronDown, 
  ExternalLink, 
  Loader2,
  Copy,
  Check,
  Plus,
  FileText,
  X,
  Stethoscope,
  Sparkles,
  BookOpen,
  Globe,
  PanelRightClose,
  PanelRightOpen,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useSnomed, SnomedConcept, DataSource } from '@/hooks/useSnomed';
import { useProfile } from '@/hooks/useProfile';
import { useIsMobile } from '@/hooks/use-mobile';
import { SnomedDetailSheet } from './SnomedDetailSheet';
import { OntologyAnalysisPanel } from './OntologyAnalysisPanel';
import { cn } from '@/lib/utils';
import { DataSourceBadge } from '@/components/ui/data-source-badge';
import { BulkSyncButton } from './BulkSyncButton';
import { OntologyStatsBar } from './OntologyStatsBar';

interface AnamnesisSession {
  id: string;
  clinical_view: string;
  status: string;
  created_at: string;
  patient_identifier?: string;
}

interface SnomedTranslation {
  sctid: string;
  pt_de: string;
  explanation_de?: string;
  source: 'official' | 'ai_translated';
  confidence: number;
}

interface SnomedTreeNode {
  concept: SnomedConcept;
  children?: SnomedTreeNode[];
  isLoading?: boolean;
  isExpanded?: boolean;
  hasChildren?: boolean;
  isTranslating?: boolean;
  translatedPt?: string;
  translationSource?: 'official' | 'ai_translated';
}

interface TreeNodeProps {
  node: SnomedTreeNode;
  level: number;
  onSelect: (concept: SnomedConcept) => void;
  onExpand: (node: SnomedTreeNode) => void;
  selectedId?: string;
  bilingualView?: boolean;
}

// SNOMED CT Root Categories (top-level hierarchies)
const SNOMED_ROOT_CATEGORIES = [
  { id: '404684003', name: 'Clinical finding', nameDE: 'Klinischer Befund' },
  { id: '123037004', name: 'Body structure', nameDE: 'Körperstruktur' },
  { id: '71388002', name: 'Procedure', nameDE: 'Prozedur' },
  { id: '410607006', name: 'Organism', nameDE: 'Organismus' },
  { id: '105590001', name: 'Substance', nameDE: 'Substanz' },
  { id: '373873005', name: 'Pharmaceutical product', nameDE: 'Pharmazeutisches Produkt' },
  { id: '78621006', name: 'Physical force', nameDE: 'Physikalische Kraft' },
  { id: '272379006', name: 'Event', nameDE: 'Ereignis' },
  { id: '363787002', name: 'Observable entity', nameDE: 'Beobachtbare Entität' },
  { id: '243796009', name: 'Situation with explicit context', nameDE: 'Situation mit explizitem Kontext' },
  { id: '48176007', name: 'Social context', nameDE: 'Sozialer Kontext' },
  { id: '308916002', name: 'Environment or geographical location', nameDE: 'Umgebung oder geographischer Ort' },
  { id: '362981000', name: 'Qualifier value', nameDE: 'Qualifizierer' },
  { id: '419891008', name: 'Record artifact', nameDE: 'Dokumentationsartefakt' },
];

function TreeNode({ node, level, onSelect, onExpand, selectedId, bilingualView = false }: TreeNodeProps) {
  const hasChildren = node.hasChildren !== false;
  const isSelected = node.concept.conceptId === selectedId;
  const displayName = node.translatedPt || node.concept.pt?.term || node.concept.fsn?.term;
  const originalName = node.concept.pt?.term || node.concept.fsn?.term;

  return (
    <div className="select-none">
      <div
        className={`group flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted ${
          isSelected ? 'bg-primary/10 text-primary font-medium ring-1 ring-primary/20' : ''
        }`}
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        onClick={() => onSelect(node.concept)}
      >
        {node.isLoading ? (
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground shrink-0" />
        ) : hasChildren ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onExpand(node);
            }}
            className="p-0.5 hover:bg-muted-foreground/20 rounded transition-colors"
          >
            {node.isExpanded ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground transition-transform duration-200" />
            )}
          </button>
        ) : (
          <div className="w-5" />
        )}
        
        <Badge variant="outline" className="text-xs font-mono shrink-0 transition-colors group-hover:border-primary/30">
          {node.concept.conceptId}
        </Badge>
        <div className="flex flex-col min-w-0 flex-1">
          <span className="text-sm truncate transition-colors">{displayName}</span>
          {bilingualView && node.translatedPt && originalName !== node.translatedPt && (
            <span className="text-[11px] text-muted-foreground truncate italic">
              {originalName}
            </span>
          )}
        </div>
        {node.translationSource === 'ai_translated' && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4 shrink-0 gap-0.5 cursor-help bg-primary/10 border-primary/20">
                <Sparkles className="h-2.5 w-2.5 text-primary" />
                KI
              </Badge>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <p className="text-xs">
                Dieser Begriff wurde automatisch per KI übersetzt.
              </p>
            </TooltipContent>
          </Tooltip>
        )}
        {node.isTranslating && (
          <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 shrink-0 gap-1 bg-primary/5 border-primary/30">
            <Sparkles className="h-2.5 w-2.5 animate-pulse text-primary" />
            <span className="text-primary">...</span>
          </Badge>
        )}
      </div>

      {node.isExpanded && node.children && (
        <div className="animate-in slide-in-from-top-1 duration-200">
          {node.children.map((child) => (
            <TreeNode
              key={child.concept.conceptId}
              node={child}
              level={level + 1}
              onSelect={onSelect}
              onExpand={onExpand}
              selectedId={selectedId}
              bilingualView={bilingualView}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function SnomedBrowser() {
  const { toast } = useToast();
  const { user } = useAuth();
  const { profile, updateProfile } = useProfile();
  const [searchParams] = useSearchParams();
  const preselectedSessionId = searchParams.get('sessionId');
  const prefilledSearch = searchParams.get('search');
  const isMobile = useIsMobile();
  
  const { 
    searchConcepts, 
    isSearching, 
    searchResults, 
    clearSearch,
    getConcept,
    lastDataSource,
    error: searchError 
  } = useSnomed({ language: 'de' });
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConcept, setSelectedConcept] = useState<SnomedConcept | null>(null);
  const [treeData, setTreeData] = useState<SnomedTreeNode[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);
  const [copied, setCopied] = useState(false);
  const [sessions, setSessions] = useState<AnamnesisSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>(preselectedSessionId || '');
  const [isAddingToSession, setIsAddingToSession] = useState(false);
  const [bilingualView, setBilingualView] = useState<boolean>(false);
  const [showEnglishDetails, setShowEnglishDetails] = useState<boolean>(false);
  const [detailSheetOpen, setDetailSheetOpen] = useState(false);
  const [detailPanelCollapsed, setDetailPanelCollapsed] = useState(false);
  const [translationData, setTranslationData] = useState<{
    pt_de?: string;
    explanation_de?: string;
    source?: 'official' | 'ai_translated';
    isLoading: boolean;
  }>({ isLoading: false });
  const [conceptDetails, setConceptDetails] = useState<{
    parents?: SnomedConcept[];
    children?: SnomedConcept[];
    icd10Mappings?: { code: string; name: string }[];
    isLoading: boolean;
  }>({ isLoading: false });

  // Show toast when search error occurs (e.g., invalid SNOMED code)
  useEffect(() => {
    if (searchError) {
      toast({
        title: 'Ungültiger SNOMED-Code',
        description: searchError.includes('not found') || searchError.includes('inactive')
          ? 'Der eingegebene Code existiert nicht oder ist inaktiv.'
          : searchError,
        variant: 'destructive',
      });
    }
  }, [searchError, toast]);

  // Sync showEnglishDetails with profile setting
  useEffect(() => {
    if (profile?.show_english_details !== undefined) {
      setShowEnglishDetails(profile.show_english_details);
    }
  }, [profile?.show_english_details]);

  const handleShowEnglishDetailsChange = useCallback((open: boolean) => {
    setShowEnglishDetails(open);
    if (profile && profile.show_english_details !== open) {
      updateProfile.mutate({ show_english_details: open });
    }
  }, [profile, updateProfile]);

  // Translate SNOMED terms via edge function
  const translateTerms = useCallback(async (terms: { sctid: string; fsn: string; pt: string }[]): Promise<Map<string, SnomedTranslation>> => {
    const resultMap = new Map<string, SnomedTranslation>();
    if (terms.length === 0) return resultMap;

    try {
      const response = await supabase.functions.invoke('snomed-translate', {
        body: { terms },
      });

      if (response.error) {
        console.error('SNOMED translation error:', response.error);
        return resultMap;
      }

      const translations = response.data?.translations || [];
      for (const t of translations) {
        resultMap.set(t.sctid, t);
      }
    } catch (error) {
      console.error('SNOMED translation fetch error:', error);
    }

    return resultMap;
  }, []);

  // Fetch translation when concept selected
  useEffect(() => {
    if (!selectedConcept) {
      setTranslationData({ isLoading: false });
      return;
    }

    const fetchTranslation = async () => {
      setTranslationData({ isLoading: true });

      try {
        const translations = await translateTerms([{
          sctid: selectedConcept.conceptId,
          fsn: selectedConcept.fsn?.term || '',
          pt: selectedConcept.pt?.term || '',
        }]);

        const translation = translations.get(selectedConcept.conceptId);
        if (translation) {
          setTranslationData({
            pt_de: translation.pt_de,
            explanation_de: translation.explanation_de,
            source: translation.source,
            isLoading: false,
          });
        } else {
          setTranslationData({ isLoading: false });
        }
      } catch (err) {
        console.error('Error fetching SNOMED translation:', err);
        setTranslationData({ isLoading: false });
      }
    };

    fetchTranslation();
  }, [selectedConcept?.conceptId, translateTerms]);

  // Load root categories on mount - DB first, then API fallback, then translate missing
  useEffect(() => {
    let mounted = true;
    
    const loadRootCategories = async () => {
      setIsLoadingCategories(true);
      try {
        // First: Try to load from local database
        const rootIds = SNOMED_ROOT_CATEGORIES.map(c => c.id);
        const { data: localCodes, error: dbError } = await supabase
          .from('snomed_codes')
          .select('*')
          .in('sctid', rootIds);
        
        const localCodesMap = new Map((localCodes || []).map(c => [c.sctid, c]));
        
        // Build initial nodes from DB + static fallback
        const rootNodes: SnomedTreeNode[] = SNOMED_ROOT_CATEGORIES.map((category) => {
          const localCode = localCodesMap.get(category.id);
          
          if (localCode) {
            const labels = localCode.labels as Record<string, string> | null;
            const labelDe = labels?.de;
            const labelEn = labels?.en || localCode.pt;
            
            // Check if we have a valid German translation (not just the English term)
            const hasValidDE = labelDe && labelDe !== labelEn;
            
            return {
              concept: {
                conceptId: localCode.sctid,
                fsn: { term: localCode.fsn, lang: 'en' },
                pt: { term: hasValidDE ? labelDe : localCode.pt, lang: hasValidDE ? 'de' : 'en' },
                active: localCode.is_active ?? true,
                definitionStatus: localCode.definition_status || 'PRIMITIVE',
                moduleId: localCode.module_id || '900000000000207008',
              },
              hasChildren: true,
              isExpanded: false,
              translatedPt: hasValidDE ? labelDe : undefined,
              translationSource: hasValidDE ? 'official' as const : undefined,
              isTranslating: !hasValidDE, // Mark for translation if no German label
            };
          }
          
          // Use static German name as fallback
          return {
            concept: {
              conceptId: category.id,
              fsn: { term: category.name, lang: 'en' },
              pt: { term: category.nameDE, lang: 'de' },
              active: true,
              definitionStatus: 'PRIMITIVE',
              moduleId: '900000000000207008',
            },
            hasChildren: true,
            isExpanded: false,
            translatedPt: category.nameDE,
            translationSource: 'official' as const,
          };
        });
        
        if (mounted) setTreeData(rootNodes);
        
        // Find nodes that need translation
        const nodesToTranslate = rootNodes.filter(n => n.isTranslating);
        
        if (nodesToTranslate.length > 0) {
          console.log(`[SNOMED] Translating ${nodesToTranslate.length} root categories...`);
          
          // Trigger translation for missing German labels
          const translations = await translateTerms(
            nodesToTranslate.map(n => ({
              sctid: n.concept.conceptId,
              fsn: n.concept.fsn?.term || '',
              pt: n.concept.pt?.term || '',
            }))
          );
          
          if (mounted && translations.size > 0) {
            setTreeData(prev => prev.map(node => {
              const translation = translations.get(node.concept.conceptId);
              if (translation) {
                return {
                  ...node,
                  translatedPt: translation.pt_de,
                  translationSource: translation.source,
                  isTranslating: false,
                  concept: {
                    ...node.concept,
                    pt: { term: translation.pt_de, lang: 'de' },
                  },
                };
              }
              return { ...node, isTranslating: false };
            }));
            console.log(`[SNOMED] Translated ${translations.size} root categories`);
          }
        }
      } catch (error) {
        console.error('Error loading SNOMED root categories:', error);
        // Use static fallback on error
        const fallbackNodes: SnomedTreeNode[] = SNOMED_ROOT_CATEGORIES.map(category => ({
          concept: {
            conceptId: category.id,
            fsn: { term: category.name, lang: 'en' },
            pt: { term: category.nameDE, lang: 'de' },
            active: true,
            definitionStatus: 'PRIMITIVE',
            moduleId: '900000000000207008',
          },
          hasChildren: true,
          isExpanded: false,
          translatedPt: category.nameDE,
          translationSource: 'official' as const,
        }));
        if (mounted) setTreeData(fallbackNodes);
      } finally {
        if (mounted) setIsLoadingCategories(false);
      }
    };

    loadRootCategories();
    return () => { mounted = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [translateTerms]);

  // Handle prefilled search from URL params (e.g., from ICD-10 analysis link)
  useEffect(() => {
    if (prefilledSearch && !isLoadingCategories) {
      setSearchQuery(prefilledSearch);
      // Trigger search after a short delay to ensure component is mounted
      const timer = setTimeout(async () => {
        await searchConcepts(prefilledSearch, 30);
        // Auto-select if exact match found in search results
        const exactMatch = searchResults.find(r => r.conceptId === prefilledSearch);
        if (exactMatch) {
          setSelectedConcept(exactMatch);
          if (isMobile) setDetailSheetOpen(true);
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [prefilledSearch, isLoadingCategories, searchConcepts, isMobile]);

  // Load active sessions
  useEffect(() => {
    const loadSessions = async () => {
      if (!user) return;
      
      const { data, error } = await supabase
        .from('anamnesis_sessions')
        .select('id, clinical_view, status, created_at, patient_identifier')
        .eq('user_id', user.id)
        .eq('status', 'in_progress')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (!error && data) {
        setSessions(data);
        if (preselectedSessionId && data.some(s => s.id === preselectedSessionId)) {
          setSelectedSessionId(preselectedSessionId);
        } else if (data.length > 0 && !selectedSessionId) {
          setSelectedSessionId(data[0].id);
        }
      }
    };
    
    loadSessions();
  }, [user, preselectedSessionId]);

  // Fetch concept details when selected
  useEffect(() => {
    if (!selectedConcept) {
      setConceptDetails({ isLoading: false });
      return;
    }

    const fetchDetails = async () => {
      setConceptDetails({ isLoading: true });
      
      try {
        // Fetch parents, children, and ICD-10 mappings in parallel
        const [parentsRes, childrenRes, mappingsRes] = await Promise.all([
          supabase.functions.invoke('snomed-lookup', {
            body: {
              action: 'parents',
              id: selectedConcept.conceptId,
              lang: 'de',
            },
          }),
          supabase.functions.invoke('snomed-lookup', {
            body: {
              action: 'children',
              id: selectedConcept.conceptId,
              limit: 20,
              lang: 'de',
            },
          }),
          supabase.functions.invoke('snomed-lookup', {
            body: {
              action: 'icd10',
              sctid: selectedConcept.conceptId,
            },
          }),
        ]);

        setConceptDetails({
          parents: parentsRes.data?.parents || [],
          children: childrenRes.data?.children || [],
          icd10Mappings: mappingsRes.data?.mappings || [],
          isLoading: false,
        });
      } catch (err) {
        console.error('Error fetching concept details:', err);
        setConceptDetails({ isLoading: false });
      }
    };

    fetchDetails();
  }, [selectedConcept?.conceptId]);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    await searchConcepts(searchQuery, 30);
  };

  const handleExpand = useCallback(async (node: SnomedTreeNode) => {
    // Toggle if already expanded
    if (node.isExpanded) {
      setTreeData(prev => updateNodeInTree(prev, node.concept.conceptId, { isExpanded: false }));
      return;
    }

    // Show loading state
    setTreeData(prev => updateNodeInTree(prev, node.concept.conceptId, { isLoading: true, isExpanded: true }));

    try {
      const { data, error } = await supabase.functions.invoke('snomed-lookup', {
        body: {
          action: 'children',
          id: node.concept.conceptId,
          limit: 50,
          lang: 'de',
        },
      });

      if (error) throw error;

      const rawChildren: SnomedConcept[] = data?.children || [];
      
      // Create initial children with isTranslating flag
      const children: SnomedTreeNode[] = rawChildren.map((child: SnomedConcept) => ({
        concept: child,
        hasChildren: true,
        isExpanded: false,
        isTranslating: true, // Mark all for translation
      }));

      // Update tree with children (show loading state for translations)
      setTreeData(prev => updateNodeInTree(prev, node.concept.conceptId, { 
        isLoading: false, 
        isExpanded: true,
        children,
        hasChildren: children.length > 0,
      }));

      // Batch translate all children to user's language
      if (rawChildren.length > 0) {
        const translations = await translateTerms(
          rawChildren.map(c => ({
            sctid: c.conceptId,
            fsn: c.fsn?.term || '',
            pt: c.pt?.term || '',
          }))
        );

        // Update children with translations
        setTreeData(prev => {
          const updateChildrenTranslations = (nodes: SnomedTreeNode[]): SnomedTreeNode[] => {
            return nodes.map(n => {
              if (n.concept.conceptId === node.concept.conceptId && n.children) {
                return {
                  ...n,
                  children: n.children.map(child => {
                    const translation = translations.get(child.concept.conceptId);
                    if (translation) {
                      return {
                        ...child,
                        translatedPt: translation.pt_de,
                        translationSource: translation.source,
                        isTranslating: false,
                      };
                    }
                    return { ...child, isTranslating: false };
                  }),
                };
              }
              if (n.children) {
                return { ...n, children: updateChildrenTranslations(n.children) };
              }
              return n;
            });
          };
          return updateChildrenTranslations(prev);
        });

        console.log(`Translated ${translations.size} SNOMED children for ${node.concept.conceptId}`);
      }
    } catch (err) {
      console.error('Error fetching children:', err);
      setTreeData(prev => updateNodeInTree(prev, node.concept.conceptId, { 
        isLoading: false, 
        isExpanded: false,
      }));
    }
  }, [translateTerms]);

  const updateNodeInTree = (
    nodes: SnomedTreeNode[], 
    targetId: string, 
    updates: Partial<SnomedTreeNode>
  ): SnomedTreeNode[] => {
    return nodes.map(node => {
      if (node.concept.conceptId === targetId) {
        return { ...node, ...updates };
      }
      if (node.children) {
        return { ...node, children: updateNodeInTree(node.children, targetId, updates) };
      }
      return node;
    });
  };

  const handleSelect = (concept: SnomedConcept) => {
    setSelectedConcept(concept);
    // Open detail sheet on mobile when selecting a concept
    if (isMobile) {
      setDetailSheetOpen(true);
    }
  };

  const handleCopyId = () => {
    if (selectedConcept) {
      navigator.clipboard.writeText(selectedConcept.conceptId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const addToSession = async () => {
    if (!selectedConcept || !selectedSessionId) {
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Bitte wählen Sie einen Begriff und eine Session aus.',
      });
      return;
    }

    setIsAddingToSession(true);
    try {
      const { error } = await supabase
        .from('observations')
        .insert({
          session_id: selectedSessionId,
          raw_input: selectedConcept.pt?.term || selectedConcept.fsn?.term,
          normalized_value: selectedConcept.pt?.term || selectedConcept.fsn?.term,
          // Store SNOMED codes in a way that's distinguishable
          // Using mesh_terms as a workaround since there's no snomed_codes column
          mesh_terms: [`SCTID:${selectedConcept.conceptId}`],
          language: 'de',
          provenance: 'ontology_browser_snomed',
          confidence: 1.0,
        });

      if (error) throw error;

      toast({
        title: 'Erfolgreich hinzugefügt',
        description: `"${selectedConcept.pt?.term}" (${selectedConcept.conceptId}) wurde zur Anamnese hinzugefügt.`,
      });
    } catch (error) {
      console.error('Error adding to session:', error);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Der Begriff konnte nicht hinzugefügt werden.',
      });
    } finally {
      setIsAddingToSession(false);
    }
  };

  const formatSessionLabel = (session: AnamnesisSession) => {
    const date = new Date(session.created_at);
    const dateStr = date.toLocaleDateString('de-DE', { 
      day: '2-digit', 
      month: '2-digit', 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    const viewLabel = session.clinical_view.charAt(0).toUpperCase() + session.clinical_view.slice(1);
    return `${viewLabel} - ${dateStr}${session.patient_identifier ? ` (${session.patient_identifier})` : ''}`;
  };

  const getSemanticTag = (fsn: string): string => {
    const match = fsn.match(/\(([^)]+)\)$/);
    return match ? match[1] : '';
  };

  return (
    <div className="h-full flex flex-col">
      {/* Search Bar with Options */}
      <div className="p-2 md:p-4 border-b">
        <div className="flex gap-2 mb-2 md:mb-3">
          <div className="relative flex-1">
            <Input
              placeholder={isMobile ? "SNOMED suchen..." : "Nach SNOMED CT Begriffen suchen (z.B. Fieber, Husten, 386661006)..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="pr-8 h-9 md:h-10 text-sm"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  clearSearch();
                }}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Suche löschen"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <Button onClick={handleSearch} disabled={isSearching} size={isMobile ? "sm" : "default"} className="shrink-0">
            {isSearching ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
          </Button>
        </div>
        
        {/* View Options */}
        <div className="flex items-center gap-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="bilingual-snomed"
              checked={bilingualView}
              onCheckedChange={setBilingualView}
            />
            <Label htmlFor="bilingual-snomed" className="text-xs md:text-sm flex items-center gap-1">
              <Globe className="h-3 w-3 md:h-3.5 md:w-3.5" />
              {isMobile ? 'Bilingual' : 'Bilinguale Ansicht'}
            </Label>
          </div>
        </div>
        
        {searchError && (
          <p className="text-xs md:text-sm text-destructive mt-2">{searchError}</p>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 flex min-h-0">
        {/* Tree / Search Results - Full width on mobile or when panel collapsed */}
        <div className={cn(
          'flex flex-col min-h-0 border-r transition-all duration-300',
          isMobile ? 'w-full border-r-0' : detailPanelCollapsed ? 'flex-1 border-r-0' : 'w-1/2'
        )}>
          <div className="p-2 border-b bg-muted/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs md:text-sm font-medium text-muted-foreground">
                {searchResults.length > 0 
                  ? `${searchResults.length} Suchergebnisse` 
                  : 'SNOMED CT Hierarchien'
                }
              </span>
              <OntologyStatsBar source="snomed" showLabel={!isMobile} />
              {lastDataSource !== 'unknown' && (
                <DataSourceBadge source={lastDataSource} />
              )}
            </div>
            <div className="flex items-center gap-2">
              <BulkSyncButton source="snomed" />
              {searchResults.length > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 text-xs"
                  onClick={() => clearSearch()}
                >
                  Zurück
                </Button>
              )}
              {!isMobile && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0"
                  onClick={() => setDetailPanelCollapsed(!detailPanelCollapsed)}
                  title={detailPanelCollapsed ? 'Details einblenden' : 'Details ausblenden'}
                >
                  {detailPanelCollapsed ? (
                    <PanelRightOpen className="h-4 w-4" />
                  ) : (
                    <PanelRightClose className="h-4 w-4" />
                  )}
                </Button>
              )}
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2">
              {searchResults.length > 0 ? (
                // Search results
                <div className="space-y-1">
                  {searchResults.map((concept) => (
                    <div
                      key={concept.conceptId}
                      className={cn(
                        'flex items-center gap-2 py-2 px-2 md:px-3 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted active:scale-[0.98]',
                        selectedConcept?.conceptId === concept.conceptId ? 'bg-primary/10 text-primary ring-1 ring-primary/20' : ''
                      )}
                      onClick={() => handleSelect(concept)}
                    >
                      <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0">
                        {concept.conceptId}
                      </Badge>
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="text-xs md:text-sm truncate">{concept.pt?.term}</span>
                        {bilingualView && concept.fsn?.term && concept.fsn.term !== concept.pt?.term && (
                          <span className="text-[10px] md:text-[11px] text-muted-foreground truncate italic">
                            {concept.fsn.term}
                          </span>
                        )}
                      </div>
                      {getSemanticTag(concept.fsn?.term || '') && (
                        <Badge variant="secondary" className="text-[9px] md:text-[10px] shrink-0 hidden sm:inline-flex">
                          {getSemanticTag(concept.fsn?.term || '')}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              ) : isLoadingCategories ? (
                // Loading categories
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-5 w-5 md:h-6 md:w-6 animate-spin text-muted-foreground" />
                  <span className="ml-2 text-xs md:text-sm text-muted-foreground">
                    Hierarchien werden geladen...
                  </span>
                </div>
              ) : (
                // Tree view
                <div>
                  {treeData.map((node) => (
                    <TreeNode
                      key={node.concept.conceptId}
                      node={node}
                      level={0}
                      onSelect={handleSelect}
                      onExpand={handleExpand}
                      selectedId={selectedConcept?.conceptId}
                      bilingualView={bilingualView}
                    />
                  ))}
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Details Panel - Hidden on mobile or when collapsed */}
        {!isMobile && !detailPanelCollapsed && (
          <div className="w-1/2 flex flex-col min-h-0 border-l animate-in slide-in-from-right-2 duration-300">
            {selectedConcept ? (
              <ScrollArea className="flex-1">
                <div className="p-4 space-y-4">
                  {/* Add to Session Card */}
                  {sessions.length > 0 && (
                    <Card className="border-primary/30 bg-primary/5">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          Zur Anamnese hinzufügen
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex gap-2">
                          <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Session wählen..." />
                            </SelectTrigger>
                            <SelectContent>
                              {sessions.map((session) => (
                                <SelectItem key={session.id} value={session.id}>
                                  {formatSessionLabel(session)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button 
                            onClick={addToSession}
                            disabled={!selectedSessionId || isAddingToSession}
                            className="shrink-0"
                          >
                            {isAddingToSession ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Plus className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Main Details Card */}
                  <Card>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-xl">
                              {translationData.pt_de || selectedConcept.pt?.term || selectedConcept.fsn?.term}
                            </CardTitle>
                            {translationData.source === 'ai_translated' && (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Badge variant="secondary" className="text-xs gap-0.5">
                                    <Sparkles className="h-3 w-3" />
                                    KI
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">KI-generierte deutsche Übersetzung</p>
                                </TooltipContent>
                              </Tooltip>
                            )}
                            {translationData.isLoading && (
                              <Badge variant="outline" className="text-xs gap-1 bg-primary/5 border-primary/30">
                                <Sparkles className="h-3 w-3 animate-pulse text-primary" />
                                <span className="text-primary">Übersetze...</span>
                              </Badge>
                            )}
                            {getSemanticTag(selectedConcept.fsn?.term || '') && (
                              <Badge variant="secondary" className="text-xs">
                                {getSemanticTag(selectedConcept.fsn?.term || '')}
                              </Badge>
                            )}
                          </div>
                          <CardDescription className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="font-mono">
                              SCTID: {selectedConcept.conceptId}
                            </Badge>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 px-2"
                              onClick={handleCopyId}
                            >
                              {copied ? (
                                <Check className="h-3 w-3 text-primary" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </Button>
                          </CardDescription>
                        </div>
                        <Button variant="outline" size="sm" asChild>
                          <a 
                            href={`https://browser.ihtsdotools.org/?perspective=full&conceptId1=${selectedConcept.conceptId}&edition=MAIN/SNOMEDCT-DE&release=&languages=de,en`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4 mr-1" />
                            SNOMED Browser
                          </a>
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* AI Explanation */}
                      {translationData.explanation_de && (
                        <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
                          <h4 className="text-sm font-medium mb-1 flex items-center gap-1">
                            <BookOpen className="h-3.5 w-3.5 text-primary" />
                            Erklärung
                            <Badge variant="secondary" className="text-[10px] ml-1 gap-0.5">
                              <Sparkles className="h-2.5 w-2.5" />
                              KI
                            </Badge>
                          </h4>
                          <p className="text-sm text-muted-foreground">{translationData.explanation_de}</p>
                        </div>
                      )}

                      {/* English Original (collapsible) */}
                      <Collapsible open={showEnglishDetails} onOpenChange={handleShowEnglishDetailsChange}>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground">
                            {showEnglishDetails ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronRight className="h-4 w-4" />
                            )}
                            <Globe className="h-4 w-4" />
                            Englische Originalbezeichnungen
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2 pl-4 border-l-2 border-muted space-y-2">
                          <div>
                            <h4 className="text-xs font-medium text-muted-foreground mb-0.5">Preferred Term (EN)</h4>
                            <p className="text-sm italic">{selectedConcept.pt?.term}</p>
                          </div>
                          {selectedConcept.fsn?.term && selectedConcept.fsn.term !== selectedConcept.pt?.term && (
                            <div>
                              <h4 className="text-xs font-medium text-muted-foreground mb-0.5">Fully Specified Name</h4>
                              <p className="text-sm italic">{selectedConcept.fsn.term}</p>
                            </div>
                          )}
                        </CollapsibleContent>
                      </Collapsible>

                      {/* Definition Status */}
                      <div className="flex gap-4">
                        <div>
                          <h4 className="text-xs font-medium text-muted-foreground mb-1">Status</h4>
                          <Badge variant={selectedConcept.active ? 'default' : 'destructive'}>
                            {selectedConcept.active ? 'Aktiv' : 'Inaktiv'}
                          </Badge>
                        </div>
                        <div>
                          <h4 className="text-xs font-medium text-muted-foreground mb-1">Definition</h4>
                          <Badge variant="outline">
                            {selectedConcept.definitionStatus === 'FULLY_DEFINED' 
                              ? 'Vollständig definiert' 
                              : 'Primitiv'}
                          </Badge>
                        </div>
                      </div>

                      {/* ICD-10 Mappings */}
                      {conceptDetails.isLoading ? (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span className="text-sm">Lade Details...</span>
                        </div>
                      ) : (
                        <>
                          {conceptDetails.icd10Mappings && conceptDetails.icd10Mappings.length > 0 && (
                            <div>
                              <h4 className="text-sm font-medium text-muted-foreground mb-2">
                                ICD-10 Mappings
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                {conceptDetails.icd10Mappings.map((mapping, idx) => (
                                  <Tooltip key={idx}>
                                    <TooltipTrigger asChild>
                                      <Badge variant="outline" className="font-mono cursor-help">
                                        {mapping.code}
                                      </Badge>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="text-xs">{mapping.name || mapping.code}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Parents */}
                          {conceptDetails.parents && conceptDetails.parents.length > 0 && (
                            <div>
                              <h4 className="text-sm font-medium text-muted-foreground mb-2">
                                Übergeordnete Konzepte
                              </h4>
                              <div className="space-y-1">
                                {conceptDetails.parents.slice(0, 5).map((parent) => (
                                  <button
                                    key={parent.conceptId}
                                    className="flex items-center gap-2 text-sm hover:text-primary transition-colors w-full text-left"
                                    onClick={() => handleSelect(parent)}
                                  >
                                    <Badge variant="outline" className="text-xs font-mono shrink-0">
                                      {parent.conceptId}
                                    </Badge>
                                    <span className="truncate">{parent.pt?.term}</span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Children preview */}
                          {conceptDetails.children && conceptDetails.children.length > 0 && (
                            <div>
                              <h4 className="text-sm font-medium text-muted-foreground mb-2">
                                Untergeordnete Konzepte ({conceptDetails.children.length}+)
                              </h4>
                              <div className="space-y-1">
                                {conceptDetails.children.slice(0, 5).map((child) => (
                                  <button
                                    key={child.conceptId}
                                    className="flex items-center gap-2 text-sm hover:text-primary transition-colors w-full text-left"
                                    onClick={() => handleSelect(child)}
                                  >
                                    <Badge variant="outline" className="text-xs font-mono shrink-0">
                                      {child.conceptId}
                                    </Badge>
                                    <span className="truncate">{child.pt?.term}</span>
                                  </button>
                                ))}
                                {conceptDetails.children.length > 5 && (
                                  <p className="text-xs text-muted-foreground">
                                    ...und {conceptDetails.children.length - 5} weitere
                                  </p>
                                )}
                              </div>
                            </div>
                          )}
                        </>
                      )}
                    </CardContent>
                  </Card>

                  {/* KI Analysis Panel */}
                  <OntologyAnalysisPanel
                    type="snomed"
                    code={selectedConcept.conceptId}
                    label={selectedConcept.pt?.term || selectedConcept.fsn?.term || selectedConcept.conceptId}
                  />
                </div>
              </ScrollArea>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <Stethoscope className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">Wählen Sie einen SNOMED CT Begriff aus</p>
                  <p className="text-xs mt-1">um Details anzuzeigen</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile Detail Bottom Sheet */}
      {isMobile && (
        <SnomedDetailSheet
          open={detailSheetOpen}
          onOpenChange={setDetailSheetOpen}
          concept={selectedConcept}
          translationData={translationData}
          conceptDetails={conceptDetails}
          sessions={sessions}
          selectedSessionId={selectedSessionId}
          onSessionChange={setSelectedSessionId}
          onAddToSession={addToSession}
          isAddingToSession={isAddingToSession}
          onCopyId={handleCopyId}
          copied={copied}
          showEnglishDetails={showEnglishDetails}
          onShowEnglishDetailsChange={handleShowEnglishDetailsChange}
          onSelectConcept={handleSelect}
        />
      )}
    </div>
  );
}
