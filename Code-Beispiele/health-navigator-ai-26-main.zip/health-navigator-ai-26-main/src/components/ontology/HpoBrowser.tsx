import { useState, useCallback, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { 
  Search, 
  ChevronRight, 
  ChevronDown, 
  ExternalLink, 
  Loader2,
  TreeDeciduous,
  Info,
  Copy,
  Globe,
  Check,
  Plus,
  FileText,
  Sparkles,
  BookOpen,
  X,
  ChevronDown as ChevronDownIcon,
  GraduationCap,
  PanelRightClose,
  PanelRightOpen,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { BulkSyncButton } from './BulkSyncButton';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { TranslationEditor } from '@/components/ontology/TranslationEditor';
import { OntologyAnalysisPanel } from '@/components/ontology/OntologyAnalysisPanel';
import { useProfile } from '@/hooks/useProfile';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { DataSourceBadge, DataSource } from '@/components/ui/data-source-badge';
import { OntologyStatsBar } from './OntologyStatsBar';

interface AnamnesisSession {
  id: string;
  clinical_view: string;
  status: string;
  created_at: string;
  patient_identifier?: string;
}

interface HPOTerm {
  id: string;
  label: string;
  labelOriginal?: string;
  definition?: string;
  synonyms: string[];
  isObsolete: boolean;
  children?: HPOTerm[];
  isLoading?: boolean;
  isTranslating?: boolean;
  isExpanded?: boolean;
  translationSource?: 'official' | 'ai_translated';
  foundViaFallback?: boolean;
  explanationDe?: string;
  isLoadingExplanation?: boolean;
}

interface TreeNodeProps {
  term: HPOTerm;
  level: number;
  onSelect: (term: HPOTerm, isLeaf: boolean) => void;
  onExpand: (term: HPOTerm) => void;
  selectedId?: string;
  bilingualView?: boolean;
}

function TreeNode({ term, level, onSelect, onExpand, selectedId, bilingualView = false }: TreeNodeProps) {
  const hasChildren = term.children && term.children.length > 0;
  const isSelected = term.id === selectedId;
  // A node is a leaf if it's expanded but has no children
  const isLeaf = term.isExpanded && !hasChildren;

  return (
    <div className="select-none">
      <div
        className={cn(
          'flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted active:scale-[0.98]',
          isSelected && 'bg-primary/10 text-primary font-medium ring-1 ring-primary/20'
        )}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={() => onSelect(term, isLeaf)}
      >
        {term.isLoading ? (
          <Loader2 className="h-3.5 w-3.5 md:h-4 md:w-4 animate-spin text-muted-foreground shrink-0" />
        ) : hasChildren || !term.isExpanded ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onExpand(term);
            }}
            className="p-0.5 hover:bg-muted-foreground/20 rounded"
          >
            {term.isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground" />
            )}
          </button>
        ) : (
          <div className="w-4 md:w-5" />
        )}
        
        <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0">
          {term.id}
        </Badge>
        <div className="flex flex-col min-w-0 flex-1">
          <span className="text-xs md:text-sm truncate">
            {term.label}
          </span>
          {bilingualView && term.labelOriginal && term.labelOriginal !== term.label && (
            <span className="text-[10px] md:text-[11px] text-muted-foreground truncate italic">
              {term.labelOriginal}
            </span>
          )}
        </div>
        {term.translationSource === 'ai_translated' && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant="secondary" className="text-[9px] md:text-[10px] px-1 py-0 h-3.5 md:h-4 shrink-0 gap-0.5 cursor-help">
                <Sparkles className="h-2 w-2 md:h-2.5 md:w-2.5" />
                KI
              </Badge>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <p className="text-xs">
                Dieser Begriff wurde automatisch per KI übersetzt.
              </p>
            </TooltipContent>
          </Tooltip>
        )}
        {term.isTranslating && (
          <Badge variant="outline" className="text-[9px] md:text-[10px] px-1 py-0 h-3.5 md:h-4 shrink-0 gap-0.5 bg-primary/5 border-primary/30">
            <Sparkles className="h-2 w-2 md:h-2.5 md:w-2.5 animate-pulse text-primary" />
          </Badge>
        )}
      </div>

      {term.isExpanded && hasChildren && (
        <div className="animate-in slide-in-from-top-1 duration-200">
          {term.children!.map((child) => (
            <TreeNode
              key={child.id}
              term={child}
              level={level + 1}
              onSelect={onSelect}
              onExpand={onExpand}
              selectedId={selectedId}
              bilingualView={bilingualView}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Available HPO languages from OLS4 API
const HPO_LANGUAGES = [
  { code: 'de', name: 'Deutsch', flag: '🇩🇪', coverage: '~19% + KI' },
  { code: 'en', name: 'English', flag: '🇬🇧', coverage: '100%' },
  { code: 'es', name: 'Español', flag: '🇪🇸', coverage: 'teilweise' },
  { code: 'fr', name: 'Français', flag: '🇫🇷', coverage: 'teilweise' },
  { code: 'it', name: 'Italiano', flag: '🇮🇹', coverage: 'teilweise' },
  { code: 'ja', name: '日本語', flag: '🇯🇵', coverage: 'teilweise' },
  { code: 'nl', name: 'Nederlands', flag: '🇳🇱', coverage: 'teilweise' },
  { code: 'pt', name: 'Português', flag: '🇵🇹', coverage: 'teilweise' },
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷', coverage: 'teilweise' },
  { code: 'zh', name: '中文', flag: '🇨🇳', coverage: 'teilweise' },
  { code: 'cs', name: 'Čeština', flag: '🇨🇿', coverage: 'minimal' },
];

// HPO Root category IDs
const PHENOTYPE_CATEGORY_IDS = [
  'HP:0000707', 'HP:0000152', 'HP:0000478', 'HP:0000598', 'HP:0001574',
  'HP:0001626', 'HP:0002086', 'HP:0001871', 'HP:0002715', 'HP:0000818',
  'HP:0000119', 'HP:0001939', 'HP:0025031', 'HP:0003011', 'HP:0000924',
  'HP:0001197', 'HP:0001507', 'HP:0040064', 'HP:0025354',
];

export function HpoBrowser() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { user } = useAuth();
  const { profile, updateProfile } = useProfile();
  const [searchParams] = useSearchParams();
  const preselectedSessionId = searchParams.get('sessionId');
  const prefilledSearch = searchParams.get('search');
  const isMobile = useIsMobile();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<HPOTerm[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedTerm, setSelectedTerm] = useState<HPOTerm | null>(null);
  const [treeData, setTreeData] = useState<HPOTerm[]>([]);
  const [copied, setCopied] = useState(false);
  const [sessions, setSessions] = useState<AnamnesisSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>(preselectedSessionId || '');
  const [isAddingToSession, setIsAddingToSession] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('de');
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);
  const [detailSheetOpen, setDetailSheetOpen] = useState(false);
  const [detailPanelCollapsed, setDetailPanelCollapsed] = useState(false);
  const [explanationData, setExplanationData] = useState<{
    explanation_de?: string;
    explanation_en?: string;
    definition_de?: string;
    definition_en?: string;
    synonyms?: string[];
    isLoading: boolean;
    error?: string;
  } | null>(null);
  const [translationVerified, setTranslationVerified] = useState<boolean>(false);
  const [bilingualView, setBilingualView] = useState<boolean>(false);
  const [showEnglishDetails, setShowEnglishDetails] = useState<boolean>(false);
  const [lastDataSource, setLastDataSource] = useState<DataSource>('unknown');

  // Sync showEnglishDetails with profile setting
  useEffect(() => {
    if (profile?.show_english_details !== undefined) {
      setShowEnglishDetails(profile.show_english_details);
    }
  }, [profile?.show_english_details]);

  const handleShowEnglishDetailsChange = useCallback((open: boolean) => {
    setShowEnglishDetails(open);
    if (profile && profile.show_english_details !== open) {
      updateProfile.mutate({ show_english_details: open });
    }
  }, [profile, updateProfile]);

  const translateTerms = useCallback(async (terms: { id: string; label: string; definition?: string }[]): Promise<Map<string, { label_de: string; source: 'official' | 'ai_translated' }>> => {
    const resultMap = new Map<string, { label_de: string; source: 'official' | 'ai_translated' }>();
    
    if (terms.length === 0 || selectedLanguage !== 'de') return resultMap;

    try {
      const response = await supabase.functions.invoke('hpo-translate', {
        body: {
          terms: terms.map(t => ({
            id: t.id,
            label_en: t.label,
            definition: t.definition,
          })),
        },
      });

      if (response.error) {
        console.error('Translation error:', response.error);
        return resultMap;
      }

      const translations = response.data?.translations || [];
      for (const t of translations) {
        resultMap.set(t.hpo_code, { 
          label_de: t.label_de, 
          source: t.source 
        });
      }
    } catch (error) {
      console.error('Translation fetch error:', error);
    }

    return resultMap;
  }, [selectedLanguage]);

  // Load root categories when language changes - DB first, then API fallback
  useEffect(() => {
    let mounted = true;
    
    const loadRootCategories = async () => {
      setIsLoadingCategories(true);
      setSearchResults([]);
      setSelectedTerm(null);
      
      try {
        // First: Try to load from local database
        const { data: localCodes, error: dbError } = await supabase
          .from('hpo_codes')
          .select('*')
          .in('hpo_code', PHENOTYPE_CATEGORY_IDS);
        
        if (!dbError && localCodes && localCodes.length === PHENOTYPE_CATEGORY_IDS.length) {
          // All root categories found in DB
          console.log(`[HPO] Loaded ${localCodes.length} root categories from database`);
          setLastDataSource('local');
          
          const categories: HPOTerm[] = localCodes.map(code => {
            const labels = code.labels as Record<string, string> | null;
            const definitions = code.definitions as Record<string, string> | null;
            const labelDe = labels?.de;
            const labelEn = labels?.en || code.label;
            const definitionDe = definitions?.de;
            
            return {
              id: code.hpo_code,
              label: selectedLanguage === 'de' && labelDe ? labelDe : code.label,
              labelOriginal: labelEn,
              definition: selectedLanguage === 'de' && definitionDe ? definitionDe : code.definition || undefined,
              synonyms: code.synonyms || [],
              isObsolete: false,
              translationSource: labelDe ? 'official' as const : undefined,
            };
          });
          
          if (mounted) setTreeData(categories);
          return;
        }
        
        // Fallback: Load from API
        console.log(`[HPO] Root categories not in DB (found ${localCodes?.length || 0}/${PHENOTYPE_CATEGORY_IDS.length}), fetching from API...`);
        setLastDataSource('api');
        
        const categories: HPOTerm[] = await Promise.all(
          PHENOTYPE_CATEGORY_IDS.map(async (hpoId) => {
            const iri = encodeURIComponent(encodeURIComponent(`http://purl.obolibrary.org/obo/${hpoId.replace(':', '_')}`));
            
            try {
              const [langResponse, enResponse] = await Promise.all([
                fetch(`https://www.ebi.ac.uk/ols4/api/ontologies/hp/terms/${iri}?lang=${selectedLanguage}`),
                selectedLanguage !== 'en' 
                  ? fetch(`https://www.ebi.ac.uk/ols4/api/ontologies/hp/terms/${iri}?lang=en`)
                  : Promise.resolve(null),
              ]);
              
              if (!langResponse.ok) {
                return { id: hpoId, label: hpoId, synonyms: [], isObsolete: false };
              }
              
              const langData = await langResponse.json();
              const enData = enResponse && enResponse.ok ? await enResponse.json() : null;
              
              const localLabel = langData.label || hpoId;
              const enLabel = enData?.label || localLabel;
              const hasOfficialTranslation = selectedLanguage !== 'en' && localLabel !== enLabel;
              
              return {
                id: hpoId,
                label: localLabel,
                labelOriginal: enLabel,
                definition: langData.description?.[0],
                synonyms: langData.synonyms || [],
                isObsolete: false,
                translationSource: hasOfficialTranslation ? 'official' as const : undefined,
              };
            } catch {
              return { id: hpoId, label: hpoId, synonyms: [], isObsolete: false };
            }
          })
        );
        
        if (selectedLanguage === 'de') {
          const untranslatedCategories = categories.filter(
            c => !c.translationSource && c.label === c.labelOriginal
          );
          
          if (untranslatedCategories.length > 0) {
            const translations = await translateTerms(
              untranslatedCategories.map(c => ({
                id: c.id,
                label: c.labelOriginal || c.label,
                definition: c.definition,
              }))
            );
            
            for (const category of categories) {
              const translation = translations.get(category.id);
              if (translation && translation.label_de !== category.labelOriginal) {
                category.label = translation.label_de;
                category.translationSource = translation.source;
              }
            }
          }
        }
        
        if (mounted) setTreeData(categories);
      } catch (error) {
        console.error('Error loading root categories:', error);
      } finally {
        if (mounted) setIsLoadingCategories(false);
      }
    };
    
    loadRootCategories();
    return () => { mounted = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLanguage]);

  // Handle prefilled search from URL params (e.g., from ICD-10 analysis link)
  useEffect(() => {
    if (prefilledSearch && !isLoadingCategories) {
      setSearchQuery(prefilledSearch);
      // Trigger search after a short delay to ensure component is mounted
      const timer = setTimeout(async () => {
        setIsSearching(true);
        try {
          const { data, error } = await supabase.functions.invoke('hpo-lookup', {
            body: {
              q: prefilledSearch,
              limit: 20,
              lang: selectedLanguage,
            },
          });

          if (!error && data) {
            const hpoOnly = Array.isArray(data) 
              ? data.filter((term: HPOTerm) => term.id && term.id.startsWith('HP:'))
              : [];
            setSearchResults(hpoOnly);
            // Auto-select if exact match found
            const exactMatch = hpoOnly.find((t: HPOTerm) => t.id === prefilledSearch);
            if (exactMatch) {
              setSelectedTerm(exactMatch);
              if (isMobile) setDetailSheetOpen(true);
            }
          }
        } catch (err) {
          console.error('Prefilled search error:', err);
        } finally {
          setIsSearching(false);
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [prefilledSearch, isLoadingCategories, selectedLanguage, isMobile]);

  // Load active sessions
  useEffect(() => {
    const loadSessions = async () => {
      if (!user) return;
      
      const { data, error } = await supabase
        .from('anamnesis_sessions')
        .select('id, clinical_view, status, created_at, patient_identifier')
        .eq('user_id', user.id)
        .eq('status', 'in_progress')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (!error && data) {
        setSessions(data);
        if (preselectedSessionId && data.some(s => s.id === preselectedSessionId)) {
          setSelectedSessionId(preselectedSessionId);
        } else if (data.length > 0 && !selectedSessionId) {
          setSelectedSessionId(data[0].id);
        }
      }
    };
    
    loadSessions();
  }, [user, preselectedSessionId]);

  // Fetch explanation when term selected
  useEffect(() => {
    if (!selectedTerm || selectedLanguage !== 'de') {
      setExplanationData(null);
      return;
    }

    const fetchExplanation = async () => {
      setExplanationData({ isLoading: true });

      try {
        const { data, error } = await supabase.functions.invoke('hpo-explain', {
          body: {
            hpo_code: selectedTerm.id,
            label_en: selectedTerm.labelOriginal || selectedTerm.label,
            definition: selectedTerm.definition,
            synonyms: selectedTerm.synonyms,
          },
        });

        if (error) throw error;

        setExplanationData({
          explanation_de: data.explanation_de,
          explanation_en: data.explanation_en,
          definition_de: data.definition_de,
          definition_en: data.definition_en || selectedTerm.definition,
          synonyms: data.synonyms || selectedTerm.synonyms,
          isLoading: false,
        });
      } catch (err) {
        console.error('Error fetching explanation:', err);
        setExplanationData({
          isLoading: false,
          error: 'Daten konnten nicht geladen werden.',
        });
      }
    };

    fetchExplanation();
  }, [selectedTerm?.id, selectedLanguage]);

  const addToSession = async () => {
    if (!selectedTerm || !selectedSessionId) {
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Bitte wählen Sie einen Begriff und eine Session aus.',
      });
      return;
    }

    setIsAddingToSession(true);
    try {
      const { error } = await supabase
        .from('observations')
        .insert({
          session_id: selectedSessionId,
          raw_input: selectedTerm.label,
          normalized_value: selectedTerm.label,
          hpo_codes: [selectedTerm.id],
          language: 'de',
          provenance: 'ontology_browser',
          confidence: 1.0,
        });

      if (error) throw error;

      toast({
        title: 'Erfolgreich hinzugefügt',
        description: `"${selectedTerm.label}" (${selectedTerm.id}) wurde zur Anamnese hinzugefügt.`,
      });
    } catch (error) {
      console.error('Error adding to session:', error);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Der Begriff konnte nicht hinzugefügt werden.',
      });
    } finally {
      setIsAddingToSession(false);
    }
  };

  const formatSessionLabel = (session: AnamnesisSession) => {
    const date = new Date(session.created_at);
    const dateStr = date.toLocaleDateString('de-DE', { 
      day: '2-digit', 
      month: '2-digit', 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    const viewLabel = session.clinical_view.charAt(0).toUpperCase() + session.clinical_view.slice(1);
    return `${viewLabel} - ${dateStr}${session.patient_identifier ? ` (${session.patient_identifier})` : ''}`;
  };

  const fetchChildren = useCallback(async (parentId: string): Promise<HPOTerm[]> => {
    try {
      const iri = encodeURIComponent(encodeURIComponent(`http://purl.obolibrary.org/obo/${parentId.replace(':', '_')}`));
      
      const [langResponse, enResponse] = await Promise.all([
        fetch(`https://www.ebi.ac.uk/ols4/api/ontologies/hp/terms/${iri}/children?size=100&lang=${selectedLanguage}`),
        selectedLanguage !== 'en' 
          ? fetch(`https://www.ebi.ac.uk/ols4/api/ontologies/hp/terms/${iri}/children?size=100&lang=en`)
          : Promise.resolve(null),
      ]);
      
      if (!langResponse.ok) return [];
      
      const langData = await langResponse.json();
      const enData = enResponse && enResponse.ok ? await enResponse.json() : null;
      
      const enLabels = new Map<string, string>(
        enData?._embedded?.terms?.map((term: Record<string, unknown>) => [
          term.obo_id as string,
          term.label as string,
        ]) || []
      );
      
      const children: HPOTerm[] = (langData._embedded?.terms || [])
        .map((term: Record<string, unknown>) => {
          const id = term.obo_id as string;
          const localLabel = term.label as string;
          const enLabel = enLabels.get(id) || localLabel;
          const hasOfficialTranslation = selectedLanguage !== 'en' && localLabel !== enLabel;
          
          return {
            id,
            label: localLabel,
            labelOriginal: enLabel,
            definition: (term.description as string[])?.[0],
            synonyms: (term.synonyms as string[]) || [],
            isObsolete: term.is_obsolete as boolean,
            translationSource: hasOfficialTranslation ? 'official' as const : undefined,
            isTranslating: !hasOfficialTranslation && selectedLanguage === 'de',
          };
        })
        .filter((t: HPOTerm) => !t.isObsolete);
      
      if (selectedLanguage === 'de') {
        const untranslatedTerms = children.filter(t => !t.translationSource);
        
        if (untranslatedTerms.length > 0) {
          const translations = await translateTerms(
            untranslatedTerms.map(t => ({
              id: t.id,
              label: t.labelOriginal || t.label,
              definition: t.definition,
            }))
          );
          
          for (const child of children) {
            const translation = translations.get(child.id);
            if (translation && translation.label_de) {
              child.label = translation.label_de;
              child.translationSource = translation.source;
            }
            child.isTranslating = false;
          }
        }
      }
      
      return children;
    } catch (error) {
      console.error('Error fetching children:', error);
      return [];
    }
  }, [selectedLanguage, translateTerms]);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const query = searchQuery.trim();
      
      // Check if input looks like an HPO code (HP:0001234, HP0001234, or just 0001234/1234)
      const hpoCodeMatch = query.match(/^(?:HP[:\-_]?)?(\d{1,7})$/i);
      
      if (hpoCodeMatch) {
        // User entered a code - try to validate it directly
        const numericPart = hpoCodeMatch[1].padStart(7, '0');
        const fullCode = `HP:${numericPart}`;
        
        const { data: validationResult, error: valError } = await supabase.functions.invoke('hpo-lookup', {
          body: {
            action: 'validate',
            codes: [fullCode],
            lang: selectedLanguage,
          },
        });

        if (!valError && validationResult?.validations) {
          const validatedTerm = validationResult.validations[0];
          if (validatedTerm) {
            // Found exact code match
            setSearchResults([{
              id: validatedTerm.id,
              label: validatedTerm.label,
              labelOriginal: validatedTerm.label,
              definition: validatedTerm.definition,
              synonyms: validatedTerm.synonyms || [],
              isObsolete: validatedTerm.isObsolete || false,
            }]);
            setIsSearching(false);
            return;
          }
        }
        // If validation failed, fall through to text search
      }
      
      // Regular text search
      const { data, error } = await supabase.functions.invoke('hpo-lookup', {
        body: {
          action: 'search',
          q: query,
          limit: 20,
          lang: selectedLanguage,
        },
      });

      if (error) throw error;
      
      const hpoOnly = Array.isArray(data) 
        ? data.filter((term: HPOTerm) => term.id && term.id.startsWith('HP:'))
        : [];
      setSearchResults(hpoOnly);
    } catch (error) {
      console.error('Search error:', error);
      toast({
        variant: 'destructive',
        title: 'Suche fehlgeschlagen',
        description: 'Die HPO-Suche konnte nicht durchgeführt werden.',
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleExpand = useCallback(async (term: HPOTerm) => {
    if (term.isExpanded) {
      setTreeData(prev => updateTermInTree(prev, term.id, { isExpanded: false }));
      return;
    }

    setTreeData(prev => updateTermInTree(prev, term.id, { isLoading: true, isExpanded: true }));

    const children = await fetchChildren(term.id);
    
    setTreeData(prev => updateTermInTree(prev, term.id, { 
      isLoading: false, 
      isExpanded: true,
      children 
    }));
  }, [fetchChildren]);

  const updateTermInTree = (
    terms: HPOTerm[], 
    targetId: string, 
    updates: Partial<HPOTerm>
  ): HPOTerm[] => {
    return terms.map(term => {
      if (term.id === targetId) {
        return { ...term, ...updates };
      }
      if (term.children) {
        return { ...term, children: updateTermInTree(term.children, targetId, updates) };
      }
      return term;
    });
  };

  // Handle term selection - on mobile, only open details for leaf nodes or search results
  const handleSelect = (term: HPOTerm, isLeaf: boolean = false) => {
    setSelectedTerm(term);
    setTranslationVerified(false);
    
    // On mobile: open drawer only for leaf nodes or search results
    if (isMobile && (isLeaf || searchResults.length > 0)) {
      setDetailSheetOpen(true);
    }
    // On desktop: expand detail panel if collapsed
    if (!isMobile && detailPanelCollapsed) {
      setDetailPanelCollapsed(false);
    }
  };

  const handleCopyId = () => {
    if (selectedTerm) {
      navigator.clipboard.writeText(selectedTerm.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Search and Language Selector */}
      <div className="p-2 md:p-4 border-b">
        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Input
              placeholder={isMobile 
                ? "HPO suchen..." 
                : selectedLanguage === 'de' 
                  ? "Nach Symptomen suchen (z.B. Kopfschmerzen, HP:0001250)..." 
                  : "Search for symptoms (e.g., Headache, HP:0001250)..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="pr-8 h-9 md:h-10 text-sm"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSearchResults([]);
                }}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Suche löschen"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <Button onClick={handleSearch} disabled={isSearching} size={isMobile ? "sm" : "default"}>
            {isSearching ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
          </Button>
          
          {/* Language Selector */}
          <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
            <SelectTrigger className={cn("shrink-0", isMobile ? "w-[100px]" : "w-[160px]")}>
              <Globe className="h-4 w-4 mr-1 md:mr-2 text-muted-foreground" />
              <SelectValue>
                {HPO_LANGUAGES.find(l => l.code === selectedLanguage)?.flag}{' '}
                {!isMobile && HPO_LANGUAGES.find(l => l.code === selectedLanguage)?.name}
              </SelectValue>
            </SelectTrigger>
            <SelectContent className="z-50 bg-popover">
              {HPO_LANGUAGES.map((lang) => (
                <SelectItem key={lang.code} value={lang.code}>
                  <span className="flex items-center gap-2">
                    <span>{lang.flag}</span>
                    <span>{lang.name}</span>
                    <span className="text-xs text-muted-foreground ml-auto">({lang.coverage})</span>
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Bilingual Toggle - Hidden on mobile */}
          {!isMobile && selectedLanguage !== 'en' && (
            <div className="flex items-center gap-2 ml-2">
              <Switch
                id="bilingual-mode"
                checked={bilingualView}
                onCheckedChange={setBilingualView}
              />
              <Label htmlFor="bilingual-mode" className="text-sm text-muted-foreground cursor-pointer">
                {selectedLanguage === 'de' ? 'Zweisprachig' : 'Bilingual'}
              </Label>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex min-h-0">
        {/* Tree / Search Results - Full width on mobile or when details panel is collapsed */}
        <div className={cn(
          'flex flex-col min-h-0 transition-all duration-300',
          isMobile ? 'w-full' : detailPanelCollapsed ? 'flex-1' : 'w-1/2 border-r'
        )}>
          <div className="p-2 border-b bg-muted/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs md:text-sm font-medium text-muted-foreground">
                {searchResults.length > 0 
                  ? `${searchResults.length} Suchergebnisse` 
                  : 'Phänotyp-Kategorien'
                }
              </span>
              <OntologyStatsBar source="hpo" showLabel={!isMobile} />
              {lastDataSource !== 'unknown' && (
                <DataSourceBadge source={lastDataSource} />
              )}
            </div>
            <div className="flex items-center gap-2">
              <BulkSyncButton source="hpo" />
              {searchResults.length > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 text-xs"
                  onClick={() => setSearchResults([])}
                >
                  Zurück
                </Button>
              )}
              {/* Desktop: Toggle detail panel */}
              {!isMobile && selectedTerm && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0"
                  onClick={() => setDetailPanelCollapsed(!detailPanelCollapsed)}
                >
                  {detailPanelCollapsed ? (
                    <PanelRightOpen className="h-4 w-4" />
                  ) : (
                    <PanelRightClose className="h-4 w-4" />
                  )}
                </Button>
              )}
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-1.5 md:p-2">
              {searchResults.length > 0 ? (
                <div className="space-y-0.5">
                  {searchResults.map((term) => (
                    <div
                      key={term.id}
                      className={cn(
                        'flex items-center gap-2 py-1.5 md:py-2 px-2 md:px-3 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted active:scale-[0.98]',
                        selectedTerm?.id === term.id && 'bg-primary/10 text-primary ring-1 ring-primary/20'
                      )}
                      onClick={() => handleSelect(term, true)}
                    >
                      <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0">
                        {term.id}
                      </Badge>
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="text-xs md:text-sm truncate">{term.label}</span>
                        {bilingualView && term.labelOriginal && term.labelOriginal !== term.label && (
                          <span className="text-[10px] md:text-[11px] text-muted-foreground truncate italic">
                            {term.labelOriginal}
                          </span>
                        )}
                      </div>
                      {term.foundViaFallback && (
                        <Badge variant="secondary" className="text-[9px] md:text-[10px] px-1 py-0 h-3.5 md:h-4 shrink-0 gap-0.5">
                          <Sparkles className="h-2 w-2 md:h-2.5 md:w-2.5" />
                          KI
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              ) : isLoadingCategories ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-5 w-5 md:h-6 md:w-6 animate-spin text-muted-foreground" />
                  <span className="ml-2 text-xs md:text-sm text-muted-foreground">
                    Kategorien werden geladen...
                  </span>
                </div>
              ) : (
                <div>
                  {treeData.map((term) => (
                    <TreeNode
                      key={term.id}
                      term={term}
                      level={0}
                      onSelect={handleSelect}
                      onExpand={handleExpand}
                      selectedId={selectedTerm?.id}
                      bilingualView={bilingualView}
                    />
                  ))}
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Details Panel - Desktop only, collapsible */}
        {!isMobile && !detailPanelCollapsed && (
          <div className="w-1/2 flex flex-col min-h-0 animate-in slide-in-from-right duration-300">
            {selectedTerm ? (
              <ScrollArea className="flex-1">
                <div className="p-4 space-y-4">
                  {/* Add to Session Card */}
                  {sessions.length > 0 && (
                    <Card className="border-primary/30 bg-primary/5">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          Zur Anamnese hinzufügen
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex gap-2">
                          <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Session wählen..." />
                            </SelectTrigger>
                            <SelectContent>
                              {sessions.map((session) => (
                                <SelectItem key={session.id} value={session.id}>
                                  {formatSessionLabel(session)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button 
                            onClick={addToSession}
                            disabled={!selectedSessionId || isAddingToSession}
                            className="shrink-0"
                          >
                            {isAddingToSession ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Plus className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <Card>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <div className="flex flex-col">
                              <CardTitle className="text-xl">{selectedTerm.label}</CardTitle>
                              {bilingualView && selectedLanguage !== 'en' && selectedTerm.labelOriginal && selectedTerm.labelOriginal !== selectedTerm.label && (
                                <span className="text-sm text-muted-foreground italic flex items-center gap-1.5 mt-0.5">
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4">EN</Badge>
                                  {selectedTerm.labelOriginal}
                                </span>
                              )}
                            </div>
                            {selectedTerm.translationSource === 'ai_translated' && (
                              <Badge variant="secondary" className="text-xs gap-1">
                                <Sparkles className="h-3 w-3" />
                                KI
                              </Badge>
                            )}
                            <TranslationEditor
                              hpoCode={selectedTerm.id}
                              labelEn={selectedTerm.labelOriginal || selectedTerm.label}
                              labelDe={selectedTerm.label}
                              definitionDe={explanationData?.definition_de}
                              translationSource={selectedTerm.translationSource}
                              isVerified={translationVerified}
                              onUpdate={(newLabel) => {
                                setSelectedTerm(prev => prev ? { ...prev, label: newLabel } : null);
                                setTranslationVerified(true);
                              }}
                            />
                          </div>
                          <CardDescription className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="font-mono">
                              {selectedTerm.id}
                            </Badge>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 px-2"
                              onClick={handleCopyId}
                            >
                              {copied ? (
                                <Check className="h-3 w-3 text-primary" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </Button>
                          </CardDescription>
                        </div>
                        <Button variant="outline" size="sm" asChild>
                          <a 
                            href={`https://hpo.jax.org/browse/term/${selectedTerm.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4 mr-1" />
                            JAX
                          </a>
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Definition */}
                      {selectedTerm.definition && (
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground mb-1 flex items-center gap-1">
                            <Info className="h-3 w-3" />
                            Definition
                          </h4>
                          {bilingualView && selectedLanguage !== 'en' ? (
                            <div className="space-y-2">
                              <div className="flex gap-2">
                                <Badge variant="outline" className="text-[10px] shrink-0">{selectedLanguage.toUpperCase()}</Badge>
                                <p className="text-sm">
                                  {selectedLanguage === 'de' 
                                    ? (explanationData?.definition_de || selectedTerm.definition)
                                    : selectedTerm.definition
                                  }
                                </p>
                              </div>
                              <div className="flex gap-2 text-muted-foreground">
                                <Badge variant="secondary" className="text-[10px] shrink-0">EN</Badge>
                                <p className="text-sm italic">
                                  {explanationData?.definition_en || selectedTerm.definition}
                                </p>
                              </div>
                            </div>
                          ) : selectedLanguage === 'de' ? (
                            <p className="text-sm">
                              {explanationData?.definition_de || selectedTerm.definition}
                            </p>
                          ) : (
                            <p className="text-sm">
                              {explanationData?.definition_en || selectedTerm.definition}
                            </p>
                          )}

                          {/* Collapsible English Original */}
                          {!bilingualView && selectedLanguage !== 'en' && (explanationData?.definition_en || selectedTerm.definition) && (
                            <Collapsible 
                              className="mt-3" 
                              open={showEnglishDetails}
                              onOpenChange={handleShowEnglishDetailsChange}
                            >
                              <CollapsibleTrigger className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors group">
                                <ChevronDownIcon className="h-3 w-3 transition-transform group-data-[state=open]:rotate-180" />
                                <GraduationCap className="h-3 w-3" />
                                <span>Original (EN) für Fachpersonal</span>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="mt-2 pl-4 border-l-2 border-muted">
                                <p className="text-sm text-muted-foreground italic">
                                  {explanationData?.definition_en || selectedTerm.definition}
                                </p>
                              </CollapsibleContent>
                            </Collapsible>
                          )}
                        </div>
                      )}

                      {/* AI Explanation */}
                      {(selectedLanguage === 'de' || selectedLanguage === 'en') && (
                        <div className="border-t pt-4">
                          <h4 className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
                            <BookOpen className="h-3 w-3" />
                            Erklärung
                            <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4 gap-0.5 ml-1">
                              <Sparkles className="h-2.5 w-2.5" />
                              KI
                            </Badge>
                          </h4>
                          {explanationData?.isLoading ? (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Loader2 className="h-4 w-4 animate-spin" />
                              <span className="text-sm">Erklärung wird generiert...</span>
                            </div>
                          ) : explanationData?.error ? (
                            <p className="text-sm text-destructive">{explanationData.error}</p>
                          ) : bilingualView && selectedLanguage !== 'en' && (explanationData?.explanation_de || explanationData?.explanation_en) ? (
                            <div className="space-y-3">
                              {explanationData?.explanation_de && (
                                <div className="flex gap-2">
                                  <Badge variant="outline" className="text-[10px] shrink-0 mt-0.5">DE</Badge>
                                  <p className="text-sm text-foreground whitespace-pre-wrap">
                                    {explanationData.explanation_de}
                                  </p>
                                </div>
                              )}
                              {explanationData?.explanation_en && (
                                <div className="flex gap-2 text-muted-foreground">
                                  <Badge variant="secondary" className="text-[10px] shrink-0 mt-0.5">EN</Badge>
                                  <p className="text-sm italic whitespace-pre-wrap">
                                    {explanationData.explanation_en}
                                  </p>
                                </div>
                              )}
                            </div>
                          ) : (selectedLanguage === 'de' ? explanationData?.explanation_de : explanationData?.explanation_en) ? (
                            <p className="text-sm text-foreground whitespace-pre-wrap">
                              {selectedLanguage === 'de' ? explanationData?.explanation_de : explanationData?.explanation_en}
                            </p>
                          ) : null}
                          
                          {/* Collapsible English Explanation */}
                          {!bilingualView && selectedLanguage === 'de' && explanationData?.explanation_en && !explanationData?.isLoading && (
                            <Collapsible 
                              className="mt-3"
                              open={showEnglishDetails}
                              onOpenChange={handleShowEnglishDetailsChange}
                            >
                              <CollapsibleTrigger className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors group">
                                <ChevronDownIcon className="h-3 w-3 transition-transform group-data-[state=open]:rotate-180" />
                                <GraduationCap className="h-3 w-3" />
                                <span>Original (EN) für Fachpersonal</span>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="mt-2 pl-4 border-l-2 border-muted">
                                <p className="text-sm text-muted-foreground italic whitespace-pre-wrap">
                                  {explanationData.explanation_en}
                                </p>
                              </CollapsibleContent>
                            </Collapsible>
                          )}
                        </div>
                      )}
                      
                      {/* Synonyms */}
                      {(explanationData?.synonyms?.length || selectedTerm.synonyms?.length) ? (
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground mb-2">
                            Synonyme
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {(explanationData?.synonyms || selectedTerm.synonyms || []).map((syn, i) => (
                              <Badge key={i} variant="outline" className="text-xs">
                                {syn}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ) : null}
                    </CardContent>
                  </Card>

                  {/* Quick Links */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Externe Ressourcen</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" size="sm" asChild className="justify-start">
                          <a 
                            href={`https://hpo.jax.org/browse/term/${selectedTerm.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-3 w-3 mr-2" />
                            JAX HPO Browser
                          </a>
                        </Button>
                        <Button variant="outline" size="sm" asChild className="justify-start">
                          <a 
                            href={`https://www.ebi.ac.uk/ols4/ontologies/hp/classes?obo_id=${selectedTerm.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-3 w-3 mr-2" />
                            EBI OLS
                          </a>
                        </Button>
                        <Button variant="outline" size="sm" asChild className="justify-start">
                          <a 
                            href={`https://monarchinitiative.org/${selectedTerm.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-3 w-3 mr-2" />
                            Monarch Initiative
                          </a>
                        </Button>
                        <Button variant="outline" size="sm" asChild className="justify-start">
                          <a 
                            href={`https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(selectedTerm.label)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-3 w-3 mr-2" />
                            PubMed Suche
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* KI Analysis Panel */}
                  <OntologyAnalysisPanel
                    type="hpo"
                    code={selectedTerm.id}
                    label={selectedTerm.label}
                  />
                </div>
              </ScrollArea>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <TreeDeciduous className="h-16 w-16 mx-auto mb-4 opacity-30" />
                  <p>Wählen Sie einen Begriff aus dem Baum</p>
                  <p className="text-sm">oder suchen Sie nach Symptomen</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile Detail Drawer */}
      {isMobile && (
        <Drawer open={detailSheetOpen} onOpenChange={setDetailSheetOpen}>
          <DrawerContent className="max-h-[85vh]">
            <DrawerHeader className="pb-2">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <DrawerTitle className="text-base truncate">
                    {selectedTerm?.label}
                  </DrawerTitle>
                  {selectedTerm && (
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary" className="font-mono text-xs">
                        {selectedTerm.id}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2"
                        onClick={handleCopyId}
                      >
                        {copied ? (
                          <Check className="h-3 w-3 text-primary" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </Button>
                    </div>
                  )}
                </div>
                <DrawerClose asChild>
                  <Button variant="ghost" size="icon" className="shrink-0 h-8 w-8">
                    <X className="h-4 w-4" />
                  </Button>
                </DrawerClose>
              </div>
            </DrawerHeader>

            <ScrollArea className="flex-1 px-4" style={{ maxHeight: 'calc(85vh - 140px)' }}>
              {selectedTerm && (
                <div className="space-y-4 pb-4">
                  {/* Add to Session */}
                  {sessions.length > 0 && (
                    <Card className="border-primary/30 bg-primary/5">
                      <CardHeader className="py-2 px-3">
                        <CardTitle className="text-xs flex items-center gap-2">
                          <FileText className="h-3.5 w-3.5" />
                          Zur Anamnese hinzufügen
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="py-2 px-3">
                        <div className="flex gap-2">
                          <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
                            <SelectTrigger className="flex-1 h-8 text-xs">
                              <SelectValue placeholder="Session wählen..." />
                            </SelectTrigger>
                            <SelectContent>
                              {sessions.map((session) => (
                                <SelectItem key={session.id} value={session.id} className="text-xs">
                                  {formatSessionLabel(session)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button 
                            onClick={addToSession}
                            disabled={!selectedSessionId || isAddingToSession}
                            size="sm"
                            className="shrink-0 h-8"
                          >
                            {isAddingToSession ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Plus className="h-3.5 w-3.5" />
                            )}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Definition */}
                  {(selectedTerm.definition || explanationData?.definition_de) && (
                    <div>
                      <h4 className="text-xs font-medium text-muted-foreground mb-1 flex items-center gap-1">
                        <Info className="h-3 w-3" />
                        Definition
                      </h4>
                      <p className="text-xs leading-relaxed">
                        {explanationData?.definition_de || selectedTerm.definition}
                      </p>
                    </div>
                  )}

                  {/* AI Explanation */}
                  {explanationData?.explanation_de && (
                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
                      <h4 className="text-xs font-medium mb-1 flex items-center gap-1">
                        <BookOpen className="h-3 w-3 text-primary" />
                        Erklärung
                        <Badge variant="secondary" className="text-[10px] ml-1 gap-0.5">
                          <Sparkles className="h-2 w-2" />
                          KI
                        </Badge>
                      </h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {explanationData.explanation_de}
                      </p>
                    </div>
                  )}

                  {explanationData?.isLoading && (
                    <div className="flex items-center gap-2 text-muted-foreground py-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span className="text-xs">Lade Details...</span>
                    </div>
                  )}

                  {/* Synonyms */}
                  {(explanationData?.synonyms?.length || selectedTerm.synonyms?.length) ? (
                    <div>
                      <h4 className="text-xs font-medium text-muted-foreground mb-2">
                        Synonyme
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {(explanationData?.synonyms || selectedTerm.synonyms || []).slice(0, 6).map((syn, i) => (
                          <Badge key={i} variant="outline" className="text-[10px]">
                            {syn}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              )}
            </ScrollArea>

            <DrawerFooter className="pt-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => selectedTerm && window.open(
                  `https://hpo.jax.org/browse/term/${selectedTerm.id}`,
                  '_blank'
                )}
              >
                <ExternalLink className="h-3.5 w-3.5 mr-2" />
                Im JAX Browser öffnen
              </Button>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      )}
    </div>
  );
}
