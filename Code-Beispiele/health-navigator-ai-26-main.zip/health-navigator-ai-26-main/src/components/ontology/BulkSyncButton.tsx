import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  Download, 
  Loader2, 
  Pause, 
  Play, 
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Clock,
  RefreshCw,
} from 'lucide-react';
import { useBulkSync, SyncSource, SyncProgress, VersionCheckResult } from '@/hooks/useBulkSync';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface BulkSyncButtonProps {
  source: SyncSource;
  label?: string;
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
}

const SOURCE_LABELS: Record<SyncSource, string> = {
  hpo: 'HPO',
  snomed: 'SNOMED CT',
  icd11: 'ICD-11',
  orphanet: 'Orphanet',
};

const SOURCE_DESCRIPTIONS: Record<SyncSource, string> = {
  hpo: 'Human Phenotype Ontology (~17.000 Begriffe)',
  snomed: 'SNOMED CT Terminologie (~400.000 Konzepte)',
  icd11: 'ICD-11 Klassifikation (~35.000 Codes)',
  orphanet: 'Orphanet seltene Erkrankungen (~13.000 Einträge)',
};

function formatNumber(num: number): string {
  return new Intl.NumberFormat('de-DE').format(num);
}

function getStatusIcon(status: SyncProgress['status'] | undefined) {
  switch (status) {
    case 'running':
      return <Loader2 className="h-3 w-3 animate-spin" />;
    case 'completed':
      return <CheckCircle2 className="h-3 w-3 text-emerald-500" />;
    case 'error':
      return <AlertCircle className="h-3 w-3 text-destructive" />;
    case 'paused':
      return <Pause className="h-3 w-3 text-amber-500" />;
    default:
      return <Clock className="h-3 w-3 text-muted-foreground" />;
  }
}

function getStatusLabel(status: SyncProgress['status'] | undefined): string {
  switch (status) {
    case 'running':
      return 'Läuft...';
    case 'completed':
      return 'Abgeschlossen';
    case 'error':
      return 'Fehler';
    case 'paused':
      return 'Pausiert';
    default:
      return 'Bereit';
  }
}

export function BulkSyncButton({ 
  source, 
  label,
  className,
  variant = 'outline',
  size = 'sm',
}: BulkSyncButtonProps) {
  const { toast } = useToast();
  const [showConfirm, setShowConfirm] = useState(false);
  const [showVersionDialog, setShowVersionDialog] = useState(false);
  const [versionCheckResult, setVersionCheckResult] = useState<VersionCheckResult | null>(null);
  const [isCheckingVersion, setIsCheckingVersion] = useState(false);
  const [hasAutoResumed, setHasAutoResumed] = useState(false);
  
  const { 
    startSync, 
    pauseSync, 
    resumeSync, 
    resetSync,
    getProgress, 
    isSyncing,
    loadSyncStatus,
    checkVersion,
  } = useBulkSync({
    onComplete: (src) => {
      toast({
        title: 'Synchronisation abgeschlossen',
        description: `${SOURCE_LABELS[src]} wurde erfolgreich synchronisiert.`,
      });
    },
    onError: (src, error) => {
      toast({
        variant: 'destructive',
        title: 'Synchronisationsfehler',
        description: `${SOURCE_LABELS[src]}: ${error}`,
      });
    },
  });

  const progress = getProgress(source);
  const syncing = isSyncing(source);
  const displayLabel = label || SOURCE_LABELS[source];

  // Check if this source supports version checking (HPO, SNOMED, ICD-11)
  const supportsVersionCheck = source === 'hpo' || source === 'snomed' || source === 'icd11';

  // Auto-resume ONLY ONCE if status is "running" on mount (e.g., after page refresh)
  // Use a ref-like flag to prevent multiple resumes
  useEffect(() => {
    if (progress?.status === 'running' && !syncing && !hasAutoResumed) {
      // The status is "running" but the client loop isn't active -> auto-resume
      console.log(`[BulkSyncButton] Auto-resuming ${source} sync (saved cursor present: ${!!progress.last_cursor})`);
      setHasAutoResumed(true);
      resumeSync(source);
    }
  }, [progress?.status, syncing, source, resumeSync, hasAutoResumed]);

  // Reset auto-resume flag when sync completes or pauses
  useEffect(() => {
    if (progress?.status === 'completed' || progress?.status === 'paused' || progress?.status === 'error') {
      setHasAutoResumed(false);
    }
  }, [progress?.status]);

  // Warn user before leaving page during sync
  useEffect(() => {
    if (syncing) {
      const handleBeforeUnload = (e: BeforeUnloadEvent) => {
        e.preventDefault();
        e.returnValue = 'Der Sync-Vorgang läuft noch. Möchten Sie die Seite wirklich verlassen?';
        return e.returnValue;
      };
      window.addEventListener('beforeunload', handleBeforeUnload);
      return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    }
  }, [syncing]);

  // Refresh status periodically while syncing (less frequent to reduce conflicts)
  useEffect(() => {
    if (syncing) {
      const interval = setInterval(() => {
        loadSyncStatus(source);
      }, 5000); // Increased from 2s to 5s to reduce conflicts
      return () => clearInterval(interval);
    }
  }, [syncing, source, loadSyncStatus]);

  const handleStartWithVersionCheck = async () => {
    if (supportsVersionCheck) {
      setIsCheckingVersion(true);
      try {
        const result = await checkVersion(source);
        setVersionCheckResult(result);
        
        if (result.needsSync) {
          // New version available - start sync directly
          setShowConfirm(false);
          await startSync(source);
        } else {
          // No version change - show dialog to ask user
          setShowConfirm(false);
          setShowVersionDialog(true);
        }
      } catch (err) {
        console.error('[BulkSyncButton] Version check failed:', err);
        // Fall back to starting sync anyway
        setShowConfirm(false);
        await startSync(source);
      } finally {
        setIsCheckingVersion(false);
      }
    } else {
      // No version check - just start
      setShowConfirm(false);
      await startSync(source);
    }
  };

  const handleForceSync = async () => {
    setShowVersionDialog(false);
    setVersionCheckResult(null);
    await resetSync(source);
    await startSync(source);
  };

  const handleStart = async () => {
    setShowConfirm(false);
    await startSync(source);
  };

  const handlePause = async () => {
    await pauseSync(source);
  };

  const handleResume = async () => {
    await resumeSync(source);
  };

  const handleReset = async () => {
    await resetSync(source);
    toast({
      title: 'Status zurückgesetzt',
      description: `${displayLabel} Synchronisation wurde zurückgesetzt.`,
    });
  };

  // Calculate progress percentage (capped at 100%)
  const progressPercent = progress?.total_available 
    ? Math.min(100, Math.round((progress.total_synced / progress.total_available) * 100))
    : null;

  // Determine primary action
  const renderActionButton = () => {
    if (syncing) {
      return (
        <Button 
          variant="outline" 
          size={size}
          onClick={handlePause}
          className={cn('gap-2', className)}
        >
          <Pause className="h-3.5 w-3.5" />
          Pause
        </Button>
      );
    }

    if (progress?.status === 'paused') {
      return (
        <Button 
          variant={variant} 
          size={size}
          onClick={handleResume}
          className={cn('gap-2', className)}
        >
          <Play className="h-3.5 w-3.5" />
          Fortsetzen
        </Button>
      );
    }

    if (progress?.status === 'completed') {
      return (
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size={size}
              onClick={handleReset}
              className={cn('gap-2', className)}
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Neu laden
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs">Status zurücksetzen und erneut synchronisieren</p>
          </TooltipContent>
        </Tooltip>
      );
    }

    return (
      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogTrigger asChild>
          <Button 
            variant={variant} 
            size={size}
            className={cn('gap-2', className)}
            disabled={isCheckingVersion}
          >
            {isCheckingVersion ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Download className="h-3.5 w-3.5" />
            )}
            Dump laden
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{displayLabel} herunterladen</AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p>
                Dies lädt alle {displayLabel}-Codes aus der externen API in die lokale Datenbank.
              </p>
              <p className="text-xs text-muted-foreground">
                {SOURCE_DESCRIPTIONS[source]}
              </p>
              <p className="text-xs">
                Der Prozess kann einige Minuten dauern und wird paginiert ausgeführt, 
                um Timeouts zu vermeiden. Sie können den Vorgang jederzeit pausieren.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleStartWithVersionCheck} disabled={isCheckingVersion}>
              {isCheckingVersion ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Download className="h-4 w-4 mr-2" />
              )}
              Starten
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    );
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        {renderActionButton()}
        
        {/* Status badge */}
        {progress && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge 
                variant="outline" 
                className={cn(
                  'gap-1 text-xs cursor-help',
                  progress.status === 'completed' && 'border-emerald-500/30 text-emerald-600 dark:text-emerald-400',
                  progress.status === 'error' && 'bg-destructive/10 border-destructive/20 text-destructive',
                  progress.status === 'running' && 'bg-primary/10 border-primary/20 text-primary',
                  progress.status === 'paused' && 'border-amber-500/30 text-amber-600 dark:text-amber-400',
                )}
              >
                {getStatusIcon(progress.status)}
                {formatNumber(progress.total_synced)} Codes
              </Badge>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <div className="space-y-1 text-xs">
                <p><strong>Status:</strong> {getStatusLabel(progress.status)}</p>
                <p><strong>Synchronisiert:</strong> {formatNumber(progress.total_synced)}</p>
                {progress.total_available && (
                  <p><strong>Gesamt:</strong> {formatNumber(progress.total_available)}</p>
                )}
                {progress.local_version && (
                  <p><strong>Version:</strong> {progress.local_version}</p>
                )}
                {progress.error_message && (
                  <p className="text-destructive"><strong>Fehler:</strong> {progress.error_message}</p>
                )}
              </div>
            </TooltipContent>
          </Tooltip>
        )}
      </div>

      {/* Progress bar when syncing */}
      {(syncing || progress?.status === 'paused') && progressPercent !== null && (
        <div className="flex items-center gap-2">
          <Progress value={progressPercent} className="h-1.5 flex-1" />
          <span className="text-xs text-muted-foreground tabular-nums">
            {progressPercent}%
          </span>
        </div>
      )}

      {/* Version check dialog - no version change detected */}
      <AlertDialog open={showVersionDialog} onOpenChange={setShowVersionDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5 text-muted-foreground" />
              Keine Versionsänderung erkannt
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <p>
                Die aktuelle {displayLabel}-Version entspricht bereits der lokalen Version.
              </p>
              <div className="p-3 bg-muted rounded-md space-y-1 text-sm">
                <p><strong>Lokale Version:</strong> {versionCheckResult?.localVersion || 'Unbekannt'}</p>
                <p><strong>Remote Version:</strong> {versionCheckResult?.remoteVersion || 'Unbekannt'}</p>
              </div>
              <p className="text-sm">
                Möchten Sie trotzdem alle Daten neu laden? Dies kann bei Dateninkonsistenzen sinnvoll sein.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowVersionDialog(false)}>
              Abbrechen
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleForceSync}>
              <Download className="h-4 w-4 mr-2" />
              Trotzdem laden
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
