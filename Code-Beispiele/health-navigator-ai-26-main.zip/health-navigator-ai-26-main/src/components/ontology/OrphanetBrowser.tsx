import { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useOrphanet, OrphanetConcept } from '@/hooks/useOrphanet';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { 
  Search, 
  ChevronRight, 
  ChevronDown, 
  Loader2,
  ExternalLink,
  Copy,
  Check,
  X,
  PanelRightClose,
  PanelRightOpen,
  Sparkles,
  Heart,
  Dna,
  Info,
  FileText,
  Stethoscope,
  TreeDeciduous,
  RefreshCw,
  Link2,
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { BulkSyncButton } from './BulkSyncButton';
import { OntologyStatsBar } from './OntologyStatsBar';
import { supabase } from '@/integrations/supabase/client';

interface OrphanetTreeNode extends OrphanetConcept {
  children?: OrphanetTreeNode[];
  isLoading?: boolean;
  isExpanded?: boolean;
  isTranslating?: boolean;
  translatedName?: string;
  translationSource?: 'official' | 'ai_translated';
}

interface OrphanetAnalysis {
  orpha_code: string;
  content: {
    explanation?: string;
    symptoms?: string[];
    diagnosis?: string;
    therapy?: string;
    prognosis?: string;
    notes?: string;
  };
  hpo_mappings?: Array<{ code: string; label: string; confidence: number }>;
  snomed_mappings?: Array<{ code: string; label: string; confidence: number }>;
  icd10_mappings?: Array<{ code: string; label: string; confidence: number }>;
  omim_mappings?: Array<{ code: string; label: string; confidence: number }>;
  generated_at?: string;
}

interface TreeNodeProps {
  node: OrphanetTreeNode;
  level: number;
  onSelect: (node: OrphanetTreeNode) => void;
  onExpand: (node: OrphanetTreeNode) => void;
  selectedCode?: string;
  bilingualView?: boolean;
}

function getClassificationBadge(classification?: string): { label: string; color: string } {
  switch (classification?.toLowerCase()) {
    case 'group':
      return { label: 'Gruppe', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' };
    case 'subtype':
      return { label: 'Subtyp', color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400' };
    case 'disorder':
    default:
      return { label: 'Erkrankung', color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400' };
  }
}

function TreeNode({ node, level, onSelect, onExpand, selectedCode, bilingualView = false }: TreeNodeProps) {
  const hasChildren = node.children && node.children.length > 0;
  const isSelected = node.orphaCode === selectedCode;
  const canExpand = !node.isTerminal;
  const classificationBadge = getClassificationBadge(node.classification);
  const displayName = node.translatedName || node.name;

  return (
    <div className="select-none">
      <div
        className={cn(
          'group flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer transition-all duration-200 hover:bg-muted active:scale-[0.98]',
          isSelected && 'bg-primary/10 text-primary font-medium ring-1 ring-primary/20'
        )}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={() => onSelect(node)}
      >
        {node.isLoading ? (
          <Loader2 className="h-3.5 w-3.5 md:h-4 md:w-4 animate-spin text-muted-foreground shrink-0" />
        ) : canExpand ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onExpand(node);
            }}
            className="p-0.5 hover:bg-muted-foreground/20 rounded transition-colors"
          >
            {node.isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground transition-transform duration-200" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 md:h-4 md:w-4 text-muted-foreground transition-transform duration-200" />
            )}
          </button>
        ) : (
          <div className="w-4 md:w-5" />
        )}
        
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge 
              variant="secondary" 
              className={cn(
                "text-[8px] md:text-[9px] px-1 py-0 h-3 md:h-3.5 shrink-0 font-medium cursor-help border-0",
                classificationBadge.color
              )}
            >
              {classificationBadge.label}
            </Badge>
          </TooltipTrigger>
          <TooltipContent side="top" className="max-w-xs">
            <p className="text-xs">
              {node.classification === 'Group' && 'Gruppe: Übergeordnete Klassifikation seltener Erkrankungen'}
              {node.classification === 'Subtype' && 'Subtyp: Unterform einer Erkrankung'}
              {(!node.classification || node.classification === 'Disorder') && 'Erkrankung: Spezifische seltene Erkrankung'}
            </p>
          </TooltipContent>
        </Tooltip>

        <Badge variant="outline" className="text-[10px] md:text-xs font-mono shrink-0 transition-colors group-hover:border-primary/30">
          ORPHA:{node.orphaCode}
        </Badge>
        <div className="flex flex-col min-w-0 flex-1">
          <span className="text-xs md:text-sm truncate transition-colors">
            {displayName}
          </span>
          {bilingualView && node.translatedName && node.nameEn && node.nameEn !== node.translatedName && (
            <span className="text-[9px] md:text-[10px] text-muted-foreground truncate italic hidden sm:block">
              {node.nameEn}
            </span>
          )}
        </div>
        
        {node.translationSource === 'ai_translated' && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant="secondary" className="text-[9px] md:text-[10px] px-1 py-0 h-3.5 md:h-4 shrink-0 gap-0.5 cursor-help bg-primary/10 text-primary border-primary/20">
                <Sparkles className="h-2 w-2 md:h-2.5 md:w-2.5" />
                KI
              </Badge>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <p className="text-xs">
                Dieser Begriff wurde automatisch per KI übersetzt.
              </p>
            </TooltipContent>
          </Tooltip>
        )}
        
        {node.isTranslating && (
          <Badge variant="outline" className="text-[9px] md:text-[10px] px-1.5 py-0 h-4 shrink-0 gap-1 bg-primary/5 border-primary/30">
            <Sparkles className="h-2.5 w-2.5 animate-pulse text-primary" />
          </Badge>
        )}
      </div>

      {node.isExpanded && hasChildren && (
        <div className="animate-in slide-in-from-top-1 duration-200">
          {node.children!.map((child) => (
            <TreeNode
              key={child.orphaCode}
              node={child}
              level={level + 1}
              onSelect={onSelect}
              onExpand={onExpand}
              selectedCode={selectedCode}
              bilingualView={bilingualView}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function OrphanetBrowser() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const prefilledSearch = searchParams.get('search');
  
  const { 
    searchConcepts, 
    getChildren,
    getClassifications,
    translateTerms,
    isSearching, 
    searchResults,
  } = useOrphanet({ language: 'de' });
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConcept, setSelectedConcept] = useState<OrphanetTreeNode | null>(null);
  const [treeData, setTreeData] = useState<OrphanetTreeNode[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);
  const [copied, setCopied] = useState(false);
  const [bilingualView, setBilingualView] = useState(false);
  const [showDetailSheet, setShowDetailSheet] = useState(false);
  const [detailPanelCollapsed, setDetailPanelCollapsed] = useState(false);
  
  // Analysis state
  const [analysis, setAnalysis] = useState<OrphanetAnalysis | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);
  const [isGeneratingAnalysis, setIsGeneratingAnalysis] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'analysis' | 'mappings'>('details');

  // Load root classifications on mount (DB-first via hook)
  useEffect(() => {
    let mounted = true;
    
    const loadClassifications = async () => {
      setIsLoadingCategories(true);
      try {
        const classifications = await getClassifications();
        if (mounted) {
          setTreeData(classifications.map(c => ({
            ...c,
            isExpanded: false,
            isTerminal: c.isTerminal ?? false,
          })));
        }
      } catch (error) {
        console.error('Error loading classifications:', error);
      } finally {
        if (mounted) setIsLoadingCategories(false);
      }
    };

    loadClassifications();
    return () => { mounted = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Handle prefilled search
  useEffect(() => {
    if (prefilledSearch && !isLoadingCategories) {
      setSearchQuery(prefilledSearch);
      const timer = setTimeout(() => {
        searchConcepts(prefilledSearch, 30);
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [prefilledSearch, isLoadingCategories, searchConcepts]);

  // Fetch analysis when concept selected
  useEffect(() => {
    if (!selectedConcept) {
      setAnalysis(null);
      return;
    }

    const fetchAnalysis = async () => {
      setIsLoadingAnalysis(true);
      try {
        const { data, error } = await supabase.functions.invoke('orphanet-analyze', {
          body: {
            action: 'get',
            orphaCode: selectedConcept.orphaCode,
          },
        });

        if (error) throw error;
        setAnalysis(data?.analysis || null);
      } catch (err) {
        console.error('Error fetching analysis:', err);
      } finally {
        setIsLoadingAnalysis(false);
      }
    };

    fetchAnalysis();
  }, [selectedConcept?.orphaCode]);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    await searchConcepts(searchQuery, 30);
  };

  const handleExpand = useCallback(async (node: OrphanetTreeNode) => {
    if (node.isTerminal) return;

    // Toggle if already expanded
    if (node.isExpanded) {
      setTreeData(prev => updateNodeInTree(prev, node.orphaCode, { isExpanded: false }));
      return;
    }

    // Set loading state
    setTreeData(prev => updateNodeInTree(prev, node.orphaCode, { isLoading: true, isExpanded: true }));

    try {
      const rawChildren = await getChildren(node.orphaCode);
      
      if (rawChildren.length === 0) {
        // Mark as terminal if no children - show info toast about API limitation
        setTreeData(prev => updateNodeInTree(prev, node.orphaCode, { 
          isLoading: false, 
          isExpanded: true,
          isTerminal: true,
          children: [],
        }));
        
        toast({
          title: 'Keine Unterkategorien geladen',
          description: 'Die ORPHAcode API erfordert jetzt eine Registrierung. Verwenden Sie die Suche oder den Bulk-Import.',
          variant: 'default',
          duration: 5000,
        });
        return;
      }

      // Create children with translation loading state
      const children: OrphanetTreeNode[] = rawChildren.map(child => ({
        ...child,
        isExpanded: false,
        isTranslating: true,
      }));

      // Update tree with children
      setTreeData(prev => updateNodeInTree(prev, node.orphaCode, { 
        isLoading: false, 
        isExpanded: true,
        children,
      }));

      // Batch translate children
      const translations = await translateTerms(
        rawChildren.map(c => ({
          orphaCode: c.orphaCode,
          name: c.nameEn || c.name,
          definition: c.definition,
        }))
      );

      // Update children with translations
      setTreeData(prev => {
        const updateChildrenTranslations = (nodes: OrphanetTreeNode[]): OrphanetTreeNode[] => {
          return nodes.map(n => {
            if (n.orphaCode === node.orphaCode && n.children) {
              return {
                ...n,
                children: n.children.map(child => {
                  const translation = translations.get(child.orphaCode);
                  if (translation) {
                    return {
                      ...child,
                      translatedName: translation.name_de,
                      translationSource: translation.source,
                      isTranslating: false,
                    };
                  }
                  return { ...child, isTranslating: false };
                }),
              };
            }
            if (n.children) {
              return { ...n, children: updateChildrenTranslations(n.children) };
            }
            return n;
          });
        };
        return updateChildrenTranslations(prev);
      });

      console.log(`Translated ${translations.size} Orphanet children for ${node.orphaCode}`);
    } catch (err) {
      console.error('Error expanding node:', err);
      setTreeData(prev => updateNodeInTree(prev, node.orphaCode, { 
        isLoading: false, 
        isExpanded: false,
      }));
    }
  }, [getChildren, translateTerms, toast]);

  const updateNodeInTree = (
    nodes: OrphanetTreeNode[], 
    targetCode: string, 
    updates: Partial<OrphanetTreeNode>
  ): OrphanetTreeNode[] => {
    return nodes.map(node => {
      if (node.orphaCode === targetCode) {
        return { ...node, ...updates };
      }
      if (node.children) {
        return { ...node, children: updateNodeInTree(node.children, targetCode, updates) };
      }
      return node;
    });
  };

  const handleSelect = (node: OrphanetTreeNode) => {
    setSelectedConcept(node);
    setActiveTab('details');
    if (isMobile) {
      setShowDetailSheet(true);
    }
  };

  const handleCopyId = () => {
    if (selectedConcept) {
      navigator.clipboard.writeText(`ORPHA:${selectedConcept.orphaCode}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const generateAnalysis = async () => {
    if (!selectedConcept) return;

    setIsGeneratingAnalysis(true);
    try {
      const { data, error } = await supabase.functions.invoke('orphanet-analyze', {
        body: {
          action: 'generate',
          orphaCode: selectedConcept.orphaCode,
          name: selectedConcept.translatedName || selectedConcept.name,
          definition: selectedConcept.definition,
        },
      });

      if (error) throw error;

      if (data?.analysis) {
        setAnalysis(data.analysis);
        toast({
          title: 'Analyse generiert',
          description: 'Die KI-Analyse wurde erfolgreich erstellt.',
        });
      }
    } catch (err: any) {
      console.error('Error generating analysis:', err);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: err.message || 'Die Analyse konnte nicht generiert werden.',
      });
    } finally {
      setIsGeneratingAnalysis(false);
    }
  };

  const navigateToCode = (type: 'hpo' | 'snomed' | 'icd10', code: string) => {
    const tabMap = { hpo: 'hpo', snomed: 'snomed', icd10: 'icd10' };
    navigate(`/ontology?tab=${tabMap[type]}&search=${encodeURIComponent(code)}&backTab=orphanet&backCode=${encodeURIComponent(`ORPHA:${selectedConcept?.orphaCode}`)}`);
  };

  // Detail panel content
  const DetailContent = () => {
    if (!selectedConcept) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-muted-foreground p-6">
          <Heart className="h-12 w-12 mb-4 opacity-50" />
          <p className="text-sm text-center">
            Wählen Sie eine seltene Erkrankung aus der Liste oder suchen Sie nach einem Begriff
          </p>
        </div>
      );
    }

    const classificationBadge = getClassificationBadge(selectedConcept.classification);

    return (
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="space-y-3 pb-4 border-b">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <h3 className="text-lg font-semibold leading-tight">
                {selectedConcept.translatedName || selectedConcept.name}
              </h3>
              {selectedConcept.nameEn && selectedConcept.nameEn !== selectedConcept.name && (
                <p className="text-sm text-muted-foreground italic mt-1">
                  {selectedConcept.nameEn}
                </p>
              )}
            </div>
            {selectedConcept.translationSource === 'ai_translated' && (
              <Badge variant="secondary" className="shrink-0 gap-1 bg-primary/10 text-primary">
                <Sparkles className="h-3 w-3" />
                KI
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="font-mono">
              ORPHA:{selectedConcept.orphaCode}
            </Badge>
            <Button variant="ghost" size="sm" className="h-7 px-2" onClick={handleCopyId}>
              {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
            </Button>
            <Badge className={cn("text-xs", classificationBadge.color)}>
              {classificationBadge.label}
            </Badge>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="flex-1 flex flex-col mt-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="details" className="text-xs">
              <Info className="h-3 w-3 mr-1" />
              Details
            </TabsTrigger>
            <TabsTrigger value="analysis" className="text-xs">
              <Sparkles className="h-3 w-3 mr-1" />
              Analyse
            </TabsTrigger>
            <TabsTrigger value="mappings" className="text-xs">
              <Link2 className="h-3 w-3 mr-1" />
              Mappings
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1 mt-4">
            <TabsContent value="details" className="m-0 space-y-4">
              {selectedConcept.definition && (
                <div className="space-y-1">
                  <h4 className="text-sm font-medium flex items-center gap-1">
                    <Info className="h-3 w-3" />
                    Definition
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {selectedConcept.definition}
                  </p>
                </div>
              )}

              {selectedConcept.prevalence && (
                <div className="space-y-1">
                  <h4 className="text-sm font-medium">Prävalenz</h4>
                  <p className="text-sm text-muted-foreground">{selectedConcept.prevalence}</p>
                </div>
              )}

              {selectedConcept.inheritance && selectedConcept.inheritance.length > 0 && (
                <div className="space-y-1">
                  <h4 className="text-sm font-medium flex items-center gap-1">
                    <Dna className="h-3 w-3" />
                    Vererbung
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedConcept.inheritance.map((mode, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">
                        {mode}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {selectedConcept.ageOfOnset && selectedConcept.ageOfOnset.length > 0 && (
                <div className="space-y-1">
                  <h4 className="text-sm font-medium">Erkrankungsalter</h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedConcept.ageOfOnset.map((age, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {age}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {selectedConcept.orphaUrl && (
                <Button variant="outline" className="w-full mt-4" asChild>
                  <a href={selectedConcept.orphaUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Auf Orphanet öffnen
                  </a>
                </Button>
              )}
            </TabsContent>

            <TabsContent value="analysis" className="m-0">
              {isLoadingAnalysis ? (
                <div className="space-y-3">
                  <Skeleton className="h-8 w-48" />
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-16 w-full" />
                </div>
              ) : !analysis ? (
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground mb-4">
                      Für diese seltene Erkrankung wurde noch keine KI-Analyse erstellt.
                    </p>
                    <Button onClick={generateAnalysis} disabled={isGeneratingAnalysis}>
                      {isGeneratingAnalysis ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Generiere...
                        </>
                      ) : (
                        <>
                          <Sparkles className="h-4 w-4 mr-2" />
                          KI-Analyse generieren
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium flex items-center gap-1">
                      <Sparkles className="h-4 w-4 text-primary" />
                      KI-Analyse
                    </h4>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={generateAnalysis}
                      disabled={isGeneratingAnalysis}
                    >
                      <RefreshCw className={cn("h-4 w-4", isGeneratingAnalysis && "animate-spin")} />
                    </Button>
                  </div>

                  {analysis.content.explanation && (
                    <div className="space-y-1">
                      <h5 className="text-xs font-medium text-muted-foreground">Erklärung</h5>
                      <p className="text-sm bg-muted/30 p-3 rounded-md">
                        {analysis.content.explanation}
                      </p>
                    </div>
                  )}

                  {analysis.content.symptoms && analysis.content.symptoms.length > 0 && (
                    <div className="space-y-1">
                      <h5 className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                        <Stethoscope className="h-3 w-3" />
                        Symptome
                      </h5>
                      <ul className="text-sm space-y-1 bg-muted/30 p-3 rounded-md">
                        {analysis.content.symptoms.map((symptom, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            {symptom}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {analysis.content.diagnosis && (
                    <div className="space-y-1">
                      <h5 className="text-xs font-medium text-muted-foreground">Diagnostik</h5>
                      <p className="text-sm bg-muted/30 p-3 rounded-md">
                        {analysis.content.diagnosis}
                      </p>
                    </div>
                  )}

                  {analysis.content.therapy && (
                    <div className="space-y-1">
                      <h5 className="text-xs font-medium text-muted-foreground">Therapie</h5>
                      <p className="text-sm bg-muted/30 p-3 rounded-md">
                        {analysis.content.therapy}
                      </p>
                    </div>
                  )}

                  {analysis.content.prognosis && (
                    <div className="space-y-1">
                      <h5 className="text-xs font-medium text-muted-foreground">Prognose</h5>
                      <p className="text-sm bg-muted/30 p-3 rounded-md">
                        {analysis.content.prognosis}
                      </p>
                    </div>
                  )}

                  {analysis.generated_at && (
                    <p className="text-xs text-muted-foreground">
                      Generiert: {new Date(analysis.generated_at).toLocaleDateString('de-DE')}
                    </p>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="mappings" className="m-0 space-y-4">
              {/* ICD-10 from concept */}
              {selectedConcept.icd10Codes && selectedConcept.icd10Codes.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-1">
                    <FileText className="h-4 w-4" />
                    ICD-10 Codes
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedConcept.icd10Codes.map((code, i) => (
                      <Badge 
                        key={i} 
                        variant="outline" 
                        className="text-xs font-mono cursor-pointer hover:bg-muted"
                        onClick={() => navigateToCode('icd10', code)}
                      >
                        {code}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* HPO from concept */}
              {selectedConcept.hpoCodes && selectedConcept.hpoCodes.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-1">
                    <TreeDeciduous className="h-4 w-4" />
                    HPO Phänotypen ({selectedConcept.hpoCodes.length})
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedConcept.hpoCodes.slice(0, 15).map((code, i) => (
                      <Badge 
                        key={i} 
                        variant="outline" 
                        className="text-xs font-mono cursor-pointer hover:bg-muted"
                        onClick={() => navigateToCode('hpo', code)}
                      >
                        {code}
                      </Badge>
                    ))}
                    {selectedConcept.hpoCodes.length > 15 && (
                      <Badge variant="secondary" className="text-xs">
                        +{selectedConcept.hpoCodes.length - 15} weitere
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {/* OMIM from concept */}
              {selectedConcept.omimCodes && selectedConcept.omimCodes.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">OMIM</h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedConcept.omimCodes.map((code, i) => (
                      <Badge key={i} variant="outline" className="text-xs font-mono">
                        <a 
                          href={`https://omim.org/entry/${code}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:underline"
                        >
                          {code}
                        </a>
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Analysis mappings */}
              {analysis?.hpo_mappings && analysis.hpo_mappings.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-1">
                    <TreeDeciduous className="h-4 w-4" />
                    HPO aus Analyse
                    <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4 gap-0.5">
                      <Sparkles className="h-2.5 w-2.5" />
                      KI
                    </Badge>
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {analysis.hpo_mappings.map((m, i) => (
                      <Tooltip key={i}>
                        <TooltipTrigger asChild>
                          <Badge 
                            variant="outline" 
                            className="text-xs font-mono cursor-pointer hover:bg-muted"
                            onClick={() => navigateToCode('hpo', m.code)}
                          >
                            {m.code}
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs">{m.label || m.code}</p>
                        </TooltipContent>
                      </Tooltip>
                    ))}
                  </div>
                </div>
              )}

              {!selectedConcept.icd10Codes?.length && 
               !selectedConcept.hpoCodes?.length && 
               !selectedConcept.omimCodes?.length &&
               !analysis?.hpo_mappings?.length && (
                <p className="text-sm text-muted-foreground">
                  Keine Mappings verfügbar. Generieren Sie eine KI-Analyse, um mögliche Mappings zu erhalten.
                </p>
              )}
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col md:flex-row gap-4 p-3 md:p-4">
      {/* Left Panel: Search & Tree */}
      <div className={cn(
        "flex flex-col min-h-0",
        isMobile ? "flex-1" : detailPanelCollapsed ? "flex-1" : "w-1/2 lg:w-3/5"
      )}>
        <Card className="flex-1 flex flex-col min-h-0">
          <CardHeader className="py-3 px-4 border-b shrink-0">
            <div className="flex items-center justify-between gap-2">
              <CardTitle className="text-base md:text-lg flex items-center gap-2">
                <Heart className="h-5 w-5 text-rose-500" />
                Seltene Erkrankungen
              </CardTitle>
              <div className="flex items-center gap-2">
                <OntologyStatsBar source="orphanet" showLabel={!isMobile} />
                <BulkSyncButton source="orphanet" />
              </div>
              {!isMobile && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setDetailPanelCollapsed(!detailPanelCollapsed)}
                  className="h-8 w-8 p-0"
                >
                  {detailPanelCollapsed ? (
                    <PanelRightOpen className="h-4 w-4" />
                  ) : (
                    <PanelRightClose className="h-4 w-4" />
                  )}
                </Button>
              )}
            </div>
            
            <div className="flex gap-2 mt-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Suche nach seltenen Erkrankungen..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="pl-9 h-9"
                />
              </div>
              <Button onClick={handleSearch} disabled={isSearching} className="h-9">
                {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </div>
          </CardHeader>

          <CardContent className="flex-1 p-0 min-h-0">
            <ScrollArea className="h-full">
              <div className="p-2 md:p-3">
                {/* Search Results */}
                {searchResults.length > 0 && (
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2 px-2">
                      <span className="text-sm font-medium">Suchergebnisse ({searchResults.length})</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSearchQuery('')}
                        className="h-6 px-2"
                      >
                        <X className="h-3 w-3 mr-1" />
                        Löschen
                      </Button>
                    </div>
                    {searchResults.map((result) => (
                      <div
                        key={result.orphaCode}
                        className={cn(
                          'flex items-center gap-2 p-2 rounded-md cursor-pointer hover:bg-muted transition-colors',
                          selectedConcept?.orphaCode === result.orphaCode && 'bg-primary/10 ring-1 ring-primary/20'
                        )}
                        onClick={() => handleSelect(result as OrphanetTreeNode)}
                      >
                        <Badge variant="outline" className="font-mono text-xs shrink-0">
                          ORPHA:{result.orphaCode}
                        </Badge>
                        <span className="text-sm truncate">{result.name}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Tree View */}
                <div className="space-y-1">
                  <h4 className="text-sm font-medium text-muted-foreground px-2 mb-2">
                    Klassifikationen seltener Erkrankungen
                  </h4>
                  {isLoadingCategories ? (
                    <div className="space-y-2 px-2">
                      <Skeleton className="h-8 w-full" />
                      <Skeleton className="h-8 w-5/6" />
                      <Skeleton className="h-8 w-4/5" />
                    </div>
                  ) : (
                    treeData.map((node) => (
                      <TreeNode
                        key={node.orphaCode}
                        node={node}
                        level={0}
                        onSelect={handleSelect}
                        onExpand={handleExpand}
                        selectedCode={selectedConcept?.orphaCode}
                        bilingualView={bilingualView}
                      />
                    ))
                  )}
                </div>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Right Panel: Details (Desktop) */}
      {!isMobile && !detailPanelCollapsed && (
        <div className="w-1/2 lg:w-2/5 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col min-h-0">
            <CardHeader className="py-3 px-4 border-b shrink-0">
              <CardTitle className="text-base">Details</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-4 overflow-hidden">
              <DetailContent />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Mobile Detail Drawer */}
      {isMobile && (
        <Drawer open={showDetailSheet} onOpenChange={setShowDetailSheet}>
          <DrawerContent className="max-h-[85vh]">
            <DrawerHeader className="border-b">
              <DrawerTitle>Details</DrawerTitle>
            </DrawerHeader>
            <div className="p-4 overflow-auto flex-1">
              <DetailContent />
            </div>
            <DrawerFooter className="border-t">
              <DrawerClose asChild>
                <Button variant="outline">Schließen</Button>
              </DrawerClose>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      )}
    </div>
  );
}
