import { 
  Sparkles, 
  Loader2,
  MessageSquare,
  ChevronRight
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';

interface KnowledgeSource {
  id: string;
  title: string;
}

interface QueryAnalysis {
  intent: 'search' | 'question' | 'inventory';
  topic: string;
  keywords: string[];
}

interface AIResponse {
  answer: string;
  sources: { index: number; title: string }[];
}

interface AIResponsePanelProps {
  isGenerating: boolean;
  response: AIResponse | null;
  queryAnalysis: QueryAnalysis;
  onGenerateAnswer: () => void;
  sources: KnowledgeSource[];
  isRestoringHistory?: boolean;
  onScrollToSource?: (index: number) => void;
}

export function AIResponsePanel({ 
  isGenerating, 
  response, 
  queryAnalysis, 
  onGenerateAnswer,
  sources,
  isRestoringHistory = false,
  onScrollToSource
}: AIResponsePanelProps) {
  const isQuestion = queryAnalysis.intent === 'question';
  const isInventory = queryAnalysis.intent === 'inventory';

  // Custom component for rendering citations inline
  const renderCitation = (num: number) => {
    const source = sources[num - 1];
    return (
      <button
        onClick={() => onScrollToSource?.(num - 1)}
        className="inline-flex items-center justify-center h-5 px-1.5 text-xs font-mono bg-primary/10 text-primary rounded cursor-pointer hover:bg-primary/20 transition-colors mx-0.5"
        title={source?.title || `Quelle ${num}`}
      >
        {num}
      </button>
    );
  };

  // Process text to replace citations with placeholder markers, then render
  const processTextWithCitations = (text: string) => {
    const parts = text.split(/(\[\d+\])/);
    return parts.map((part, i) => {
      const match = part.match(/\[(\d+)\]/);
      if (match) {
        return renderCitation(parseInt(match[1]));
      }
      return <span key={i}>{part}</span>;
    });
  };

  // Custom markdown components with citation support
  const markdownComponents = {
    p: ({ children }: { children?: React.ReactNode }) => {
      // Process string children to handle citations
      const processChildren = (child: React.ReactNode): React.ReactNode => {
        if (typeof child === 'string') {
          return processTextWithCitations(child);
        }
        return child;
      };
      
      return (
        <p className="mb-3 last:mb-0">
          {Array.isArray(children) ? children.map((c, i) => <span key={i}>{processChildren(c)}</span>) : processChildren(children)}
        </p>
      );
    },
    h1: ({ children }: { children?: React.ReactNode }) => (
      <h1 className="text-xl font-bold mt-4 mb-2 first:mt-0">{children}</h1>
    ),
    h2: ({ children }: { children?: React.ReactNode }) => (
      <h2 className="text-lg font-semibold mt-4 mb-2 first:mt-0">{children}</h2>
    ),
    h3: ({ children }: { children?: React.ReactNode }) => (
      <h3 className="text-base font-semibold mt-3 mb-2 first:mt-0">{children}</h3>
    ),
    ul: ({ children }: { children?: React.ReactNode }) => (
      <ul className="list-disc list-inside mb-3 space-y-1 ml-2">{children}</ul>
    ),
    ol: ({ children }: { children?: React.ReactNode }) => (
      <ol className="list-decimal list-inside mb-3 space-y-1 ml-2">{children}</ol>
    ),
    li: ({ children }: { children?: React.ReactNode }) => {
      const processChildren = (child: React.ReactNode): React.ReactNode => {
        if (typeof child === 'string') {
          return processTextWithCitations(child);
        }
        return child;
      };
      return (
        <li className="leading-relaxed">
          {Array.isArray(children) ? children.map((c, i) => <span key={i}>{processChildren(c)}</span>) : processChildren(children)}
        </li>
      );
    },
    strong: ({ children }: { children?: React.ReactNode }) => (
      <strong className="font-semibold text-foreground">{children}</strong>
    ),
    em: ({ children }: { children?: React.ReactNode }) => (
      <em className="italic">{children}</em>
    ),
    blockquote: ({ children }: { children?: React.ReactNode }) => (
      <blockquote className="border-l-4 border-primary/30 pl-4 my-3 italic text-muted-foreground">
        {children}
      </blockquote>
    ),
    code: ({ children }: { children?: React.ReactNode }) => (
      <code className="bg-muted px-1.5 py-0.5 rounded text-sm font-mono">{children}</code>
    ),
  };

  return (
    <Card>
      <CardHeader className="pb-3 px-3 sm:px-6">
        <CardTitle className="text-base sm:text-lg flex items-center gap-2">
          <Sparkles className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
          KI-Antwort
        </CardTitle>
      </CardHeader>
      <CardContent className="px-3 sm:px-6">
        {/* Not a question and not inventory - offer to generate */}
        {!isQuestion && !isInventory && !response && !isGenerating && !isRestoringHistory && (
          <div className="text-center py-6 sm:py-8">
            <MessageSquare className="h-10 w-10 sm:h-12 sm:w-12 text-muted-foreground/50 mx-auto mb-3 sm:mb-4" />
            <p className="text-sm text-muted-foreground mb-4 px-2">
              Ihre Suche wurde als Themensuche erkannt.
              <br />
              Möchten Sie eine KI-Zusammenfassung generieren?
            </p>
            <Button onClick={onGenerateAnswer} size="sm">
              <Sparkles className="h-4 w-4 mr-2" />
              Zusammenfassung generieren
            </Button>
          </div>
        )}

        {/* Generating */}
        {isGenerating && (
          <div className="flex items-center justify-center py-10 sm:py-12">
            <div className="text-center">
              <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-primary mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Generiere Antwort aus {sources.length} Quellen...</p>
            </div>
          </div>
        )}

        {/* Response */}
        {response && !isGenerating && (
          <ScrollArea className="h-[50vh] sm:h-[350px]">
            <div className="space-y-4 pr-2 sm:pr-4">
              <article className="text-sm sm:text-base leading-relaxed text-foreground/90">
                <ReactMarkdown components={markdownComponents}>
                  {response.answer}
                </ReactMarkdown>
              </article>

              {response.sources.length > 0 && (
                <div className="pt-4 border-t">
                  <p className="text-sm font-medium mb-2">Zitierte Quellen:</p>
                  <div className="space-y-1.5">
                    {response.sources.map((source) => (
                      <div 
                        key={source.index} 
                        className="flex items-start gap-2 text-sm text-muted-foreground"
                      >
                        <span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded flex-shrink-0">
                          [{source.index}]
                        </span>
                        <span className="leading-snug">{source.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
        )}

        {/* Waiting for question - only show for fresh searches, not history restores */}
        {isQuestion && !response && !isGenerating && !isRestoringHistory && (
          <div className="flex items-center justify-center py-10 sm:py-12">
            <div className="text-center">
              <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-primary mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Bereite Antwort vor...</p>
            </div>
          </div>
        )}

        {/* No AI response for restored history entry */}
        {isRestoringHistory && !response && !isGenerating && (
          <div className="text-center py-6 sm:py-8">
            <p className="text-sm text-muted-foreground mb-4">
              Für diese Suche wurde keine KI-Antwort gespeichert.
            </p>
            <Button onClick={onGenerateAnswer} size="sm">
              <Sparkles className="h-4 w-4 mr-2" />
              Jetzt generieren
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
