import { useState, useEffect, useCallback, useRef } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { 
  Search, 
  Loader2, 
  Sparkles,
  RefreshCw,
  BookOpen,
  HelpCircle,
  X,
  Globe,
  Settings2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { SourceListPanel, SourceListPanelHandle } from './SourceListPanel';
import { AIResponsePanel } from './AIResponsePanel';
import { SearchHistoryPanel, HistoryEntry } from './SearchHistoryPanel';
import { QueryClarificationDialog } from './QueryClarificationDialog';
import { ClassificationBadge } from './ClassificationBadge';

interface QueryAnalysis {
  intent: 'search' | 'question' | 'inventory';
  topic: string;
  keywords: string[];
  dateRange?: { from?: string; to?: string };
  pmcQuery?: string;
}

interface QueryClassification {
  category: 'literature' | 'knowledge_base' | 'inventory' | 'explanation' | 'combined';
  confidence: number;
  needs_clarification: boolean;
  clarification_options?: string[];
  suggested_sources: string[];
  extracted_keywords: string[];
  date_filter?: { from?: string; to?: string };
}

interface KnowledgeSource {
  id: string;
  source_type: string;
  external_id?: string;
  title: string;
  authors?: string;
  year?: number;
  relevance_score?: number;
  url?: string;
  content_status: string;
  translation_status: string;
  original_language?: string;
  original_content?: string;
  translated_content?: string;
}

interface SearchResult {
  searchId: string;
  query: string;
  queryAnalysis: QueryAnalysis;
  classification?: QueryClassification;
  sources: KnowledgeSource[];
  totalSources: number;
  pmcQuery?: string;
}

interface AIResponse {
  answer: string;
  sources: { index: number; title: string }[];
}

export function UnifiedKnowledgeSearch() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<SearchResult | null>(null);
  const [sources, setSources] = useState<KnowledgeSource[]>([]);
  
  const [isGeneratingAnswer, setIsGeneratingAnswer] = useState(false);
  const [aiResponse, setAiResponse] = useState<AIResponse | null>(null);
  const [rateLimitError, setRateLimitError] = useState(false);

  // Search settings
  const [pmcLimit, setPmcLimit] = useState<number>(25);

  // Clarification dialog state
  const [showClarification, setShowClarification] = useState(false);
  const [clarificationQuery, setClarificationQuery] = useState('');
  const [clarificationOptions, setClarificationOptions] = useState<string[]>([]);

  // Track if we're loading sources from history
  const [isLoadingSources, setIsLoadingSources] = useState(false);

  // Used to ignore stale async history-load responses (e.g. when user resets via X)
  const restoreRequestIdRef = useRef(0);
  
  // Ref for source list panel to scroll to sources
  const sourceListRef = useRef<SourceListPanelHandle>(null);
  
  const handleScrollToSource = useCallback((index: number) => {
    sourceListRef.current?.scrollToSource(index);
  }, []);

  // Persist active search to localStorage so it survives navigation
  useEffect(() => {
    if (searchResult?.searchId) {
      localStorage.setItem('knowledge-active-search', JSON.stringify({
        searchId: searchResult.searchId,
        query: searchResult.query,
        queryAnalysis: searchResult.queryAnalysis,
        pmcQuery: searchResult.pmcQuery,
        classification: searchResult.classification,
      }));
    }
  }, [searchResult]);

  // Restore last active search on mount
  useEffect(() => {
    const saved = localStorage.getItem('knowledge-active-search');
    if (saved && !searchResult) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.searchId) {
          // Load ai_response from DB first, then restore
          supabase
            .from('knowledge_searches')
            .select('ai_response')
            .eq('id', parsed.searchId)
            .single()
            .then(({ data }) => {
              handleSelectHistoryEntry({
                searchId: parsed.searchId,
                query: parsed.query,
                queryAnalysis: parsed.queryAnalysis,
                aiResponse: data?.ai_response || null,
              });
            });
        }
      } catch {}
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load a history entry with its sources and AI response
  const handleSelectHistoryEntry = useCallback(async (entry: HistoryEntry) => {
    const requestId = ++restoreRequestIdRef.current;

    const immediateResult: SearchResult = {
      searchId: entry.searchId,
      query: entry.query,
      queryAnalysis: entry.queryAnalysis || { intent: 'search', topic: entry.query, keywords: [] },
      sources: [],
      totalSources: 0,
      pmcQuery: entry.queryAnalysis?.pmcQuery,
    };

    setQuery(entry.query);
    setSearchResult(immediateResult);
    setSources([]);
    setIsLoadingSources(true);

    if (entry.aiResponse) {
      setAiResponse({ answer: entry.aiResponse, sources: [] });
    } else {
      setAiResponse(null);
    }

    try {
      const { data: sourcesData, error } = await supabase
        .from('knowledge_sources')
        .select('*')
        .eq('search_id', entry.searchId)
        .order('relevance_score', { ascending: false });

      if (error) throw error;

      // User reset/clicked elsewhere while we were loading
      if (restoreRequestIdRef.current !== requestId) return;

      const loadedSources = (sourcesData || []) as KnowledgeSource[];
      setSources(loadedSources);

      setSearchResult({
        ...immediateResult,
        sources: loadedSources,
        totalSources: loadedSources.length,
      });

      if (entry.aiResponse && loadedSources.length > 0) {
        const citedIndices = [...entry.aiResponse.matchAll(/\[(\d+)\]/g)].map(m => parseInt(m[1]) - 1);
        const citedSources = [...new Set(citedIndices)]
          .filter(i => i >= 0 && i < loadedSources.length)
          .map(i => ({ index: i + 1, title: loadedSources[i].title }));

        if (restoreRequestIdRef.current !== requestId) return;
        setAiResponse({ answer: entry.aiResponse, sources: citedSources });
      }
    } catch (err: any) {
      // Ignore errors for requests that are no longer current
      if (restoreRequestIdRef.current !== requestId) return;

      console.error('Failed to load history entry:', err);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: 'Die Suche konnte nicht geladen werden.',
      });
    } finally {
      if (restoreRequestIdRef.current === requestId) {
        setIsLoadingSources(false);
      }
    }
  }, [toast]);

  // Poll for source updates
  useEffect(() => {
    if (!searchResult?.searchId) return;

    const pendingSources = sources.filter(
      s => s.content_status === 'pending' || s.content_status === 'loading' ||
           s.translation_status === 'loading'
    );

    if (pendingSources.length === 0) return;

    const interval = setInterval(async () => {
      const { data } = await supabase
        .from('knowledge_sources')
        .select('*')
        .eq('search_id', searchResult.searchId);

      if (data) {
        setSources(data as KnowledgeSource[]);

        const stillPending = data.filter(
          s => s.content_status === 'pending' || s.content_status === 'loading' ||
               s.translation_status === 'loading'
        );
        if (stillPending.length === 0) {
          clearInterval(interval);
        }
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [searchResult?.searchId, sources]);

  const handleSearch = useCallback(async (forceCategory?: string) => {
    const searchQuery = forceCategory ? clarificationQuery : query;
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setSearchResult(null);
    setSources([]);
    setAiResponse(null);
    setRateLimitError(false);

    try {
      const { data, error } = await supabase.functions.invoke('knowledge-search', {
        body: { 
          query: searchQuery.trim(), 
          language: 'de',
          forceCategory,
          pmcLimit,
        }
      });

      if (error) throw error;

      // Handle clarification request
      if (data.needsClarification) {
        setClarificationQuery(searchQuery);
        setClarificationOptions(data.options || []);
        setShowClarification(true);
        setIsSearching(false);
        return;
      }

      setSearchResult(data);
      setSources(data.sources || []);

      queryClient.invalidateQueries({ queryKey: ['knowledge-searches-history'] });

      // Handle inventory response directly
      if (data.inventoryResponse) {
        setAiResponse({ answer: data.inventoryResponse, sources: [] });
      }
      // If it's a question, generate AI answer
      else if (data.queryAnalysis?.intent === 'question' || data.classification?.category === 'explanation') {
        await generateAnswer(data);
      }
    } catch (err: any) {
      console.error('Search error:', err);
      
      if (err.message?.includes('429')) {
        setRateLimitError(true);
        toast({
          variant: 'destructive',
          title: 'Anfragelimit erreicht',
          description: 'Bitte warten Sie einen Moment und versuchen Sie es erneut.'
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Suchfehler',
          description: err.message || 'Die Suche konnte nicht durchgeführt werden.'
        });
      }
    } finally {
      setIsSearching(false);
    }
  }, [query, clarificationQuery, toast, queryClient]);

  const handleCategorySelect = (category: string) => {
    handleSearch(category);
  };

  const generateAnswer = async (result: SearchResult) => {
    setIsGeneratingAnswer(true);
    setRateLimitError(false);

    try {
      const sourceContext = result.sources
        .slice(0, 8)
        .map((s, i) => `[${i + 1}] ${s.title}${s.year ? ` (${s.year})` : ''}\n${s.original_content || 'Inhalt wird geladen...'}`)
        .join('\n\n');

      const { data, error } = await supabase.functions.invoke('ai-chat', {
        body: {
          messages: [
            {
              role: 'system',
              content: `Du bist ein medizinischer Assistent, der Fragen basierend auf wissenschaftlichen Quellen beantwortet.
Antworte präzise und evidenzbasiert. Zitiere deine Quellen mit [1], [2], etc.

VERFÜGBARE QUELLEN:
${sourceContext}`
            },
            { role: 'user', content: result.query }
          ],
          model: 'google/gemini-3-flash-preview'
        }
      });

      if (error) {
        if (error.message?.includes('429')) {
          setRateLimitError(true);
          toast({
            variant: 'destructive',
            title: 'Anfragelimit erreicht',
            description: 'Bitte warten Sie einen Moment.'
          });
          return;
        }
        throw error;
      }

      if (data?.error) {
        if (data.error.includes('429')) {
          setRateLimitError(true);
          return;
        }
        throw new Error(data.error);
      }

      const answer = data?.content || data?.message || 'Keine Antwort erhalten.';
      
      const citedIndices = [...answer.matchAll(/\[(\d+)\]/g)].map(m => parseInt(m[1]) - 1);
      const citedSources = [...new Set(citedIndices)]
        .filter(i => i >= 0 && i < result.sources.length)
        .map(i => ({ index: i + 1, title: result.sources[i].title }));

      setAiResponse({ answer, sources: citedSources });

      try {
        await supabase
          .from('knowledge_searches')
          .update({ 
            ai_response: answer,
            answer_generated_at: new Date().toISOString()
          })
          .eq('id', result.searchId);
        
        queryClient.invalidateQueries({ queryKey: ['knowledge-searches-history'] });
      } catch (saveErr) {
        console.warn('Failed to save AI response:', saveErr);
      }
    } catch (err: any) {
      console.error('AI error:', err);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: err.message || 'Die KI-Antwort konnte nicht generiert werden.'
      });
    } finally {
      setIsGeneratingAnswer(false);
    }
  };

  const handleRetry = () => {
    if (searchResult) {
      generateAnswer(searchResult);
    } else {
      handleSearch();
    }
  };

  const exampleQueries = [
    { text: 'Wieviele Dokumente habe ich hochgeladen?', icon: 'kb', category: 'inventory' },
    { text: 'Erkläre Hypertonie aus meiner Wissensdatenbank', icon: 'kb', category: 'explanation' },
    { text: 'Wie wird Diabetes Typ 2 diagnostiziert?', icon: 'question', category: 'combined' },
    { text: 'Aktuelle Artikel zu Herzinsuffizienz 2024', icon: 'search', category: 'literature' },
  ];

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Clarification Dialog */}
      <QueryClarificationDialog
        open={showClarification}
        onOpenChange={setShowClarification}
        query={clarificationQuery}
        options={clarificationOptions}
        onSelectCategory={handleCategorySelect}
      />

      {/* Search Input */}
      <Card>
        <CardHeader className="pb-3 px-3 sm:px-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <Sparkles className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
            Wissenssuche
          </CardTitle>
          <CardDescription className="text-xs sm:text-sm">
            Stellen Sie Fragen zu Ihren Leitlinien und wissenschaftlicher Literatur
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-3 sm:px-6">
          <div className="space-y-3">
            <div className="relative">
              <Textarea
                placeholder="Ihre Frage oder Suchbegriff..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSearch())}
                rows={2}
                disabled={isSearching}
                className="resize-none text-base pr-10"
              />
              {searchResult && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-2 h-6 w-6"
                  onClick={() => {
                    // cancel/ignore any in-flight history restore
                    restoreRequestIdRef.current++;
                    setIsLoadingSources(false);
                    setIsSearching(false);

                    setSearchResult(null);
                    setSources([]);
                    setAiResponse(null);
                    setQuery('');
                    localStorage.removeItem('knowledge-active-search');
                  }}
                  title="Neue Suche"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex flex-wrap gap-1.5 sm:gap-2">
                {exampleQueries.map((eq) => (
                  <Button
                    key={eq.text}
                    variant="outline"
                    size="sm"
                    className="h-auto py-1.5 text-xs px-2 gap-1.5"
                    onClick={() => setQuery(eq.text)}
                    disabled={isSearching}
                  >
                    {eq.icon === 'kb' && <BookOpen className="h-3 w-3 text-primary flex-shrink-0" />}
                    {eq.icon === 'question' && <HelpCircle className="h-3 w-3 text-muted-foreground flex-shrink-0" />}
                    {eq.icon === 'search' && <Globe className="h-3 w-3 text-muted-foreground flex-shrink-0" />}
                    <span className="text-left line-clamp-1">{eq.text.slice(0, 35)}{eq.text.length > 35 ? '...' : ''}</span>
                  </Button>
                ))}
              </div>
              <div className="flex gap-2 self-end sm:self-auto">
                {/* Settings Popover */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-1.5">
                      <Settings2 className="h-4 w-4" />
                      <span className="hidden sm:inline">{pmcLimit}</span>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-56" align="end">
                    <div className="space-y-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">Europe PMC Limit</Label>
                        <Select value={String(pmcLimit)} onValueChange={(v) => setPmcLimit(Number(v))}>
                          <SelectTrigger className="h-8 text-sm">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="25">25 Artikel</SelectItem>
                            <SelectItem value="50">50 Artikel</SelectItem>
                            <SelectItem value="75">75 Artikel</SelectItem>
                            <SelectItem value="100">100 Artikel (max)</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-[10px] text-muted-foreground">
                          80% Relevanz, 10% Aktualität, 10% Zitierungen
                        </p>
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>
                {rateLimitError && (
                  <Button variant="outline" size="sm" onClick={handleRetry} disabled={isSearching || isGeneratingAnswer}>
                    <RefreshCw className="h-4 w-4 mr-1.5" />
                    Erneut
                  </Button>
                )}
                <Button onClick={() => handleSearch()} disabled={isSearching || !query.trim()} size="sm" className="sm:size-default">
                  {isSearching ? (
                    <Loader2 className="h-4 w-4 animate-spin sm:mr-2" />
                  ) : (
                    <Search className="h-4 w-4 sm:mr-2" />
                  )}
                  <span className="hidden sm:inline">Suchen</span>
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Loading State */}
      {isSearching && (
        <Card>
          <CardContent className="flex items-center justify-center py-10 sm:py-12">
            <div className="text-center">
              <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-primary mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Analysiere Anfrage und durchsuche Quellen...</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Results */}
      {searchResult && !isSearching && (
        <div className="space-y-4 sm:space-y-6">
          {/* Classification Badge & PMC Query */}
          <div className="space-y-2">
            {searchResult.classification && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Erkannte Kategorie:</span>
                <ClassificationBadge classification={searchResult.classification} />
              </div>
            )}
            {searchResult.pmcQuery && (
              <div className="p-2 bg-muted/50 rounded-md border">
                <div className="flex items-center gap-1.5 mb-1">
                  <Globe className="h-3 w-3 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Europe PMC Query:</span>
                </div>
                <code className="text-xs break-all text-foreground/80">{searchResult.pmcQuery}</code>
              </div>
            )}
          </div>

          {/* AI Response - above sources */}
          <AIResponsePanel
            isGenerating={isGeneratingAnswer}
            response={aiResponse}
            queryAnalysis={searchResult.queryAnalysis}
            onGenerateAnswer={() => generateAnswer(searchResult)}
            sources={sources}
            isRestoringHistory={isLoadingSources}
            onScrollToSource={handleScrollToSource}
          />

          {/* Source List */}
          <SourceListPanel 
            ref={sourceListRef}
            sources={sources} 
            queryAnalysis={searchResult.queryAnalysis}
            isLoading={isLoadingSources}
            onAuthorSearch={(authorQuery) => {
              setQuery(authorQuery);
              // Trigger search immediately
              setTimeout(() => handleSearch(), 100);
            }}
          />
        </div>
      )}

      {/* Search History - always visible at bottom */}
      {!isSearching && (
        <SearchHistoryPanel onSelectEntry={handleSelectHistoryEntry} />
      )}
    </div>
  );
}
