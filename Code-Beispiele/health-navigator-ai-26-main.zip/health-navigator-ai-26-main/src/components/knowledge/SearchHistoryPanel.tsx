import { useQuery } from '@tanstack/react-query';
import { History, Clock, ChevronRight, Sparkles, Search as SearchIcon, MessageSquare } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { formatDistanceToNow } from 'date-fns';
import { de } from 'date-fns/locale';

interface KnowledgeSearch {
  id: string;
  query: string;
  query_analysis: {
    intent: 'search' | 'question' | 'inventory';
    topic: string;
    keywords: string[];
    pmcQuery?: string;
  } | null;
  ai_response: string | null;
  created_at: string;
}

export interface HistoryEntry {
  searchId: string;
  query: string;
  queryAnalysis: KnowledgeSearch['query_analysis'];
  aiResponse: string | null;
}

interface SearchHistoryPanelProps {
  onSelectEntry: (entry: HistoryEntry) => void;
}

export function SearchHistoryPanel({ onSelectEntry }: SearchHistoryPanelProps) {
  const { data: searches, isLoading } = useQuery({
    queryKey: ['knowledge-searches-history'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('knowledge_searches')
        .select('id, query, query_analysis, ai_response, created_at')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      return data as KnowledgeSearch[];
    },
    refetchOnWindowFocus: false,
  });

  if (isLoading || !searches?.length) {
    return null;
  }

  const handleClick = (search: KnowledgeSearch) => {
    onSelectEntry({
      searchId: search.id,
      query: search.query,
      queryAnalysis: search.query_analysis,
      aiResponse: search.ai_response,
    });
  };

  return (
    <Card>
      <CardHeader className="pb-2 px-3 sm:px-6">
        <CardTitle className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
          <History className="h-4 w-4" />
          Letzte Suchen
        </CardTitle>
      </CardHeader>
      <CardContent className="px-3 sm:px-6 pb-3">
        <ScrollArea className="max-h-[280px]">
          <div className="space-y-1">
            {searches.map((search) => (
              <button
                key={search.id}
                onClick={() => handleClick(search)}
                className="w-full flex items-start gap-2 p-2 rounded-md hover:bg-muted/50 transition-colors text-left group"
              >
                <div className="flex-shrink-0 mt-0.5">
                  {search.query_analysis?.intent === 'question' ? (
                    <Sparkles className="h-3.5 w-3.5 text-primary" />
                  ) : (
                    <SearchIcon className="h-3.5 w-3.5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium line-clamp-1 group-hover:text-primary transition-colors">
                    {search.query}
                  </p>
                  <div className="flex items-center flex-wrap gap-1.5 text-xs text-muted-foreground mt-0.5">
                    <Clock className="h-3 w-3" />
                    <span>
                      {formatDistanceToNow(new Date(search.created_at), { 
                        addSuffix: true, 
                        locale: de 
                      })}
                    </span>
                    {search.query_analysis?.intent && (
                      <Badge variant="outline" className="text-[10px] h-4 px-1">
                        {search.query_analysis.intent === 'question' ? 'Frage' : 'Suche'}
                      </Badge>
                    )}
                    {search.ai_response && (
                      <Badge variant="secondary" className="text-[10px] h-4 px-1 gap-0.5">
                        <MessageSquare className="h-2.5 w-2.5" />
                        Antwort
                      </Badge>
                    )}
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 mt-1" />
              </button>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
