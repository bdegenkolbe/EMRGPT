import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Building2, 
  Link2, 
  Mail, 
  Search, 
  UserCheck,
  ExternalLink
} from 'lucide-react';

interface AuthorDetail {
  given: string;
  family: string;
  fullName: string;
  orcid?: string;
  email?: string;
  affiliations?: string[];
}

interface AuthorDetailDialogProps {
  author: AuthorDetail | null;
  isFirstAuthor?: boolean;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSearch?: (query: string) => void;
}

function openExternalLink(url: string) {
  const inIframe = (() => {
    try {
      return window.self !== window.top;
    } catch {
      return true;
    }
  })();
  
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.target = inIframe ? '_top' : '_blank';
  anchor.rel = 'noopener noreferrer';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}

export function AuthorDetailDialog({ 
  author, 
  isFirstAuthor = false,
  open, 
  onOpenChange,
  onSearch 
}: AuthorDetailDialogProps) {
  if (!author) return null;

  const handleSearchAllArticles = () => {
    if (onSearch) {
      // Europe PMC author search syntax
      const searchQuery = `AUTH:"${author.family}"`;
      onSearch(searchQuery);
      onOpenChange(false);
    }
  };

  const handleSearchFirstAuthor = () => {
    if (onSearch) {
      // Europe PMC first author search syntax
      const searchQuery = `AUTH_FIRST:"${author.family}"`;
      onSearch(searchQuery);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-primary" />
            {author.fullName}
            {isFirstAuthor && (
              <Badge variant="secondary" className="text-xs">
                <UserCheck className="h-3 w-3 mr-1" />
                Erstautor
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          {/* ORCID */}
          {author.orcid && (
            <div className="flex items-center gap-3">
              <Link2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">ORCID</p>
                <button
                  onClick={() => openExternalLink(`https://orcid.org/${author.orcid}`)}
                  className="text-sm text-primary hover:underline flex items-center gap-1"
                >
                  {author.orcid}
                  <ExternalLink className="h-3 w-3" />
                </button>
              </div>
            </div>
          )}

          {/* Email */}
          {author.email && (
            <div className="flex items-center gap-3">
              <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">E-Mail</p>
                <a
                  href={`mailto:${author.email}`}
                  className="text-sm text-primary hover:underline"
                >
                  {author.email}
                </a>
              </div>
            </div>
          )}

          {/* Affiliations */}
          {author.affiliations && author.affiliations.length > 0 && (
            <div className="flex items-start gap-3">
              <Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs text-muted-foreground mb-1">
                  {author.affiliations.length === 1 ? 'Institution' : 'Institutionen'}
                </p>
                <ul className="space-y-1">
                  {author.affiliations.map((affiliation, idx) => (
                    <li key={idx} className="text-sm">
                      {affiliation}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* No additional info */}
          {!author.orcid && !author.email && (!author.affiliations || author.affiliations.length === 0) && (
            <p className="text-sm text-muted-foreground text-center py-2">
              Keine weiteren Informationen verfügbar
            </p>
          )}

          {/* Search Actions */}
          {onSearch && (
            <div className="border-t pt-4 mt-4 space-y-2">
              <p className="text-xs font-medium text-muted-foreground mb-2">
                Weitere Artikel suchen
              </p>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start gap-2"
                onClick={handleSearchAllArticles}
              >
                <Search className="h-4 w-4" />
                Alle Artikel von {author.family}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start gap-2"
                onClick={handleSearchFirstAuthor}
              >
                <UserCheck className="h-4 w-4" />
                Artikel mit {author.family} als Erstautor
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
