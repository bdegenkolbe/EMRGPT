import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { BookOpen, Globe, Database, HelpCircle, Sparkles } from 'lucide-react';

interface QueryClarificationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  query: string;
  options?: string[];
  onSelectCategory: (category: string) => void;
}

const categoryInfo: Record<string, { icon: React.ReactNode; label: string; description: string }> = {
  literature: {
    icon: <Globe className="h-5 w-5" />,
    label: 'Literatursuche',
    description: 'Suche in Europe PMC / PubMed nach aktuellen Artikeln',
  },
  knowledge_base: {
    icon: <BookOpen className="h-5 w-5" />,
    label: 'Wissensbasis',
    description: 'Suche in Ihren hochgeladenen Leitlinien (RAG)',
  },
  explanation: {
    icon: <HelpCircle className="h-5 w-5" />,
    label: 'Erklärung',
    description: 'Erkläre Konzepte aus vorhandenen Daten',
  },
  inventory: {
    icon: <Database className="h-5 w-5" />,
    label: 'Bestandsabfrage',
    description: 'Statistiken und Metadaten Ihrer Dokumente',
  },
  combined: {
    icon: <Sparkles className="h-5 w-5" />,
    label: 'Kombinierte Suche',
    description: 'Durchsuche beide Quellen (intern + extern)',
  },
};

export function QueryClarificationDialog({
  open,
  onOpenChange,
  query,
  options,
  onSelectCategory,
}: QueryClarificationDialogProps) {
  // Default categories if none provided
  const displayCategories = options?.length 
    ? options.map(opt => {
        // Try to match option text to category
        const lowerOpt = opt.toLowerCase();
        if (lowerOpt.includes('literatur') || lowerOpt.includes('pubmed') || lowerOpt.includes('artikel')) return 'literature';
        if (lowerOpt.includes('leitlinie') || lowerOpt.includes('wissensb')) return 'knowledge_base';
        if (lowerOpt.includes('erkläre') || lowerOpt.includes('erklärung')) return 'explanation';
        if (lowerOpt.includes('bestand') || lowerOpt.includes('statistik') || lowerOpt.includes('dokument')) return 'inventory';
        return 'combined';
      })
    : ['knowledge_base', 'literature', 'combined'];

  const uniqueCategories = [...new Set(displayCategories)];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Wohin soll ich suchen?</DialogTitle>
          <DialogDescription className="pt-2">
            Ihre Anfrage "<span className="font-medium text-foreground">{query}</span>" kann unterschiedlich interpretiert werden.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-3 py-4">
          {uniqueCategories.map((category) => {
            const info = categoryInfo[category] || categoryInfo.combined;
            return (
              <Button
                key={category}
                variant="outline"
                className="h-auto p-4 justify-start gap-4 text-left"
                onClick={() => {
                  onSelectCategory(category);
                  onOpenChange(false);
                }}
              >
                <div className="p-2 rounded-lg bg-primary/10 text-primary">
                  {info.icon}
                </div>
                <div className="flex-1">
                  <div className="font-medium">{info.label}</div>
                  <div className="text-sm text-muted-foreground">{info.description}</div>
                </div>
              </Button>
            );
          })}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Abbrechen
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
