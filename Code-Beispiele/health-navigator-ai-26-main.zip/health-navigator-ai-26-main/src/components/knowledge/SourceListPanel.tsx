import { useState, useEffect, useRef, useImperativeHandle, forwardRef, useCallback } from 'react';
import { 
  BookOpen, 
  Globe, 
  ExternalLink,
  ChevronDown,
  ChevronRight,
  Loader2,
  CheckCircle,
  AlertCircle,
  Languages,
  Download,
  FileText,
  ToggleLeft,
  ToggleRight,
  User,
  Building2,
  Link2,
  Copy,
  Check,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { AuthorDetailDialog } from './AuthorDetailDialog';

interface AuthorDetail {
  given: string;
  family: string;
  fullName: string;
  orcid?: string;
  affiliations?: string[];
}

interface KnowledgeSource {
  id: string;
  source_type: string;
  external_id?: string;
  title: string;
  translated_title?: string;
  authors?: string;
  year?: number;
  relevance_score?: number;
  url?: string;
  content_status: string;
  translation_status: string;
  original_language?: string;
  original_content?: string;
  translated_content?: string;
  content_type?: string;
  pdf_path?: string;
  metadata?: {
    authorDetails?: AuthorDetail[];
    journal?: string;
    publicationDate?: string;
    doi?: string;
    pmid?: string;
    pmcid?: string;
    citedByCount?: number;
    isOpenAccess?: boolean;
    pdfUrl?: string;
  };
}

interface QueryAnalysis {
  intent: 'search' | 'question' | 'inventory';
  topic: string;
  keywords: string[];
}

export interface SourceListPanelHandle {
  scrollToSource: (index: number) => void;
}

interface SourceListPanelProps {
  sources: KnowledgeSource[];
  queryAnalysis: QueryAnalysis;
  isLoading?: boolean;
  onAuthorSearch?: (query: string) => void;
}

export const SourceListPanel = forwardRef<SourceListPanelHandle, SourceListPanelProps>(
  function SourceListPanel({ sources, queryAnalysis, isLoading = false, onAuthorSearch }, ref) {
  const { toast } = useToast();
  const [expandedSources, setExpandedSources] = useState<Set<string>>(new Set());
  const [importingSource, setImportingSource] = useState<string | null>(null);
  const sourceRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const scrollViewportRef = useRef<HTMLDivElement | null>(null);
  
  // Resizable height for the scroll area
  const [scrollHeight, setScrollHeight] = useState<number>(() => {
    const saved = localStorage.getItem('knowledge-sources-height');
    return saved ? Number(saved) : 400;
  });
  const isResizing = useRef(false);
  const startY = useRef(0);
  const startHeight = useRef(0);

  // Pagination: show first 50, then allow "Load More"
  const INITIAL_PAGE_SIZE = 50;
  const [displayCount, setDisplayCount] = useState(INITIAL_PAGE_SIZE);

  // Track background job status (PDF downloads + content loading run in backend)
  const [jobStatus, setJobStatus] = useState<{
    pdfCompleted: number;
    pdfTotal: number;
    pdfFailed: number;
    contentCompleted: number;
    contentTotal: number;
    isRunning: boolean;
  }>({ pdfCompleted: 0, pdfTotal: 0, pdfFailed: 0, contentCompleted: 0, contentTotal: 0, isRunning: false });
  const [isRetrying, setIsRetrying] = useState(false);
  const [stalledDetected, setStalledDetected] = useState(false);
  const pollingSearchIdRef = useRef<string | null>(null);
  const searchIdRef = useRef<string | null>(null);

  // Persist scroll position on scroll
  const handleScroll = useCallback(() => {
    if (scrollViewportRef.current) {
      localStorage.setItem('knowledge-sources-scroll', String(scrollViewportRef.current.scrollTop));
    }
  }, []);

  // Restore scroll position after sources load
  useEffect(() => {
    if (sources.length > 0 && !isLoading && scrollViewportRef.current) {
      const saved = localStorage.getItem('knowledge-sources-scroll');
      if (saved) {
        requestAnimationFrame(() => {
          scrollViewportRef.current?.scrollTo({ top: Number(saved) });
        });
      }
    }
  }, [sources.length, isLoading]);

  // Resize handlers
  const handleResizeStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isResizing.current = true;
    startY.current = e.clientY;
    startHeight.current = scrollHeight;

    const handleMouseMove = (ev: MouseEvent) => {
      if (!isResizing.current) return;
      const newHeight = Math.max(200, Math.min(800, startHeight.current + (ev.clientY - startY.current)));
      setScrollHeight(newHeight);
      localStorage.setItem('knowledge-sources-height', String(newHeight));
    };
    const handleMouseUp = () => {
      isResizing.current = false;
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, [scrollHeight]);

  // Reset display count when sources change significantly
  useEffect(() => {
    setDisplayCount(INITIAL_PAGE_SIZE);
  }, [sources.length > 0 ? sources[0]?.id : null]);

  // Detect stalled state: jobs queue empty but sources still incomplete (content, translation, or PDF)
  const checkStalledState = useCallback(() => {
    const loaded = sources.filter(s => s.content_status === 'loaded').length;
    const errored = sources.filter(s => s.content_status === 'error').length;
    const translated = sources.filter(s => s.translation_status === 'completed' || s.translation_status === 'skipped').length;
    const transErrored = sources.filter(s => s.translation_status === 'error').length;
    const hasPdf = sources.filter(s => !!s.pdf_path).length;
    
    const contentDone = loaded + errored === sources.length;
    const transDone = translated + transErrored >= sources.length;
    const pdfDone = hasPdf >= loaded;
    const allDone = contentDone && transDone && pdfDone;
    
    const hasIncomplete = !allDone;
    
    if (hasIncomplete && !jobStatus.isRunning && sources.length > 0) {
      setStalledDetected(true);
    } else {
      setStalledDetected(false);
    }
  }, [sources, jobStatus.isRunning]);

  useEffect(() => {
    // Delay check to allow polling to settle
    const timer = setTimeout(checkStalledState, 5000);
    return () => clearTimeout(timer);
  }, [checkStalledState]);

  // Retry stalled jobs
  const handleRetry = useCallback(async () => {
    if (!searchIdRef.current) {
      // Get search_id
      const { data } = await supabase
        .from('knowledge_sources')
        .select('search_id')
        .eq('id', sources[0]?.id)
        .single();
      if (data) searchIdRef.current = data.search_id;
    }

    if (!searchIdRef.current) return;

    setIsRetrying(true);
    setStalledDetected(false);

    try {
      const { data, error } = await supabase.functions.invoke('background-job-runner', {
        body: { mode: 'requeue', searchId: searchIdRef.current, targetLanguage: 'de' },
      });

      if (error) throw error;

      const requeued = data?.requeued || 0;
      if (requeued > 0) {
        toast({
          title: 'Jobs neu gestartet',
          description: `${requeued} ausstehende Aufgaben wurden erneut eingereiht.`,
        });
        // Reset polling to pick up new jobs
        pollingSearchIdRef.current = null;
      } else {
        toast({
          title: 'Keine ausstehenden Aufgaben',
          description: 'Alle Aufgaben sind bereits abgeschlossen.',
        });
      }
    } catch (err) {
      console.error('[SourceListPanel] Retry failed:', err);
      toast({
        title: 'Fehler',
        description: 'Jobs konnten nicht neu gestartet werden.',
        variant: 'destructive',
      });
    } finally {
      setIsRetrying(false);
      // Re-check stalled state after a delay to allow sources to refresh
      setTimeout(() => {
        checkStalledState();
      }, 10000);
    }
  }, [sources, toast]);

  // Poll background_jobs table for progress (jobs run in backend)
  useEffect(() => {
    if (isLoading || sources.length === 0) return;
    
    const firstSourceId = sources[0]?.id;
    if (!firstSourceId) return;

    if (pollingSearchIdRef.current === firstSourceId) return;
    pollingSearchIdRef.current = firstSourceId;

    let isCancelled = false;

    const pollJobs = async () => {
      const { data: sourceData } = await supabase
        .from('knowledge_sources')
        .select('search_id')
        .eq('id', firstSourceId)
        .single();

      if (!sourceData?.search_id || isCancelled) return;

      const searchId = sourceData.search_id;
      searchIdRef.current = searchId;

      const poll = async () => {
        if (isCancelled) return;

        const { data: jobs } = await supabase
          .from('background_jobs')
          .select('job_type, status')
          .eq('search_id', searchId);

        if (!jobs || isCancelled) return;

        const pdfJobs = jobs.filter(j => j.job_type === 'pdf_download' || j.job_type === 'generate_pdf');
        const contentJobs = jobs.filter(j => j.job_type === 'content_load' || j.job_type === 'translate');

        const pdfCompleted = pdfJobs.filter(j => j.status === 'completed').length;
        const pdfFailed = pdfJobs.filter(j => j.status === 'failed').length;
        const pdfTotal = pdfJobs.length;

        const contentCompleted = contentJobs.filter(j => j.status === 'completed').length;
        const contentTotal = contentJobs.length;

        const pendingOrRunning = jobs.filter(j => j.status === 'pending' || j.status === 'running').length;
        const isRunning = pendingOrRunning > 0;

        setJobStatus({
          pdfCompleted,
          pdfTotal,
          pdfFailed,
          contentCompleted,
          contentTotal,
          isRunning,
        });

        if (!isRunning && pdfTotal > 0 && pdfCompleted > 0) {
          toast({
            title: 'PDF-Download abgeschlossen',
            description: `${pdfCompleted} von ${pdfTotal} PDFs gespeichert${pdfFailed > 0 ? ` (${pdfFailed} fehlgeschlagen)` : ''}`,
          });
        }

        if (isRunning && !isCancelled) {
          setTimeout(poll, 2000);
        }
      };

      await poll();
    };

    pollJobs();

    return () => {
      isCancelled = true;
    };
  }, [sources, isLoading, toast]);

  // Expose scrollToSource method to parent
  useImperativeHandle(ref, () => ({
    scrollToSource: (index: number) => {
      // First ensure the source is visible
      if (index >= displayCount) {
        setDisplayCount(index + 10);
      }
      
      const sourceId = sources[index]?.id;
      if (sourceId) {
        // Expand the source
        setExpandedSources(prev => new Set(prev).add(sourceId));
        
        // Scroll to the source with a slight delay to allow expansion
        setTimeout(() => {
          const element = sourceRefs.current.get(index);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            // Add highlight effect
            element.classList.add('ring-2', 'ring-primary', 'ring-offset-2');
            setTimeout(() => {
              element.classList.remove('ring-2', 'ring-primary', 'ring-offset-2');
            }, 2000);
          }
        }, 100);
      }
    }
  }), [sources, displayCount]);

  const toggleSource = (id: string) => {
    setExpandedSources(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const guidelineSources = sources.filter(s => s.source_type === 'guideline');
  const literatureSources = sources.filter(s => s.source_type === 'europepmc');
  
  // Apply pagination
  const displayedGuidelineSources = guidelineSources.slice(0, displayCount);
  const remainingForLiterature = Math.max(0, displayCount - guidelineSources.length);
  const displayedLiteratureSources = literatureSources.slice(0, remainingForLiterature);
  
  const totalDisplayed = displayedGuidelineSources.length + displayedLiteratureSources.length;
  const hasMore = totalDisplayed < sources.length;

  const loadedCount = sources.filter(s => s.content_status === 'loaded').length;
  const errorCount = sources.filter(s => s.content_status === 'error').length;
  const translatedCount = sources.filter(s => s.translation_status === 'completed' || s.translation_status === 'skipped').length;
  const transErrorCount = sources.filter(s => s.translation_status === 'error').length;
  const pdfCount = sources.filter(s => !!s.pdf_path).length;

  const getStatusIcon = (source: KnowledgeSource) => {
    if (source.content_status === 'loading' || source.translation_status === 'loading') {
      return <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />;
    }
    if (source.content_status === 'error') {
      return <AlertCircle className="h-3 w-3 text-destructive" />;
    }
    if (source.translation_status === 'completed' || source.translation_status === 'skipped') {
      return <CheckCircle className="h-3 w-3 text-primary" />;
    }
    return null;
  };

  const getDisplayContent = (source: KnowledgeSource): string | null => {
    if (source.translated_content) return source.translated_content;
    if (source.original_content) return source.original_content;
    return null;
  };
  
  const decodeAndStrip = (text: string): string => {
    // Decode HTML entities by using a temporary element approach
    let decoded = text
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&apos;/g, "'");
    // Strip any remaining HTML tags
    decoded = decoded.replace(/<[^>]*>/g, '');
    // Decode again in case of double-encoding
    decoded = decoded
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
      .replace(/<[^>]*>/g, '');
    return decoded.trim();
  };

  const getDisplayTitle = (source: KnowledgeSource): string => {
    const raw = source.translated_title || source.title;
    return decodeAndStrip(raw);
  };

  return (
    <Card>
      <CardHeader className="pb-3 px-3 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <CardTitle className="text-base sm:text-lg flex items-center gap-2">
            <BookOpen className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
            Quellen ({sources.length})
          </CardTitle>
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <span className={errorCount > 0 ? 'text-destructive' : ''}>
              {loadedCount}/{sources.length} geladen{errorCount > 0 ? ` (${errorCount} ✗)` : ''}
            </span>
            {sources.some(s => s.original_language !== 'de') && (
              <>
                <span>•</span>
                <Languages className="h-3 w-3" />
                <span className={transErrorCount > 0 ? 'text-destructive' : ''}>
                  {translatedCount}/{sources.length} übersetzt{transErrorCount > 0 ? ` (${transErrorCount} ✗)` : ''}
                </span>
              </>
            )}
            <>
              <span>•</span>
              <FileText className="h-3 w-3" />
              <span>{pdfCount}/{loadedCount} PDFs</span>
            </>
            {stalledDetected && !isRetrying && (
              <Button
                variant="ghost"
                size="sm"
                className="h-5 px-1.5 text-xs gap-1 text-amber-600 hover:text-amber-700"
                onClick={handleRetry}
              >
                <RefreshCw className="h-3 w-3" />
                Fortsetzen
              </Button>
            )}
            {isRetrying && (
              <Loader2 className="h-3 w-3 animate-spin text-primary" />
            )}
          </div>
        </div>
        {(loadedCount < sources.length || translatedCount < sources.length || jobStatus.isRunning) && (
          <Progress 
            value={jobStatus.isRunning 
              ? ((jobStatus.pdfCompleted + jobStatus.contentCompleted) / Math.max(1, jobStatus.pdfTotal + jobStatus.contentTotal)) * 100
              : (loadedCount + translatedCount) / (sources.length * 2) * 100
            } 
            className="h-1 mt-2"
          />
        )}
      </CardHeader>
      <CardContent className="px-3 sm:px-6">
        {isLoading && sources.length === 0 ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground mr-2" />
            <span className="text-sm text-muted-foreground">Quellen werden geladen...</span>
          </div>
        ) : (
        <>
        <ScrollArea style={{ height: `${scrollHeight}px` }} onScrollCapture={handleScroll} ref={(node) => {
          if (node) {
            const viewport = (node as HTMLElement).querySelector('[data-radix-scroll-area-viewport]');
            if (viewport) scrollViewportRef.current = viewport as HTMLDivElement;
          }
        }}>
          <div className="space-y-4 pr-2 sm:pr-4">
            {/* Guidelines Section */}
            {displayedGuidelineSources.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  Leitlinien ({guidelineSources.length})
                </h4>
                <div className="space-y-2">
                  {displayedGuidelineSources.map((source, idx) => (
                    <div
                      key={source.id}
                      ref={(el) => el && sourceRefs.current.set(idx, el)}
                      className="transition-all duration-300"
                    >
                      <SourceItem
                        source={source}
                        index={idx + 1}
                        isExpanded={expandedSources.has(source.id)}
                        onToggle={() => toggleSource(source.id)}
                        statusIcon={getStatusIcon(source)}
                        displayContent={getDisplayContent(source)}
                        originalContent={source.original_content || null}
                        displayTitle={getDisplayTitle(source)}
                        originalTitle={source.title}
                        onAuthorSearch={onAuthorSearch}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Literature Section */}
            {displayedLiteratureSources.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Wissenschaftliche Literatur ({literatureSources.length})
                </h4>
                <div className="space-y-2">
                  {displayedLiteratureSources.map((source, idx) => {
                    const globalIdx = guidelineSources.length + idx;
                    return (
                      <div
                        key={source.id}
                        ref={(el) => el && sourceRefs.current.set(globalIdx, el)}
                        className="transition-all duration-300"
                      >
                        <SourceItem
                          source={source}
                          index={globalIdx + 1}
                          isExpanded={expandedSources.has(source.id)}
                          onToggle={() => toggleSource(source.id)}
                          statusIcon={getStatusIcon(source)}
                          displayContent={getDisplayContent(source)}
                          originalContent={source.original_content || null}
                          displayTitle={getDisplayTitle(source)}
                          originalTitle={source.title}
                          onAuthorSearch={onAuthorSearch}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Load More Button */}
            {hasMore && (
              <div className="flex justify-center pt-2 pb-4">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setDisplayCount(prev => prev + 50)}
                  className="gap-2"
                >
                  <ChevronDown className="h-4 w-4" />
                  Weitere {Math.min(50, sources.length - totalDisplayed)} von {sources.length - totalDisplayed} laden
                </Button>
              </div>
            )}

            {sources.length === 0 && !isLoading && (
              <p className="text-center text-muted-foreground py-8">
                Keine Quellen gefunden
              </p>
            )}
          </div>
        </ScrollArea>
        {/* Resize handle */}
        <div
          className="h-2 cursor-row-resize flex items-center justify-center hover:bg-muted/50 transition-colors rounded-b"
          onMouseDown={handleResizeStart}
        >
          <div className="w-8 h-0.5 rounded-full bg-border" />
        </div>
        </>
        )}
      </CardContent>
    </Card>
  );
});

interface SourceItemProps {
  source: KnowledgeSource;
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
  statusIcon: React.ReactNode;
  displayContent: string | null;
  originalContent: string | null;
  displayTitle: string;
  originalTitle: string;
  onAuthorSearch?: (query: string) => void;
}

function SourceItem({ 
  source, 
  index, 
  isExpanded, 
  onToggle, 
  statusIcon, 
  displayContent,
  originalContent,
  displayTitle,
  originalTitle,
  onAuthorSearch
}: SourceItemProps) {
  const { toast } = useToast();
  const [showOriginal, setShowOriginal] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const [selectedAuthor, setSelectedAuthor] = useState<AuthorDetail | null>(null);
  const [selectedAuthorIsFirst, setSelectedAuthorIsFirst] = useState(false);
  const [authorDialogOpen, setAuthorDialogOpen] = useState(false);
  
  const hasTranslation = source.original_language !== 'de' && 
    (source.translation_status === 'completed' || source.translated_content || source.translated_title);
  
  const currentTitle = showOriginal ? originalTitle : displayTitle;
  const currentContent = showOriginal ? originalContent : displayContent;

  const handleAuthorClick = (author: AuthorDetail, isFirst: boolean, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedAuthor(author);
    setSelectedAuthorIsFirst(isFirst);
    setAuthorDialogOpen(true);
  };

  // Check if this source has a PMC ID (can download PDF)
  const pmcid = source.metadata?.pmcid;
  const canDownloadPdf = !!pmcid && source.metadata?.isOpenAccess;

  const handleDownloadPdf = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!pmcid) return;

    setIsDownloadingPdf(true);
    try {
      const { data, error } = await supabase.functions.invoke('europepmc-download', {
        body: {
          pmcid: pmcid.startsWith('PMC') ? pmcid : `PMC${pmcid}`,
          title: source.title,
          metadata: {
            authors: source.metadata?.authorDetails?.map(a => a.fullName) || [],
            journal: source.metadata?.journal,
            publicationDate: source.metadata?.publicationDate,
            doi: source.metadata?.doi,
            abstract: source.original_content || source.translated_content,
          }
        }
      });

      if (error) throw error;

      toast({
        title: 'PDF gespeichert',
        description: `${data.filePath} (${Math.round((data.fileSize || 0) / 1024)} KB)`,
      });
    } catch (err: any) {
      console.error('PDF download error:', err);
      toast({
        variant: 'destructive',
        title: 'PDF-Download fehlgeschlagen',
        description: err.message || 'Unbekannter Fehler',
      });
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  const handleCopyLink = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!source.url) return;

    const ok = await copyToClipboard(source.url);
    if (!ok) {
      toast({
        variant: 'destructive',
        title: 'Kopieren fehlgeschlagen',
        description: 'Ihr Browser hat den Clipboard-Zugriff blockiert.',
      });
      return;
    }

    setLinkCopied(true);
    window.setTimeout(() => setLinkCopied(false), 1500);
    toast({ title: 'Link kopiert' });
  };

  const handleOpenLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!source.url) return;
    openExternalLink(source.url);
  };

  return (
    <>
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <div className="rounded-lg border bg-card hover:bg-muted/50 transition-colors">
        <div className="flex items-start">
          <CollapsibleTrigger asChild>
            <button className="flex-1 p-2.5 sm:p-3 text-left">
              <div className="flex items-start gap-1.5 sm:gap-2">
                <span className="text-xs font-mono text-muted-foreground mt-0.5">[{index}]</span>
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4 mt-0.5 text-muted-foreground flex-shrink-0" />
                ) : (
                  <ChevronRight className="h-4 w-4 mt-0.5 text-muted-foreground flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-1.5 sm:gap-2">
                    <h5 className="font-medium text-sm leading-snug">
                      {currentTitle}
                    </h5>
                    {statusIcon}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-xs text-muted-foreground mt-1.5">
                    {source.year && <span>{source.year}</span>}
                    {/* Content status badge */}
                    {source.content_status === 'loaded' ? (
                      <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1 border-emerald-500/40 text-emerald-700 dark:text-emerald-400">
                        <CheckCircle className="h-3 w-3" />
                        {source.content_type === 'fulltext' ? 'Volltext' : 'Abstract'}
                      </Badge>
                    ) : source.content_status === 'error' ? (
                      <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1 border-destructive/40 text-destructive">
                        <AlertCircle className="h-3 w-3" />
                        Fehler
                      </Badge>
                    ) : source.content_status === 'loading' ? (
                      <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1">
                        <Loader2 className="h-3 w-3 animate-spin" />
                        Laden…
                      </Badge>
                    ) : null}
                    {/* Translation status badge */}
                    {source.original_language && source.original_language !== 'de' && (
                      source.translation_status === 'completed' ? (
                        <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1 border-blue-500/40 text-blue-700 dark:text-blue-400">
                          <Languages className="h-3 w-3" />
                          DE
                        </Badge>
                      ) : source.translation_status === 'error' ? (
                        <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1 border-destructive/40 text-destructive">
                          <Languages className="h-3 w-3" />
                          Fehler
                        </Badge>
                      ) : source.translation_status === 'loading' ? (
                        <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          Übersetze…
                        </Badge>
                      ) : source.original_language !== 'de' ? (
                        <Badge variant="secondary" className="text-xs h-5 px-1.5">
                          {source.original_language.toUpperCase()}
                        </Badge>
                      ) : null
                    )}
                    {/* PDF status badge */}
                    {source.pdf_path ? (
                      <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1 border-violet-500/40 text-violet-700 dark:text-violet-400">
                        <FileText className="h-3 w-3" />
                        PDF
                      </Badge>
                    ) : source.content_status === 'loaded' && !source.pdf_path ? (
                      <Badge variant="outline" className="text-xs h-5 px-1.5 gap-1 text-muted-foreground">
                        <FileText className="h-3 w-3" />
                        Kein PDF
                      </Badge>
                    ) : null}
                    {source.relevance_score && (
                      <Badge variant="outline" className="text-xs h-5 px-1.5">
                        {Math.round(source.relevance_score * 100)}%
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </button>
          </CollapsibleTrigger>

          {source.url && (
            <div className="mt-2.5 sm:mt-3 mr-2 sm:mr-3 flex gap-1">
              <button
                type="button"
                onClick={handleOpenLink}
                className="h-7 w-7 flex-shrink-0 inline-flex items-center justify-center rounded-md hover:bg-muted transition-colors"
                title="Quelle öffnen"
                aria-label="Quelle öffnen"
              >
                <ExternalLink className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={handleCopyLink}
                className="h-7 w-7 flex-shrink-0 inline-flex items-center justify-center rounded-md hover:bg-muted transition-colors"
                title="Link kopieren"
                aria-label="Link kopieren"
              >
                {linkCopied ? (
                  <Check className="h-3.5 w-3.5 text-primary" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
              </button>
            </div>
          )}
        </div>
        <CollapsibleContent>
          <div className="px-2.5 sm:px-3 pb-3 pt-0">
            {/* Translation Toggle */}
            {hasTranslation && (
              <div className="flex items-center justify-end gap-2 mb-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowOriginal(!showOriginal);
                  }}
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-md hover:bg-muted"
                >
                  {showOriginal ? (
                    <>
                      <ToggleRight className="h-4 w-4 text-primary" />
                      <span>Original ({source.original_language?.toUpperCase()})</span>
                    </>
                  ) : (
                    <>
                      <ToggleLeft className="h-4 w-4" />
                      <span>Übersetzung (DE)</span>
                    </>
                  )}
                </button>
              </div>
            )}
            <div className="p-3 sm:p-4 bg-muted/50 rounded-lg space-y-3">
              {/* Publication Metadata Section */}
              {(source.metadata?.journal || source.metadata?.publicationDate || source.metadata?.doi) && (
                <div className="border-b border-border/50 pb-3 space-y-1.5">
                  {source.metadata.journal && (
                    <div className="flex items-center gap-1.5 text-sm">
                      <BookOpen className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                      <span className="font-medium">{source.metadata.journal}</span>
                    </div>
                  )}
                  <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                    {source.metadata.publicationDate && (
                      <span>Veröffentlicht: {source.metadata.publicationDate}</span>
                    )}
                    {source.metadata.citedByCount !== undefined && source.metadata.citedByCount > 0 && (
                      <span>{source.metadata.citedByCount} Zitierungen</span>
                    )}
                    {source.metadata.isOpenAccess && (
                      <Badge variant="secondary" className="text-xs h-5">
                        Open Access
                      </Badge>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    {source.metadata.pmid && (
                      <Badge variant="outline" className="h-5">PMID: {source.metadata.pmid}</Badge>
                    )}
                    {source.metadata.pmcid && (
                      <Badge variant="outline" className="h-5">PMC{source.metadata.pmcid}</Badge>
                    )}
                    {source.metadata.doi && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          openExternalLink(`https://doi.org/${source.metadata!.doi}`);
                        }}
                        className="inline-flex items-center gap-1 text-primary hover:underline"
                      >
                        DOI: {source.metadata.doi}
                      </button>
                    )}
                    {source.metadata.pdfUrl && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          openExternalLink(source.metadata!.pdfUrl!);
                        }}
                        className="inline-flex items-center gap-1 text-primary hover:underline"
                      >
                        <FileText className="h-3 w-3" />
                        PDF
                      </button>
                    )}
                    {canDownloadPdf && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-6 text-xs gap-1"
                        disabled={isDownloadingPdf}
                        onClick={handleDownloadPdf}
                      >
                        {isDownloadingPdf ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <Download className="h-3 w-3" />
                        )}
                        In Wissensdatenbank speichern
                      </Button>
                    )}
                  </div>
                </div>
              )}
              
              {/* Author Details Section - Horizontal with semicolons */}
              {source.metadata?.authorDetails && source.metadata.authorDetails.length > 0 && (
                <div className="border-b border-border/50 pb-3">
                  <h6 className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1.5">
                    <User className="h-3 w-3" />
                    Autoren ({source.metadata.authorDetails.length})
                  </h6>
                  <p className="text-sm leading-relaxed">
                    {source.metadata.authorDetails.map((author, idx) => (
                      <span key={idx}>
                        <button
                          type="button"
                          onClick={(e) => handleAuthorClick(author, idx === 0, e)}
                          className="text-primary hover:underline font-medium"
                        >
                          {author.fullName}
                        </button>
                        {author.orcid && (
                          <a
                            href={`https://orcid.org/${author.orcid}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="ml-1 inline-flex items-center gap-0.5 text-xs text-muted-foreground hover:text-primary"
                            title="ORCID"
                          >
                            <Link2 className="h-3 w-3" />
                          </a>
                        )}
                        {idx < source.metadata!.authorDetails!.length - 1 && (
                          <span className="text-muted-foreground">; </span>
                        )}
                      </span>
                    ))}
                  </p>
                </div>
              )}
              
              {/* Content */}
              {currentContent ? (
                <article className="text-sm leading-relaxed text-foreground/90 space-y-2">
                  <FormattedContent content={currentContent} />
                </article>
              ) : source.content_status === 'loading' ? (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm">Inhalt wird geladen...</span>
                </div>
              ) : source.content_status === 'error' ? (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">Abstract nicht verfügbar in Europe PMC.</span>
                    {' '}Viele Fachzeitschriften stellen Abstracts nur auf der Verlagsseite bereit.
                  </p>
                  {source.url && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                        onClick={handleOpenLink}
                      >
                      <ExternalLink className="h-3.5 w-3.5" />
                      Beim Verlag öffnen
                    </Button>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">Kein Inhalt verfügbar</p>
              )}
            </div>
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
    
    {/* Author Detail Dialog - outside Collapsible so it stays open */}
    <AuthorDetailDialog
      author={selectedAuthor}
      isFirstAuthor={selectedAuthorIsFirst}
      open={authorDialogOpen}
      onOpenChange={setAuthorDialogOpen}
      onSearch={onAuthorSearch}
    />
    </>
  );
}

function getExternalLinkTarget(): '_blank' | '_self' | '_top' {
  if (typeof window === 'undefined') return '_blank';

  // In Lovable Editor, the app runs inside an iframe.
  // Many external sites (Google, Europe PMC, publishers) refuse to be displayed in an iframe.
  // `_top` reliably breaks out of the iframe (works in preview); in a normal app context we use `_blank`.
  const inIframe = (() => {
    try {
      return window.self !== window.top;
    } catch {
      return true;
    }
  })();
  if (inIframe) return '_top';

  const ua = navigator.userAgent;
  const isSafari = /Safari/i.test(ua) && !/Chrome|Chromium|Edg|OPR/i.test(ua);
  // Safari can block some COOP sites when opened with _blank; _self is more reliable there.
  return isSafari ? '_self' : '_blank';
}

function openExternalLink(url: string) {
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.target = getExternalLinkTarget();
  anchor.rel = 'noopener noreferrer';

  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}

async function copyToClipboard(text: string): Promise<boolean> {
  // Primary: modern async clipboard API
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Fallback: execCommand (often works even when clipboard permissions are restricted in iframes)
    try {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.setAttribute('readonly', '');
      textarea.style.position = 'fixed';
      textarea.style.top = '0';
      textarea.style.left = '-9999px';

      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(textarea);
      return ok;
    } catch {
      return false;
    }
  }
}

// Component to render content with HTML tags properly formatted
function FormattedContent({ content }: { content: string }) {
  // Convert HTML entities first
  let text = content
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");

  // Split by heading tags and inline formatting tags
  const parts: React.ReactNode[] = [];
  
  // Regex to match headings (h1-h6) and their content
  const headingRegex = /<h([1-6])>(.*?)<\/h\1>/gi;
  
  let lastIndex = 0;
  let match;
  let partIndex = 0;
  
  while ((match = headingRegex.exec(text)) !== null) {
    // Add text before the heading
    if (match.index > lastIndex) {
      const textBefore = text.slice(lastIndex, match.index);
      if (textBefore.trim()) {
        parts.push(
          <span key={partIndex++} className="whitespace-pre-wrap">
            {formatInlineTags(textBefore)}
          </span>
        );
      }
    }
    
    // Add the heading
    const level = parseInt(match[1]);
    const headingContent = match[2];
    const HeadingClass = level <= 3 
      ? "font-semibold text-foreground mt-3 mb-1 first:mt-0 block" 
      : "font-medium text-foreground mt-2 mb-1 first:mt-0 block";
    
    parts.push(
      <span key={partIndex++} className={HeadingClass}>
        {formatInlineTags(headingContent)}
      </span>
    );
    
    lastIndex = match.index + match[0].length;
  }
  
  // Add remaining text after last heading
  if (lastIndex < text.length) {
    const remaining = text.slice(lastIndex);
    if (remaining.trim()) {
      parts.push(
        <span key={partIndex++} className="whitespace-pre-wrap">
          {formatInlineTags(remaining)}
        </span>
      );
    }
  }
  
  // If no headings found, just format inline tags
  if (parts.length === 0) {
    return <div className="whitespace-pre-wrap">{formatInlineTags(text)}</div>;
  }
  
  return <div className="space-y-1">{parts}</div>;
}

// Helper to format inline tags (bold, italic, underline)
function formatInlineTags(text: string): React.ReactNode {
  const tagRegex = /<(\/?)([biu]|strong|em)>/gi;
  const segments: { text: string; bold: boolean; italic: boolean }[] = [];
  
  let lastIndex = 0;
  let boldActive = false;
  let italicActive = false;
  let match;
  
  // Reset regex
  const regex = new RegExp(tagRegex);
  
  while ((match = regex.exec(text)) !== null) {
    const textBefore = text.slice(lastIndex, match.index);
    if (textBefore) {
      segments.push({ text: textBefore, bold: boldActive, italic: italicActive });
    }
    
    const isClosing = match[1] === '/';
    const tagName = match[2].toLowerCase();
    
    if (tagName === 'b' || tagName === 'strong') {
      boldActive = !isClosing;
    } else if (tagName === 'i' || tagName === 'em' || tagName === 'u') {
      italicActive = !isClosing;
    }
    
    lastIndex = match.index + match[0].length;
  }
  
  // Add remaining text
  if (lastIndex < text.length) {
    segments.push({ text: text.slice(lastIndex), bold: boldActive, italic: italicActive });
  }
  
  if (segments.length === 0) {
    return text;
  }
  
  return (
    <>
      {segments.map((segment, i) => {
        if (!segment.bold && !segment.italic) {
          return <span key={i}>{segment.text}</span>;
        }
        let className = '';
        if (segment.bold) className += 'font-semibold ';
        if (segment.italic) className += 'italic ';
        return <span key={i} className={className.trim()}>{segment.text}</span>;
      })}
    </>
  );
}
