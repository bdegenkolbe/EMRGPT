import { Badge } from '@/components/ui/badge';
import { BookOpen, Globe, Database, HelpCircle, Sparkles } from 'lucide-react';

interface Classification {
  category: 'literature' | 'knowledge_base' | 'inventory' | 'explanation' | 'combined';
  confidence: number;
  suggested_sources?: string[];
}

interface ClassificationBadgeProps {
  classification?: Classification | null;
}

const categoryConfig: Record<string, { icon: React.ReactNode; label: string; variant: 'default' | 'secondary' | 'outline' }> = {
  literature: {
    icon: <Globe className="h-3 w-3" />,
    label: 'Literatur',
    variant: 'secondary',
  },
  knowledge_base: {
    icon: <BookOpen className="h-3 w-3" />,
    label: 'Wissensbasis',
    variant: 'default',
  },
  explanation: {
    icon: <HelpCircle className="h-3 w-3" />,
    label: 'Erklärung',
    variant: 'outline',
  },
  inventory: {
    icon: <Database className="h-3 w-3" />,
    label: 'Bestand',
    variant: 'outline',
  },
  combined: {
    icon: <Sparkles className="h-3 w-3" />,
    label: 'Kombiniert',
    variant: 'default',
  },
};

export function ClassificationBadge({ classification }: ClassificationBadgeProps) {
  if (!classification) return null;

  const config = categoryConfig[classification.category] || categoryConfig.combined;
  const confidencePercent = Math.round((classification.confidence || 0) * 100);

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Badge variant={config.variant} className="gap-1.5 text-xs">
        {config.icon}
        {config.label}
      </Badge>
      {confidencePercent > 0 && (
        <span className="text-xs text-muted-foreground">
          ({confidencePercent}% Konfidenz)
        </span>
      )}
      {classification.suggested_sources && classification.suggested_sources.length > 0 && (
        <span className="text-xs text-muted-foreground">
          → {classification.suggested_sources.map(s => 
            s === 'guideline' ? 'Leitlinien' : 
            s === 'europepmc' ? 'PubMed' : s
          ).join(' + ')}
        </span>
      )}
    </div>
  );
}
