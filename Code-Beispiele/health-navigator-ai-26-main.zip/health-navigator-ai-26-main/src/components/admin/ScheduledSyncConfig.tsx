import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Clock, RefreshCw, Calendar, Info, Check, X } from 'lucide-react';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

type SourceName = 'hpo' | 'snomed' | 'icd11' | 'orphanet' | 'icd10_who';

interface ScheduledJob {
  id: string;
  source_name: SourceName;
  is_enabled: boolean;
  cron_expression: string;
  last_run_at: string | null;
  next_run_at: string | null;
  last_run_status: string | null;
  last_run_message: string | null;
}

const SOURCE_LABELS: Record<SourceName, string> = {
  hpo: 'HPO (Human Phenotype Ontology)',
  snomed: 'SNOMED CT',
  icd11: 'ICD-11',
  orphanet: 'Orphanet',
  icd10_who: 'ICD-10 WHO (International)',
};

const SOURCE_DESCRIPTIONS: Record<SourceName, string> = {
  hpo: 'Phänotyp-Ontologie via EBI OLS4 API',
  snomed: 'Klinische Terminologie via Snowstorm API',
  icd11: 'WHO Klassifikation via ICD-11 API',
  orphanet: 'Seltene Erkrankungen via ORPHAcode API',
  icd10_who: 'Internationale ICD-10 via WHO API',
};

// Common cron presets
const CRON_PRESETS = [
  { label: 'Wöchentlich (So 03:00)', value: '0 3 * * 0' },
  { label: 'Wöchentlich (Mo 02:00)', value: '0 2 * * 1' },
  { label: 'Täglich (03:00)', value: '0 3 * * *' },
  { label: 'Monatlich (1. des Monats)', value: '0 3 1 * *' },
  { label: 'Benutzerdefiniert', value: 'custom' },
];

function parseCronToReadable(cron: string): string {
  const parts = cron.split(' ');
  if (parts.length !== 5) return cron;

  const [minute, hour, dayOfMonth, month, dayOfWeek] = parts;
  const days = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];

  if (dayOfMonth === '*' && month === '*') {
    if (dayOfWeek === '*') {
      return `Täglich um ${hour}:${minute.padStart(2, '0')} Uhr`;
    }
    const dayNum = parseInt(dayOfWeek);
    if (!isNaN(dayNum) && dayNum >= 0 && dayNum <= 6) {
      return `Jeden ${days[dayNum]} um ${hour}:${minute.padStart(2, '0')} Uhr`;
    }
  }
  
  if (dayOfWeek === '*' && month === '*' && dayOfMonth !== '*') {
    return `Am ${dayOfMonth}. jeden Monats um ${hour}:${minute.padStart(2, '0')} Uhr`;
  }

  return cron;
}

export function ScheduledSyncConfig() {
  const [jobs, setJobs] = useState<ScheduledJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<SourceName | null>(null);
  const [editingCron, setEditingCron] = useState<Record<SourceName, string>>({} as Record<SourceName, string>);
  const [customCron, setCustomCron] = useState<Record<SourceName, string>>({} as Record<SourceName, string>);
  const { toast } = useToast();

  const loadJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('scheduled_sync_jobs')
        .select('*')
        .order('source_name');

      if (error) throw error;

      // Type cast the data since the types aren't generated yet
      const typedData = (data || []) as unknown as ScheduledJob[];
      setJobs(typedData);
      
      // Initialize editing state
      const cronState: Record<string, string> = {};
      const customState: Record<string, string> = {};
      typedData.forEach(job => {
        const preset = CRON_PRESETS.find(p => p.value === job.cron_expression);
        cronState[job.source_name] = preset ? preset.value : 'custom';
        customState[job.source_name] = job.cron_expression;
      });
      setEditingCron(cronState as Record<SourceName, string>);
      setCustomCron(customState as Record<SourceName, string>);
    } catch (err: any) {
      console.error('[ScheduledSyncConfig] Load error:', err);
      toast({
        variant: 'destructive',
        title: 'Fehler beim Laden',
        description: err.message,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadJobs();
  }, []);

  const handleToggle = async (source: SourceName, enabled: boolean) => {
    setSaving(source);
    try {
      const cronExpression = editingCron[source] === 'custom' 
        ? customCron[source] 
        : editingCron[source];

      const { error } = await supabase
        .from('scheduled_sync_jobs')
        .update({ 
          is_enabled: enabled,
          cron_expression: cronExpression,
          updated_at: new Date().toISOString(),
        })
        .eq('source_name', source);

      if (error) throw error;

      setJobs(prev => prev.map(j => 
        j.source_name === source ? { ...j, is_enabled: enabled, cron_expression: cronExpression } : j
      ));

      toast({
        title: enabled ? 'Automatischer Sync aktiviert' : 'Automatischer Sync deaktiviert',
        description: `${SOURCE_LABELS[source]} wird ${enabled ? 'nun automatisch synchronisiert' : 'nicht mehr automatisch synchronisiert'}.`,
      });
    } catch (err: any) {
      console.error('[ScheduledSyncConfig] Toggle error:', err);
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: err.message,
      });
    } finally {
      setSaving(null);
    }
  };

  const handleCronChange = async (source: SourceName, value: string) => {
    setEditingCron(prev => ({ ...prev, [source]: value }));
    
    if (value !== 'custom') {
      // Save preset immediately
      setSaving(source);
      try {
        const { error } = await supabase
          .from('scheduled_sync_jobs')
          .update({ 
            cron_expression: value,
            updated_at: new Date().toISOString(),
          })
          .eq('source_name', source);

        if (error) throw error;

        setJobs(prev => prev.map(j => 
          j.source_name === source ? { ...j, cron_expression: value } : j
        ));
        setCustomCron(prev => ({ ...prev, [source]: value }));

        toast({
          title: 'Zeitplan gespeichert',
          description: parseCronToReadable(value),
        });
      } catch (err: any) {
        toast({
          variant: 'destructive',
          title: 'Fehler',
          description: err.message,
        });
      } finally {
        setSaving(null);
      }
    }
  };

  const handleCustomCronSave = async (source: SourceName) => {
    const cronValue = customCron[source];
    if (!cronValue || cronValue.split(' ').length !== 5) {
      toast({
        variant: 'destructive',
        title: 'Ungültiger Cron-Ausdruck',
        description: 'Bitte geben Sie einen gültigen 5-teiligen Cron-Ausdruck ein (z.B. "0 3 * * 0")',
      });
      return;
    }

    setSaving(source);
    try {
      const { error } = await supabase
        .from('scheduled_sync_jobs')
        .update({ 
          cron_expression: cronValue,
          updated_at: new Date().toISOString(),
        })
        .eq('source_name', source);

      if (error) throw error;

      setJobs(prev => prev.map(j => 
        j.source_name === source ? { ...j, cron_expression: cronValue } : j
      ));

      toast({
        title: 'Zeitplan gespeichert',
        description: parseCronToReadable(cronValue),
      });
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Fehler',
        description: err.message,
      });
    } finally {
      setSaving(null);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Automatische Synchronisation
        </CardTitle>
        <CardDescription>
          Konfigurieren Sie automatische Delta-Syncs für Ontologien. Bei jeder Ausführung wird 
          zuerst geprüft, ob eine neue Version vorliegt.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {jobs.map((job) => (
          <div 
            key={job.id} 
            className="p-4 border rounded-lg space-y-4"
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-medium">{SOURCE_LABELS[job.source_name]}</h4>
                  <Badge variant={job.is_enabled ? 'default' : 'secondary'}>
                    {job.is_enabled ? 'Aktiv' : 'Inaktiv'}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {SOURCE_DESCRIPTIONS[job.source_name]}
                </p>
              </div>
              <Switch
                checked={job.is_enabled}
                onCheckedChange={(checked) => handleToggle(job.source_name, checked)}
                disabled={saving === job.source_name}
              />
            </div>

            {/* Schedule Config */}
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Zeitplan</Label>
                <Select
                  value={editingCron[job.source_name] || 'custom'}
                  onValueChange={(v) => handleCronChange(job.source_name, v)}
                  disabled={saving === job.source_name}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Zeitplan wählen..." />
                  </SelectTrigger>
                  <SelectContent>
                    {CRON_PRESETS.map(preset => (
                      <SelectItem key={preset.value} value={preset.value}>
                        {preset.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {editingCron[job.source_name] === 'custom' && (
                <div className="space-y-2">
                  <Label className="flex items-center gap-1">
                    Cron-Ausdruck
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="h-3.5 w-3.5 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-xs">
                        <p>Format: Minute Stunde Tag-des-Monats Monat Wochentag</p>
                        <p className="text-xs mt-1">Beispiel: "0 3 * * 0" = Jeden Sonntag um 03:00</p>
                      </TooltipContent>
                    </Tooltip>
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      value={customCron[job.source_name] || ''}
                      onChange={(e) => setCustomCron(prev => ({ ...prev, [job.source_name]: e.target.value }))}
                      placeholder="0 3 * * 0"
                      className="font-mono text-sm"
                    />
                    <Button 
                      size="sm" 
                      onClick={() => handleCustomCronSave(job.source_name)}
                      disabled={saving === job.source_name}
                    >
                      {saving === job.source_name ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Status Info */}
            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Clock className="h-4 w-4" />
                <span>
                  Zeitplan: {parseCronToReadable(job.cron_expression)}
                </span>
              </div>

              {job.last_run_at && (
                <div className="flex items-center gap-1.5">
                  <RefreshCw className="h-4 w-4" />
                  <span>
                    Letzte Ausführung: {format(new Date(job.last_run_at), 'dd.MM.yyyy HH:mm', { locale: de })}
                  </span>
                  {job.last_run_status === 'success' ? (
                    <Check className="h-4 w-4 text-emerald-500" />
                  ) : job.last_run_status === 'error' ? (
                    <Tooltip>
                      <TooltipTrigger>
                        <X className="h-4 w-4 text-destructive" />
                      </TooltipTrigger>
                      <TooltipContent>
                        {job.last_run_message || 'Unbekannter Fehler'}
                      </TooltipContent>
                    </Tooltip>
                  ) : job.last_run_status === 'skipped' ? (
                    <Badge variant="outline" className="text-xs">Übersprungen</Badge>
                  ) : null}
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Info Box */}
        <div className="p-4 bg-muted/50 rounded-lg text-sm text-muted-foreground">
          <div className="flex gap-2">
            <Info className="h-4 w-4 mt-0.5 shrink-0" />
            <div>
              <p className="font-medium text-foreground">Hinweis zum Delta-Sync</p>
              <p className="mt-1">
                Bei jeder automatischen Ausführung wird zunächst die Remote-Version abgefragt. 
                Nur wenn eine neuere Version verfügbar ist, wird der Sync gestartet. 
                Andernfalls wird die Ausführung übersprungen (Status: "Übersprungen").
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
