import { useQuery } from '@tanstack/react-query';
import { 
  Database, 
  FileText, 
  GitBranch, 
  Sparkles, 
  Stethoscope,
  Pill,
  BookOpen,
  Activity,
  Globe,
  Languages,
  Loader2,
  RefreshCw,
  TrendingUp,
  Calendar,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

interface OntologyStats {
  system: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  table: string;
  totalCount: number;
  terminalCount?: number;
  analysisCount?: number;
  lastUpdated?: string;
  additionalStats?: Record<string, number | string>;
}

function formatNumber(num: number): string {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
  return num.toString();
}

export function OntologyStatistics() {
  // Fetch all ontology statistics in parallel
  const { data: stats, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ['ontology-statistics'],
    queryFn: async () => {
      const [
        hpoResult,
        snomedResult,
        icd10gmResult,
        icd11Result,
        orphanetResult,
        loincResult,
        emdnResult,
        umdnsResult,
        hpoAnalysesResult,
        snomedAnalysesResult,
        icd10gmAnalysesResult,
        icd11AnalysesResult,
        orphanetAnalysesResult,
        mappingsResult,
        translationsResult,
      ] = await Promise.all([
        // Code tables
        supabase.from('hpo_codes').select('hpo_code, is_terminal, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('snomed_codes').select('sctid, is_terminal, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('icd10gm_codes').select('code, is_terminal, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('icd11_codes').select('code, is_terminal, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('orphanet_codes').select('orpha_code, is_terminal, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('loinc_codes').select('loinc_num, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('emdn_codes').select('code, level, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('umdns_codes').select('code, created_at', { count: 'exact', head: false }).limit(1),
        // Analysis tables
        supabase.from('hpo_analyses').select('id, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('snomed_analyses').select('id, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('icd10gm_analyses').select('id, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('icd11_analyses').select('id, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('orphanet_analyses').select('id, created_at', { count: 'exact', head: false }).limit(1),
        // Mappings & translations
        supabase.from('ontology_mappings').select('id, validation_status, created_at', { count: 'exact', head: false }).limit(1),
        supabase.from('term_translations').select('id, created_at', { count: 'exact', head: false }).limit(1),
      ]);

      // Get terminal counts separately
      const [
        hpoTerminalResult,
        snomedTerminalResult,
        icd10gmTerminalResult,
        icd11TerminalResult,
        orphanetTerminalResult,
      ] = await Promise.all([
        supabase.from('hpo_codes').select('hpo_code', { count: 'exact', head: true }).eq('is_terminal', true),
        supabase.from('snomed_codes').select('sctid', { count: 'exact', head: true }).eq('is_terminal', true),
        supabase.from('icd10gm_codes').select('code', { count: 'exact', head: true }).eq('is_terminal', true),
        supabase.from('icd11_codes').select('code', { count: 'exact', head: true }).eq('is_terminal', true),
        supabase.from('orphanet_codes').select('orpha_code', { count: 'exact', head: true }).eq('is_terminal', true),
      ]);

      // Get mapping status breakdown
      const [validMappings, pendingMappings, conflictMappings] = await Promise.all([
        supabase.from('ontology_mappings').select('id', { count: 'exact', head: true }).eq('validation_status', 'valid'),
        supabase.from('ontology_mappings').select('id', { count: 'exact', head: true }).eq('validation_status', 'pending'),
        supabase.from('ontology_mappings').select('id', { count: 'exact', head: true }).eq('validation_status', 'conflict'),
      ]);

      return {
        codes: {
          hpo: { total: hpoResult.count || 0, terminal: hpoTerminalResult.count || 0 },
          snomed: { total: snomedResult.count || 0, terminal: snomedTerminalResult.count || 0 },
          icd10gm: { total: icd10gmResult.count || 0, terminal: icd10gmTerminalResult.count || 0 },
          icd11: { total: icd11Result.count || 0, terminal: icd11TerminalResult.count || 0 },
          orphanet: { total: orphanetResult.count || 0, terminal: orphanetTerminalResult.count || 0 },
          loinc: { total: loincResult.count || 0 },
          emdn: { total: emdnResult.count || 0 },
          umdns: { total: umdnsResult.count || 0 },
        },
        analyses: {
          hpo: hpoAnalysesResult.count || 0,
          snomed: snomedAnalysesResult.count || 0,
          icd10gm: icd10gmAnalysesResult.count || 0,
          icd11: icd11AnalysesResult.count || 0,
          orphanet: orphanetAnalysesResult.count || 0,
        },
        mappings: {
          total: mappingsResult.count || 0,
          valid: validMappings.count || 0,
          pending: pendingMappings.count || 0,
          conflict: conflictMappings.count || 0,
        },
        translations: translationsResult.count || 0,
      };
    },
    staleTime: 5 * 60 * 1000,
  });

  const ontologySystems = [
    { 
      id: 'hpo', 
      name: 'HPO', 
      fullName: 'Human Phenotype Ontology',
      icon: Stethoscope, 
      color: 'text-blue-500',
      description: 'Phänotyp-Beschreibungen',
    },
    { 
      id: 'snomed', 
      name: 'SNOMED CT', 
      fullName: 'SNOMED Clinical Terms',
      icon: Globe, 
      color: 'text-purple-500',
      description: 'Klinische Terminologie',
    },
    { 
      id: 'icd10gm', 
      name: 'ICD-10-GM', 
      fullName: 'ICD-10 German Modification',
      icon: FileText, 
      color: 'text-green-500',
      description: 'Diagnose-Klassifikation',
    },
    { 
      id: 'icd11', 
      name: 'ICD-11', 
      fullName: 'ICD-11 Foundation',
      icon: FileText, 
      color: 'text-teal-500',
      description: 'Neue WHO-Klassifikation',
    },
    { 
      id: 'orphanet', 
      name: 'Orphanet', 
      fullName: 'Orphanet Rare Diseases',
      icon: Sparkles, 
      color: 'text-orange-500',
      description: 'Seltene Erkrankungen',
    },
    { 
      id: 'loinc', 
      name: 'LOINC', 
      fullName: 'Logical Observation Identifiers',
      icon: Activity, 
      color: 'text-red-500',
      description: 'Labor-Codes',
    },
    { 
      id: 'emdn', 
      name: 'EMDN', 
      fullName: 'European Medical Device Nomenclature',
      icon: Pill, 
      color: 'text-indigo-500',
      description: 'Medizinprodukte',
    },
    { 
      id: 'umdns', 
      name: 'UMDNS', 
      fullName: 'Universal Medical Device Nomenclature',
      icon: Pill, 
      color: 'text-pink-500',
      description: 'Geräte-Referenz',
    },
  ];

  const totalCodes = stats ? Object.values(stats.codes).reduce((sum, c) => sum + (c.total || 0), 0) : 0;
  const totalAnalyses = stats ? Object.values(stats.analyses).reduce((sum, c) => sum + c, 0) : 0;

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Database className="h-5 w-5" />
            Ontologie-Datenbank
          </h2>
          <p className="text-sm text-muted-foreground">
            Persistierte Codes und KI-Analysen aller Terminologie-Systeme
          </p>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => refetch()}
          disabled={isRefetching}
        >
          {isRefetching ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4" />
          )}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Gesamt-Codes</CardDescription>
            <CardTitle className="text-2xl">{formatNumber(totalCodes)}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">
              Über {ontologySystems.length} Systeme
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>KI-Analysen</CardDescription>
            <CardTitle className="text-2xl">{formatNumber(totalAnalyses)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Sparkles className="h-3 w-3" />
              Gecachte Erklärungen
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Ontologie-Mappings</CardDescription>
            <CardTitle className="text-2xl">{formatNumber(stats?.mappings.total || 0)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Badge variant="default" className="text-xs">{stats?.mappings.valid} validiert</Badge>
              {(stats?.mappings.pending ?? 0) > 0 && (
                <Badge variant="secondary" className="text-xs">{stats?.mappings.pending} ausstehend</Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Übersetzungen</CardDescription>
            <CardTitle className="text-2xl">{formatNumber(stats?.translations || 0)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Languages className="h-3 w-3" />
              EN ↔ DE Terme
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tabs */}
      <Tabs defaultValue="codes" className="space-y-4">
        <TabsList>
          <TabsTrigger value="codes" className="gap-2">
            <Database className="h-4 w-4" />
            Codes ({formatNumber(totalCodes)})
          </TabsTrigger>
          <TabsTrigger value="analyses" className="gap-2">
            <Sparkles className="h-4 w-4" />
            Analysen ({formatNumber(totalAnalyses)})
          </TabsTrigger>
          <TabsTrigger value="mappings" className="gap-2">
            <GitBranch className="h-4 w-4" />
            Mappings ({formatNumber(stats?.mappings.total || 0)})
          </TabsTrigger>
        </TabsList>

        {/* Codes Tab */}
        <TabsContent value="codes" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle>Persistierte Terminologie-Codes</CardTitle>
              <CardDescription>
                Lokal gespeicherte Codes aus allen angebundenen Ontologie-Systemen
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {ontologySystems.map((system) => {
                  const codeStats = stats?.codes[system.id as keyof typeof stats.codes];
                  const total = codeStats?.total || 0;
                  const terminal = 'terminal' in (codeStats || {}) ? (codeStats as any).terminal : undefined;
                  const Icon = system.icon;

                  return (
                    <Card key={system.id} className="relative overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Icon className={`h-5 w-5 ${system.color}`} />
                            <CardTitle className="text-sm font-medium">{system.name}</CardTitle>
                          </div>
                          {total > 0 && (
                            <Badge variant="secondary" className="text-xs">
                              {formatNumber(total)}
                            </Badge>
                          )}
                        </div>
                        <CardDescription className="text-xs">{system.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        {total > 0 ? (
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Gesamt</span>
                              <span className="font-medium">{total.toLocaleString()}</span>
                            </div>
                            {terminal !== undefined && (
                              <>
                                <div className="flex justify-between text-xs">
                                  <span className="text-muted-foreground">Terminal</span>
                                  <span className="font-medium">{terminal.toLocaleString()}</span>
                                </div>
                                <Progress 
                                  value={total > 0 ? (terminal / total) * 100 : 0} 
                                  className="h-1.5" 
                                />
                                <p className="text-xs text-muted-foreground text-right">
                                  {total > 0 ? Math.round((terminal / total) * 100) : 0}% Terminal
                                </p>
                              </>
                            )}
                          </div>
                        ) : (
                          <p className="text-xs text-muted-foreground italic">Keine Codes importiert</p>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analyses Tab */}
        <TabsContent value="analyses" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle>KI-generierte Analysen</CardTitle>
              <CardDescription>
                Gecachte klinische Erklärungen und Mapping-Vorschläge pro Ontologie
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
                {[
                  { id: 'hpo', name: 'HPO', icon: Stethoscope, color: 'text-blue-500' },
                  { id: 'snomed', name: 'SNOMED', icon: Globe, color: 'text-purple-500' },
                  { id: 'icd10gm', name: 'ICD-10-GM', icon: FileText, color: 'text-green-500' },
                  { id: 'icd11', name: 'ICD-11', icon: FileText, color: 'text-teal-500' },
                  { id: 'orphanet', name: 'Orphanet', icon: Sparkles, color: 'text-orange-500' },
                ].map((system) => {
                  const count = stats?.analyses[system.id as keyof typeof stats.analyses] || 0;
                  const codeCount = stats?.codes[system.id as keyof typeof stats.codes]?.total || 0;
                  const coverage = codeCount > 0 ? (count / codeCount) * 100 : 0;
                  const Icon = system.icon;

                  return (
                    <Card key={system.id}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-2">
                          <Icon className={`h-4 w-4 ${system.color}`} />
                          <CardTitle className="text-sm">{system.name}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl font-bold">{formatNumber(count)}</span>
                            <span className="text-xs text-muted-foreground">Analysen</span>
                          </div>
                          {codeCount > 0 && (
                            <>
                              <Progress value={Math.min(coverage, 100)} className="h-1.5" />
                              <p className="text-xs text-muted-foreground">
                                {coverage.toFixed(1)}% Abdeckung
                              </p>
                            </>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Mappings Tab */}
        <TabsContent value="mappings" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle>Ontologie-Mappings</CardTitle>
              <CardDescription>
                Querverweise zwischen verschiedenen Terminologie-Systemen
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                {/* Status Distribution */}
                <div className="space-y-4">
                  <h4 className="text-sm font-medium">Status-Verteilung</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full bg-primary" />
                        <span className="text-sm">Validiert</span>
                      </div>
                      <span className="font-medium">{stats?.mappings.valid.toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={stats?.mappings.total ? (stats.mappings.valid / stats.mappings.total) * 100 : 0} 
                      className="h-2" 
                    />
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full bg-secondary" />
                        <span className="text-sm">Ausstehend</span>
                      </div>
                      <span className="font-medium">{stats?.mappings.pending.toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={stats?.mappings.total ? (stats.mappings.pending / stats.mappings.total) * 100 : 0} 
                      className="h-2" 
                    />
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full bg-destructive" />
                        <span className="text-sm">Konflikte</span>
                      </div>
                      <span className="font-medium">{stats?.mappings.conflict.toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={stats?.mappings.total ? (stats.mappings.conflict / stats.mappings.total) * 100 : 0} 
                      className="h-2" 
                    />
                  </div>
                </div>

                {/* Summary Stats */}
                <div className="space-y-4">
                  <h4 className="text-sm font-medium">Übersicht</h4>
                  <div className="grid gap-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <span className="text-sm text-muted-foreground">Gesamt-Mappings</span>
                      <span className="text-lg font-bold">{stats?.mappings.total.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <span className="text-sm text-muted-foreground">Validierungsrate</span>
                      <span className="text-lg font-bold">
                        {stats?.mappings.total 
                          ? Math.round((stats.mappings.valid / stats.mappings.total) * 100) 
                          : 0}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <span className="text-sm text-muted-foreground">Übersetzungen</span>
                      <span className="text-lg font-bold">{stats?.translations.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
