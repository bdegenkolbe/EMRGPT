import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { de, en, fr, it } from './locales';

const resources = {
  de,
  en,
  fr,
  it,
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'de',
    fallbackLng: 'de',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
