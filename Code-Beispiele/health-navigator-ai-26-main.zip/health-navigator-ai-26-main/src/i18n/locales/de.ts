export const de = {
  translation: {
    common: {
      loading: "Laden...",
      save: "Speichern",
      cancel: "Abbrechen",
      delete: "Löschen",
      edit: "Bearbeiten",
      create: "Erstellen",
      search: "Suchen",
      filter: "Filtern",
      start: "Starten",
      view: "Anzeigen",
      manage: "Verwalten",
      back: "Zurück",
      next: "Weiter",
      confirm: "Bestätigen",
      yes: "Ja",
      no: "Nein",
      user: "Benutzer",
      admin: "Administrator",
      profile: "Profil",
      logout: "Abmelden",
      toggleTheme: "Design wechseln",
      toggleLanguage: "Sprache wechseln",
      error: "Fehler",
      success: "Erfolgreich"
    },
    nav: {
      dashboard: "Dashboard",
      anamnesis: "Anamnese",
      sessions: "Sitzungen",
      administration: "Administration",
      users: "Benutzer",
      integrations: "Integrationen",
      settings: "Einstellungen"
    },
    auth: {
      loginTitle: "Anmelden",
      loginDescription: "Melden Sie sich mit Ihren Zugangsdaten an",
      email: "E-Mail",
      password: "Passwort",
      login: "Anmelden",
      invalidCredentials: "Ungültige E-Mail oder Passwort",
      noPublicRegistration: "Keine öffentliche Registrierung. Kontaktieren Sie einen Administrator."
    },
    dashboard: {
      welcome: "Willkommen, {{name}}",
      subtitle: "Was möchten Sie heute tun?",
      newAnamnesis: "Neue Anamnese",
      newAnamnesisDesc: "Starten Sie eine neue Patientenanamnese",
      mySessions: "Meine Sitzungen",
      mySessionsDesc: "Bisherige Anamnesen anzeigen und fortsetzen",
      manageUsers: "Benutzer verwalten",
      manageUsersDesc: "Benutzer, Rollen und Berechtigungen",
      totalSessions: "Gesamte Sitzungen",
      completedToday: "Heute abgeschlossen",
      noData: "Noch keine Daten"
    },
    profile: {
      title: "Mein Profil",
      displayName: "Anzeigename",
      language: "Sprache",
      darkMode: "Dunkler Modus",
      changePassword: "Passwort ändern",
      newPassword: "Neues Passwort",
      confirmPassword: "Passwort bestätigen",
      updateSuccess: "Profil erfolgreich aktualisiert",
      passwordUpdated: "Passwort erfolgreich geändert",
      passwordError: "Passwort konnte nicht geändert werden",
      updateError: "Profil konnte nicht aktualisiert werden"
    },
    medical: {
      views: {
        hausarztpraxis: "Hausarztpraxis",
        notaufnahme: "Notaufnahme",
        telemedizin: "Telemedizin",
        fachambulanz: "Fachambulanz",
        klinik: "Klinik"
      }
    },
    admin: {
      users: {
        title: "Benutzerverwaltung",
        addUser: "Benutzer hinzufügen",
        email: "E-Mail",
        role: "Rolle",
        views: "Klinische Sichten",
        createdAt: "Erstellt am",
        assignViews: "Sichten zuweisen"
      },
      integrations: {
        title: "Integrationen",
        addIntegration: "Integration hinzufügen",
        provider: "Anbieter",
        status: "Status",
        active: "Aktiv",
        inactive: "Inaktiv",
        providers: {
          gemini: "Google Gemini",
          chatgpt: "OpenAI ChatGPT",
          ncbi: "NCBI/PubMed"
        }
      }
    },
    anamnesis: {
      selectView: "Klinische Sicht wählen",
      startSession: "Sitzung starten",
      readAloud: "Vorlesen",
      stopReading: "Vorlesen stoppen",
      voiceInput: "Spracheingabe",
      typeMessage: "Nachricht eingeben...",
      send: "Senden",
      redFlag: "Wichtiger Hinweis",
      redFlags: "Red Flags",
      progress: "Anamnese-Fortschritt",
      consent: "Einverständnis",
      consentText: "Ich verstehe, dass dies ein KI-gestütztes Anamnese-Tool ist und keine ärztliche Beratung ersetzt.",
      categories: {
        chiefComplaint: "Hauptbeschwerde",
        hpi: "Anamnese",
        ros: "Systeme",
        pmh: "Vorgeschichte",
        medications: "Medikamente",
        social: "Sozial",
        family: "Familie",
        summary: "Zusammenfassung"
      },
      phases: {
        consent: "Einverständnis",
        redFlags: "Notfall-Check",
        chiefComplaint: "Hauptbeschwerde",
        hpi: "Aktuelle Beschwerden",
        ros: "Systemüberprüfung",
        pmh: "Vorgeschichte",
        summary: "Zusammenfassung"
      }
    },
    evidence: {
      title: "Evidenz-Panel",
      refresh: "Aktualisieren",
      tabSummary: "Zusammenfassung",
      tabTrials: "Klinische Studien",
      fetchSuccess: "Evidenz geladen",
      fetchSuccessDescription: "{{count}} Treffer gefunden",
      fetchError: "Fehler beim Laden",
      fetchErrorDescription: "Evidenz konnte nicht abgerufen werden",
      noData: "Keine Evidenz vorhanden",
      startSearch: "Evidenz-Suche starten",
      noPubMed: "Keine PubMed-Treffer",
      noTrials: "Keine klinischen Studien",
      summaryTitle: "KI-Zusammenfassung",
      disclaimerTitle: "Haftungsausschluss",
      disclaimerText: "Diese Literaturhinweise dienen nur der Information und ersetzen keine medizinische Beratung. Die Auswahl basiert auf automatischer Textanalyse und kann unvollständig sein.",
      auditInfo: "Audit-Informationen",
      searchDate: "Suchdatum",
      queryTerms: "Suchbegriffe",
      sources: "Quellen"
    },
    documentation: {
      soapNote: "SOAP-Note",
      redFlags: "Red Flags",
      subjective: "Subjektiv",
      objective: "Objektiv",
      assessment: "Beurteilung",
      plan: "Plan",
      chiefComplaint: "Hauptbeschwerde",
      hpi: "Anamnese der aktuellen Erkrankung",
      ros: "Systemübersicht",
      observations: "Beobachtungen",
      negated: "Negiert",
      severity: "Schweregrad",
      onset: "Beginn",
      duration: "Dauer",
      summary: "Zusammenfassung",
      hpoCodes: "HPO-Codes",
      meshTerms: "MeSH-Terme",
      planPlaceholder: "(Vom Behandler auszufüllen)",
      disclaimer: "Dieses Dokument wurde durch KI-gestützte Anamnese erstellt und ersetzt keine ärztliche Beurteilung."
    },
    export: {
      title: "Exportieren",
      pdf: "PDF herunterladen",
      json: "JSON herunterladen",
      fhir: "FHIR-Bundle herunterladen",
      pdfSuccess: "PDF erstellt",
      pdfSuccessDescription: "Die SOAP-Note wurde als PDF heruntergeladen.",
      jsonSuccess: "JSON erstellt",
      jsonSuccessDescription: "Die Session-Daten wurden als JSON heruntergeladen.",
      fhirSuccess: "FHIR-Bundle erstellt",
      fhirSuccessDescription: "Die Daten wurden als FHIR R4 Bundle heruntergeladen.",
      error: "Export-Fehler"
    },
    languages: {
      de: "Deutsch",
      en: "English",
      fr: "Français",
      it: "Italiano"
    }
  }
};
