export const fr = {
  translation: {
    common: {
      loading: "Chargement...",
      save: "Enregistrer",
      cancel: "Annuler",
      delete: "Supprimer",
      edit: "Modifier",
      create: "Créer",
      search: "Rechercher",
      filter: "Filtrer",
      start: "Démarrer",
      view: "Afficher",
      manage: "Gérer",
      back: "Retour",
      next: "Suivant",
      confirm: "Confirmer",
      yes: "Oui",
      no: "Non",
      user: "Utilisateur",
      admin: "Administrateur",
      profile: "Profil",
      logout: "Déconnexion",
      toggleTheme: "Changer le thème",
      toggleLanguage: "Changer la langue",
      error: "Erreur",
      success: "Succès"
    },
    nav: {
      dashboard: "Tableau de bord",
      anamnesis: "Anamnèse",
      sessions: "Sessions",
      administration: "Administration",
      users: "Utilisateurs",
      integrations: "Intégrations",
      settings: "Paramètres"
    },
    auth: {
      loginTitle: "Connexion",
      loginDescription: "Entrez vos identifiants pour vous connecter",
      email: "E-mail",
      password: "Mot de passe",
      login: "Se connecter",
      invalidCredentials: "E-mail ou mot de passe invalide",
      noPublicRegistration: "Pas d'inscription publique. Contactez un administrateur."
    },
    dashboard: {
      welcome: "Bienvenue, {{name}}",
      subtitle: "Que souhaitez-vous faire aujourd'hui?",
      newAnamnesis: "Nouvelle anamnèse",
      newAnamnesisDesc: "Démarrer une nouvelle anamnèse patient",
      mySessions: "Mes sessions",
      mySessionsDesc: "Voir et continuer les anamnèses précédentes",
      manageUsers: "Gérer les utilisateurs",
      manageUsersDesc: "Utilisateurs, rôles et permissions",
      totalSessions: "Sessions totales",
      completedToday: "Terminées aujourd'hui",
      noData: "Pas encore de données"
    },
    profile: {
      title: "Mon profil",
      displayName: "Nom d'affichage",
      language: "Langue",
      darkMode: "Mode sombre",
      changePassword: "Changer le mot de passe",
      newPassword: "Nouveau mot de passe",
      confirmPassword: "Confirmer le mot de passe",
      updateSuccess: "Profil mis à jour avec succès",
      passwordUpdated: "Mot de passe modifié avec succès",
      passwordError: "Impossible de changer le mot de passe",
      updateError: "Impossible de mettre à jour le profil"
    },
    medical: {
      views: {
        hausarztpraxis: "Médecine générale",
        notaufnahme: "Urgences",
        telemedizin: "Télémédecine",
        fachambulanz: "Clinique spécialisée",
        klinik: "Hôpital"
      }
    },
    admin: {
      users: {
        title: "Gestion des utilisateurs",
        addUser: "Ajouter un utilisateur",
        email: "E-mail",
        role: "Rôle",
        views: "Vues cliniques",
        createdAt: "Créé le",
        assignViews: "Attribuer des vues"
      },
      integrations: {
        title: "Intégrations",
        addIntegration: "Ajouter une intégration",
        provider: "Fournisseur",
        status: "Statut",
        active: "Actif",
        inactive: "Inactif",
        providers: {
          gemini: "Google Gemini",
          chatgpt: "OpenAI ChatGPT",
          ncbi: "NCBI/PubMed"
        }
      }
    },
    anamnesis: {
      selectView: "Sélectionner la vue clinique",
      startSession: "Démarrer la session",
      readAloud: "Lire à haute voix",
      stopReading: "Arrêter la lecture",
      voiceInput: "Entrée vocale",
      typeMessage: "Tapez un message...",
      send: "Envoyer",
      redFlag: "Avis important",
      redFlags: "Signaux d'alerte",
      progress: "Progression de l'anamnèse",
      consent: "Consentement",
      consentText: "Je comprends qu'il s'agit d'un outil d'anamnèse assisté par IA et qu'il ne remplace pas un avis médical.",
      categories: {
        chiefComplaint: "Motif principal",
        hpi: "Antécédents",
        ros: "Systèmes",
        pmh: "Antécédents médicaux",
        medications: "Médicaments",
        social: "Social",
        family: "Famille",
        summary: "Résumé"
      },
      phases: {
        consent: "Consentement",
        redFlags: "Vérification d'urgence",
        chiefComplaint: "Motif principal",
        hpi: "Histoire de la maladie actuelle",
        ros: "Revue des systèmes",
        pmh: "Antécédents médicaux",
        summary: "Résumé"
      }
    },
    evidence: {
      title: "Panel de preuves",
      refresh: "Actualiser",
      tabSummary: "Résumé",
      tabTrials: "Essais cliniques",
      fetchSuccess: "Preuves chargées",
      fetchSuccessDescription: "{{count}} résultats trouvés",
      fetchError: "Erreur de chargement",
      fetchErrorDescription: "Impossible de récupérer les preuves",
      noData: "Aucune preuve disponible",
      startSearch: "Lancer la recherche de preuves",
      noPubMed: "Aucun résultat PubMed",
      noTrials: "Aucun essai clinique",
      summaryTitle: "Résumé IA",
      disclaimerTitle: "Avertissement",
      disclaimerText: "Ces références bibliographiques sont fournies à titre informatif uniquement et ne remplacent pas un avis médical. La sélection est basée sur une analyse automatique du texte et peut être incomplète.",
      auditInfo: "Informations d'audit",
      searchDate: "Date de recherche",
      queryTerms: "Termes de recherche",
      sources: "Sources"
    },
    documentation: {
      soapNote: "Note SOAP",
      redFlags: "Signaux d'alerte",
      subjective: "Subjectif",
      objective: "Objectif",
      assessment: "Évaluation",
      plan: "Plan",
      chiefComplaint: "Motif principal",
      hpi: "Histoire de la maladie actuelle",
      ros: "Revue des systèmes",
      observations: "Observations",
      negated: "Négation",
      severity: "Sévérité",
      onset: "Début",
      duration: "Durée",
      summary: "Résumé",
      hpoCodes: "Codes HPO",
      meshTerms: "Termes MeSH",
      planPlaceholder: "(À compléter par le clinicien)",
      disclaimer: "Ce document a été généré par une anamnèse assistée par IA et ne remplace pas le jugement clinique."
    },
    export: {
      title: "Exporter",
      pdf: "Télécharger PDF",
      json: "Télécharger JSON",
      fhir: "Télécharger Bundle FHIR",
      pdfSuccess: "PDF créé",
      pdfSuccessDescription: "La note SOAP a été téléchargée en PDF.",
      jsonSuccess: "JSON créé",
      jsonSuccessDescription: "Les données de session ont été téléchargées en JSON.",
      fhirSuccess: "Bundle FHIR créé",
      fhirSuccessDescription: "Les données ont été téléchargées en Bundle FHIR R4.",
      error: "Erreur d'exportation"
    },
    languages: {
      de: "Deutsch",
      en: "English",
      fr: "Français",
      it: "Italiano"
    }
  }
};
