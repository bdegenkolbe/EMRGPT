export const it = {
  translation: {
    common: {
      loading: "Caricamento...",
      save: "Salva",
      cancel: "Annulla",
      delete: "Elimina",
      edit: "Modifica",
      create: "Crea",
      search: "Cerca",
      filter: "Filtra",
      start: "Avvia",
      view: "Visualizza",
      manage: "Gestisci",
      back: "Indietro",
      next: "Avanti",
      confirm: "Conferma",
      yes: "Sì",
      no: "No",
      user: "Utente",
      admin: "Amministratore",
      profile: "Profilo",
      logout: "Esci",
      toggleTheme: "Cambia tema",
      toggleLanguage: "Cambia lingua",
      error: "Errore",
      success: "Successo"
    },
    nav: {
      dashboard: "Dashboard",
      anamnesis: "Anamnesi",
      sessions: "Sessioni",
      administration: "Amministrazione",
      users: "Utenti",
      integrations: "Integrazioni",
      settings: "Impostazioni"
    },
    auth: {
      loginTitle: "Accedi",
      loginDescription: "Inserisci le tue credenziali per accedere",
      email: "E-mail",
      password: "Password",
      login: "Accedi",
      invalidCredentials: "E-mail o password non validi",
      noPublicRegistration: "Nessuna registrazione pubblica. Contatta un amministratore."
    },
    dashboard: {
      welcome: "Benvenuto, {{name}}",
      subtitle: "Cosa vorresti fare oggi?",
      newAnamnesis: "Nuova anamnesi",
      newAnamnesisDesc: "Avvia una nuova anamnesi paziente",
      mySessions: "Le mie sessioni",
      mySessionsDesc: "Visualizza e continua le anamnesi precedenti",
      manageUsers: "Gestisci utenti",
      manageUsersDesc: "Utenti, ruoli e permessi",
      totalSessions: "Sessioni totali",
      completedToday: "Completate oggi",
      noData: "Nessun dato ancora"
    },
    profile: {
      title: "Il mio profilo",
      displayName: "Nome visualizzato",
      language: "Lingua",
      darkMode: "Modalità scura",
      changePassword: "Cambia password",
      newPassword: "Nuova password",
      confirmPassword: "Conferma password",
      updateSuccess: "Profilo aggiornato con successo",
      passwordUpdated: "Password modificata con successo",
      passwordError: "Impossibile cambiare la password",
      updateError: "Impossibile aggiornare il profilo"
    },
    medical: {
      views: {
        hausarztpraxis: "Medicina generale",
        notaufnahme: "Pronto soccorso",
        telemedizin: "Telemedicina",
        fachambulanz: "Clinica specialistica",
        klinik: "Ospedale"
      }
    },
    admin: {
      users: {
        title: "Gestione utenti",
        addUser: "Aggiungi utente",
        email: "E-mail",
        role: "Ruolo",
        views: "Viste cliniche",
        createdAt: "Creato il",
        assignViews: "Assegna viste"
      },
      integrations: {
        title: "Integrazioni",
        addIntegration: "Aggiungi integrazione",
        provider: "Fornitore",
        status: "Stato",
        active: "Attivo",
        inactive: "Inattivo",
        providers: {
          gemini: "Google Gemini",
          chatgpt: "OpenAI ChatGPT",
          ncbi: "NCBI/PubMed"
        }
      }
    },
    anamnesis: {
      selectView: "Seleziona vista clinica",
      startSession: "Avvia sessione",
      readAloud: "Leggi ad alta voce",
      stopReading: "Interrompi lettura",
      voiceInput: "Input vocale",
      typeMessage: "Scrivi un messaggio...",
      send: "Invia",
      redFlag: "Avviso importante",
      redFlags: "Segnali di allarme",
      progress: "Progresso anamnesi",
      consent: "Consenso",
      consentText: "Comprendo che questo è uno strumento di anamnesi assistito da IA e non sostituisce il parere medico.",
      categories: {
        chiefComplaint: "Motivo principale",
        hpi: "Anamnesi",
        ros: "Sistemi",
        pmh: "Anamnesi patologica",
        medications: "Farmaci",
        social: "Sociale",
        family: "Famiglia",
        summary: "Riepilogo"
      },
      phases: {
        consent: "Consenso",
        redFlags: "Controllo emergenza",
        chiefComplaint: "Motivo principale",
        hpi: "Storia della malattia attuale",
        ros: "Revisione dei sistemi",
        pmh: "Anamnesi patologica",
        summary: "Riepilogo"
      }
    },
    evidence: {
      title: "Pannello evidenze",
      refresh: "Aggiorna",
      tabSummary: "Riepilogo",
      tabTrials: "Studi clinici",
      fetchSuccess: "Evidenze caricate",
      fetchSuccessDescription: "{{count}} risultati trovati",
      fetchError: "Errore di caricamento",
      fetchErrorDescription: "Impossibile recuperare le evidenze",
      noData: "Nessuna evidenza disponibile",
      startSearch: "Avvia ricerca evidenze",
      noPubMed: "Nessun risultato PubMed",
      noTrials: "Nessuno studio clinico",
      summaryTitle: "Riepilogo IA",
      disclaimerTitle: "Avvertenza",
      disclaimerText: "Questi riferimenti bibliografici sono forniti solo a scopo informativo e non sostituiscono il parere medico. La selezione si basa su analisi automatica del testo e potrebbe essere incompleta.",
      auditInfo: "Informazioni di audit",
      searchDate: "Data ricerca",
      queryTerms: "Termini di ricerca",
      sources: "Fonti"
    },
    documentation: {
      soapNote: "Nota SOAP",
      redFlags: "Segnali di allarme",
      subjective: "Soggettivo",
      objective: "Oggettivo",
      assessment: "Valutazione",
      plan: "Piano",
      chiefComplaint: "Motivo principale",
      hpi: "Storia della malattia attuale",
      ros: "Revisione dei sistemi",
      observations: "Osservazioni",
      negated: "Negato",
      severity: "Gravità",
      onset: "Esordio",
      duration: "Durata",
      summary: "Riepilogo",
      hpoCodes: "Codici HPO",
      meshTerms: "Termini MeSH",
      planPlaceholder: "(Da compilare dal clinico)",
      disclaimer: "Questo documento è stato generato tramite anamnesi assistita da IA e non sostituisce il giudizio clinico."
    },
    export: {
      title: "Esporta",
      pdf: "Scarica PDF",
      json: "Scarica JSON",
      fhir: "Scarica Bundle FHIR",
      pdfSuccess: "PDF creato",
      pdfSuccessDescription: "La nota SOAP è stata scaricata come PDF.",
      jsonSuccess: "JSON creato",
      jsonSuccessDescription: "I dati della sessione sono stati scaricati come JSON.",
      fhirSuccess: "Bundle FHIR creato",
      fhirSuccessDescription: "I dati sono stati scaricati come Bundle FHIR R4.",
      error: "Errore di esportazione"
    },
    languages: {
      de: "Deutsch",
      en: "English",
      fr: "Français",
      it: "Italiano"
    }
  }
};
