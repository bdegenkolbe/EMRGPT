export const en = {
  translation: {
    common: {
      loading: "Loading...",
      save: "Save",
      cancel: "Cancel",
      delete: "Delete",
      edit: "Edit",
      create: "Create",
      search: "Search",
      filter: "Filter",
      start: "Start",
      view: "View",
      manage: "Manage",
      back: "Back",
      next: "Next",
      confirm: "Confirm",
      yes: "Yes",
      no: "No",
      user: "User",
      admin: "Administrator",
      profile: "Profile",
      logout: "Sign out",
      toggleTheme: "Toggle theme",
      toggleLanguage: "Toggle language",
      error: "Error",
      success: "Success"
    },
    nav: {
      dashboard: "Dashboard",
      anamnesis: "Anamnesis",
      sessions: "Sessions",
      administration: "Administration",
      users: "Users",
      integrations: "Integrations",
      settings: "Settings"
    },
    auth: {
      loginTitle: "Sign In",
      loginDescription: "Enter your credentials to sign in",
      email: "Email",
      password: "Password",
      login: "Sign In",
      invalidCredentials: "Invalid email or password",
      noPublicRegistration: "No public registration. Contact an administrator."
    },
    dashboard: {
      welcome: "Welcome, {{name}}",
      subtitle: "What would you like to do today?",
      newAnamnesis: "New Anamnesis",
      newAnamnesisDesc: "Start a new patient anamnesis",
      mySessions: "My Sessions",
      mySessionsDesc: "View and continue previous anamneses",
      manageUsers: "Manage Users",
      manageUsersDesc: "Users, roles and permissions",
      totalSessions: "Total Sessions",
      completedToday: "Completed Today",
      noData: "No data yet"
    },
    profile: {
      title: "My Profile",
      displayName: "Display Name",
      language: "Language",
      darkMode: "Dark Mode",
      changePassword: "Change Password",
      newPassword: "New Password",
      confirmPassword: "Confirm Password",
      updateSuccess: "Profile updated successfully",
      passwordUpdated: "Password changed successfully",
      passwordError: "Could not change password",
      updateError: "Could not update profile"
    },
    medical: {
      views: {
        hausarztpraxis: "General Practice",
        notaufnahme: "Emergency Room",
        telemedizin: "Telemedicine",
        fachambulanz: "Specialist Clinic",
        klinik: "Hospital"
      }
    },
    admin: {
      users: {
        title: "User Management",
        addUser: "Add User",
        email: "Email",
        role: "Role",
        views: "Clinical Views",
        createdAt: "Created At",
        assignViews: "Assign Views"
      },
      integrations: {
        title: "Integrations",
        addIntegration: "Add Integration",
        provider: "Provider",
        status: "Status",
        active: "Active",
        inactive: "Inactive",
        providers: {
          gemini: "Google Gemini",
          chatgpt: "OpenAI ChatGPT",
          ncbi: "NCBI/PubMed"
        }
      }
    },
    anamnesis: {
      selectView: "Select Clinical View",
      startSession: "Start Session",
      readAloud: "Read aloud",
      stopReading: "Stop reading",
      voiceInput: "Voice input",
      typeMessage: "Type a message...",
      send: "Send",
      redFlag: "Important Notice",
      redFlags: "Red Flags",
      progress: "Anamnesis Progress",
      consent: "Consent",
      consentText: "I understand that this is an AI-assisted anamnesis tool and does not replace medical advice.",
      categories: {
        chiefComplaint: "Chief Complaint",
        hpi: "History",
        ros: "Systems",
        pmh: "Past History",
        medications: "Medications",
        social: "Social",
        family: "Family",
        summary: "Summary"
      },
      phases: {
        consent: "Consent",
        redFlags: "Emergency Check",
        chiefComplaint: "Chief Complaint",
        hpi: "History of Present Illness",
        ros: "Review of Systems",
        pmh: "Past Medical History",
        summary: "Summary"
      }
    },
    evidence: {
      title: "Evidence Panel",
      refresh: "Refresh",
      tabSummary: "Summary",
      tabTrials: "Clinical Trials",
      fetchSuccess: "Evidence loaded",
      fetchSuccessDescription: "{{count}} results found",
      fetchError: "Loading error",
      fetchErrorDescription: "Could not fetch evidence",
      noData: "No evidence available",
      startSearch: "Start evidence search",
      noPubMed: "No PubMed results",
      noTrials: "No clinical trials",
      summaryTitle: "AI Summary",
      disclaimerTitle: "Disclaimer",
      disclaimerText: "These literature references are for informational purposes only and do not replace medical advice. The selection is based on automatic text analysis and may be incomplete.",
      auditInfo: "Audit Information",
      searchDate: "Search Date",
      queryTerms: "Query Terms",
      sources: "Sources"
    },
    documentation: {
      soapNote: "SOAP Note",
      redFlags: "Red Flags",
      subjective: "Subjective",
      objective: "Objective",
      assessment: "Assessment",
      plan: "Plan",
      chiefComplaint: "Chief Complaint",
      hpi: "History of Present Illness",
      ros: "Review of Systems",
      observations: "Observations",
      negated: "Negated",
      severity: "Severity",
      onset: "Onset",
      duration: "Duration",
      summary: "Summary",
      hpoCodes: "HPO Codes",
      meshTerms: "MeSH Terms",
      planPlaceholder: "(To be completed by clinician)",
      disclaimer: "This document was generated through AI-assisted anamnesis and does not replace clinical judgment."
    },
    export: {
      title: "Export",
      pdf: "Download PDF",
      json: "Download JSON",
      fhir: "Download FHIR Bundle",
      pdfSuccess: "PDF created",
      pdfSuccessDescription: "The SOAP note has been downloaded as PDF.",
      jsonSuccess: "JSON created",
      jsonSuccessDescription: "Session data has been downloaded as JSON.",
      fhirSuccess: "FHIR Bundle created",
      fhirSuccessDescription: "Data has been downloaded as FHIR R4 Bundle.",
      error: "Export error"
    },
    languages: {
      de: "Deutsch",
      en: "English",
      fr: "Français",
      it: "Italiano"
    }
  }
};
