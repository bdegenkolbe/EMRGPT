export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      ai_usage_logs: {
        Row: {
          completion_tokens: number
          created_at: string
          error_message: string | null
          id: string
          latency_ms: number | null
          model: string
          prompt_tokens: number
          provider: string
          request_metadata: Json | null
          session_id: string | null
          source_detail: string | null
          source_type: string
          status: string
          total_tokens: number | null
          user_id: string | null
        }
        Insert: {
          completion_tokens?: number
          created_at?: string
          error_message?: string | null
          id?: string
          latency_ms?: number | null
          model: string
          prompt_tokens?: number
          provider: string
          request_metadata?: Json | null
          session_id?: string | null
          source_detail?: string | null
          source_type: string
          status?: string
          total_tokens?: number | null
          user_id?: string | null
        }
        Update: {
          completion_tokens?: number
          created_at?: string
          error_message?: string | null
          id?: string
          latency_ms?: number | null
          model?: string
          prompt_tokens?: number
          provider?: string
          request_metadata?: Json | null
          session_id?: string | null
          source_detail?: string | null
          source_type?: string
          status?: string
          total_tokens?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ai_usage_logs_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "anamnesis_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      anamnesis_paths: {
        Row: {
          ai_reasoning: string | null
          created_at: string
          differential_diagnoses: Json
          hpo_codes: string[]
          id: string
          is_combined: boolean
          mermaid_diagram: string | null
          question_tree: Json
          session_id: string | null
          source_observation_ids: string[] | null
          symptom_hierarchy: Json
          temporal_sequence: Json
          updated_at: string
          version: number
        }
        Insert: {
          ai_reasoning?: string | null
          created_at?: string
          differential_diagnoses?: Json
          hpo_codes?: string[]
          id?: string
          is_combined?: boolean
          mermaid_diagram?: string | null
          question_tree?: Json
          session_id?: string | null
          source_observation_ids?: string[] | null
          symptom_hierarchy?: Json
          temporal_sequence?: Json
          updated_at?: string
          version?: number
        }
        Update: {
          ai_reasoning?: string | null
          created_at?: string
          differential_diagnoses?: Json
          hpo_codes?: string[]
          id?: string
          is_combined?: boolean
          mermaid_diagram?: string | null
          question_tree?: Json
          session_id?: string | null
          source_observation_ids?: string[] | null
          symptom_hierarchy?: Json
          temporal_sequence?: Json
          updated_at?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "anamnesis_paths_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "anamnesis_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      anamnesis_sessions: {
        Row: {
          clinical_view: Database["public"]["Enums"]["clinical_view"]
          completed_at: string | null
          created_at: string | null
          id: string
          language: string
          patient_identifier: string | null
          started_at: string | null
          status: string
          user_id: string
        }
        Insert: {
          clinical_view: Database["public"]["Enums"]["clinical_view"]
          completed_at?: string | null
          created_at?: string | null
          id?: string
          language?: string
          patient_identifier?: string | null
          started_at?: string | null
          status?: string
          user_id: string
        }
        Update: {
          clinical_view?: Database["public"]["Enums"]["clinical_view"]
          completed_at?: string | null
          created_at?: string | null
          id?: string
          language?: string
          patient_identifier?: string | null
          started_at?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      background_jobs: {
        Row: {
          batch_id: string | null
          completed_at: string | null
          created_at: string
          error_message: string | null
          id: string
          job_type: string
          payload: Json
          progress_current: number | null
          progress_total: number | null
          result: Json | null
          search_id: string | null
          source_id: string | null
          started_at: string | null
          status: string
        }
        Insert: {
          batch_id?: string | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          job_type: string
          payload?: Json
          progress_current?: number | null
          progress_total?: number | null
          result?: Json | null
          search_id?: string | null
          source_id?: string | null
          started_at?: string | null
          status?: string
        }
        Update: {
          batch_id?: string | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          job_type?: string
          payload?: Json
          progress_current?: number | null
          progress_total?: number | null
          result?: Json | null
          search_id?: string | null
          source_id?: string | null
          started_at?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "background_jobs_search_id_fkey"
            columns: ["search_id"]
            isOneToOne: false
            referencedRelation: "knowledge_searches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "background_jobs_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "knowledge_sources"
            referencedColumns: ["id"]
          },
        ]
      }
      conversation_messages: {
        Row: {
          content: string
          created_at: string | null
          id: string
          is_red_flag: boolean | null
          ontology_codes: Json | null
          role: string
          session_id: string
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          is_red_flag?: boolean | null
          ontology_codes?: Json | null
          role: string
          session_id: string
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          is_red_flag?: boolean | null
          ontology_codes?: Json | null
          role?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "anamnesis_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      emdn_codes: {
        Row: {
          code: string
          created_at: string | null
          description: string | null
          level: number | null
          mdr_class: string | null
          name_de: string | null
          name_en: string
          parent_code: string | null
        }
        Insert: {
          code: string
          created_at?: string | null
          description?: string | null
          level?: number | null
          mdr_class?: string | null
          name_de?: string | null
          name_en: string
          parent_code?: string | null
        }
        Update: {
          code?: string
          created_at?: string | null
          description?: string | null
          level?: number | null
          mdr_class?: string | null
          name_de?: string | null
          name_en?: string
          parent_code?: string | null
        }
        Relationships: []
      }
      evidence_items: {
        Row: {
          created_at: string | null
          external_id: string
          id: string
          provenance: Json | null
          relevance_score: number | null
          request_id: string
          snippet: string | null
          source: string
          study_type: string | null
          title: string
          url: string | null
          venue: string | null
          year: number | null
        }
        Insert: {
          created_at?: string | null
          external_id: string
          id?: string
          provenance?: Json | null
          relevance_score?: number | null
          request_id: string
          snippet?: string | null
          source: string
          study_type?: string | null
          title: string
          url?: string | null
          venue?: string | null
          year?: number | null
        }
        Update: {
          created_at?: string | null
          external_id?: string
          id?: string
          provenance?: Json | null
          relevance_score?: number | null
          request_id?: string
          snippet?: string | null
          source?: string
          study_type?: string | null
          title?: string
          url?: string | null
          venue?: string | null
          year?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "evidence_items_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "evidence_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      evidence_requests: {
        Row: {
          created_at: string | null
          id: string
          query_context: Json
          query_strings: Json
          session_id: string
          sources: string[]
        }
        Insert: {
          created_at?: string | null
          id?: string
          query_context: Json
          query_strings: Json
          session_id: string
          sources: string[]
        }
        Update: {
          created_at?: string | null
          id?: string
          query_context?: Json
          query_strings?: Json
          session_id?: string
          sources?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "evidence_requests_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "anamnesis_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      fhir_allergies: {
        Row: {
          category: string | null
          clinical_status: string | null
          code: string | null
          code_display: string | null
          created_at: string
          criticality: string | null
          fhir_id: string
          fhir_resource: Json
          id: string
          onset_datetime: string | null
          patient_id: string
          reactions: Json | null
          type: string | null
          updated_at: string
          verification_status: string | null
        }
        Insert: {
          category?: string | null
          clinical_status?: string | null
          code?: string | null
          code_display?: string | null
          created_at?: string
          criticality?: string | null
          fhir_id: string
          fhir_resource: Json
          id?: string
          onset_datetime?: string | null
          patient_id: string
          reactions?: Json | null
          type?: string | null
          updated_at?: string
          verification_status?: string | null
        }
        Update: {
          category?: string | null
          clinical_status?: string | null
          code?: string | null
          code_display?: string | null
          created_at?: string
          criticality?: string | null
          fhir_id?: string
          fhir_resource?: Json
          id?: string
          onset_datetime?: string | null
          patient_id?: string
          reactions?: Json | null
          type?: string | null
          updated_at?: string
          verification_status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fhir_allergies_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
        ]
      }
      fhir_conditions: {
        Row: {
          abatement_datetime: string | null
          category: string | null
          clinical_status: string | null
          code: string | null
          code_display: string | null
          code_system: string | null
          created_at: string
          encounter_id: string | null
          fhir_id: string
          fhir_resource: Json
          hpo_codes: string[] | null
          id: string
          onset_datetime: string | null
          patient_id: string
          severity: string | null
          snomed_codes: string[] | null
          updated_at: string
          verification_status: string | null
        }
        Insert: {
          abatement_datetime?: string | null
          category?: string | null
          clinical_status?: string | null
          code?: string | null
          code_display?: string | null
          code_system?: string | null
          created_at?: string
          encounter_id?: string | null
          fhir_id: string
          fhir_resource: Json
          hpo_codes?: string[] | null
          id?: string
          onset_datetime?: string | null
          patient_id: string
          severity?: string | null
          snomed_codes?: string[] | null
          updated_at?: string
          verification_status?: string | null
        }
        Update: {
          abatement_datetime?: string | null
          category?: string | null
          clinical_status?: string | null
          code?: string | null
          code_display?: string | null
          code_system?: string | null
          created_at?: string
          encounter_id?: string | null
          fhir_id?: string
          fhir_resource?: Json
          hpo_codes?: string[] | null
          id?: string
          onset_datetime?: string | null
          patient_id?: string
          severity?: string | null
          snomed_codes?: string[] | null
          updated_at?: string
          verification_status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fhir_conditions_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "fhir_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fhir_conditions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
        ]
      }
      fhir_document_references: {
        Row: {
          analysis_result: Json | null
          analysis_status: string | null
          author_display: string | null
          content_type: string | null
          created_at: string
          date: string | null
          description: string | null
          encounter_id: string | null
          extracted_text: string | null
          fhir_id: string
          fhir_resource: Json
          id: string
          patient_id: string
          status: string
          storage_path: string | null
          transferred_resources: Json | null
          type_code: string | null
          type_display: string | null
          updated_at: string
        }
        Insert: {
          analysis_result?: Json | null
          analysis_status?: string | null
          author_display?: string | null
          content_type?: string | null
          created_at?: string
          date?: string | null
          description?: string | null
          encounter_id?: string | null
          extracted_text?: string | null
          fhir_id: string
          fhir_resource: Json
          id?: string
          patient_id: string
          status: string
          storage_path?: string | null
          transferred_resources?: Json | null
          type_code?: string | null
          type_display?: string | null
          updated_at?: string
        }
        Update: {
          analysis_result?: Json | null
          analysis_status?: string | null
          author_display?: string | null
          content_type?: string | null
          created_at?: string
          date?: string | null
          description?: string | null
          encounter_id?: string | null
          extracted_text?: string | null
          fhir_id?: string
          fhir_resource?: Json
          id?: string
          patient_id?: string
          status?: string
          storage_path?: string | null
          transferred_resources?: Json | null
          type_code?: string | null
          type_display?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fhir_document_references_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "fhir_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fhir_document_references_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
        ]
      }
      fhir_encounters: {
        Row: {
          class: string | null
          created_at: string
          diagnosis_codes: Json | null
          fhir_id: string
          fhir_resource: Json
          id: string
          patient_id: string
          period_end: string | null
          period_start: string | null
          reason_codes: Json | null
          service_provider: string | null
          status: string
          type_code: string | null
          type_display: string | null
          updated_at: string
        }
        Insert: {
          class?: string | null
          created_at?: string
          diagnosis_codes?: Json | null
          fhir_id: string
          fhir_resource: Json
          id?: string
          patient_id: string
          period_end?: string | null
          period_start?: string | null
          reason_codes?: Json | null
          service_provider?: string | null
          status: string
          type_code?: string | null
          type_display?: string | null
          updated_at?: string
        }
        Update: {
          class?: string | null
          created_at?: string
          diagnosis_codes?: Json | null
          fhir_id?: string
          fhir_resource?: Json
          id?: string
          patient_id?: string
          period_end?: string | null
          period_start?: string | null
          reason_codes?: Json | null
          service_provider?: string | null
          status?: string
          type_code?: string | null
          type_display?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fhir_encounters_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
        ]
      }
      fhir_medication_requests: {
        Row: {
          authored_on: string | null
          created_at: string
          dosage_route: string | null
          dosage_text: string | null
          encounter_id: string | null
          fhir_id: string
          fhir_resource: Json
          id: string
          intent: string | null
          medication_code: string | null
          medication_display: string | null
          patient_id: string
          reason_codes: Json | null
          requester_display: string | null
          status: string
          updated_at: string
        }
        Insert: {
          authored_on?: string | null
          created_at?: string
          dosage_route?: string | null
          dosage_text?: string | null
          encounter_id?: string | null
          fhir_id: string
          fhir_resource: Json
          id?: string
          intent?: string | null
          medication_code?: string | null
          medication_display?: string | null
          patient_id: string
          reason_codes?: Json | null
          requester_display?: string | null
          status: string
          updated_at?: string
        }
        Update: {
          authored_on?: string | null
          created_at?: string
          dosage_route?: string | null
          dosage_text?: string | null
          encounter_id?: string | null
          fhir_id?: string
          fhir_resource?: Json
          id?: string
          intent?: string | null
          medication_code?: string | null
          medication_display?: string | null
          patient_id?: string
          reason_codes?: Json | null
          requester_display?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fhir_medication_requests_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "fhir_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fhir_medication_requests_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
        ]
      }
      fhir_observations: {
        Row: {
          category: string | null
          code_display: string | null
          created_at: string
          effective_datetime: string | null
          encounter_id: string | null
          fhir_id: string
          fhir_resource: Json
          id: string
          interpretation: string | null
          loinc_code: string | null
          patient_id: string
          reference_range_high: number | null
          reference_range_low: number | null
          status: string
          updated_at: string
          value_quantity: number | null
          value_string: string | null
          value_unit: string | null
        }
        Insert: {
          category?: string | null
          code_display?: string | null
          created_at?: string
          effective_datetime?: string | null
          encounter_id?: string | null
          fhir_id: string
          fhir_resource: Json
          id?: string
          interpretation?: string | null
          loinc_code?: string | null
          patient_id: string
          reference_range_high?: number | null
          reference_range_low?: number | null
          status: string
          updated_at?: string
          value_quantity?: number | null
          value_string?: string | null
          value_unit?: string | null
        }
        Update: {
          category?: string | null
          code_display?: string | null
          created_at?: string
          effective_datetime?: string | null
          encounter_id?: string | null
          fhir_id?: string
          fhir_resource?: Json
          id?: string
          interpretation?: string | null
          loinc_code?: string | null
          patient_id?: string
          reference_range_high?: number | null
          reference_range_low?: number | null
          status?: string
          updated_at?: string
          value_quantity?: number | null
          value_string?: string | null
          value_unit?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fhir_observations_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "fhir_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fhir_observations_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
        ]
      }
      fhir_patients: {
        Row: {
          active: boolean | null
          address: Json | null
          birth_date: string | null
          created_at: string
          created_by: string
          family_name: string
          fhir_id: string
          fhir_resource: Json
          gender: string | null
          given_name: string
          id: string
          identifier_mrn: string | null
          telecom: Json | null
          updated_at: string
        }
        Insert: {
          active?: boolean | null
          address?: Json | null
          birth_date?: string | null
          created_at?: string
          created_by: string
          family_name: string
          fhir_id: string
          fhir_resource: Json
          gender?: string | null
          given_name: string
          id?: string
          identifier_mrn?: string | null
          telecom?: Json | null
          updated_at?: string
        }
        Update: {
          active?: boolean | null
          address?: Json | null
          birth_date?: string | null
          created_at?: string
          created_by?: string
          family_name?: string
          fhir_id?: string
          fhir_resource?: Json
          gender?: string | null
          given_name?: string
          id?: string
          identifier_mrn?: string | null
          telecom?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      fhir_procedures: {
        Row: {
          body_site: string | null
          category: string | null
          code: string | null
          code_display: string | null
          code_system: string | null
          created_at: string
          encounter_id: string | null
          fhir_id: string
          fhir_resource: Json
          id: string
          note: string | null
          patient_id: string
          performed_datetime: string | null
          performer_display: string | null
          reason_codes: Json | null
          source_document_id: string | null
          status: string
          updated_at: string
        }
        Insert: {
          body_site?: string | null
          category?: string | null
          code?: string | null
          code_display?: string | null
          code_system?: string | null
          created_at?: string
          encounter_id?: string | null
          fhir_id: string
          fhir_resource: Json
          id?: string
          note?: string | null
          patient_id: string
          performed_datetime?: string | null
          performer_display?: string | null
          reason_codes?: Json | null
          source_document_id?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          body_site?: string | null
          category?: string | null
          code?: string | null
          code_display?: string | null
          code_system?: string | null
          created_at?: string
          encounter_id?: string | null
          fhir_id?: string
          fhir_resource?: Json
          id?: string
          note?: string | null
          patient_id?: string
          performed_datetime?: string | null
          performer_display?: string | null
          reason_codes?: Json | null
          source_document_id?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fhir_procedures_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "fhir_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fhir_procedures_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fhir_procedures_source_document_id_fkey"
            columns: ["source_document_id"]
            isOneToOne: false
            referencedRelation: "fhir_document_references"
            referencedColumns: ["id"]
          },
        ]
      }
      guideline_chunks: {
        Row: {
          chunk_index: number
          content: string
          created_at: string
          embedding: string | null
          guideline_id: string
          id: string
          metadata: Json | null
          page_number: number | null
          section_title: string | null
          token_count: number | null
        }
        Insert: {
          chunk_index: number
          content: string
          created_at?: string
          embedding?: string | null
          guideline_id: string
          id?: string
          metadata?: Json | null
          page_number?: number | null
          section_title?: string | null
          token_count?: number | null
        }
        Update: {
          chunk_index?: number
          content?: string
          created_at?: string
          embedding?: string | null
          guideline_id?: string
          id?: string
          metadata?: Json | null
          page_number?: number | null
          section_title?: string | null
          token_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "guideline_chunks_guideline_id_fkey"
            columns: ["guideline_id"]
            isOneToOne: false
            referencedRelation: "guidelines"
            referencedColumns: ["id"]
          },
        ]
      }
      guidelines: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          detected_hpo_codes: string[] | null
          detected_icd10_codes: string[] | null
          detected_snomed_codes: string[] | null
          embedding_error: string | null
          embedding_progress: number | null
          embedding_status: string | null
          file_name: string | null
          file_path: string | null
          file_size: number | null
          id: string
          mime_type: string | null
          source: string | null
          title: string
          total_chunks: number | null
          updated_at: string
          valid_from: string | null
          valid_until: string | null
          version: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          detected_hpo_codes?: string[] | null
          detected_icd10_codes?: string[] | null
          detected_snomed_codes?: string[] | null
          embedding_error?: string | null
          embedding_progress?: number | null
          embedding_status?: string | null
          file_name?: string | null
          file_path?: string | null
          file_size?: number | null
          id?: string
          mime_type?: string | null
          source?: string | null
          title: string
          total_chunks?: number | null
          updated_at?: string
          valid_from?: string | null
          valid_until?: string | null
          version?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          detected_hpo_codes?: string[] | null
          detected_icd10_codes?: string[] | null
          detected_snomed_codes?: string[] | null
          embedding_error?: string | null
          embedding_progress?: number | null
          embedding_status?: string | null
          file_name?: string | null
          file_path?: string | null
          file_size?: number | null
          id?: string
          mime_type?: string | null
          source?: string | null
          title?: string
          total_chunks?: number | null
          updated_at?: string
          valid_from?: string | null
          valid_until?: string | null
          version?: string | null
        }
        Relationships: []
      }
      hpo_analyses: {
        Row: {
          content: Json
          created_at: string
          generated_at: string | null
          generated_by: string | null
          hpo_code: string
          icd10_mappings: Json | null
          id: string
          snomed_mappings: Json | null
          source_language: string
          updated_at: string
        }
        Insert: {
          content?: Json
          created_at?: string
          generated_at?: string | null
          generated_by?: string | null
          hpo_code: string
          icd10_mappings?: Json | null
          id?: string
          snomed_mappings?: Json | null
          source_language?: string
          updated_at?: string
        }
        Update: {
          content?: Json
          created_at?: string
          generated_at?: string | null
          generated_by?: string | null
          hpo_code?: string
          icd10_mappings?: Json | null
          id?: string
          snomed_mappings?: Json | null
          source_language?: string
          updated_at?: string
        }
        Relationships: []
      }
      hpo_codes: {
        Row: {
          created_at: string | null
          definition: string | null
          definitions: Json | null
          explanations: Json | null
          hpo_code: string
          is_terminal: boolean | null
          label: string
          labels: Json | null
          level: number | null
          parent_codes: string[] | null
          source: string | null
          synonyms: string[] | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          definition?: string | null
          definitions?: Json | null
          explanations?: Json | null
          hpo_code: string
          is_terminal?: boolean | null
          label: string
          labels?: Json | null
          level?: number | null
          parent_codes?: string[] | null
          source?: string | null
          synonyms?: string[] | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          definition?: string | null
          definitions?: Json | null
          explanations?: Json | null
          hpo_code?: string
          is_terminal?: boolean | null
          label?: string
          labels?: Json | null
          level?: number | null
          parent_codes?: string[] | null
          source?: string | null
          synonyms?: string[] | null
          updated_at?: string | null
        }
        Relationships: []
      }
      icd10gm_analyses: {
        Row: {
          content: Json
          created_at: string
          generated_at: string | null
          generated_by: string | null
          hpo_mappings: Json | null
          icd_code: string
          id: string
          snomed_mappings: Json | null
          source_language: string
          symptom_mappings: Json | null
          updated_at: string
        }
        Insert: {
          content?: Json
          created_at?: string
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd_code: string
          id?: string
          snomed_mappings?: Json | null
          source_language?: string
          symptom_mappings?: Json | null
          updated_at?: string
        }
        Update: {
          content?: Json
          created_at?: string
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd_code?: string
          id?: string
          snomed_mappings?: Json | null
          source_language?: string
          symptom_mappings?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      icd10gm_codes: {
        Row: {
          block: string | null
          category: string | null
          chapter: string | null
          code: string
          created_at: string | null
          definitions: Json | null
          exclusions: string[] | null
          explanations: Json | null
          inclusions: string[] | null
          is_terminal: boolean | null
          labels: Json | null
          notes: string | null
          parent_code: string | null
          title: string
          title_short: string | null
          year: number | null
        }
        Insert: {
          block?: string | null
          category?: string | null
          chapter?: string | null
          code: string
          created_at?: string | null
          definitions?: Json | null
          exclusions?: string[] | null
          explanations?: Json | null
          inclusions?: string[] | null
          is_terminal?: boolean | null
          labels?: Json | null
          notes?: string | null
          parent_code?: string | null
          title: string
          title_short?: string | null
          year?: number | null
        }
        Update: {
          block?: string | null
          category?: string | null
          chapter?: string | null
          code?: string
          created_at?: string | null
          definitions?: Json | null
          exclusions?: string[] | null
          explanations?: Json | null
          inclusions?: string[] | null
          is_terminal?: boolean | null
          labels?: Json | null
          notes?: string | null
          parent_code?: string | null
          title?: string
          title_short?: string | null
          year?: number | null
        }
        Relationships: []
      }
      icd11_analyses: {
        Row: {
          content: Json | null
          created_at: string | null
          generated_at: string | null
          generated_by: string | null
          hpo_mappings: Json | null
          icd_code: string
          id: string
          snomed_mappings: Json | null
          source_language: string | null
          symptom_mappings: Json | null
          updated_at: string | null
        }
        Insert: {
          content?: Json | null
          created_at?: string | null
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd_code: string
          id?: string
          snomed_mappings?: Json | null
          source_language?: string | null
          symptom_mappings?: Json | null
          updated_at?: string | null
        }
        Update: {
          content?: Json | null
          created_at?: string | null
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd_code?: string
          id?: string
          snomed_mappings?: Json | null
          source_language?: string | null
          symptom_mappings?: Json | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "icd11_analyses_icd_code_fkey"
            columns: ["icd_code"]
            isOneToOne: true
            referencedRelation: "icd11_codes"
            referencedColumns: ["code"]
          },
        ]
      }
      icd11_codes: {
        Row: {
          block: string | null
          category: string | null
          chapter: string | null
          class_kind: string | null
          code: string
          created_at: string | null
          definition: string | null
          definitions: Json | null
          exclusions: string[] | null
          explanations: Json | null
          foundation_uri: string | null
          inclusions: string[] | null
          is_terminal: boolean | null
          labels: Json | null
          linearization_uri: string | null
          notes: string | null
          parent_code: string | null
          title: string
          title_short: string | null
        }
        Insert: {
          block?: string | null
          category?: string | null
          chapter?: string | null
          class_kind?: string | null
          code: string
          created_at?: string | null
          definition?: string | null
          definitions?: Json | null
          exclusions?: string[] | null
          explanations?: Json | null
          foundation_uri?: string | null
          inclusions?: string[] | null
          is_terminal?: boolean | null
          labels?: Json | null
          linearization_uri?: string | null
          notes?: string | null
          parent_code?: string | null
          title: string
          title_short?: string | null
        }
        Update: {
          block?: string | null
          category?: string | null
          chapter?: string | null
          class_kind?: string | null
          code?: string
          created_at?: string | null
          definition?: string | null
          definitions?: Json | null
          exclusions?: string[] | null
          explanations?: Json | null
          foundation_uri?: string | null
          inclusions?: string[] | null
          is_terminal?: boolean | null
          labels?: Json | null
          linearization_uri?: string | null
          notes?: string | null
          parent_code?: string | null
          title?: string
          title_short?: string | null
        }
        Relationships: []
      }
      integrations: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          name: string
          provider: string
          updated_at: string
          vault_secret_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          provider: string
          updated_at?: string
          vault_secret_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          provider?: string
          updated_at?: string
          vault_secret_id?: string | null
        }
        Relationships: []
      }
      knowledge_searches: {
        Row: {
          ai_response: string | null
          answer_generated_at: string | null
          created_at: string
          id: string
          language: string
          query: string
          query_analysis: Json | null
          user_id: string
        }
        Insert: {
          ai_response?: string | null
          answer_generated_at?: string | null
          created_at?: string
          id?: string
          language?: string
          query: string
          query_analysis?: Json | null
          user_id: string
        }
        Update: {
          ai_response?: string | null
          answer_generated_at?: string | null
          created_at?: string
          id?: string
          language?: string
          query?: string
          query_analysis?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      knowledge_sources: {
        Row: {
          authors: string | null
          content_status: string
          content_type: string
          created_at: string
          external_id: string | null
          id: string
          metadata: Json | null
          original_content: string | null
          original_language: string | null
          pdf_path: string | null
          relevance_score: number | null
          search_id: string
          source_type: string
          target_language: string | null
          title: string
          translated_content: string | null
          translated_title: string | null
          translation_status: string
          updated_at: string
          url: string | null
          year: number | null
        }
        Insert: {
          authors?: string | null
          content_status?: string
          content_type?: string
          created_at?: string
          external_id?: string | null
          id?: string
          metadata?: Json | null
          original_content?: string | null
          original_language?: string | null
          pdf_path?: string | null
          relevance_score?: number | null
          search_id: string
          source_type: string
          target_language?: string | null
          title: string
          translated_content?: string | null
          translated_title?: string | null
          translation_status?: string
          updated_at?: string
          url?: string | null
          year?: number | null
        }
        Update: {
          authors?: string | null
          content_status?: string
          content_type?: string
          created_at?: string
          external_id?: string | null
          id?: string
          metadata?: Json | null
          original_content?: string | null
          original_language?: string | null
          pdf_path?: string | null
          relevance_score?: number | null
          search_id?: string
          source_type?: string
          target_language?: string | null
          title?: string
          translated_content?: string | null
          translated_title?: string | null
          translation_status?: string
          updated_at?: string
          url?: string | null
          year?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_sources_search_id_fkey"
            columns: ["search_id"]
            isOneToOne: false
            referencedRelation: "knowledge_searches"
            referencedColumns: ["id"]
          },
        ]
      }
      loinc_codes: {
        Row: {
          class: string | null
          class_type: number | null
          component: string
          created_at: string | null
          display_name: string | null
          example_ucum_units: string | null
          loinc_num: string
          long_common_name: string | null
          method_type: string | null
          property: string | null
          scale_type: string | null
          short_name: string | null
          status: string | null
          system: string | null
          time_aspect: string | null
        }
        Insert: {
          class?: string | null
          class_type?: number | null
          component: string
          created_at?: string | null
          display_name?: string | null
          example_ucum_units?: string | null
          loinc_num: string
          long_common_name?: string | null
          method_type?: string | null
          property?: string | null
          scale_type?: string | null
          short_name?: string | null
          status?: string | null
          system?: string | null
          time_aspect?: string | null
        }
        Update: {
          class?: string | null
          class_type?: number | null
          component?: string
          created_at?: string | null
          display_name?: string | null
          example_ucum_units?: string | null
          loinc_num?: string
          long_common_name?: string | null
          method_type?: string | null
          property?: string | null
          scale_type?: string | null
          short_name?: string | null
          status?: string | null
          system?: string | null
          time_aspect?: string | null
        }
        Relationships: []
      }
      observations: {
        Row: {
          confidence: number | null
          created_at: string | null
          duration: string | null
          hpo_codes: string[] | null
          id: string
          language: string
          mesh_terms: string[] | null
          negated: boolean | null
          normalized_value: string | null
          onset: string | null
          provenance: string | null
          raw_input: string
          rxnorm_codes: string[] | null
          session_id: string
          severity: string | null
        }
        Insert: {
          confidence?: number | null
          created_at?: string | null
          duration?: string | null
          hpo_codes?: string[] | null
          id?: string
          language: string
          mesh_terms?: string[] | null
          negated?: boolean | null
          normalized_value?: string | null
          onset?: string | null
          provenance?: string | null
          raw_input: string
          rxnorm_codes?: string[] | null
          session_id: string
          severity?: string | null
        }
        Update: {
          confidence?: number | null
          created_at?: string | null
          duration?: string | null
          hpo_codes?: string[] | null
          id?: string
          language?: string
          mesh_terms?: string[] | null
          negated?: boolean | null
          normalized_value?: string | null
          onset?: string | null
          provenance?: string | null
          raw_input?: string
          rxnorm_codes?: string[] | null
          session_id?: string
          severity?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "observations_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "anamnesis_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      ontology_mappings: {
        Row: {
          confidence: number
          conflict_details: Json | null
          conflict_severity: string | null
          conflict_type: string | null
          created_at: string
          extraction_source: string | null
          graph_depth: number | null
          id: string
          is_bidirectional: boolean | null
          last_validated_at: string | null
          mapping_type: string
          notes: string | null
          related_mapping_ids: string[] | null
          resolved_at: string | null
          resolved_by: string | null
          reverse_mapping_id: string | null
          source_code: string
          source_label: string
          source_system: string
          target_code: string
          target_label: string
          target_system: string
          updated_at: string
          validated_at: string | null
          validated_by: string | null
          validation_status: string
        }
        Insert: {
          confidence?: number
          conflict_details?: Json | null
          conflict_severity?: string | null
          conflict_type?: string | null
          created_at?: string
          extraction_source?: string | null
          graph_depth?: number | null
          id?: string
          is_bidirectional?: boolean | null
          last_validated_at?: string | null
          mapping_type: string
          notes?: string | null
          related_mapping_ids?: string[] | null
          resolved_at?: string | null
          resolved_by?: string | null
          reverse_mapping_id?: string | null
          source_code: string
          source_label: string
          source_system: string
          target_code: string
          target_label: string
          target_system: string
          updated_at?: string
          validated_at?: string | null
          validated_by?: string | null
          validation_status?: string
        }
        Update: {
          confidence?: number
          conflict_details?: Json | null
          conflict_severity?: string | null
          conflict_type?: string | null
          created_at?: string
          extraction_source?: string | null
          graph_depth?: number | null
          id?: string
          is_bidirectional?: boolean | null
          last_validated_at?: string | null
          mapping_type?: string
          notes?: string | null
          related_mapping_ids?: string[] | null
          resolved_at?: string | null
          resolved_by?: string | null
          reverse_mapping_id?: string | null
          source_code?: string
          source_label?: string
          source_system?: string
          target_code?: string
          target_label?: string
          target_system?: string
          updated_at?: string
          validated_at?: string | null
          validated_by?: string | null
          validation_status?: string
        }
        Relationships: []
      }
      orphanet_analyses: {
        Row: {
          content: Json
          created_at: string | null
          generated_at: string | null
          generated_by: string | null
          hpo_mappings: Json | null
          icd10_mappings: Json | null
          id: string
          omim_mappings: Json | null
          orpha_code: string
          snomed_mappings: Json | null
          source_language: string
          updated_at: string | null
        }
        Insert: {
          content?: Json
          created_at?: string | null
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd10_mappings?: Json | null
          id?: string
          omim_mappings?: Json | null
          orpha_code: string
          snomed_mappings?: Json | null
          source_language?: string
          updated_at?: string | null
        }
        Update: {
          content?: Json
          created_at?: string | null
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd10_mappings?: Json | null
          id?: string
          omim_mappings?: Json | null
          orpha_code?: string
          snomed_mappings?: Json | null
          source_language?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      orphanet_codes: {
        Row: {
          age_of_onset: string[] | null
          classification: string | null
          created_at: string | null
          definition: string | null
          definitions: Json | null
          explanations: Json | null
          hpo_codes: string[] | null
          icd10_codes: string[] | null
          inheritance: string[] | null
          is_terminal: boolean | null
          labels: Json | null
          level: number | null
          name: string
          name_short: string | null
          omim_codes: string[] | null
          orpha_code: string
          orpha_url: string | null
          parent_code: string | null
          prevalence: string | null
          snomed_codes: string[] | null
          source: string | null
          updated_at: string | null
        }
        Insert: {
          age_of_onset?: string[] | null
          classification?: string | null
          created_at?: string | null
          definition?: string | null
          definitions?: Json | null
          explanations?: Json | null
          hpo_codes?: string[] | null
          icd10_codes?: string[] | null
          inheritance?: string[] | null
          is_terminal?: boolean | null
          labels?: Json | null
          level?: number | null
          name: string
          name_short?: string | null
          omim_codes?: string[] | null
          orpha_code: string
          orpha_url?: string | null
          parent_code?: string | null
          prevalence?: string | null
          snomed_codes?: string[] | null
          source?: string | null
          updated_at?: string | null
        }
        Update: {
          age_of_onset?: string[] | null
          classification?: string | null
          created_at?: string | null
          definition?: string | null
          definitions?: Json | null
          explanations?: Json | null
          hpo_codes?: string[] | null
          icd10_codes?: string[] | null
          inheritance?: string[] | null
          is_terminal?: boolean | null
          labels?: Json | null
          level?: number | null
          name?: string
          name_short?: string | null
          omim_codes?: string[] | null
          orpha_code?: string
          orpha_url?: string | null
          parent_code?: string | null
          prevalence?: string | null
          snomed_codes?: string[] | null
          source?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      patient_chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          metadata: Json | null
          patient_id: string
          role: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          metadata?: Json | null
          patient_id: string
          role: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          metadata?: Json | null
          patient_id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "patient_chat_messages_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "fhir_patients"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_domains: {
        Row: {
          classification_keywords: string[] | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          slug: string
          updated_at: string
        }
        Insert: {
          classification_keywords?: string[] | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          slug: string
          updated_at?: string
        }
        Update: {
          classification_keywords?: string[] | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      pipeline_executions: {
        Row: {
          completed_at: string | null
          created_at: string
          domain: string
          domain_classification: Json | null
          error_message: string | null
          id: string
          input_data: Json
          output_data: Json | null
          pipeline_id: string | null
          session_id: string | null
          status: string
          total_latency_ms: number | null
          total_tokens: number | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          domain?: string
          domain_classification?: Json | null
          error_message?: string | null
          id?: string
          input_data: Json
          output_data?: Json | null
          pipeline_id?: string | null
          session_id?: string | null
          status?: string
          total_latency_ms?: number | null
          total_tokens?: number | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          domain?: string
          domain_classification?: Json | null
          error_message?: string | null
          id?: string
          input_data?: Json
          output_data?: Json | null
          pipeline_id?: string | null
          session_id?: string | null
          status?: string
          total_latency_ms?: number | null
          total_tokens?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "pipeline_executions_pipeline_id_fkey"
            columns: ["pipeline_id"]
            isOneToOne: false
            referencedRelation: "pipelines"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pipeline_executions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "anamnesis_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_phase_logs: {
        Row: {
          completed_at: string | null
          completion_tokens: number | null
          created_at: string
          error_message: string | null
          execution_id: string
          id: string
          input_data: Json
          latency_ms: number | null
          output_data: Json | null
          phase: string
          prompt_tokens: number | null
          status: string
          template_id: string | null
        }
        Insert: {
          completed_at?: string | null
          completion_tokens?: number | null
          created_at?: string
          error_message?: string | null
          execution_id: string
          id?: string
          input_data: Json
          latency_ms?: number | null
          output_data?: Json | null
          phase: string
          prompt_tokens?: number | null
          status?: string
          template_id?: string | null
        }
        Update: {
          completed_at?: string | null
          completion_tokens?: number | null
          created_at?: string
          error_message?: string | null
          execution_id?: string
          id?: string
          input_data?: Json
          latency_ms?: number | null
          output_data?: Json | null
          phase?: string
          prompt_tokens?: number | null
          status?: string
          template_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pipeline_phase_logs_execution_id_fkey"
            columns: ["execution_id"]
            isOneToOne: false
            referencedRelation: "pipeline_executions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pipeline_phase_logs_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "prompt_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      pipelines: {
        Row: {
          created_at: string
          description: string | null
          domain_id: string
          fallback_pipeline_id: string | null
          id: string
          is_active: boolean
          name: string
          phase_order: string[]
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          domain_id: string
          fallback_pipeline_id?: string | null
          id?: string
          is_active?: boolean
          name: string
          phase_order?: string[]
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          domain_id?: string
          fallback_pipeline_id?: string | null
          id?: string
          is_active?: boolean
          name?: string
          phase_order?: string[]
          slug?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "pipelines_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "pipeline_domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pipelines_fallback_pipeline_id_fkey"
            columns: ["fallback_pipeline_id"]
            isOneToOne: false
            referencedRelation: "pipelines"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          dark_mode: boolean
          display_name: string | null
          email: string
          id: string
          language: string
          show_english_details: boolean
          sidebar_collapsed: boolean
          sidebar_tab_order: string[] | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          dark_mode?: boolean
          display_name?: string | null
          email: string
          id?: string
          language?: string
          show_english_details?: boolean
          sidebar_collapsed?: boolean
          sidebar_tab_order?: string[] | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          dark_mode?: boolean
          display_name?: string | null
          email?: string
          id?: string
          language?: string
          show_english_details?: boolean
          sidebar_collapsed?: boolean
          sidebar_tab_order?: string[] | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      prompt_templates: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          domain_id: string | null
          id: string
          is_active: boolean
          model_config: Json | null
          name: string
          parameter_schema: Json | null
          parent_template_id: string | null
          phase: string
          pipeline_id: string | null
          system_prompt: string
          updated_at: string
          user_prompt_template: string | null
          version: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          domain_id?: string | null
          id?: string
          is_active?: boolean
          model_config?: Json | null
          name: string
          parameter_schema?: Json | null
          parent_template_id?: string | null
          phase: string
          pipeline_id?: string | null
          system_prompt: string
          updated_at?: string
          user_prompt_template?: string | null
          version?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          domain_id?: string | null
          id?: string
          is_active?: boolean
          model_config?: Json | null
          name?: string
          parameter_schema?: Json | null
          parent_template_id?: string | null
          phase?: string
          pipeline_id?: string | null
          system_prompt?: string
          updated_at?: string
          user_prompt_template?: string | null
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "prompt_templates_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "pipeline_domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prompt_templates_parent_template_id_fkey"
            columns: ["parent_template_id"]
            isOneToOne: false
            referencedRelation: "prompt_templates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prompt_templates_pipeline_id_fkey"
            columns: ["pipeline_id"]
            isOneToOne: false
            referencedRelation: "pipelines"
            referencedColumns: ["id"]
          },
        ]
      }
      scheduled_sync_jobs: {
        Row: {
          created_at: string
          cron_expression: string
          id: string
          is_enabled: boolean
          last_run_at: string | null
          last_run_message: string | null
          last_run_status: string | null
          next_run_at: string | null
          source_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          cron_expression?: string
          id?: string
          is_enabled?: boolean
          last_run_at?: string | null
          last_run_message?: string | null
          last_run_status?: string | null
          next_run_at?: string | null
          source_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          cron_expression?: string
          id?: string
          is_enabled?: boolean
          last_run_at?: string | null
          last_run_message?: string | null
          last_run_status?: string | null
          next_run_at?: string | null
          source_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      snomed_analyses: {
        Row: {
          content: Json
          created_at: string
          generated_at: string | null
          generated_by: string | null
          hpo_mappings: Json | null
          icd10_mappings: Json | null
          id: string
          sctid: string
          source_language: string
          updated_at: string
        }
        Insert: {
          content?: Json
          created_at?: string
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd10_mappings?: Json | null
          id?: string
          sctid: string
          source_language?: string
          updated_at?: string
        }
        Update: {
          content?: Json
          created_at?: string
          generated_at?: string | null
          generated_by?: string | null
          hpo_mappings?: Json | null
          icd10_mappings?: Json | null
          id?: string
          sctid?: string
          source_language?: string
          updated_at?: string
        }
        Relationships: []
      }
      snomed_codes: {
        Row: {
          created_at: string | null
          definition_status: string | null
          definitions: Json | null
          effective_time: string | null
          explanations: Json | null
          fsn: string
          is_active: boolean | null
          is_terminal: boolean | null
          labels: Json | null
          level: number | null
          module_id: string | null
          parent_codes: string[] | null
          pt: string
          sctid: string
          semantic_tag: string | null
          source: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          definition_status?: string | null
          definitions?: Json | null
          effective_time?: string | null
          explanations?: Json | null
          fsn: string
          is_active?: boolean | null
          is_terminal?: boolean | null
          labels?: Json | null
          level?: number | null
          module_id?: string | null
          parent_codes?: string[] | null
          pt: string
          sctid: string
          semantic_tag?: string | null
          source?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          definition_status?: string | null
          definitions?: Json | null
          effective_time?: string | null
          explanations?: Json | null
          fsn?: string
          is_active?: boolean | null
          is_terminal?: boolean | null
          labels?: Json | null
          level?: number | null
          module_id?: string | null
          parent_codes?: string[] | null
          pt?: string
          sctid?: string
          semantic_tag?: string | null
          source?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      sync_status: {
        Row: {
          completed_at: string | null
          created_at: string | null
          error_message: string | null
          id: string
          last_cursor: string | null
          local_version: string | null
          remote_version: string | null
          source_name: string
          started_at: string | null
          status: string | null
          total_available: number | null
          total_synced: number | null
          updated_at: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string | null
          error_message?: string | null
          id?: string
          last_cursor?: string | null
          local_version?: string | null
          remote_version?: string | null
          source_name: string
          started_at?: string | null
          status?: string | null
          total_available?: number | null
          total_synced?: number | null
          updated_at?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string | null
          error_message?: string | null
          id?: string
          last_cursor?: string | null
          local_version?: string | null
          remote_version?: string | null
          source_name?: string
          started_at?: string | null
          status?: string | null
          total_available?: number | null
          total_synced?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      term_translations: {
        Row: {
          created_at: string
          created_by: string | null
          english_term: string
          german_term: string
          id: string
          source: string
          updated_at: string
          usage_count: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          english_term: string
          german_term: string
          id?: string
          source?: string
          updated_at?: string
          usage_count?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          english_term?: string
          german_term?: string
          id?: string
          source?: string
          updated_at?: string
          usage_count?: number
        }
        Relationships: []
      }
      umdns_codes: {
        Row: {
          code: string
          created_at: string | null
          definition: string | null
          emdn_mapping: string | null
          name: string
        }
        Insert: {
          code: string
          created_at?: string | null
          definition?: string | null
          emdn_mapping?: string | null
          name: string
        }
        Update: {
          code?: string
          created_at?: string | null
          definition?: string | null
          emdn_mapping?: string | null
          name?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_views: {
        Row: {
          created_at: string
          id: string
          user_id: string
          view: Database["public"]["Enums"]["clinical_view"]
        }
        Insert: {
          created_at?: string
          id?: string
          user_id: string
          view: Database["public"]["Enums"]["clinical_view"]
        }
        Update: {
          created_at?: string
          id?: string
          user_id?: string
          view?: Database["public"]["Enums"]["clinical_view"]
        }
        Relationships: []
      }
    }
    Views: {
      ai_usage_statistics: {
        Row: {
          avg_latency_ms: number | null
          day: string | null
          error_count: number | null
          model: string | null
          provider: string | null
          request_count: number | null
          source_type: string | null
          total_completion_tokens: number | null
          total_prompt_tokens: number | null
          total_tokens: number | null
        }
        Relationships: []
      }
      background_job_summary: {
        Row: {
          batch_id: string | null
          completed_count: number | null
          failed_count: number | null
          job_type: string | null
          pending_count: number | null
          running_count: number | null
          search_id: string | null
          total_count: number | null
        }
        Relationships: [
          {
            foreignKeyName: "background_jobs_search_id_fkey"
            columns: ["search_id"]
            isOneToOne: false
            referencedRelation: "knowledge_searches"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      find_circular_mappings: {
        Args: { max_depth?: number; start_code: string; start_system: string }
        Returns: {
          cycle_detected: boolean
          path: string[]
          path_length: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      increment_term_usage: { Args: { term_id: string }; Returns: undefined }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      search_guidelines: {
        Args: {
          filter_guideline_ids?: string[]
          match_count?: number
          match_threshold?: number
          query_embedding: string
        }
        Returns: {
          chunk_id: string
          content: string
          guideline_id: string
          guideline_title: string
          page_number: number
          section_title: string
          similarity: number
        }[]
      }
      validate_transitive_mappings: {
        Args: { p_limit?: number; p_source_system?: string }
        Returns: {
          conflict_type: string
          description: string
          mapping_id: string
          related_ids: string[]
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "user"
      clinical_view:
        | "hausarztpraxis"
        | "notaufnahme"
        | "telemedizin"
        | "fachambulanz"
        | "klinik"
      mapping_validation_status:
        | "pending"
        | "valid"
        | "conflict"
        | "exception"
        | "orphan"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
      clinical_view: [
        "hausarztpraxis",
        "notaufnahme",
        "telemedizin",
        "fachambulanz",
        "klinik",
      ],
      mapping_validation_status: [
        "pending",
        "valid",
        "conflict",
        "exception",
        "orphan",
      ],
    },
  },
} as const
